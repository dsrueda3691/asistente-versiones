import Foundation

/// Sesión de conversación manos libres: tras wake/hotkey (si está habilitado) o por frase,
/// Viernes se queda en «te escucho» y re-escucha tras cada respuesta TTS sin repetir el wake.
/// Honestidad: no es un chip MCU; es un bucle listen → handle → TTS → listen con timeout de silencio.
final class HandsFreeSession {
    static let defaultsKey = "viernes.handsFreeEnabled"
    /// ~25–30 s sin habla termina la sesión.
    static let silenceTimeout: TimeInterval = 28

    /// Frases normalizadas (sin acentos) que cierran la sesión sin salir de la app.
    static let endPhrases: [String] = [
        "adios", "corta", "modo normal", "deja de escuchar",
        "deja de oirme", "para de escuchar", "sal del modo manos libres",
        "modo manos libres off", "manos libres off", "termina sesion",
        "corta la sesion", "ya esta", "ya basta"
    ]

    static let startPhrases: [String] = [
        "modo manos libres", "quedate escuchando", "manos libres",
        "escuchame sin wake", "sesion manos libres", "activa manos libres"
    ]

    /// Preferencia del usuario. Default **ON** (Jarvis feel); wake word sigue default OFF.
    static var isPreferenceEnabled: Bool {
        get {
            if UserDefaults.standard.object(forKey: defaultsKey) == nil {
                return true
            }
            return UserDefaults.standard.bool(forKey: defaultsKey)
        }
        set { UserDefaults.standard.set(newValue, forKey: defaultsKey) }
    }

    private(set) var isActive = false
    /// Pausada por teclado / agente / confirmación pendiente (no cierra la sesión).
    private(set) var isPaused = false
    private var generation = 0

    var onEnded: ((String) -> Void)?

    func start(reason: String = "Manos libres ON") {
        isActive = true
        isPaused = false
        generation &+= 1
    }

    func end(spoken: String = "Modo normal. Di «Viernes» o usa el atajo cuando me necesites.") {
        guard isActive else { return }
        isActive = false
        isPaused = false
        generation &+= 1
        onEnded?(spoken)
    }

    func pause() {
        guard isActive else { return }
        isPaused = true
    }

    func resume() {
        guard isActive else { return }
        isPaused = false
    }

    /// Token para invalidar un listen pendiente al cerrar/pausar.
    var currentGeneration: Int { generation }

    static func isEndPhrase(_ normalized: String) -> Bool {
        let s = normalized.trimmingCharacters(in: .whitespacesAndNewlines)
        if endPhrases.contains(s) { return true }
        for p in endPhrases where s == p || s.hasPrefix(p + " ") || s.hasSuffix(" " + p) {
            return true
        }
        if s.contains("deja de escuchar") || s.contains("modo normal") { return true }
        if s == "corta" || s.hasPrefix("corta ") { return true }
        return false
    }

    static func isStartPhrase(_ normalized: String) -> Bool {
        let s = normalized.trimmingCharacters(in: .whitespacesAndNewlines)
        if startPhrases.contains(s) { return true }
        return startPhrases.contains(where: { s.contains($0) })
    }
}
