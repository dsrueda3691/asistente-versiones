import Foundation
import ServiceManagement

/// Abrir Viernes al iniciar sesión (macOS 13+ SMAppService / Login Items).
/// Default OFF. No es un daemon oculto: el usuario lo activa en Ajustes.
enum LoginItemManager {
    static let defaultsKey = "viernes.openAtLogin"

    static var isEnabledPreference: Bool {
        get { UserDefaults.standard.bool(forKey: defaultsKey) }
        set { UserDefaults.standard.set(newValue, forKey: defaultsKey) }
    }

    /// Estado real del Login Item según el sistema (puede diferir si el usuario lo cambió en Ajustes del Sistema).
    static var isRegistered: Bool {
        if #available(macOS 13.0, *) {
            return SMAppService.mainApp.status == .enabled
        }
        return isEnabledPreference
    }

    @discardableResult
    static func setOpenAtLogin(_ enabled: Bool) -> (ok: Bool, message: String) {
        isEnabledPreference = enabled
        if #available(macOS 13.0, *) {
            do {
                if enabled {
                    try SMAppService.mainApp.register()
                    return (true, "Viernes se abrirá al iniciar sesión.")
                } else {
                    try SMAppService.mainApp.unregister()
                    return (true, "Ya no se abrirá al iniciar sesión.")
                }
            } catch {
                let msg = "No pude cambiar el Login Item. Revisa Ajustes del Sistema → Generales → Elementos de inicio. (\(error.localizedDescription))"
                return (false, msg)
            }
        }
        return (false, "Login Items requiere macOS 13 o superior.")
    }
}
