import Foundation

/// Cliente OpenAI Chat Completions para `gpt-6-astra` (texto + visión multimodal).
/// API key solo desde Keychain. Nunca se loguea.
struct OpenAIClient: LLMBackend {
    static let modelDefaultsKey = "viernes.openaiModel"
    static let defaultModel = "gpt-6-astra"
    static let chatURL = URL(string: "https://api.openai.com/v1/chat/completions")!

    var timeout: TimeInterval = 60
    var visionTimeout: TimeInterval = 120

    var model: String {
        let stored = UserDefaults.standard.string(forKey: Self.modelDefaultsKey)?
            .trimmingCharacters(in: .whitespacesAndNewlines) ?? ""
        return stored.isEmpty ? Self.defaultModel : stored
    }

    static var configuredModelName: String {
        let stored = UserDefaults.standard.string(forKey: modelDefaultsKey)?
            .trimmingCharacters(in: .whitespacesAndNewlines) ?? ""
        return stored.isEmpty ? defaultModel : stored
    }

    var displayModelName: String { model }
    var displayVisionModelName: String { model }

    func chat(system: String, user: String) async throws -> String {
        try await complete(
            system: system,
            user: user,
            history: [],
            imageJPEG: nil,
            forceJSON: true,
            timeoutOverride: timeout
        )
    }

    func chat(system: String, history: [ChatMessage], user: String, forceJSON: Bool) async throws -> String {
        try await complete(
            system: system,
            user: user,
            history: history,
            imageJPEG: nil,
            forceJSON: forceJSON,
            timeoutOverride: timeout
        )
    }

    func plainChat(system: String, user: String) async throws -> String {
        try await complete(
            system: system,
            user: user,
            history: [],
            imageJPEG: nil,
            forceJSON: false,
            timeoutOverride: timeout
        )
    }

    func chatVision(system: String, user: String, imageJPEG: Data) async throws -> String {
        try await complete(
            system: system,
            user: user,
            history: [],
            imageJPEG: imageJPEG,
            forceJSON: false,
            timeoutOverride: visionTimeout
        )
    }

    private func complete(
        system: String,
        user: String,
        history: [ChatMessage],
        imageJPEG: Data?,
        forceJSON: Bool,
        timeoutOverride: TimeInterval
    ) async throws -> String {
        guard let apiKey = KeychainHelper.loadOpenAIKey() else {
            throw BrainBackendError.missingAPIKey
        }

        var request = URLRequest(url: Self.chatURL)
        request.httpMethod = "POST"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.setValue("Bearer \(apiKey)", forHTTPHeaderField: "Authorization")
        request.timeoutInterval = timeoutOverride

        let userContent: Any
        if let imageJPEG {
            let b64 = imageJPEG.base64EncodedString()
            userContent = [
                ["type": "text", "text": user],
                [
                    "type": "image_url",
                    "image_url": [
                        "url": "data:image/jpeg;base64,\(b64)"
                    ]
                ]
            ]
        } else {
            userContent = user
        }

        var messages: [[String: Any]] = [
            ["role": "system", "content": system]
        ]
        for h in history {
            let role = (h.role == "assistant") ? "assistant" : "user"
            messages.append(["role": role, "content": h.content])
        }
        messages.append(["role": "user", "content": userContent])

        var body: [String: Any] = [
            "model": model,
            "messages": messages,
            "temperature": imageJPEG == nil ? 0.4 : 0.2
        ]
        if forceJSON {
            body["response_format"] = ["type": "json_object"]
        }

        request.httpBody = try JSONSerialization.data(withJSONObject: body)

        let data: Data
        let response: URLResponse
        do {
            (data, response) = try await URLSession.shared.data(for: request)
        } catch {
            throw BrainBackendError.network
        }

        if let http = response as? HTTPURLResponse {
            switch http.statusCode {
            case 200...299:
                break
            case 401:
                throw BrainBackendError.unauthorized
            case 429:
                throw BrainBackendError.rateLimited
            default:
                throw BrainBackendError.badStatus(http.statusCode)
            }
        }

        guard let json = try? JSONSerialization.jsonObject(with: data) as? [String: Any] else {
            throw BrainBackendError.decodeFailed
        }

        if let choices = json["choices"] as? [[String: Any]],
           let first = choices.first,
           let message = first["message"] as? [String: Any] {
            if let content = message["content"] as? String {
                let trimmed = content.trimmingCharacters(in: .whitespacesAndNewlines)
                if trimmed.isEmpty { throw BrainBackendError.emptyResponse }
                return trimmed
            }
            // Algunos modelos multimodal pueden devolver content como array de partes.
            if let parts = message["content"] as? [[String: Any]] {
                let text = parts.compactMap { $0["text"] as? String }.joined(separator: "\n")
                    .trimmingCharacters(in: .whitespacesAndNewlines)
                if text.isEmpty { throw BrainBackendError.emptyResponse }
                return text
            }
        }

        throw BrainBackendError.emptyResponse
    }
}
