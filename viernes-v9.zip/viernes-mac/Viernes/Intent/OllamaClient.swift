import Foundation

/// Contrato legacy para un LLM local (Ollama en localhost).
protocol LocalLLMClient {
    func complete(prompt: String) async throws -> String
    func chat(system: String, user: String) async throws -> String
}

enum OllamaError: Error, LocalizedError {
    case unreachable
    case emptyResponse
    case badStatus(Int)
    case decodeFailed

    var errorDescription: String? {
        switch self {
        case .unreachable:
            return "Ollama no está corriendo en localhost."
        case .emptyResponse:
            return "Ollama devolvió una respuesta vacía."
        case .badStatus(let code):
            return "Ollama respondió con código \(code)."
        case .decodeFailed:
            return "No pude leer la respuesta de Ollama."
        }
    }

    var asBrainError: BrainBackendError {
        switch self {
        case .unreachable: return .unreachableLocal
        case .emptyResponse: return .emptyResponse
        case .badStatus(let code): return .badStatus(code)
        case .decodeFailed: return .decodeFailed
        }
    }
}

/// Cliente real contra http://127.0.0.1:11434/api/chat.
/// Texto: UserDefaults `viernes.ollamaModel` → `llama3.2`
/// Visión: UserDefaults `viernes.ollamaVisionModel` → `llava`
struct OllamaClient: LocalLLMClient, LLMBackend {
    static let modelDefaultsKey = "viernes.ollamaModel"
    static let visionModelDefaultsKey = "viernes.ollamaVisionModel"
    static let defaultModel = "llama3.2"
    static let defaultVisionModel = "llava"

    var baseURL = URL(string: "http://127.0.0.1:11434")!
    var timeout: TimeInterval = 45
    var visionTimeout: TimeInterval = 90

    var model: String {
        let stored = UserDefaults.standard.string(forKey: Self.modelDefaultsKey)?
            .trimmingCharacters(in: .whitespacesAndNewlines) ?? ""
        return stored.isEmpty ? Self.defaultModel : stored
    }

    var visionModel: String {
        let stored = UserDefaults.standard.string(forKey: Self.visionModelDefaultsKey)?
            .trimmingCharacters(in: .whitespacesAndNewlines) ?? ""
        return stored.isEmpty ? Self.defaultVisionModel : stored
    }

    var displayModelName: String { model }
    var displayVisionModelName: String { visionModel }

    static var configuredModelName: String {
        let stored = UserDefaults.standard.string(forKey: modelDefaultsKey)?
            .trimmingCharacters(in: .whitespacesAndNewlines) ?? ""
        return stored.isEmpty ? defaultModel : stored
    }

    static var configuredVisionModelName: String {
        let stored = UserDefaults.standard.string(forKey: visionModelDefaultsKey)?
            .trimmingCharacters(in: .whitespacesAndNewlines) ?? ""
        return stored.isEmpty ? defaultVisionModel : stored
    }

    func complete(prompt: String) async throws -> String {
        try await chat(system: "Eres un asistente útil. Responde en español, breve.", user: prompt)
    }

    func chat(system: String, user: String) async throws -> String {
        try await chat(
            system: system,
            user: user,
            history: [],
            imagesBase64: nil,
            modelOverride: nil,
            timeoutOverride: nil,
            forceJSON: true
        )
    }

    func chat(system: String, history: [ChatMessage], user: String, forceJSON: Bool) async throws -> String {
        try await chat(
            system: system,
            user: user,
            history: history,
            imagesBase64: nil,
            modelOverride: nil,
            timeoutOverride: history.isEmpty ? nil : 75,
            forceJSON: forceJSON
        )
    }

    /// Texto libre (sin forzar JSON). Útil para generar contenido a tipear.
    func plainChat(system: String, user: String, timeout: TimeInterval = 90) async throws -> String {
        try await chat(
            system: system,
            user: user,
            history: [],
            imagesBase64: nil,
            modelOverride: nil,
            timeoutOverride: timeout,
            forceJSON: false
        )
    }

    func plainChat(system: String, history: [ChatMessage], user: String) async throws -> String {
        try await chat(
            system: system,
            user: user,
            history: history,
            imagesBase64: nil,
            modelOverride: nil,
            timeoutOverride: 90,
            forceJSON: false
        )
    }

    func plainChat(system: String, user: String) async throws -> String {
        try await plainChat(system: system, user: user, timeout: 90)
    }

    /// Chat multimodal: imágenes en base64 (JPEG/PNG) en el mensaje de usuario (formato Ollama).
    func chatVision(system: String, user: String, imageJPEG: Data) async throws -> String {
        let b64 = imageJPEG.base64EncodedString()
        return try await chat(
            system: system,
            user: user,
            history: [],
            imagesBase64: [b64],
            modelOverride: visionModel,
            timeoutOverride: visionTimeout,
            forceJSON: false
        )
    }

    private func chat(
        system: String,
        user: String,
        history: [ChatMessage],
        imagesBase64: [String]?,
        modelOverride: String?,
        timeoutOverride: TimeInterval?,
        forceJSON: Bool
    ) async throws -> String {
        do {
            return try await chatAPI(
                system: system,
                user: user,
                history: history,
                imagesBase64: imagesBase64,
                modelOverride: modelOverride,
                timeoutOverride: timeoutOverride,
                forceJSON: forceJSON
            )
        } catch let err as OllamaError {
            // Fallback a /api/generate solo si chat falla y no hay visión.
            if imagesBase64 == nil, case .badStatus = err {
                return try await generateAPI(
                    system: system,
                    user: user,
                    history: history,
                    modelOverride: modelOverride,
                    timeoutOverride: timeoutOverride,
                    forceJSON: forceJSON
                )
            }
            if imagesBase64 == nil, case .decodeFailed = err {
                return try await generateAPI(
                    system: system,
                    user: user,
                    history: history,
                    modelOverride: modelOverride,
                    timeoutOverride: timeoutOverride,
                    forceJSON: forceJSON
                )
            }
            throw err
        }
    }

    private func chatAPI(
        system: String,
        user: String,
        history: [ChatMessage],
        imagesBase64: [String]?,
        modelOverride: String?,
        timeoutOverride: TimeInterval?,
        forceJSON: Bool
    ) async throws -> String {
        let url = baseURL.appendingPathComponent("api/chat")
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.timeoutInterval = timeoutOverride ?? timeout

        var messages: [[String: Any]] = [
            ["role": "system", "content": system]
        ]
        for h in history {
            let role = (h.role == "assistant") ? "assistant" : "user"
            messages.append(["role": role, "content": h.content])
        }
        var userMessage: [String: Any] = [
            "role": "user",
            "content": user
        ]
        if let imagesBase64, !imagesBase64.isEmpty {
            userMessage["images"] = imagesBase64
        }
        messages.append(userMessage)

        var body: [String: Any] = [
            "model": modelOverride ?? model,
            "stream": false,
            "messages": messages,
            "options": [
                "temperature": imagesBase64 == nil ? 0.4 : 0.2
            ]
        ]
        if forceJSON {
            body["format"] = "json"
        }

        request.httpBody = try JSONSerialization.data(withJSONObject: body)
        return try await perform(request: request)
    }

    /// Fallback /api/generate con prompt concatenado (historial incluido).
    private func generateAPI(
        system: String,
        user: String,
        history: [ChatMessage],
        modelOverride: String?,
        timeoutOverride: TimeInterval?,
        forceJSON: Bool
    ) async throws -> String {
        let url = baseURL.appendingPathComponent("api/generate")
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.timeoutInterval = timeoutOverride ?? timeout

        var prompt = system + "\n\n"
        for h in history {
            let label = h.role == "assistant" ? "Asistente" : "Usuario"
            prompt += "\(label): \(h.content)\n"
        }
        prompt += "Usuario: \(user)\nAsistente:"

        var body: [String: Any] = [
            "model": modelOverride ?? model,
            "stream": false,
            "prompt": prompt,
            "options": ["temperature": 0.4]
        ]
        if forceJSON {
            body["format"] = "json"
        }
        request.httpBody = try JSONSerialization.data(withJSONObject: body)
        return try await perform(request: request)
    }

    private func perform(request: URLRequest) async throws -> String {
        let data: Data
        let response: URLResponse
        do {
            (data, response) = try await URLSession.shared.data(for: request)
        } catch {
            throw OllamaError.unreachable
        }

        if let http = response as? HTTPURLResponse, !(200...299).contains(http.statusCode) {
            if http.statusCode == 404 {
                throw OllamaError.unreachable
            }
            throw OllamaError.badStatus(http.statusCode)
        }

        guard let json = try? JSONSerialization.jsonObject(with: data) as? [String: Any] else {
            throw OllamaError.decodeFailed
        }

        if let message = json["message"] as? [String: Any],
           let content = message["content"] as? String {
            let trimmed = content.trimmingCharacters(in: .whitespacesAndNewlines)
            if trimmed.isEmpty { throw OllamaError.emptyResponse }
            return trimmed
        }

        if let content = json["response"] as? String {
            let trimmed = content.trimmingCharacters(in: .whitespacesAndNewlines)
            if trimmed.isEmpty { throw OllamaError.emptyResponse }
            return trimmed
        }

        throw OllamaError.emptyResponse
    }
}
