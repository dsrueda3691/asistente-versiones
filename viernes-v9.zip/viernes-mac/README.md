# Viernes (V9)

Asistente de barra de menús para macOS. Habla en español, te escucha (hotkey, icono o **wake word opcional**), responde con voz y **recuerda la conversación en disco**. Inspirado en Friday / Jarvis: seco, breve, competente — **sin pretender ser una película**.

**V9** = V8 (wake opcional, memoria persistente, export, DocumentReader, Brain, openApp) **+** sesión **manos libres** **+** audio/video → Whisper local **+** agente hasta **5** pasos **+** Login Item **+** línea de presencia real.

Viernes es una herramienta personal. **No está pensada para el App Store**: el sandbox está desactivado. Marketing version **9.0**.

## Jarvis de verdad vs mito MCU

| Objetivo realista (V9) | Lo que **no** es |
| --- | --- |
| Conversación manos libres tras wake/hotkey | Hologramas / HUD Iron Man cubriendo el escritorio |
| Audio → Whisper local → resumen con el Brain | Visión frame-a-frame de video a 60 fps |
| Agente corto (hasta 5 pasos, con confirmación) | Autonomía total sin preguntarte |
| Estado real (batería, mute, wake, app frontal) | Métricas inventadas de “sistemas Stark” |
| Login Item opcional | Daemon oculto siempre-en-cámara |

En un MacBook Air de estudiante: **ambicioso pero honesto**.

## Qué cambió en V9

### 1. Manos libres (el feeling Jarvis)
- Tras **wake** o **hotkey/icono** (si la preferencia está ON), entra `HandsFreeSession`.
- Tras cada respuesta (cuando termina el TTS), **vuelve a escuchar** sin repetir «Viernes».
- Termina con: «adiós», «corta», «modo normal», «deja de escuchar», **silencio ~28 s**, o el botón **Manos libres ON** del HUD.
- UserDefaults `viernes.handsFreeEnabled` — **default ON**.
- También: «modo manos libres» / «quédate escuchando».
- Se **pausa** durante trabajo de teclado, agente o confirmaciones pendientes; se reanuda después.
- HUD: «Manos libres ON» · punto cyan/naranja.

### 2. Audio / video local (Whisper)
Frases: «transcribe esto», «qué dice el audio», «explícame el video», «resume el video».

1. Resuelve el archivo (QuickTime / IINA / VLC / Finder, o nombre en Escritorio/Descargas).
2. Extrae audio (`ffmpeg` / `afconvert` / AVFoundation), **máx. ~4 min** (excerpt).
3. Transcribe con lo que haya en PATH:
   - `whisper` (openai-whisper)
   - `whisper-cli` / whisper.cpp (+ modelo ggml si hace falta)
   - `ollama` con un modelo cuyo nombre contenga `whisper` (si está en `ollama list`)
4. Pasa el texto al Brain (con memoria) para resumir/explicar.
5. Si **no** hay Whisper: pista hablada de instalación (`brew install whisper-cpp` / `pip install openai-whisper`). **No inventa** el contenido.

Honestidad: **nunca** afirma ver el video cuadro a cuadro; el camino es audio → texto → LLM.

### 3. Agente más capaz
- Hasta **5** pasos (sigue pidiendo Confirmar).
- Pasos: `analyze`, `type`, `openApp`, `webSearch`, `readClipboard`, `copyDraft` / `saveDraft`, `openURL` (solo http/https).
- Progreso hablado: «Paso 2 de 4…».
- Sigue prohibido: borrar, shell, enviar correo dentro del agente, clics ciegos en contraseñas.

### 4. Abrir al iniciar sesión
- Toggle en Ajustes: «Abrir Viernes al iniciar sesión» (`SMAppService` / Login Items, macOS 13+; target 14+).
- UserDefaults `viernes.openAtLogin` — **default OFF**.

### 5. Presencia / estado
- Al lanzar (una vez, si no mute): «Viernes en línea. Sistemas listos.»
- HUD idle: «Listo · Safari» (app frontal real).
- «estado del sistema» / «cómo estás»: batería %, mute, wake, manos libres, cerebro — datos locales reales.

## Se mantiene de V8 (y antes)

Wake toggle (default **OFF**), memoria persistente, draft export, DocumentReader, Brain con historial, open apps por nombre, Mail/Calendar/Reminders con confirmación, Notes, screen vision, keyboard jobs, Local/Astra/Auto, Keychain, hotkey, mute, safety (no delete, no shell, no blind mail, no keylogging).

## Requisitos

- macOS 14+, Xcode, micrófono.
- Opcional: Ollama, API key OpenAI (Astra), Whisper local para media, ffmpeg.

## Cómo usarlo

1. Abre `Viernes.xcodeproj` en Xcode → Run.
2. ✦ / ⌃⌥⌘V / wake «Viernes» → (si HF ON) sesión manos libres.
3. Habla o escribe. Local / Astra / Auto.

### Frases → intent (V9)

| Frase ejemplo | Intent |
| --- | --- |
| «modo manos libres» / «quédate escuchando» | `handsFreeStart` |
| «adiós» / «corta» / «modo normal» / «deja de escuchar» (en sesión) | fin manos libres (no sale de la app) |
| «transcribe esto» / «qué dice el audio» / «resume el video» | `understandMedia` |
| «estado del sistema» / «cómo estás» | `systemStatus` |
| «Viernes» (wake ON) | wake → manos libres si preferencia ON → comando |
| «olvida» / «nueva conversación» | `resetMemory` |
| «copia el borrador» / «guárdalo» / «pégalo» | export* |
| «lee el README» / «explica este PDF» | `readDocument` |
| «abre Xcode» | `openApp` |
| «haz esto en pantalla» / «agente: …» | `agentMode` (plan ≤5 + confirma) |
| «mira la pantalla» / «usa el teclado…» | screen / keyboard |
| correo / evento / recordatorio / nota | con confirmación donde aplica |

## Whisper: detección

Orden: `whisper-cli` / binarios whisper.cpp → `whisper` CLI → `ollama list` con modelo `*whisper*`. Rutas: `PATH`, `/opt/homebrew/bin`, `/usr/local/bin`. Modelos ggml buscados en `~/models`, share de Homebrew. Sin herramienta = mensaje de instalación, sin fake.

## Proveedor

| Modo | Comportamiento | Costo |
| --- | --- | --- |
| **Local** | Ollama localhost | Gratis (tu Mac) |
| **Astra** | OpenAI | Según tu API key |
| **Auto** | Astra si hay clave; si no, Ollama | Mixto |

## API key (Keychain)

```bash
security add-generic-password -a openai_api_key -s com.danielrueda.Viernes -w 'sk-...' -U
```

## Estructura

```
viernes-mac/
  Viernes.xcodeproj
  README.md
  Viernes/
    Speech/HandsFreeSession.swift, WakeWordMonitor.swift, Listener, Speaker
    IO/MediaUnderstander.swift, DocumentReader.swift
    System/SystemPresence.swift
    Intent/… AgentMode (5 pasos), LoginItemManager, Brain, …
    Memory/ConversationMemory.swift
    UI/PopoverView.swift
```

## Seguridad

- No correo sin **Enviar** en el popover.
- No borra archivos. No shell arbitrario. No keylogging.
- Wake default **OFF**. Manos libres preferencia default ON (no es mic 24/7 por sí solo; el mic se usa en ráfagas de escucha).
- openURL del agente: solo http/https.
- Memoria solo en Application Support local.

## Límites honestos

- No MCU holograms / Iron Man HUD.
- No cámara siempre-on ni grabación continua de pantalla.
- Whisper es opcional y local; sin él, no “entiende” video.
- Wake con Speech de Apple: batería + posibles falsos positivos.
- No se afirma compilación en este entorno Linux; abre el proyecto en un Mac con Xcode.
