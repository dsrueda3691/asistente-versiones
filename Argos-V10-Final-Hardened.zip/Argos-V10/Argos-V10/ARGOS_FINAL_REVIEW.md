# Argos V10 — revisión final de esta entrega

## Corregido directamente sobre Argos-V10-Final

1. Compilación: corregida la ruta de `auxiliaryTopLeftArea` / `auxiliaryTopRightArea` opcionales.
2. Compacto: el panel ya no tiene el ancho del hueco físico del notch; usa un frame compacto propio centrado sobre el notch.
3. Expandido: se posiciona debajo del área reservada del notch y no usa animación de resize del `NSPanel`.
4. Preferencias: migración desde `persistentDomain` de los dominios anteriores.
5. Keychain: conserva la API key de `com.danielrueda.Viernes`.
6. Hotkey: migración desde el dominio anterior.
7. Ventanas: Accessibility sube al `kAXWindowAttribute` para obtener el título de ventana.
8. Contexto: archivos/ventanas pasan como contexto adicional a las rutas de documento, media, visión y agente.
9. Drag & drop: los adjuntos no se marcan como «tarea completada»; quedan como contexto preparado.
10. Estado visual: `ArgosRuntimeState.activity` es la única fuente de verdad para el personaje y la cabecera.
11. Personaje: siete estados diferenciados y animación de humo, filos de luz, ceño, gema y éxito.
12. Aprobación: riesgo, plan/cola, detalle y confirmación explícita.
13. Primer arranque: ventana de permisos.
14. Integraciones externas: hub de accesos sin fingir autenticación API.
15. Proyecto: versión 10.0, bundle `com.danielrueda.Argos`.

## Validación disponible en este entorno

- Todos los `.swift` pasan `swiftc -parse`.
- El `.xcodeproj` contiene las nuevas referencias y fuentes.
- No se pudo ejecutar `xcodebuild` porque este entorno no dispone de macOS/Xcode.

Por tanto, el siguiente chequeo real debe hacerse en Xcode sobre un Mac. No se afirma aquí que el binario haya sido construido en este entorno.

## Integraciones externas

Gmail, Outlook, GitHub y WhatsApp aparecen como accesos del producto, pero no se marca una cuenta como autenticada automáticamente. Las conexiones API/OAuth reales dependen de credenciales y configuración de desarrollador del usuario/servicio.

## Hardening verification — 2026-10-03

- Swift syntax parse: **36/36 Swift files passed `swiftc -parse`** in this environment.
- Xcode project: `IntegrationServices.swift` and `AuthenticationServices.framework` are registered.
- Bundle ID remains `com.danielrueda.Argos`; marketing version remains `10.0`.
- The actual macOS/Xcode build, OAuth provider registration, signing, notarization and notch-device validation still require a Mac with Xcode and the relevant developer accounts.
- Integration behavior is intentionally explicit: Gmail/Outlook/GitHub use OAuth, WhatsApp uses Business Cloud API credentials; Argos does not claim access to a personal WhatsApp Web session.
