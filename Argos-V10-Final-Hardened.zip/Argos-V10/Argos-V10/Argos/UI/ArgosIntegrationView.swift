import SwiftUI
import AppKit

struct ArgosIntegrationView: View {
    @State private var gmailClientID = UserDefaults.standard.string(forKey: GmailIntegration.clientIDKey) ?? ""
    @State private var outlookClientID = UserDefaults.standard.string(forKey: OutlookIntegration.clientIDKey) ?? ""
    @State private var outlookTenant = UserDefaults.standard.string(forKey: OutlookIntegration.tenantKey) ?? "common"
    @State private var githubClientID = UserDefaults.standard.string(forKey: GitHubIntegration.clientIDKey) ?? ""
    @State private var whatsappPhoneID = UserDefaults.standard.string(forKey: WhatsAppIntegration.phoneNumberIDKey) ?? ""
    @State private var whatsappGraphVersion = UserDefaults.standard.string(forKey: WhatsAppIntegration.graphVersionKey) ?? "v23.0"
    @State private var whatsappToken = ""
    @State private var message = ""

    var body: some View {
        VStack(alignment: .leading, spacing: 18) {
            Text("Integraciones reales")
                .font(.title3.weight(.semibold))
            Text("Las cuentas se conectan mediante OAuth cuando el proveedor lo permite. Los tokens se guardan en el Llavero de macOS; los Client ID son configuración pública. Las acciones que envían mensajes pasan primero por aprobación en el notch.")
                .font(.callout)
                .foregroundStyle(.secondary)
                .fixedSize(horizontal: false, vertical: true)

            integrationCard(
                title: "Gmail",
                symbol: "envelope.fill",
                connected: GmailIntegration.connected,
                description: "Leer bandeja y enviar correo mediante Gmail API.",
                fields: {
                    TextField("Google OAuth Client ID", text: $gmailClientID)
                        .textFieldStyle(.roundedBorder)
                },
                actions: {
                    Button(GmailIntegration.connected ? "Reconectar" : "Conectar") {
                        UserDefaults.standard.set(gmailClientID.trimmingCharacters(in: .whitespacesAndNewlines), forKey: GmailIntegration.clientIDKey)
                        Task { await connectGmail() }
                    }
                }
            )

            integrationCard(
                title: "Outlook / Microsoft 365",
                symbol: "envelope.badge.person.crop",
                connected: OutlookIntegration.connected,
                description: "Leer bandeja y enviar correo mediante Microsoft Graph.",
                fields: {
                    TextField("Microsoft Entra Client ID", text: $outlookClientID)
                        .textFieldStyle(.roundedBorder)
                    TextField("Tenant", text: $outlookTenant)
                        .textFieldStyle(.roundedBorder)
                },
                actions: {
                    Button(OutlookIntegration.connected ? "Reconectar" : "Conectar") {
                        UserDefaults.standard.set(outlookClientID.trimmingCharacters(in: .whitespacesAndNewlines), forKey: OutlookIntegration.clientIDKey)
                        UserDefaults.standard.set(outlookTenant.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty ? "common" : outlookTenant.trimmingCharacters(in: .whitespacesAndNewlines), forKey: OutlookIntegration.tenantKey)
                        Task { await connectOutlook() }
                    }
                }
            )

            integrationCard(
                title: "GitHub",
                symbol: "chevron.left.forwardslash.chevron.right",
                connected: GitHubIntegration.connected,
                description: "Consultar tus PR abiertos y preparar acciones futuras con permisos explícitos.",
                fields: {
                    TextField("GitHub App / OAuth Client ID", text: $githubClientID)
                        .textFieldStyle(.roundedBorder)
                },
                actions: {
                    Button(GitHubIntegration.connected ? "Reconectar" : "Conectar") {
                        UserDefaults.standard.set(githubClientID.trimmingCharacters(in: .whitespacesAndNewlines), forKey: GitHubIntegration.clientIDKey)
                        Task { await connectGitHub() }
                    }
                }
            )

            integrationCard(
                title: "WhatsApp Business Cloud API",
                symbol: "message.fill",
                connected: WhatsAppIntegration.configured,
                description: "Enviar mensajes mediante la Cloud API de WhatsApp Business. No usa WhatsApp Web ni automatiza una cuenta personal.",
                fields: {
                    TextField("Phone Number ID", text: $whatsappPhoneID)
                        .textFieldStyle(.roundedBorder)
                    TextField("Graph API version", text: $whatsappGraphVersion)
                        .textFieldStyle(.roundedBorder)
                    SecureField("Access Token (se guarda en Llavero)", text: $whatsappToken)
                        .textFieldStyle(.roundedBorder)
                },
                actions: {
                    Button("Guardar configuración") {
                        UserDefaults.standard.set(whatsappPhoneID.trimmingCharacters(in: .whitespacesAndNewlines), forKey: WhatsAppIntegration.phoneNumberIDKey)
                        UserDefaults.standard.set(whatsappGraphVersion.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty ? "v23.0" : whatsappGraphVersion.trimmingCharacters(in: .whitespacesAndNewlines), forKey: WhatsAppIntegration.graphVersionKey)
                        WhatsAppIntegration.saveAccessToken(whatsappToken)
                        whatsappToken = ""
                        message = "WhatsApp configurado."
                    }
                }
            )

            if !message.isEmpty {
                Label(message, systemImage: "checkmark.circle.fill")
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }

            Text("Configuración externa necesaria")
                .font(.headline)
            Text("Gmail requiere un OAuth Client de tipo Desktop y permisos de Gmail API. Microsoft requiere registrar Argos como aplicación nativa y habilitar Mail.Read/Mail.Send. GitHub usa autorización de dispositivo. WhatsApp requiere una cuenta de WhatsApp Business Cloud API, Phone Number ID y token.")
                .font(.caption)
                .foregroundStyle(.secondary)
                .fixedSize(horizontal: false, vertical: true)
        }
        .onAppear {
            reload()
        }
    }

    @ViewBuilder
    private func integrationCard<Fields: View, Actions: View>(
        title: String,
        symbol: String,
        connected: Bool,
        description: String,
        @ViewBuilder fields: () -> Fields,
        @ViewBuilder actions: () -> Actions
    ) -> some View {
        VStack(alignment: .leading, spacing: 9) {
            HStack(spacing: 10) {
                Image(systemName: symbol).frame(width: 24).foregroundStyle(.purple)
                Text(title).font(.headline)
                Spacer()
                Label(connected ? "Conectado" : "No conectado", systemImage: connected ? "checkmark.circle.fill" : "circle")
                    .font(.caption)
                    .foregroundStyle(connected ? .green : .secondary)
            }
            Text(description).font(.caption).foregroundStyle(.secondary)
            fields()
            HStack { Spacer(); actions() }
        }
        .padding(12)
        .background(.quaternary.opacity(0.35), in: RoundedRectangle(cornerRadius: 14))
    }

    private func reload() {
        gmailClientID = UserDefaults.standard.string(forKey: GmailIntegration.clientIDKey) ?? ""
        outlookClientID = UserDefaults.standard.string(forKey: OutlookIntegration.clientIDKey) ?? ""
        outlookTenant = UserDefaults.standard.string(forKey: OutlookIntegration.tenantKey) ?? "common"
        githubClientID = UserDefaults.standard.string(forKey: GitHubIntegration.clientIDKey) ?? ""
        whatsappPhoneID = UserDefaults.standard.string(forKey: WhatsAppIntegration.phoneNumberIDKey) ?? ""
        whatsappGraphVersion = UserDefaults.standard.string(forKey: WhatsAppIntegration.graphVersionKey) ?? "v23.0"
    }

    private func connectGmail() async {
        do { try await GmailIntegration.connect(); message = "Gmail conectado." }
        catch { message = "Gmail: \(error.localizedDescription)" }
    }

    private func connectOutlook() async {
        do { try await OutlookIntegration.connect(); message = "Outlook conectado." }
        catch { message = "Outlook: \(error.localizedDescription)" }
    }

    private func connectGitHub() async {
        do { try await GitHubIntegration.connect(); message = "GitHub conectado." }
        catch { message = "GitHub: \(error.localizedDescription)" }
    }
}
