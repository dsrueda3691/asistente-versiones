# Argos V10 — revisión de producto

## Correcciones
- `NSPanel` compacto con geometría segura para Macs con y sin notch.
- `auxiliaryTopLeftArea` / `auxiliaryTopRightArea` ahora se desenvuelven correctamente.
- El modo expandido se posiciona debajo del área reservada del notch y no anima el frame del panel.
- La UI usa `ArgosRuntimeState.activity` como única fuente de verdad visual.
- Éxito, error y cancelación siguen siendo resultados distintos.
- Arrastrar Argos sobre una ventana asciende al `kAXWindowAttribute` para obtener el título real.
- Se solicita Accesibilidad cuando la función lo necesita.
- Se mantiene el monitor local durante el drag para no depender de eventos globales de la propia app.
- Los adjuntos ya pueden alimentar rutas de documento, media, visión y agente como contexto textual adicional.
- Soltar un archivo ya no se representa como «tarea completada»; queda como contexto listo para la siguiente acción.
- Los adjuntos pueden eliminarse individualmente.
- Migración real desde el persistent domain de `com.danielrueda.Viernes` / `Viernes`.
- Migración de API key antigua del Keychain y hotkey antiguo.
- Pantalla de primeros pasos para permisos.
- Hub de accesos para Gmail, Outlook, GitHub y WhatsApp sin almacenar credenciales externas.
- Personaje Argos con humo, filos de luz, ceño, gema, estados diferenciados y animación continua.
- Eliminadas referencias visibles de «V9» y «popover».

## Nota sobre integraciones externas
Gmail, Outlook, GitHub y WhatsApp tienen accesos de servicio en la UI, pero las integraciones API autenticadas no se pueden considerar «conectadas» sin credenciales/configuración del usuario o de una aplicación OAuth. Argos no inventa una conexión ni guarda secretos externos por defecto.
