import Foundation
import AppKit

enum AgentModeError: Error, LocalizedError {
    case emptyGoal
    case planFailed(String)
    case cancelled
    case stepFailed(String)
    case timedOut

    var errorDescription: String? { userMessage }
    var userMessage: String {
        switch self {
        case .emptyGoal: return "¿Qué quieres que haga en pantalla?"
        case .planFailed(let m): return "No pude armar el plan. \(m)"
        case .cancelled: return "Agente detenido."
        case .stepFailed(let m): return m
        case .timedOut: return "Se agotó el tiempo del agente (~3 min)."
        }
    }
}

/// Modo agente corto: captura → plan hasta 5 pasos seguros → confirmación → ejecución.
@MainActor
final class AgentMode {
    static let maxSteps = 5
    static let timeCapSeconds: TimeInterval = 180

    private let brain: Brain
    private(set) var isRunning = false
    private var cancelled = false
    var onProgress: ((String) -> Void)?
    /// Acceso al lastDraft para copy/save seguros.
    var draftProvider: (() -> String?)?

    init(brain: Brain) {
        self.brain = brain
    }

    func cancel() {
        cancelled = true
        isRunning = false
    }

    func plan(goal: String, imageJPEG: Data) async throws -> PendingAgentPlan {
        let trimmed = goal.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmed.isEmpty else { throw AgentModeError.emptyGoal }

        let system = """
        Eres Argos planificando un agente CORTO y seguro en macOS.
        Dado el objetivo y UNA captura de pantalla, responde SOLO JSON:
        {"steps":[{"kind":"analyze|type|openApp|webSearch|readClipboard|copyDraft|saveDraft|openURL","detail":"..."}]}
        Reglas:
        - Máximo \(Self.maxSteps) pasos.
        - analyze: mirar/describir (detail = pregunta).
        - type: texto a escribir/pegar (detail = texto o instrucción corta).
        - openApp: app por nombre (detail = Safari, Finder, Notas, Mail, Calendario, Terminal, Ajustes, Xcode, Cursor…).
        - webSearch: búsqueda web (detail = query).
        - readClipboard: leer portapapeles (detail puede ser vacío o "clipboard").
        - copyDraft / saveDraft: solo si hay borrador de conversación; saveDraft detail = nombre archivo opcional.
        - openURL: SOLO http:// o https:// (detail = URL completa). Prohibido file:, javascript:, etc.
        - PROHIBIDO: borrar, shell, enviar correo, crear eventos/recordatorios, clics en campos de contraseña, descargas masivas.
        - Si no hace falta acción, un solo paso analyze.
        """
        let user = "Objetivo del usuario:\n\(trimmed)\n\nDevuelve el plan JSON (máx. \(Self.maxSteps) pasos)."

        do {
            let raw = try await brain.generatePlainText(system: system, user: user)
            let steps = Self.parseSteps(from: raw)
            guard !steps.isEmpty else {
                throw AgentModeError.planFailed("El modelo no devolvió pasos útiles.")
            }
            let limited = Array(steps.prefix(Self.maxSteps))
            return PendingAgentPlan(
                goal: trimmed,
                steps: limited,
                screenJPEGBase64: imageJPEG.base64EncodedString()
            )
        } catch let err as BrainBackendError {
            throw AgentModeError.planFailed(err.userMessage)
        } catch let err as AgentModeError {
            throw err
        } catch {
            throw AgentModeError.planFailed(error.localizedDescription)
        }
    }

    func execute(
        plan: PendingAgentPlan,
        keyboard: KeyboardController,
        analyze: @escaping (String, Data) async -> String
    ) async -> (spoken: String, detail: String) {
        cancelled = false
        isRunning = true
        defer { isRunning = false }
        let started = Date()
        var log: [String] = []
        var jpegData: Data?
        if let b64 = plan.screenJPEGBase64 {
            jpegData = Data(base64Encoded: b64)
        }
        let total = plan.steps.count

        for step in plan.steps {
            if cancelled { return (AgentModeError.cancelled.userMessage, log.joined(separator: "\n")) }
            if Date().timeIntervalSince(started) > Self.timeCapSeconds {
                return (AgentModeError.timedOut.userMessage, log.joined(separator: "\n"))
            }
            onProgress?("Paso \(step.id) de \(total)…")
            switch step.kind {
            case .analyze:
                if let jpeg = jpegData {
                    let reply = await analyze(step.detail, jpeg)
                    log.append("✓ \(step.line)\n  → \(reply)")
                } else {
                    log.append("⚠ \(step.line) (sin captura)")
                }
            case .type:
                do {
                    let result = try await keyboard.runJob(instruction: step.detail) { [brain] instr in
                        if instr.count < 400 && !instr.lowercased().contains("escribe") {
                            return instr
                        }
                        let system = "Eres Argos. Generas SOLO el texto a pegar. Sin markdown ni explicaciones."
                        return try await brain.generatePlainText(system: system, user: instr)
                    }
                    log.append("✓ \(step.line)\n  → \(result.spoken)")
                } catch {
                    let msg = (error as? KeyboardError)?.userMessage ?? "Falló escribir."
                    log.append("✗ \(step.line)\n  → \(msg)")
                    return ("Paso de teclado falló: \(msg)", log.joined(separator: "\n"))
                }
            case .openApp:
                let name = step.detail.trimmingCharacters(in: .whitespacesAndNewlines)
                let config = NSWorkspace.OpenConfiguration()
                config.activates = true
                var opened = false
                if let bundle = Self.bundleID(for: name),
                   let url = NSWorkspace.shared.urlForApplication(withBundleIdentifier: bundle) {
                    NSWorkspace.shared.openApplication(at: url, configuration: config) { _, _ in }
                    opened = true
                } else if let url = ActionRunner.urlForApp(named: name) {
                    NSWorkspace.shared.openApplication(at: url, configuration: config) { _, _ in }
                    opened = true
                }
                log.append(opened ? "✓ \(step.line)" : "✗ No encontré \(name)")
            case .webSearch:
                let q = step.detail.trimmingCharacters(in: .whitespacesAndNewlines)
                if let encoded = q.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed),
                   let url = URL(string: "https://www.google.com/search?q=\(encoded)") {
                    NSWorkspace.shared.open(url)
                    log.append("✓ \(step.line)")
                } else {
                    log.append("✗ Búsqueda inválida")
                }
            case .readClipboard:
                let text = NSPasteboard.general.string(forType: .string)?
                    .trimmingCharacters(in: .whitespacesAndNewlines) ?? ""
                if text.isEmpty {
                    log.append("✓ \(step.line)\n  → (vacío)")
                } else {
                    let preview = text.count > 200 ? String(text.prefix(200)) + "…" : text
                    log.append("✓ \(step.line)\n  → \(preview)")
                }
            case .copyDraft:
                if let draft = draftProvider?(), !draft.isEmpty {
                    NSPasteboard.general.clearContents()
                    NSPasteboard.general.setString(draft, forType: .string)
                    log.append("✓ \(step.line)")
                } else {
                    log.append("✗ Sin borrador para copiar")
                }
            case .saveDraft:
                if let draft = draftProvider?(), !draft.isEmpty {
                    let fm = FileManager.default
                    let desktop = fm.urls(for: .desktopDirectory, in: .userDomainMask).first
                    let documents = fm.urls(for: .documentDirectory, in: .userDomainMask).first
                    let directory = desktop ?? documents
                    if let directory {
                        var preferred = step.detail.trimmingCharacters(in: .whitespacesAndNewlines)
                        if preferred.isEmpty { preferred = "borrador-argos.txt" }
                        let url = ActionRunner.uniqueWritableURL(in: directory, preferredName: preferred)
                        do {
                            try (draft.hasSuffix("\n") ? draft : draft + "\n").write(to: url, atomically: true, encoding: .utf8)
                            log.append("✓ \(step.line)\n  → \(url.path)")
                        } catch {
                            log.append("✗ No pude guardar borrador")
                        }
                    } else {
                        log.append("✗ Sin carpeta Escritorio/Documentos")
                    }
                } else {
                    log.append("✗ Sin borrador para guardar")
                }
            case .openURL:
                let raw = step.detail.trimmingCharacters(in: .whitespacesAndNewlines)
                guard let url = URL(string: raw),
                      let scheme = url.scheme?.lowercased(),
                      scheme == "http" || scheme == "https" else {
                    log.append("✗ URL rechazada (solo http/https): \(raw)")
                    continue
                }
                NSWorkspace.shared.open(url)
                log.append("✓ \(step.line)")
            }
        }
        let spoken = cancelled
            ? AgentModeError.cancelled.userMessage
            : "Listo. Completé el plan de \(plan.steps.count) paso\(plan.steps.count == 1 ? "" : "s")."
        return (spoken, log.joined(separator: "\n"))
    }

    private static func parseSteps(from raw: String) -> [AgentStep] {
        let jsonText: String
        if let start = raw.firstIndex(of: "{"), let end = raw.lastIndex(of: "}"), start < end {
            jsonText = String(raw[start...end])
        } else {
            jsonText = raw
        }
        guard let data = jsonText.data(using: .utf8),
              let obj = try? JSONSerialization.jsonObject(with: data) as? [String: Any],
              let arr = obj["steps"] as? [[String: Any]] else {
            return []
        }
        var steps: [AgentStep] = []
        for (idx, item) in arr.prefix(maxSteps).enumerated() {
            let kindRaw = ((item["kind"] as? String) ?? "").lowercased()
                .replacingOccurrences(of: "_", with: "")
            let detail = ((item["detail"] as? String) ?? "").trimmingCharacters(in: .whitespacesAndNewlines)
            let kind: AgentStep.Kind?
            switch kindRaw {
            case "analyze", "look", "screen": kind = .analyze
            case "type", "typing", "keyboard", "paste": kind = .type
            case "openapp", "open": kind = .openApp
            case "websearch", "search": kind = .webSearch
            case "readclipboard", "clipboard": kind = .readClipboard
            case "copydraft": kind = .copyDraft
            case "savedraft": kind = .saveDraft
            case "openurl", "url": kind = .openURL
            default: kind = nil
            }
            guard let kind else { continue }
            // readClipboard puede tener detail vacío
            if kind != .readClipboard && kind != .copyDraft && detail.isEmpty { continue }
            let d = detail.isEmpty ? kind.rawValue : detail
            steps.append(AgentStep(id: idx + 1, kind: kind, detail: d))
        }
        return steps
    }

    private static func bundleID(for name: String) -> String? {
        let n = name.folding(options: [.diacriticInsensitive, .caseInsensitive], locale: Locale(identifier: "es")).lowercased()
        let map: [(String, String)] = [
            ("safari", "com.apple.Safari"),
            ("finder", "com.apple.finder"),
            ("notas", "com.apple.Notes"),
            ("notes", "com.apple.Notes"),
            ("mail", "com.apple.mail"),
            ("correo", "com.apple.mail"),
            ("calendario", "com.apple.iCal"),
            ("calendar", "com.apple.iCal"),
            ("terminal", "com.apple.Terminal"),
            ("ajustes", "com.apple.systempreferences"),
            ("preferencias", "com.apple.systempreferences"),
            ("xcode", "com.apple.dt.Xcode"),
            ("cursor", "com.todesktop.230313mzl4w4u92")
        ]
        for (alias, bundle) in map where n.contains(alias) {
            return bundle
        }
        return nil
    }
}
