import SwiftUI
import AppKit

struct ArgosIntegrationView: View {
    private struct Integration: Identifiable {
        let id: String
        let name: String
        let subtitle: String
        let symbol: String
        let url: URL
    }

    private let integrations: [Integration] = [
        .init(id: "gmail", name: "Gmail", subtitle: "Abrir composición web", symbol: "envelope.fill", url: URL(string: "https://mail.google.com/mail/?view=cm&fs=1")!),
        .init(id: "outlook", name: "Outlook", subtitle: "Abrir composición web", symbol: "envelope.badge.person.crop", url: URL(string: "https://outlook.office.com/mail/deeplink/compose")!),
        .init(id: "github", name: "GitHub", subtitle: "Abrir tu espacio de desarrollo", symbol: "chevron.left.forwardslash.chevron.right", url: URL(string: "https://github.com")!),
        .init(id: "whatsapp", name: "WhatsApp", subtitle: "Abrir chat / mensaje preparado", symbol: "message.fill", url: URL(string: "https://web.whatsapp.com")!)
    ]

    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("Integraciones")
                .font(.headline)
            Text("Argos puede abrir y preparar acciones en servicios externos sin guardar credenciales dentro de la interfaz. Las automatizaciones API completas requieren que configures la cuenta/API correspondiente.")
                .font(.callout)
                .foregroundStyle(.secondary)
                .fixedSize(horizontal: false, vertical: true)

            ForEach(integrations) { integration in
                HStack(spacing: 12) {
                    Image(systemName: integration.symbol)
                        .frame(width: 28)
                        .foregroundStyle(.purple)
                    VStack(alignment: .leading, spacing: 2) {
                        Text(integration.name).font(.subheadline.weight(.semibold))
                        Text(integration.subtitle).font(.caption).foregroundStyle(.secondary)
                    }
                    Spacer()
                    Button("Abrir") {
                        NSWorkspace.shared.open(integration.url)
                    }
                    .buttonStyle(.bordered)
                }
                .padding(10)
                .background(.quaternary.opacity(0.35), in: RoundedRectangle(cornerRadius: 12))
            }

            Text("WhatsApp admite enlaces con texto prellenado y Gmail/Outlook exponen páginas de composición web; Argos no considera esas acciones como mensajes enviados hasta que el usuario los envía en el servicio.")
                .font(.caption)
                .foregroundStyle(.secondary)
        }
    }
}
