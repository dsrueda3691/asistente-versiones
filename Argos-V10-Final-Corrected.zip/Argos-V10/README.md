# Argos

Compañero de escritorio nativo para macOS: cerebro local/nube, memoria, voz, contexto visual, agente con aprobación humana y una interfaz que vive en el notch.

## Arquitectura

- **Core:** Brain, Memory, LLMBackend, AgentMode y ActionRunner.
- **Capabilities:** captura de pantalla/ventana, documentos, audio/video, voz y automatizaciones nativas de macOS.
- **UI:** compañero del notch, personaje Canvas/TimelineView, conversación, actividad y aprobaciones.
- **System:** NSPanel, contexto de ventanas, hotkeys, permisos y Login Item.

## Comportamiento

- Estados visuales: Reposo, Escuchando, Pensando, Trabajando, Aprobación, Completado y Error.
- Panel compacto alineado con el notch; panel expandido para conversación/actividad/contexto.
- Arrastrar archivos al compañero crea contexto.
- Arrastrar Argos sobre una ventana usa Accessibility + Quartz para identificar la ventana y ScreenCaptureKit para capturarla cuando el permiso está disponible.
- Los agentes presentan un plan antes de ejecutar acciones.
- Las acciones peligrosas permanecen detrás de `PendingAction` y requieren confirmación.

## Compatibilidad

- macOS 14+
- Swift 5
- Sin dependencias de terceros.

## Primer arranque

Argos muestra una pantalla de primeros pasos para solicitar micrófono, reconocimiento de voz, grabación de pantalla y Accesibilidad. Estos permisos también pueden administrarse posteriormente desde Ajustes del Sistema.

## Cerebro

- Local: Ollama.
- Astra: backend OpenAI existente en V9.
- Auto: intenta nube cuando hay credencial y hace fallback a local.

## Integraciones externas

Argos incluye un hub de accesos para Gmail, Outlook, GitHub y WhatsApp. Los accesos web no se consideran autenticación API: para automatizaciones API completas hay que configurar las credenciales/OAuth del servicio correspondiente.

## Seguridad

Argos mantiene el principio Human-in-the-Loop del Core original. No se añaden comandos shell arbitrarios ni ejecución ciega de acciones externas.
