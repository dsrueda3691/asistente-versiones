# Argos V12 — modos de trabajo integrados (sin compilar)

## Cómo se usa
- Frase: «modo programar <tarea>», «modo documentos <tarea>», «modo revisar <tarea>».
  Solo se reconoce por frase del usuario (nunca por propuesta del modelo ni desde el iPhone).
- Ajustes → «Trabajo en proyectos»: carpeta del proyecto, motor (Argos, Claude Code, Codex),
  proveedor, modelo (escríbelo tú) y clave (Llavero).
- Pestaña Actividad: progreso, aprobaciones (Aplicar / Integrar / Descartar) y resultado.

## Flujo de «programar»
1. Crea una rama aislada (`git worktree`, rama `argos/<tarea>`). Tu rama no se toca.
2. El motor trabaja dentro de esa rama. Los cambios se confirman allí.
3. Pide aprobación para integrar la rama (`git merge --no-ff`). Si descartas, se borra la rama.
Requiere que la carpeta sea un repositorio git con al menos un commit.

## Flujo de «documentos» y «revisar»
- «documentos» sin carpeta elegida escribe en ~/Documents/Argos. Los cambios se muestran y
  se escriben solo si los apruebas.
- «revisar» es solo lectura.

## Límites conocidos
- Un motor por tarea (no varios a la vez).
- El proveedor y el modelo son globales; el campo `providerID` de cada modo aún no se usa.
- Los flags de Claude Code (`-p`, `--permission-mode`, `--allowedTools`) y de Codex
  (`exec --cd … --sandbox …`) deben comprobarse con la versión instalada.
- Si tu rama tiene cambios sin confirmar, la integración puede fallar; se aborta sin tocar nada.
- Sin compilar. Revisar en Xcode especialmente WorkCoordinator, WorkViews y ArgosApp.startWork.

## Proveedores de chat (punto 6)
- Nuevo proveedor «otro» en el selector del notch y de ajustes. Muestra el proveedor elegido
  en Ajustes › Trabajo (Anthropic, OpenAI, Gemini, LM Studio u Ollama) y su modelo.
- Solo texto. Las imágenes (pantalla) siguen usando OpenAI u Ollama; con «otro» devuelve un aviso.
- Compatible con cualquier servicio que hable la API de OpenAI (chat/completions) o la de Anthropic.
- Los modelos no tienen valor por defecto: escríbelos en Ajustes tal como los da cada proveedor.

## Alcance cerrado
- Punto 1 (delegación): Claude Code y Codex en la carpeta del proyecto, o el agente propio.
- Punto 5 (vista previa sin bloquear): cambios en rama aislada; integrar o descartar al final.
- Punto 6 (proveedores): ver arriba.
- Modos: Programar, Documentos y Revisar.
- Pendiente aparte (omitido a petición): iPhone, modo demo y pulido.
