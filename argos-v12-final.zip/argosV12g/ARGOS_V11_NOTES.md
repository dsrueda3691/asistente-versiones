# Argos V11 — memoria persistente + base de herramientas

## Base
Derivado de Argos V10 Final Hardened v7. No se elimina el puente remoto endurecido ni PendingAction.

## Implementado
- Perfil persistente local: `ProfileStore`.
- Memoria semántica local: `SemanticMemory` con embeddings de Ollama (`nomic-embed-text` por defecto) y fallback textual.
- Fachada `ArgosMemoryStore` para recordar, buscar y olvidar.
- Comandos: `recuerda que…`, `¿qué recuerdas sobre…?`, `olvida de tu memoria…`.
- Extracción conservadora de patrones explícitos: jefe, preferencias y proyecto actual.
- El contexto de largo plazo se añade a preguntas del Brain y a preguntas libres desde iPhone.
- Catálogo estructurado de herramientas y `ArgosToolPolicy`; las acciones con efecto siguen pasando por el flujo existente de `PendingAction`.
- El Brain recibe el catálogo de herramientas seguro como contexto.
- Ajustes muestran el perfil de memoria y permiten borrar memoria de largo plazo.
- Ollama añade `/api/embeddings`; el tráfico de embeddings queda en localhost.
- Versión de aplicación: 11.0.

## Diseño de seguridad
- La memoria de largo plazo es independiente de `ConversationMemory`.
- `resetMemory` sigue borrando solo la conversación de sesión.
- El usuario puede borrar toda la memoria de largo plazo desde Ajustes o recuerdos concretos por voz/texto.
- No se ejecutan herramientas directamente desde el catálogo: el catálogo describe capacidades y `ToolPolicy` clasifica riesgo; el runtime conserva `PendingAction` para efectos externos.
- Las preguntas remotas libres son de solo lectura: aunque el Brain produzca una intención internamente, esa intención no se ejecuta por la ruta remota.

## Validación
- 41 archivos Swift registrados en el proyecto (36 originales + 5 nuevos).
- Todos los `.swift` pasan `swiftc -parse` en el entorno de validación.
- No se afirma compilación real de Xcode/macOS: falta probar en un Mac con Xcode y Ollama.

## Ollama recomendado para memoria
`ollama pull nomic-embed-text`

El nombre del embedding puede cambiarse con `argos.embeddingModel` en UserDefaults.
