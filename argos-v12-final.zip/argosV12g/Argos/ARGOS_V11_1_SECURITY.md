# Argos V11.1 — seguridad de memoria remota y herramientas

## Memoria desde el iPhone
- La pregunta libre remota ya no lee la memoria a largo plazo ni el historial del Mac.
- Usa un historial propio en memoria (máx. 12 mensajes) que se pierde al reiniciar.
- Mientras una petición es remota (`isRemoteRequest`), no se escribe en la memoria local:
  ni frases, ni respuestas, ni patrones explícitos.

## Política de herramientas (origen)
- Lo que dices tú (`.userPhrase`): flujo habitual.
- Lo que propone el modelo (`.modelSuggestion`):
  - Permitido: lecturas (estado, objetivos, recordatorios, PRs, calendario, correo, recuerdos).
  - Permitido con aprobación: correo, WhatsApp, evento, recordatorio, objetivo, plan del agente.
  - Denegado: crear archivos, copiar plantillas, teclear en otra app, leer documentos,
    analizar pantalla, transcribir medios, crear notas, exportar, guardar/olvidar memoria,
    reiniciar memoria, salir de la app, abrir URLs.
- El catálogo que se ofrece al modelo solo incluye lecturas y acciones con aprobación.

## Pendiente
- No compilado en Xcode. Revisar `ArgosApp.swift` (líneas de `isRemoteRequest`).
- Algunas peticiones que antes dependían del modelo para crear archivos o leer documentos
  ahora requieren frase directa (el parser determinista las reconoce).
