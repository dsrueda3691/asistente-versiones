import SwiftUI
import AppKit

/// Panel de trabajo dentro de la pestaña Actividad: progreso, aprobaciones y resultado.
@MainActor
struct ArgosWorkPanel: View {
    @ObservedObject var work: WorkCoordinator = WorkCoordinator.shared

    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            if let approval = work.pending {
                approvalCard(approval)
            }
            if work.isRunning || !work.log.isEmpty {
                HStack {
                    Text(work.isRunning ? "Trabajando…" : "Último trabajo")
                        .font(.caption.weight(.semibold)).foregroundStyle(.white.opacity(0.8))
                    Spacer()
                    if work.isRunning {
                        Button("Detener") { work.cancel() }
                            .buttonStyle(.plain).font(.caption.weight(.semibold)).foregroundStyle(.red)
                    }
                }
                ScrollView {
                    VStack(alignment: .leading, spacing: 3) {
                        ForEach(work.log.suffix(60)) { line in
                            Text(line.text)
                                .font(.system(size: 10, design: .monospaced))
                                .foregroundStyle(color(line.style))
                                .frame(maxWidth: .infinity, alignment: .leading)
                                .textSelection(.enabled)
                        }
                    }
                }
                .frame(maxHeight: 150)
                .padding(8)
                .background(Color.black.opacity(0.35), in: RoundedRectangle(cornerRadius: 10, style: .continuous))
            }
            if let result = work.result {
                resultCard(result)
            }
        }
    }

    private func color(_ s: WorkLogLine.Style) -> Color {
        switch s {
        case .info: return .white.opacity(0.6)
        case .tool: return Color(argosHex: 0x5AA9FF)
        case .text: return .white.opacity(0.85)
        case .error: return Color(argosHex: 0xFF5C6C)
        case .result: return Color(argosHex: 0x5FE3B0)
        }
    }

    @ViewBuilder private func approvalCard(_ a: WorkApproval) -> some View {
        VStack(alignment: .leading, spacing: 8) {
            Text("Necesito tu autorización").font(.caption.weight(.semibold)).foregroundStyle(.purple)
            Text(a.title).font(.subheadline.weight(.bold))
            Text(a.reason).font(.caption).foregroundStyle(.white.opacity(0.7)).lineLimit(3)
            if case .changes(let changes) = a.kind {
                ScrollView {
                    VStack(alignment: .leading, spacing: 6) {
                        ForEach(changes) { c in
                            Text("\(c.kind.rawValue) · \(c.path)  +\(c.added) −\(c.removed)")
                                .font(.caption.weight(.semibold))
                            Text(String(c.diff.prefix(900)))
                                .font(.system(size: 9, design: .monospaced))
                                .foregroundStyle(.white.opacity(0.7))
                        }
                    }
                }
                .frame(maxHeight: 180)
            }
            HStack(spacing: 8) {
                Button { work.answer(true) } label: {
                    Text(primaryLabel(a)).font(.subheadline.weight(.bold)).frame(maxWidth: .infinity).padding(.vertical, 7)
                        .background(Color.purple, in: Capsule()).foregroundStyle(.white)
                }
                Button { work.answer(false) } label: {
                    Text("Descartar").font(.subheadline.weight(.semibold)).frame(maxWidth: .infinity).padding(.vertical, 7)
                        .background(Color.white.opacity(0.10), in: Capsule()).foregroundStyle(.white)
                }
            }.buttonStyle(.plain)
        }
        .padding(12)
        .background(Color.purple.opacity(0.10), in: RoundedRectangle(cornerRadius: 14, style: .continuous))
    }

    private func primaryLabel(_ a: WorkApproval) -> String {
        if case .branch = a.kind { return "Integrar" }
        return "Aplicar"
    }

    @ViewBuilder private func resultCard(_ r: WorkResult) -> some View {
        VStack(alignment: .leading, spacing: 4) {
            Text("Rama \(r.branch)").font(.caption.weight(.semibold)).foregroundStyle(.white.opacity(0.8))
            ForEach(r.files) { f in
                Text("\(f.path)  +\(f.added) −\(f.removed)").font(.caption).foregroundStyle(.white.opacity(0.7))
            }
        }
        .padding(10)
        .background(Color.white.opacity(0.06), in: RoundedRectangle(cornerRadius: 12, style: .continuous))
    }
}

/// Ajustes del modo trabajo: carpeta del proyecto, motor, proveedor, modelo y clave.
struct ArgosWorkSettingsView: View {
    @AppStorage(WorkSettings.workspaceKey) private var workspacePath = ""
    @AppStorage(WorkSettings.providerKey) private var providerID = "anthropic"
    @AppStorage(WorkSettings.modelKey) private var model = ""
    @AppStorage(WorkSettings.engineKey) private var engine = "native"
    @State private var keyDraft = ""
    @State private var keyMessage: String?
    @State private var external: [ExternalAgentStatus] = []

    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text("Trabajo en proyectos").font(.headline)
            HStack {
                Text(workspacePath.isEmpty ? "Sin carpeta de proyecto" : workspacePath)
                    .font(.caption).lineLimit(1).truncationMode(.middle)
                Spacer()
                Button("Elegir carpeta…") { chooseFolder() }
            }
            Picker("Motor", selection: $engine) {
                Text("Argos").tag("native")
                ForEach(external.filter(\.installed), id: \.kind) { s in
                    Text(s.kind == .claude ? "Claude Code" : "Codex").tag(s.kind == .claude ? "claudeCode" : "codex")
                }
            }
            Picker("Proveedor", selection: $providerID) {
                ForEach(WorkProvider.presets) { p in Text(p.title).tag(p.id) }
            }
            TextField("Modelo (escríbelo tal como lo da tu proveedor)", text: $model)
                .textFieldStyle(.roundedBorder)
            if let p = WorkProvider.presets.first(where: { $0.id == providerID }), p.needsKey {
                HStack {
                    SecureField("Clave de \(p.title)", text: $keyDraft).textFieldStyle(.roundedBorder)
                    Button("Guardar") {
                        WorkKeyStore.save(keyDraft.trimmingCharacters(in: .whitespacesAndNewlines), for: p.id)
                        keyDraft = ""
                        keyMessage = "Clave guardada en el Llavero."
                    }
                    .disabled(keyDraft.trimmingCharacters(in: .whitespaces).isEmpty)
                }
            }
            if let keyMessage { Text(keyMessage).font(.caption).foregroundStyle(.secondary) }
            Text("Claude Code y Codex: \(external.map { "\($0.kind.title) \($0.installed ? "instalado" : "no instalado")" }.joined(separator: " · "))")
                .font(.caption2).foregroundStyle(.secondary)
        }
        .task { external = await ExternalAgents.detect() }
    }

    private func chooseFolder() {
        let panel = NSOpenPanel()
        panel.canChooseFiles = false
        panel.canChooseDirectories = true
        panel.allowsMultipleSelection = false
        panel.prompt = "Usar esta carpeta"
        if panel.runModal() == .OK, let url = panel.url {
            workspacePath = url.path
        }
    }
}

extension Color {
    /// Color desde 0xRRGGBB. Nombre propio para no chocar con otros inicializadores del proyecto.
    init(argosHex value: UInt32) {
        self.init(.sRGB,
                  red: Double((value >> 16) & 0xFF) / 255,
                  green: Double((value >> 8) & 0xFF) / 255,
                  blue: Double(value & 0xFF) / 255,
                  opacity: 1)
    }
}
