import Foundation

enum WorkError: LocalizedError {
    case message(String)
    var errorDescription: String? {
        switch self { case .message(let m): return m }
    }
}

/// Mantiene todas las operaciones de archivos dentro de la carpeta del proyecto.
struct WorkspaceSandbox {
    let root: URL

    static let ignoredDirectories: Set<String> = [
        ".git", "node_modules", ".build", "build", "DerivedData", "Pods", ".venv", "venv",
        "__pycache__", ".next", "dist", "target", ".idea", ".gradle"
    ]

    init(root: URL) {
        self.root = root.standardizedFileURL.resolvingSymlinksInPath()
    }

    /// Resuelve una ruta relativa; rechaza `..`, rutas absolutas y enlaces que salgan de la raíz.
    func resolve(_ relative: String) throws -> URL {
        let cleaned = relative.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !cleaned.isEmpty else { throw WorkError.message("Ruta vacía.") }
        guard !cleaned.hasPrefix("/"), !cleaned.hasPrefix("~") else {
            throw WorkError.message("Usa rutas relativas a la carpeta del proyecto.")
        }
        let url = root.appendingPathComponent(cleaned).standardizedFileURL.resolvingSymlinksInPath()
        guard url.path == root.path || url.path.hasPrefix(root.path + "/") else {
            throw WorkError.message("La ruta queda fuera de la carpeta del proyecto.")
        }
        return url
    }

    func relativePath(_ url: URL) -> String {
        let p = url.standardizedFileURL.resolvingSymlinksInPath().path
        if p == root.path { return "." }
        if p.hasPrefix(root.path + "/") { return String(p.dropFirst(root.path.count + 1)) }
        return p
    }

    static func isSensitive(_ url: URL) -> Bool {
        let name = url.lastPathComponent.lowercased()
        if name == ".env" || name.hasPrefix(".env.") || name == ".npmrc" || name == ".netrc" { return true }
        if name.hasPrefix("id_rsa") || name.hasPrefix("id_ed25519") || name.hasPrefix("id_ecdsa") { return true }
        if name.hasSuffix(".pem") || name.hasSuffix(".key") || name.hasSuffix(".p12") || name.hasSuffix(".keystore") { return true }
        if name.hasPrefix("credentials") || name.hasPrefix("secrets") { return true }
        let parts = url.pathComponents.map { $0.lowercased() }
        return parts.contains(".ssh") || parts.contains(".aws") || parts.contains(".gnupg")
    }

    func isInsideGitDirectory(_ url: URL) -> Bool {
        url.pathComponents.contains(".git")
    }
}
