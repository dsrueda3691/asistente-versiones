import Foundation

/// Bucle del agente propio: el modelo elige herramientas, Argos las ejecuta dentro del proyecto
/// y los cambios se acumulan como propuesta hasta que el usuario decide.
@MainActor
final class NativeAgent {
    struct Outcome {
        var summary: String
        var changes: [ProposedChange]
        var commands: [String]
        var failure: String?
    }

    static let maxSteps = 14
    static let maxSeconds: TimeInterval = 600

    /// Pide al modelo el siguiente paso. Debe devolver JSON: {"tool": "...", "args": {...}}.
    private let decide: (_ system: String, _ transcript: String) async -> String?
    private let log: (String) -> Void
    private let progress: (Int, Int) -> Void

    init(decide: @escaping (_ system: String, _ transcript: String) async -> String?,
         log: @escaping (String) -> Void,
         progress: @escaping (Int, Int) -> Void) {
        self.decide = decide
        self.log = log
        self.progress = progress
    }

    func run(goal: String, profile: WorkProfile, root: URL) async -> Outcome {
        let sandbox = WorkspaceSandbox(root: root)
        var toolbox = WorkToolbox(sandbox: sandbox, allowed: profile.tools, isolated: profile.useWorktree)
        let system = profile.systemPrompt + """


        Responde SIEMPRE con un único objeto JSON y nada más: {"tool": "<nombre>", "args": {…}}.
        Herramientas disponibles:
        \(WorkToolbox.catalogPrompt(allowed: profile.tools))
        Cuando termines usa "finish" con un resumen claro. No inventes rutas: lista o busca antes.
        """
        var transcript = "Objetivo: \(goal)\n"
        let started = Date()
        var failure: String?
        var summary: String?

        for step in 1...Self.maxSteps {
            if Date().timeIntervalSince(started) > Self.maxSeconds {
                failure = "Se alcanzó el tiempo máximo de la tarea."
                break
            }
            progress(step, Self.maxSteps)
            guard let raw = await decide(system, transcript) else {
                failure = "El modelo no respondió."
                break
            }
            guard let call = Self.parse(raw) else {
                transcript += "\n[Respuesta no válida, responde solo con JSON]\n"
                continue
            }
            if call.name == "finish" {
                summary = call.args["summary"] ?? "Tarea terminada."
                break
            }
            log("→ \(call.name) \(call.args["path"] ?? call.args["query"] ?? call.args["command"] ?? "")")
            let result = await toolbox.execute(call, log: log)
            transcript += "\n[\(call.name)] \(String(result.prefix(4_000)))\n"
        }

        return Outcome(
            summary: summary ?? failure ?? "Argos se detuvo sin terminar.",
            changes: Array(toolbox.proposed.values).sorted { $0.path < $1.path },
            commands: toolbox.commands,
            failure: summary == nil ? (failure ?? "Sin resumen final.") : nil
        )
    }

    /// Extrae el primer objeto JSON de la respuesta del modelo.
    static func parse(_ raw: String) -> WorkToolCall? {
        guard let start = raw.firstIndex(of: "{"), let end = raw.lastIndex(of: "}") else { return nil }
        let json = String(raw[start...end])
        guard let data = json.data(using: .utf8),
              let obj = try? JSONSerialization.jsonObject(with: data) as? [String: Any],
              let name = obj["tool"] as? String else { return nil }
        var args: [String: String] = [:]
        for (k, v) in (obj["args"] as? [String: Any]) ?? [:] { args[k] = "\(v)" }
        return WorkToolCall(name: name, args: args)
    }
}
