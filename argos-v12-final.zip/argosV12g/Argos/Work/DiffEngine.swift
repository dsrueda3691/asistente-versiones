import Foundation

/// Diff de líneas (LCS) con salida unificada, para la vista previa de cambios.
enum DiffEngine {
    private enum Op { case equal(String), delete(String), insert(String) }
    private struct Entry { var op: Op; var o: Int; var n: Int }

    static func lines(_ s: String) -> [String] {
        s.isEmpty ? [] : s.components(separatedBy: "\n")
    }

    static func unified(old: String?, new: String?, path: String, context: Int = 3,
                        maxChars: Int = 24_000) -> (text: String, added: Int, removed: Int) {
        let a = lines(old ?? "")
        let b = lines(new ?? "")
        let ops = diffOps(a, b)

        var entries: [Entry] = []
        var o = 0, n = 0, added = 0, removed = 0
        for op in ops {
            entries.append(Entry(op: op, o: o, n: n))
            switch op {
            case .equal: o += 1; n += 1
            case .delete: o += 1; removed += 1
            case .insert: n += 1; added += 1
            }
        }

        let changed = entries.indices.filter {
            if case .equal = entries[$0].op { return false } else { return true }
        }
        guard !changed.isEmpty else { return ("(sin cambios)", 0, 0) }

        // Rangos con contexto, fusionando los que se solapan.
        var ranges: [ClosedRange<Int>] = []
        for idx in changed {
            let lo = max(0, idx - context), hi = min(entries.count - 1, idx + context)
            if let last = ranges.last, lo <= last.upperBound + 1 {
                ranges[ranges.count - 1] = last.lowerBound...max(last.upperBound, hi)
            } else {
                ranges.append(lo...hi)
            }
        }

        var out = "--- a/\(path)\n+++ b/\(path)\n"
        for r in ranges {
            let slice = entries[r]
            let oldCount = slice.filter { if case .insert = $0.op { return false } else { return true } }.count
            let newCount = slice.filter { if case .delete = $0.op { return false } else { return true } }.count
            let first = slice.first!
            out += "@@ -\(first.o + 1),\(oldCount) +\(first.n + 1),\(newCount) @@\n"
            for e in slice {
                switch e.op {
                case .equal(let t): out += " " + t + "\n"
                case .delete(let t): out += "-" + t + "\n"
                case .insert(let t): out += "+" + t + "\n"
                }
            }
            if out.count > maxChars { break }
        }
        if out.count > maxChars {
            out = String(out.prefix(maxChars)) + "\n… (diff recortado)\n"
        }
        return (out, added, removed)
    }

    private static func diffOps(_ a: [String], _ b: [String]) -> [Op] {
        // Prefijo y sufijo comunes: reducen mucho el problema en ediciones típicas.
        var start = 0
        while start < a.count, start < b.count, a[start] == b[start] { start += 1 }
        var endA = a.count, endB = b.count
        while endA > start, endB > start, a[endA - 1] == b[endB - 1] { endA -= 1; endB -= 1 }

        let ma = Array(a[start..<endA]), mb = Array(b[start..<endB])
        var middle: [Op] = []
        if ma.isEmpty {
            middle = mb.map { .insert($0) }
        } else if mb.isEmpty {
            middle = ma.map { .delete($0) }
        } else if ma.count * mb.count > 4_000_000 {
            middle = ma.map { .delete($0) } + mb.map { .insert($0) }
        } else {
            middle = lcsOps(ma, mb)
        }

        var ops: [Op] = []
        ops.append(contentsOf: a[0..<start].map { .equal($0) })
        ops.append(contentsOf: middle)
        ops.append(contentsOf: a[endA..<a.count].map { .equal($0) })
        return ops
    }

    private static func lcsOps(_ a: [String], _ b: [String]) -> [Op] {
        let n = a.count, m = b.count
        let width = m + 1
        var table = [Int32](repeating: 0, count: (n + 1) * width)
        for i in stride(from: n - 1, through: 0, by: -1) {
            for j in stride(from: m - 1, through: 0, by: -1) {
                if a[i] == b[j] {
                    table[i * width + j] = table[(i + 1) * width + j + 1] + 1
                } else {
                    table[i * width + j] = max(table[(i + 1) * width + j], table[i * width + j + 1])
                }
            }
        }
        var ops: [Op] = []
        var i = 0, j = 0
        while i < n, j < m {
            if a[i] == b[j] {
                ops.append(.equal(a[i])); i += 1; j += 1
            } else if table[(i + 1) * width + j] >= table[i * width + j + 1] {
                ops.append(.delete(a[i])); i += 1
            } else {
                ops.append(.insert(b[j])); j += 1
            }
        }
        while i < n { ops.append(.delete(a[i])); i += 1 }
        while j < m { ops.append(.insert(b[j])); j += 1 }
        return ops
    }
}
