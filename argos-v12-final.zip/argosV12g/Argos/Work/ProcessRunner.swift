import Foundation

struct CommandResult {
    var exitCode: Int32
    var output: String
    var timedOut: Bool
}

/// Estado compartido entre los hilos de lectura y de terminación de un proceso.
private final class RunState {
    private let lock = NSLock()
    private var buffer = Data()
    private var partial = ""
    private var finished = false
    var timedOut = false

    func append(_ data: Data, limit: Int) {
        lock.lock(); defer { lock.unlock() }
        guard buffer.count < limit else { return }
        buffer.append(data.prefix(limit - buffer.count))
    }

    /// Devuelve las líneas completas recibidas con este fragmento.
    func lines(from data: Data) -> [String] {
        lock.lock(); defer { lock.unlock() }
        partial += String(decoding: data, as: UTF8.self)
        var out: [String] = []
        while let r = partial.range(of: "\n") {
            out.append(String(partial[partial.startIndex..<r.lowerBound]))
            partial = String(partial[r.upperBound...])
        }
        return out
    }

    func remainder() -> String? {
        lock.lock(); defer { lock.unlock() }
        let r = partial.trimmingCharacters(in: .whitespacesAndNewlines)
        partial = ""
        return r.isEmpty ? nil : r
    }

    func text() -> String {
        lock.lock(); defer { lock.unlock() }
        return String(decoding: buffer, as: UTF8.self)
    }

    /// Ejecuta el cierre una sola vez.
    func finish(_ block: () -> Void) {
        lock.lock()
        let already = finished
        finished = true
        lock.unlock()
        if !already { block() }
    }
}

/// Registro de procesos vivos, para poder detenerlos todos.
final class LiveProcesses {
    static let shared = LiveProcesses()
    private let lock = NSLock()
    private var items: [Int32: Process] = [:]

    func add(_ p: Process) { lock.lock(); items[p.processIdentifier] = p; lock.unlock() }
    func remove(_ p: Process) { lock.lock(); items[p.processIdentifier] = nil; lock.unlock() }
    func terminateAll() {
        lock.lock(); let all = Array(items.values); lock.unlock()
        for p in all where p.isRunning { p.terminate() }
    }
}

enum ProcessRunner {
    static let searchDirs: [String] = [
        "/usr/bin", "/bin", "/usr/sbin", "/opt/homebrew/bin", "/usr/local/bin",
        NSHomeDirectory() + "/.local/bin", NSHomeDirectory() + "/.cargo/bin",
        NSHomeDirectory() + "/.npm-global/bin", NSHomeDirectory() + "/.claude/local",
        NSHomeDirectory() + "/.bun/bin"
    ]

    static func findExecutable(_ name: String) -> String? {
        if name.contains("/") {
            return FileManager.default.isExecutableFile(atPath: name) ? name : nil
        }
        for dir in searchDirs {
            let path = dir + "/" + name
            if FileManager.default.isExecutableFile(atPath: path) { return path }
        }
        return nil
    }

    /// Entorno mínimo y limpio para comandos del agente propio (sin claves ni tokens).
    static func cleanEnvironment() -> [String: String] {
        [
            "PATH": searchDirs.joined(separator: ":"),
            "HOME": NSHomeDirectory(),
            "USER": NSUserName(),
            "LANG": "en_US.UTF-8",
            "TERM": "dumb",
            "GIT_TERMINAL_PROMPT": "0",
            "CI": "1"
        ]
    }

    /// Entorno para agentes externos: hereda el del usuario y amplía el PATH.
    static func inheritedEnvironment() -> [String: String] {
        var env = ProcessInfo.processInfo.environment
        let current = env["PATH"] ?? ""
        env["PATH"] = (searchDirs + current.split(separator: ":").map(String.init)).joined(separator: ":")
        env["GIT_TERMINAL_PROMPT"] = "0"
        return env
    }

    /// Ejecuta un proceso y espera su salida (stdout + stderr), con tiempo máximo.
    static func run(_ executable: String, _ args: [String], cwd: URL, timeout: TimeInterval = 180,
                    maxBytes: Int = 200_000, env: [String: String]? = nil) async -> CommandResult {
        await withCheckedContinuation { cont in
            let process = Process()
            process.executableURL = URL(fileURLWithPath: executable)
            process.arguments = args
            process.currentDirectoryURL = cwd
            process.environment = env ?? cleanEnvironment()
            process.standardInput = FileHandle.nullDevice
            let pipe = Pipe()
            process.standardOutput = pipe
            process.standardError = pipe
            let state = RunState()

            pipe.fileHandleForReading.readabilityHandler = { handle in
                let data = handle.availableData
                if !data.isEmpty { state.append(data, limit: maxBytes) }
            }
            process.terminationHandler = { p in
                pipe.fileHandleForReading.readabilityHandler = nil
                state.append(pipe.fileHandleForReading.readDataToEndOfFile(), limit: maxBytes)
                LiveProcesses.shared.remove(p)
                let result = CommandResult(exitCode: p.terminationStatus, output: state.text(), timedOut: state.timedOut)
                state.finish { cont.resume(returning: result) }
            }
            do {
                try process.run()
                LiveProcesses.shared.add(process)
            } catch {
                state.finish {
                    cont.resume(returning: CommandResult(exitCode: -1, output: "No pude ejecutar el comando: \(error.localizedDescription)", timedOut: false))
                }
                return
            }
            DispatchQueue.global().asyncAfter(deadline: .now() + timeout) {
                guard process.isRunning else { return }
                state.timedOut = true
                process.terminate()
                DispatchQueue.global().asyncAfter(deadline: .now() + 3) {
                    if process.isRunning { kill(process.processIdentifier, SIGKILL) }
                }
            }
        }
    }

    /// Ejecuta un proceso entregando su salida línea a línea. Devuelve el código de salida.
    static func stream(_ executable: String, _ args: [String], cwd: URL, env: [String: String],
                       timeout: TimeInterval, onLine: @escaping (String) -> Void) async -> Int32 {
        await withCheckedContinuation { cont in
            let process = Process()
            process.executableURL = URL(fileURLWithPath: executable)
            process.arguments = args
            process.currentDirectoryURL = cwd
            process.environment = env
            process.standardInput = FileHandle.nullDevice
            let pipe = Pipe()
            process.standardOutput = pipe
            process.standardError = pipe
            let state = RunState()

            pipe.fileHandleForReading.readabilityHandler = { handle in
                let data = handle.availableData
                if data.isEmpty { return }
                for line in state.lines(from: data) where !line.isEmpty { onLine(line) }
            }
            process.terminationHandler = { p in
                pipe.fileHandleForReading.readabilityHandler = nil
                let rest = pipe.fileHandleForReading.readDataToEndOfFile()
                if !rest.isEmpty { for line in state.lines(from: rest) where !line.isEmpty { onLine(line) } }
                if let tail = state.remainder() { onLine(tail) }
                LiveProcesses.shared.remove(p)
                let code: Int32 = state.timedOut ? 124 : p.terminationStatus
                state.finish { cont.resume(returning: code) }
            }
            do {
                try process.run()
                LiveProcesses.shared.add(process)
            } catch {
                onLine("No pude iniciar el proceso: \(error.localizedDescription)")
                state.finish { cont.resume(returning: -1) }
                return
            }
            DispatchQueue.global().asyncAfter(deadline: .now() + timeout) {
                guard process.isRunning else { return }
                state.timedOut = true
                process.terminate()
                DispatchQueue.global().asyncAfter(deadline: .now() + 3) {
                    if process.isRunning { kill(process.processIdentifier, SIGKILL) }
                }
            }
        }
    }
}
