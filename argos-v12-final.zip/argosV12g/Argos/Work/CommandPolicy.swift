import Foundation

enum CommandDecision: Equatable {
    case allow
    case ask(String)
    case deny(String)
}

/// Política de comandos del agente propio: lista segura, preguntar o prohibir.
/// No se usa shell: el comando se divide en argumentos y se ejecuta directamente.
enum CommandPolicy {
    static func tokenize(_ s: String) -> [String]? {
        var args: [String] = []
        var current = ""
        var quote: Character?
        var hasToken = false
        var escape = false
        for ch in s {
            if escape { current.append(ch); escape = false; hasToken = true; continue }
            if ch == "\\" && quote != "'" { escape = true; continue }
            if let q = quote {
                if ch == q { quote = nil } else { current.append(ch) }
                continue
            }
            if ch == "\"" || ch == "'" { quote = ch; hasToken = true; continue }
            if ch == " " || ch == "\t" {
                if hasToken { args.append(current); current = ""; hasToken = false }
                continue
            }
            current.append(ch); hasToken = true
        }
        if quote != nil { return nil }
        if hasToken { args.append(current) }
        return args
    }

    static func evaluate(_ raw: String, isolated: Bool) -> (argv: [String], decision: CommandDecision) {
        let forbidden = [";", "|", "&", ">", "<", "`", "$(", "\n"]
        if forbidden.contains(where: { raw.contains($0) }) {
            return ([], .deny("No se permite encadenar comandos, redirigir ni sustituir. Ejecuta un solo comando por llamada."))
        }
        guard let argv = tokenize(raw), let first = argv.first else {
            return ([], .deny("Comando vacío o con comillas sin cerrar."))
        }
        let name = (first as NSString).lastPathComponent
        let args = Array(argv.dropFirst())
        let sub = args.first(where: { !$0.hasPrefix("-") })

        let denied: Set<String> = ["sudo", "su", "rm", "rmdir", "dd", "mkfs", "diskutil", "launchctl", "security",
                                   "defaults", "osascript", "kill", "killall", "shutdown", "reboot", "chown",
                                   "ssh", "scp", "sftp", "nc", "ncat", "telnet", "sh", "bash", "zsh", "fish", "eval", "exec"]
        if denied.contains(name) {
            return (argv, .deny("«\(name)» no está permitido. Para borrar archivos usa delete_file."))
        }

        func gate(_ ok: Bool, _ why: String) -> CommandDecision {
            if ok && isolated { return .allow }
            return .ask(ok ? "\(why) Se pregunta porque no se trabaja en una rama aislada." : why)
        }

        switch name {
        case "git":
            if args.contains(where: { $0 == "-C" || $0.hasPrefix("--git-dir") || $0.hasPrefix("--work-tree") || $0 == "-c" }) {
                return (argv, .deny("Opciones de git no permitidas (-C, -c, --git-dir, --work-tree)."))
            }
            guard let s = sub else { return (argv, .ask("git sin subcomando.")) }
            let readOnly: Set<String> = ["status", "diff", "log", "show", "rev-parse", "ls-files", "blame", "describe", "shortlog"]
            if readOnly.contains(s) { return (argv, .allow) }
            if s == "branch" {
                let listing = args.dropFirst().allSatisfy { $0.hasPrefix("-") }
                return (argv, listing ? .allow : gate(true, "Crear o borrar ramas."))
            }
            if s == "add" { return (argv, gate(true, "Añadir al índice de git.")) }
            if s == "commit" {
                if args.contains("--amend") { return (argv, .ask("Reescribe el último commit.")) }
                return (argv, gate(true, "Crear un commit."))
            }
            if s == "reset" && args.contains("--hard") { return (argv, .deny("git reset --hard no está permitido.")) }
            if s == "clean" { return (argv, .deny("git clean no está permitido.")) }
            if s == "push" {
                if args.contains(where: { $0 == "--force" || $0 == "-f" || $0.hasPrefix("--force-with-lease") }) {
                    return (argv, .deny("git push forzado no está permitido."))
                }
                return (argv, .ask("Enviar commits a un servidor remoto (git push)."))
            }
            return (argv, .ask("git \(s) modifica el repositorio o usa la red."))

        case "swift":
            if let s = sub, ["build", "test"].contains(s) { return (argv, gate(true, "Compilar o probar el paquete Swift.")) }
            if args == ["--version"] { return (argv, .allow) }
            return (argv, .ask("Comando de swift fuera de la lista segura."))

        case "xcodebuild":
            if args == ["-version"] { return (argv, .allow) }
            if args.contains("build") || args.contains("test") || args.contains("-list") {
                return (argv, gate(true, "Compilar o probar con xcodebuild."))
            }
            return (argv, .ask("Comando de xcodebuild fuera de la lista segura."))

        case "npm", "pnpm", "yarn":
            if args == ["--version"] { return (argv, .allow) }
            if args.first == "test" || args == ["run", "test"] || args == ["run", "build"] ||
                args == ["run", "lint"] || args == ["run", "typecheck"] || args.first == "t" {
                return (argv, gate(true, "Ejecutar un script de \(name) definido en el proyecto."))
            }
            return (argv, .ask("\(name) puede descargar paquetes o ejecutar scripts."))

        case "cargo":
            if let s = sub, ["build", "test", "check", "clippy", "fmt"].contains(s) { return (argv, gate(true, "Compilar o probar con cargo.")) }
            return (argv, .ask("Comando de cargo fuera de la lista segura."))

        case "go":
            if let s = sub, ["build", "test", "vet"].contains(s) { return (argv, gate(true, "Compilar o probar con go.")) }
            return (argv, .ask("Comando de go fuera de la lista segura."))

        case "pytest":
            return (argv, gate(true, "Ejecutar pruebas con pytest."))

        case "python3", "python":
            if args.count >= 2, args[0] == "-m", ["pytest", "unittest"].contains(args[1]) {
                return (argv, gate(true, "Ejecutar pruebas de Python."))
            }
            return (argv, .ask("Ejecutar código de Python."))

        case "make":
            if let s = sub, ["test", "build", "check", "lint"].contains(s) { return (argv, gate(true, "Ejecutar un objetivo del Makefile.")) }
            return (argv, .ask("Objetivo de make fuera de la lista segura."))

        case "ls", "pwd", "wc", "head", "tail", "grep", "cat", "which", "echo", "date":
            return (argv, .allow)

        case "find":
            if args.contains(where: { $0 == "-exec" || $0 == "-delete" || $0 == "-ok" || $0 == "-execdir" }) {
                return (argv, .deny("find con -exec o -delete no está permitido."))
            }
            return (argv, .allow)

        default:
            return (argv, .ask("«\(name)» no está en la lista segura."))
        }
    }
}
