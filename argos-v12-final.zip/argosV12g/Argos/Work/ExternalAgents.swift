import Foundation

/// Delegación a agentes externos instalados en tu Mac (Claude Code, Codex).
/// Se lanzan en la carpeta del proyecto, sin shell, y su salida se muestra en vivo.
enum ExternalAgentKind: String, CaseIterable {
    case claude, codex
    var title: String { self == .claude ? "Claude Code" : "Codex" }
    var executable: String { self == .claude ? "claude" : "codex" }
}

struct ExternalAgentStatus {
    var kind: ExternalAgentKind
    var path: String?
    var version: String?
    var installed: Bool { path != nil }
}

enum ExternalAgents {
    static func detect() async -> [ExternalAgentStatus] {
        var out: [ExternalAgentStatus] = []
        for kind in ExternalAgentKind.allCases {
            guard let path = ProcessRunner.findExecutable(kind.executable) else {
                out.append(ExternalAgentStatus(kind: kind, path: nil, version: nil)); continue
            }
            let r = await ProcessRunner.run(path, ["--version"], cwd: FileManager.default.homeDirectoryForCurrentUser,
                                            timeout: 15, maxBytes: 4_000, env: ProcessRunner.inheritedEnvironment())
            let v = r.output.trimmingCharacters(in: .whitespacesAndNewlines).components(separatedBy: "\n").first
            out.append(ExternalAgentStatus(kind: kind, path: path, version: v))
        }
        return out
    }

    /// Lanza el agente externo con la tarea. Mientras corre, `onLine` recibe su salida.
    /// Claude Code se ejecuta en modo impresión con permisos acotados a la carpeta del proyecto.
    static func delegate(kind: ExternalAgentKind, path: String, task: String, root: URL,
                         onLine: @escaping (String) -> Void) async -> Int32 {
        let args: [String]
        switch kind {
        case .claude:
            args = ["-p", task, "--permission-mode", "acceptEdits",
                    "--allowedTools", "Read,Edit,Write,Glob,Grep,Bash(git status:*),Bash(git diff:*),Bash(git log:*),Bash(swift build:*),Bash(swift test:*),Bash(npm test:*)"]
        case .codex:
            args = ["exec", "--cd", root.path, "--sandbox", "workspace-write", task]
        }
        return await ProcessRunner.stream(path, args, cwd: root, env: ProcessRunner.inheritedEnvironment(),
                                          timeout: 1_200, onLine: onLine)
    }
}
