import Foundation
import Security

/// Proveedor de modelo para el agente propio. Dos protocolos cubren casi todo:
///  • Anthropic (Messages API).
///  • Cualquier servicio compatible con OpenAI: OpenAI, LM Studio, Ollama (/v1), Gemini (endpoint OpenAI).
struct WorkProvider: Codable, Identifiable, Equatable {
    enum Protocol: String, Codable { case anthropic, openAICompatible }
    enum Locality: String, Codable { case local, cloud }

    var id: String
    var title: String
    var protocolKind: Protocol
    var baseURL: String
    var model: String
    var locality: Locality
    var needsKey: Bool

    static let presets: [WorkProvider] = [
        WorkProvider(id: "anthropic", title: "Anthropic (Claude)", protocolKind: .anthropic,
                     baseURL: "https://api.anthropic.com", model: "", locality: .cloud, needsKey: true),
        WorkProvider(id: "openai", title: "OpenAI", protocolKind: .openAICompatible,
                     baseURL: "https://api.openai.com/v1", model: "", locality: .cloud, needsKey: true),
        WorkProvider(id: "gemini", title: "Gemini", protocolKind: .openAICompatible,
                     baseURL: "https://generativelanguage.googleapis.com/v1beta/openai", model: "", locality: .cloud, needsKey: true),
        WorkProvider(id: "lmstudio", title: "LM Studio (local)", protocolKind: .openAICompatible,
                     baseURL: "http://127.0.0.1:1234/v1", model: "", locality: .local, needsKey: false),
        WorkProvider(id: "ollama", title: "Ollama (local)", protocolKind: .openAICompatible,
                     baseURL: "http://127.0.0.1:11434/v1", model: "", locality: .local, needsKey: false)
    ]
}

enum WorkProviderError: LocalizedError {
    case noKey(String), noModel(String), http(Int, String), badResponse
    var errorDescription: String? {
        switch self {
        case .noKey(let p): return "Falta la clave de \(p) en Ajustes."
        case .noModel(let p): return "Elige un modelo para \(p) en Ajustes."
        case .http(let c, let b): return "El proveedor respondió \(c): \(b.prefix(200))"
        case .badResponse: return "Respuesta del proveedor no reconocida."
        }
    }
}

/// Claves de proveedores en el Llavero de macOS (una entrada por proveedor).
enum WorkKeyStore {
    static let service = "com.danielrueda.Argos.providers"

    static func save(_ key: String, for provider: String) {
        let q: [String: Any] = [kSecClass as String: kSecClassGenericPassword,
                                kSecAttrService as String: service, kSecAttrAccount as String: provider]
        SecItemDelete(q as CFDictionary)
        guard !key.isEmpty else { return }
        var add = q
        add[kSecValueData as String] = Data(key.utf8)
        SecItemAdd(add as CFDictionary, nil)
    }

    static func load(_ provider: String) -> String? {
        let q: [String: Any] = [kSecClass as String: kSecClassGenericPassword,
                                kSecAttrService as String: service, kSecAttrAccount as String: provider,
                                kSecReturnData as String: true, kSecMatchLimit as String: kSecMatchLimitOne]
        var out: CFTypeRef?
        guard SecItemCopyMatching(q as CFDictionary, &out) == errSecSuccess, let d = out as? Data else { return nil }
        return String(data: d, encoding: .utf8)
    }
}

/// Cliente mínimo para llamar al modelo elegido.
struct WorkModelClient {
    let provider: WorkProvider
    let model: String
    let maxTokens: Int

    func complete(system: String, user: String) async throws -> String {
        try await complete(system: system, messages: [("user", user)])
    }

    /// Conversación completa (roles user/assistant), con el sistema aparte.
    func complete(system: String, messages: [(String, String)]) async throws -> String {
        guard !model.isEmpty else { throw WorkProviderError.noModel(provider.title) }
        let key = provider.needsKey ? (WorkKeyStore.load(provider.id) ?? "") : ""
        if provider.needsKey && key.isEmpty { throw WorkProviderError.noKey(provider.title) }

        switch provider.protocolKind {
        case .anthropic:
            var req = URLRequest(url: URL(string: provider.baseURL + "/v1/messages")!)
            req.httpMethod = "POST"
            req.timeoutInterval = 120
            req.setValue(key, forHTTPHeaderField: "x-api-key")
            req.setValue("2023-06-01", forHTTPHeaderField: "anthropic-version")
            req.setValue("application/json", forHTTPHeaderField: "content-type")
            let body: [String: Any] = ["model": model, "max_tokens": maxTokens, "system": system,
                                       "messages": messages.map { ["role": $0.0, "content": $0.1] }]
            req.httpBody = try JSONSerialization.data(withJSONObject: body)
            let obj = try await send(req)
            guard let parts = obj["content"] as? [[String: Any]] else { throw WorkProviderError.badResponse }
            let text = parts.compactMap { $0["text"] as? String }.joined()
            guard !text.isEmpty else { throw WorkProviderError.badResponse }
            return text

        case .openAICompatible:
            var req = URLRequest(url: URL(string: provider.baseURL + "/chat/completions")!)
            req.httpMethod = "POST"
            req.timeoutInterval = 120
            req.setValue("application/json", forHTTPHeaderField: "Content-Type")
            if !key.isEmpty { req.setValue("Bearer \(key)", forHTTPHeaderField: "Authorization") }
            let body: [String: Any] = ["model": model, "max_tokens": maxTokens,
                                       "messages": [["role": "system", "content": system]] + messages.map { ["role": $0.0, "content": $0.1] }]
            req.httpBody = try JSONSerialization.data(withJSONObject: body)
            let obj = try await send(req)
            guard let choices = obj["choices"] as? [[String: Any]],
                  let msg = choices.first?["message"] as? [String: Any],
                  let text = msg["content"] as? String else { throw WorkProviderError.badResponse }
            return text
        }
    }

    private func send(_ req: URLRequest) async throws -> [String: Any] {
        let (data, resp) = try await URLSession.shared.data(for: req)
        let code = (resp as? HTTPURLResponse)?.statusCode ?? 0
        guard (200..<300).contains(code) else {
            throw WorkProviderError.http(code, String(data: data, encoding: .utf8) ?? "")
        }
        guard let obj = try JSONSerialization.jsonObject(with: data) as? [String: Any] else {
            throw WorkProviderError.badResponse
        }
        return obj
    }
}

/// Adapta el cliente al formato que usa NativeAgent: (sistema, transcripción) → texto.
extension WorkModelClient {
    func decider() -> (String, String) async -> String? {
        { system, transcript in
            try? await complete(system: system, user: transcript)
        }
    }
}

/// Backend de chat del Brain para el proveedor elegido en Ajustes › Trabajo.
/// Solo texto: las imágenes siguen yendo a OpenAI u Ollama.
struct CompatibleBackend: LLMBackend {
    let client: WorkModelClient

    var displayModelName: String { client.model }
    var displayVisionModelName: String { client.model }

    func chat(system: String, user: String) async throws -> String {
        try await client.complete(system: system, messages: [("user", user)])
    }

    func chat(system: String, history: [ChatMessage], user: String, forceJSON: Bool) async throws -> String {
        let past = history.filter { $0.role == "user" || $0.role == "assistant" }.map { ($0.role, $0.content) }
        return try await client.complete(system: system, messages: past + [("user", user)])
    }

    func plainChat(system: String, user: String) async throws -> String {
        try await client.complete(system: system, messages: [("user", user)])
    }

    func chatVision(system: String, user: String, imageJPEG: Data) async throws -> String {
        throw WorkProviderError.http(0, "Este proveedor no analiza imágenes en el chat. Para la pantalla usa Astra u Ollama.")
    }
}
