import Foundation

/// Ajustes del modo trabajo (UserDefaults). Las claves de proveedores van en el Llavero.
enum WorkSettings {
    static let workspaceKey = "argos.work.workspacePath"
    static let providerKey = "argos.work.providerID"
    static let modelKey = "argos.work.model"
    static let engineKey = "argos.work.engine"

    static var workspace: Workspace? {
        guard let path = UserDefaults.standard.string(forKey: workspaceKey), !path.isEmpty else { return nil }
        return Workspace(name: URL(fileURLWithPath: path).lastPathComponent, path: path)
    }

    static var provider: WorkProvider {
        let id = UserDefaults.standard.string(forKey: providerKey) ?? "anthropic"
        return WorkProvider.presets.first { $0.id == id } ?? WorkProvider.presets[0]
    }

    static var model: String {
        (UserDefaults.standard.string(forKey: modelKey) ?? "").trimmingCharacters(in: .whitespacesAndNewlines)
    }

    static var label: String {
        model.isEmpty ? "\(provider.title) · sin modelo" : "\(provider.title) · \(model)"
    }

    static func client(maxTokens: Int) -> WorkModelClient {
        WorkModelClient(provider: provider, model: model, maxTokens: maxTokens)
    }

    static var engine: WorkEngine {
        WorkEngine(rawValue: UserDefaults.standard.string(forKey: engineKey) ?? "native") ?? .native
    }
}
