import Foundation

/// Orquesta una tarea de un modo.
///  • Modos con repositorio: todo ocurre en una rama aislada (git worktree). Tu rama no se toca.
///    Al final puedes integrar la rama (git merge) o descartarla; ambas cosas piden aprobación.
///  • Modos sin repositorio (Documentos): los cambios se muestran y se escriben solo si los apruebas.
@MainActor
final class WorkCoordinator: ObservableObject {
    static let shared = WorkCoordinator()

    @Published private(set) var isRunning = false
    @Published private(set) var log: [WorkLogLine] = []
    @Published private(set) var pending: WorkApproval?
    @Published private(set) var result: WorkResult?

    private var waiter: CheckedContinuation<Bool, Never>?
    private var cancelled = false

    func append(_ style: WorkLogLine.Style, _ text: String) {
        log.append(WorkLogLine(style: style, text: String(text.prefix(2_000))))
        if log.count > 400 { log.removeFirst(log.count - 400) }
    }

    /// Como `append`, pero seguro desde cualquier hilo (la salida de procesos llega en segundo plano).
    nonisolated func appendFromBackground(_ style: WorkLogLine.Style, _ text: String) {
        Task { @MainActor in self.append(style, text) }
    }

    func cancel() {
        cancelled = true
        LiveProcesses.shared.terminateAll()
        finishWaiter(false)
    }

    /// Respuesta del usuario a la aprobación pendiente (aplicar, integrar o descartar).
    func answer(_ allow: Bool) {
        pending = nil
        finishWaiter(allow)
    }

    private func finishWaiter(_ allow: Bool) {
        let c = waiter
        waiter = nil
        c?.resume(returning: allow)
    }

    private func ask(_ approval: WorkApproval) async -> Bool {
        pending = approval
        return await withCheckedContinuation { waiter = $0 }
    }

    /// Ejecuta la tarea completa.
    func run(goal: String, profile: WorkProfile, engine: WorkEngine, workspace: Workspace?,
             brain: @escaping (_ system: String, _ transcript: String) async -> String?) async {
        guard !isRunning else { return }
        isRunning = true
        cancelled = false
        log = []
        result = nil
        defer { isRunning = false }

        // Carpeta de trabajo: el proyecto elegido o, en Documentos, ~/Documents/Argos.
        var root: URL? = workspace?.url
        if root == nil && !profile.needsWorkspace {
            root = Self.defaultDocumentsFolder()
        }
        guard let root else { append(.error, "Elige una carpeta de proyecto en este modo."); return }

        // Repositorio y rama aislada.
        var isolated: (path: URL, branch: String, base: String, repo: URL)?
        if profile.needsWorkspace {
            guard await GitService.isRepo(root) else {
                append(.error, "La carpeta no es un repositorio git. Inicialízalo con git init y vuelve a intentarlo.")
                return
            }
            do {
                let repo = await GitService.topLevel(root) ?? root
                let wt = try await GitService.createWorktree(repo: repo, task: goal)
                isolated = (wt.path, wt.branch, wt.base, repo)
                append(.info, "Trabajo en la rama \(wt.branch). Tu rama no se modifica hasta que la integres.")
            } catch {
                append(.error, error.localizedDescription)
                return
            }
        }
        let workRoot = isolated?.path ?? root

        // 1) Ejecutar el motor elegido dentro de workRoot.
        var summary = ""
        var proposals: [ProposedChange] = []
        var failed = false

        if engine == .native {
            let agent = NativeAgent(decide: brain,
                                    log: { [weak self] in self?.appendFromBackground(.tool, $0) },
                                    progress: { [weak self] s, total in self?.appendFromBackground(.info, "Paso \(s) de \(total)") })
            let outcome = await agent.run(goal: goal, profile: profile, root: workRoot)
            summary = outcome.summary
            proposals = outcome.changes
            failed = outcome.failure != nil
            if let f = outcome.failure { append(.error, f) }
        } else {
            let kind: ExternalAgentKind = engine == .claudeCode ? .claude : .codex
            guard let path = ProcessRunner.findExecutable(kind.executable) else {
                append(.error, "\(kind.title) no está instalado en este Mac.")
                cleanupIsolated(isolated)
                return
            }
            append(.info, "Lanzando \(kind.title) en \(workRoot.lastPathComponent)…")
            let code = await ExternalAgents.delegate(kind: kind, path: path, task: goal, root: workRoot) { [weak self] line in
                self?.appendFromBackground(.text, line)
            }
            failed = code != 0
            summary = failed ? "\(kind.title) terminó con código \(code)." : "\(kind.title) terminó."
        }

        if cancelled {
            cleanupIsolated(isolated)
            append(.info, "Tarea cancelada. No se aplicó nada.")
            return
        }

        // 2) Cambios propuestos por el agente propio.
        if let iso = isolated {
            // Se escriben dentro de la rama aislada, nunca en tu rama, y se confirman allí.
            for c in proposals {
                if let err = await Self.apply(c, in: iso.path) { append(.error, err) }
            }
            let committed = await GitService.commitAll(in: iso.path, message: "Argos: \(goal.prefix(60))")
            let files = committed ? await GitService.numstat(in: iso.path, base: iso.base) : []
            if files.isEmpty {
                append(.info, "No hubo cambios que guardar.")
                cleanupIsolated(isolated)
            } else {
                result = WorkResult(summary: summary, branch: iso.branch, worktree: iso.path, repo: iso.repo,
                                    base: iso.base, files: files)
                let add = files.reduce(0) { $0 + $1.added }
                let del = files.reduce(0) { $0 + $1.removed }
                append(failed ? .error : .result, summary)
                let integrate = await ask(WorkApproval(
                    title: "Integrar \(files.count) archivo(s) en tu rama (+\(add) −\(del))",
                    reason: "Rama \(iso.branch). Si dices que no, la rama se descarta y no se toca tu código.",
                    kind: .branch(iso.branch)))
                if integrate {
                    let merged = await GitService.merge(branch: iso.branch, into: iso.repo, message: "Argos: \(goal.prefix(60))")
                    append(merged ? .result : .error, merged ? "Integrado en tu rama." : "No pude integrar: revisa conflictos en el repositorio.")
                } else {
                    append(.info, "Rama descartada. Tu código no cambió.")
                }
                await GitService.removeWorktree(repo: iso.repo, path: iso.path, branch: iso.branch)
            }
            if !failed { return }
            return
        }

        // 3) Sin repositorio (Documentos): aprobar antes de escribir.
        if !proposals.isEmpty {
            let approved = await ask(WorkApproval(title: "Aplicar \(proposals.count) cambio(s)", reason: summary,
                                                  kind: .changes(proposals)))
            if approved {
                for c in proposals {
                    if let err = await Self.apply(c, in: root) { append(.error, err) }
                    else { append(.result, "Aplicado: \(c.path)") }
                }
            } else {
                append(.info, "Cambios descartados.")
            }
        }
        append(failed ? .error : .result, summary)
    }

    private func cleanupIsolated(_ iso: (path: URL, branch: String, base: String, repo: URL)?) {
        guard let iso else { return }
        Task { await GitService.removeWorktree(repo: iso.repo, path: iso.path, branch: iso.branch) }
    }

    static func defaultDocumentsFolder() -> URL {
        let docs = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first
            ?? URL(fileURLWithPath: NSHomeDirectory() + "/Documents")
        let dir = docs.appendingPathComponent("Argos", isDirectory: true)
        try? FileManager.default.createDirectory(at: dir, withIntermediateDirectories: true)
        return dir
    }

    /// Escribe un cambio dentro de `root`. Async para poder exportar a PDF/DOCX sin bloquear.
    static func apply(_ c: ProposedChange, in root: URL) async -> String? {
        let url = root.appendingPathComponent(c.path)
        do {
            switch c.kind {
            case .delete:
                try FileManager.default.removeItem(at: url)
            case .create, .modify:
                try FileManager.default.createDirectory(at: url.deletingLastPathComponent(), withIntermediateDirectories: true)
                if let fmt = c.exportFormat {
                    if let err = await DocumentExporter.export(content: c.newText ?? "", format: fmt, to: url) { return err }
                } else {
                    try (c.newText ?? "").write(to: url, atomically: true, encoding: .utf8)
                }
            }
            return nil
        } catch {
            return "No pude aplicar \(c.path): \(error.localizedDescription)"
        }
    }
}
