import Foundation

/// Operaciones de git con `Process` (sin shell). Se usan para trabajar en una rama aislada.
enum GitService {
    static var gitPath: String { ProcessRunner.findExecutable("git") ?? "/usr/bin/git" }

    static func run(_ args: [String], in dir: URL, timeout: TimeInterval = 90) async -> CommandResult {
        await ProcessRunner.run(gitPath, args, cwd: dir, timeout: timeout)
    }

    static func isRepo(_ dir: URL) async -> Bool {
        let r = await run(["rev-parse", "--is-inside-work-tree"], in: dir, timeout: 15)
        return r.exitCode == 0 && r.output.trimmingCharacters(in: .whitespacesAndNewlines) == "true"
    }

    static func topLevel(_ dir: URL) async -> URL? {
        let r = await run(["rev-parse", "--show-toplevel"], in: dir, timeout: 15)
        guard r.exitCode == 0 else { return nil }
        let p = r.output.trimmingCharacters(in: .whitespacesAndNewlines)
        return p.isEmpty ? nil : URL(fileURLWithPath: p, isDirectory: true)
    }

    static func head(_ dir: URL) async -> String? {
        let r = await run(["rev-parse", "HEAD"], in: dir, timeout: 15)
        guard r.exitCode == 0 else { return nil }
        return r.output.trimmingCharacters(in: .whitespacesAndNewlines)
    }

    static func slug(_ text: String) -> String {
        let folded = text.folding(options: [.diacriticInsensitive, .caseInsensitive], locale: nil)
        let words = folded.split { !$0.isLetter && !$0.isNumber }.prefix(4).map(String.init)
        let s = words.joined(separator: "-")
        return s.isEmpty ? "tarea" : String(s.prefix(40))
    }

    static func worktreesDirectory() -> URL {
        let base = FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask).first
            ?? URL(fileURLWithPath: NSHomeDirectory() + "/Library/Application Support")
        let dir = base.appendingPathComponent("Argos/worktrees", isDirectory: true)
        try? FileManager.default.createDirectory(at: dir, withIntermediateDirectories: true)
        return dir
    }

    /// Crea una rama nueva en un worktree propio, a partir del último commit.
    static func createWorktree(repo: URL, task: String) async throws -> (path: URL, branch: String, base: String) {
        guard let base = await head(repo) else {
            throw WorkError.message("El repositorio no tiene ningún commit todavía. Haz un primer commit y vuelve a intentarlo.")
        }
        let stamp = Int(Date().timeIntervalSince1970)
        let branch = "argos/\(slug(task))-\(stamp)"
        let path = worktreesDirectory().appendingPathComponent("\(repo.lastPathComponent)-\(stamp)", isDirectory: true)
        let r = await run(["worktree", "add", "-b", branch, path.path, base], in: repo, timeout: 120)
        guard r.exitCode == 0 else {
            throw WorkError.message("No pude crear la rama aislada: \(r.output.prefix(300))")
        }
        return (path, branch, base)
    }

    static func removeWorktree(repo: URL, path: URL, branch: String) async {
        _ = await run(["worktree", "remove", "--force", path.path], in: repo, timeout: 60)
        _ = await run(["branch", "-D", branch], in: repo, timeout: 30)
    }

    /// Guarda todo lo que haya en el worktree como un commit. Devuelve true si había cambios.
    static func commitAll(in dir: URL, message: String) async -> Bool {
        _ = await run(["add", "-A"], in: dir, timeout: 60)
        let status = await run(["status", "--porcelain"], in: dir, timeout: 30)
        guard !status.output.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else { return false }
        let r = await run(["-c", "user.name=Argos", "-c", "user.email=argos@localhost", "-c", "commit.gpgsign=false",
                           "commit", "--no-verify", "-m", message], in: dir, timeout: 60)
        return r.exitCode == 0
    }

    static func numstat(in dir: URL, base: String) async -> [WorkResultFile] {
        let r = await run(["diff", "--numstat", base, "HEAD"], in: dir, timeout: 60)
        guard r.exitCode == 0 else { return [] }
        return r.output.split(separator: "\n").compactMap { line in
            let parts = line.split(separator: "\t", maxSplits: 2).map(String.init)
            guard parts.count == 3 else { return nil }
            return WorkResultFile(path: parts[2], added: Int(parts[0]) ?? 0, removed: Int(parts[1]) ?? 0)
        }
    }

    static func fileDiff(in dir: URL, base: String, path: String) async -> String {
        let r = await run(["diff", base, "HEAD", "--", path], in: dir, timeout: 60)
        return String(r.output.prefix(24_000))
    }

    /// Integra la rama de la tarea en la rama actual del repositorio del usuario (sin fast-forward).
    static func merge(branch: String, into repo: URL, message: String) async -> Bool {
        let r = await run(["merge", "--no-ff", "-m", message, branch], in: repo, timeout: 120)
        if r.exitCode != 0 { _ = await run(["merge", "--abort"], in: repo, timeout: 30) }
        return r.exitCode == 0
    }
}
