import Foundation

/// Carpeta de proyecto en la que un modo puede trabajar.
struct Workspace: Codable, Identifiable, Equatable {
    var id = UUID()
    var name: String
    var path: String
    var url: URL { URL(fileURLWithPath: path, isDirectory: true) }
}

/// Quién hace el trabajo: el agente propio de Argos o un agente externo en tu Mac.
enum WorkEngine: String, Codable, CaseIterable, Identifiable {
    case native, claudeCode, codex
    var id: String { rawValue }
    var title: String {
        switch self {
        case .native: return "Argos"
        case .claudeCode: return "Claude Code"
        case .codex: return "Codex"
        }
    }
}

/// Un «modo»: instrucciones, herramientas permitidas y modelo para un tipo de trabajo.
struct WorkProfile: Codable, Identifiable, Equatable {
    var id: String
    var name: String
    var symbol: String
    var summary: String
    var systemPrompt: String
    var tools: [String]
    var providerID: String
    var model: String
    var needsWorkspace: Bool
    var useWorktree: Bool
    var canDelegate: Bool

    static let defaults: [WorkProfile] = [
        WorkProfile(
            id: "programar", name: "Programar", symbol: "chevron.left.forwardslash.chevron.right",
            summary: "Lee y edita tu repositorio, ejecuta pruebas y usa git en una rama aislada.",
            systemPrompt: "Eres Argos en modo Programar: un ingeniero de software cuidadoso. Explora el proyecto antes de cambiarlo (list_dir, search, read_file), haz cambios pequeños y coherentes con el estilo existente, y verifica con las pruebas o la compilación cuando existan. Cuando termines, haz un commit con un mensaje claro usando git add y git commit. Resume qué hiciste y qué falta.",
            tools: ["list_dir", "read_file", "search", "write_file", "edit_file", "delete_file", "run_command"],
            providerID: "anthropic", model: "", needsWorkspace: true, useWorktree: true, canDelegate: true),
        WorkProfile(
            id: "documentos", name: "Documentos", symbol: "doc.richtext",
            summary: "Crea y edita documentos: Markdown, HTML, CSV, JSON, Word (docx), RTF y PDF.",
            systemPrompt: "Eres Argos en modo Documentos: un redactor y analista. Lee los materiales de la carpeta si hacen falta y crea los archivos pedidos con write_file o create_document. Para docx, rtf y pdf escribe el contenido como HTML limpio (títulos, listas, tablas). Resume lo que creaste.",
            tools: ["list_dir", "read_file", "search", "write_file", "edit_file", "create_document"],
            providerID: "anthropic", model: "", needsWorkspace: false, useWorktree: false, canDelegate: false),
        WorkProfile(
            id: "revisar", name: "Revisar", symbol: "magnifyingglass",
            summary: "Solo lectura: revisa código, busca errores y propone mejoras sin modificar nada.",
            systemPrompt: "Eres Argos en modo Revisar: un revisor de código riguroso. Solo puedes leer. Busca errores, riesgos de seguridad y mejoras; cita archivo y línea; ordena los hallazgos por gravedad y propón arreglos concretos sin aplicarlos.",
            tools: ["list_dir", "read_file", "search"],
            providerID: "anthropic", model: "", needsWorkspace: true, useWorktree: false, canDelegate: true)
    ]
}

enum ChangeKind: String { case create, modify, delete }

/// Cambio propuesto sobre un archivo. No se escribe en disco hasta que el usuario lo aprueba.
struct ProposedChange: Identifiable {
    let id = UUID()
    var kind: ChangeKind
    var path: String
    var oldText: String?
    var newText: String?
    var exportFormat: String?
    var added: Int
    var removed: Int
    var diff: String
}

struct WorkLogLine: Identifiable {
    enum Style { case info, tool, text, error, result }
    let id = UUID()
    var style: Style
    var text: String
}

struct WorkApproval: Identifiable {
    enum Kind {
        case changes([ProposedChange])
        case command(String)
        case branch(String)
    }
    let id = UUID()
    var title: String
    var reason: String
    var kind: Kind
}

struct WorkResultFile: Identifiable {
    var id: String { path }
    var path: String
    var added: Int
    var removed: Int
}

/// Resultado de una tarea en rama aislada (git worktree), pendiente de revisión.
struct WorkResult {
    var summary: String
    var branch: String
    var worktree: URL
    var repo: URL
    var base: String
    var files: [WorkResultFile]
}
