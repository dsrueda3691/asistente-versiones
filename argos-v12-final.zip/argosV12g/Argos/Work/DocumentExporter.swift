import Foundation
import AppKit

/// Convierte HTML a DOCX, RTF y PDF usando herramientas nativas de macOS.
enum DocumentExporter {
    /// Asegura que el texto sea HTML: si no lo es, lo envuelve en un documento sencillo.
    static func htmlDocument(from content: String) -> String {
        let trimmed = content.trimmingCharacters(in: .whitespacesAndNewlines)
        if trimmed.lowercased().contains("<html") || trimmed.lowercased().contains("<body") { return trimmed }
        let escaped = trimmed.replacingOccurrences(of: "&", with: "&amp;")
            .replacingOccurrences(of: "<", with: "&lt;").replacingOccurrences(of: ">", with: "&gt;")
        let body = escaped.components(separatedBy: "\n\n").map { "<p>" + $0.replacingOccurrences(of: "\n", with: "<br>") + "</p>" }
        return "<html><head><meta charset=\"utf-8\"></head><body style=\"font-family:-apple-system,Helvetica;font-size:12pt\">\(body.joined())</body></html>"
    }

    /// Escribe `content` como `format` en `destination`. Devuelve el mensaje de resultado.
    static func export(content: String, format: String, to destination: URL) async -> String? {
        let html = htmlDocument(from: content)
        let tmp = FileManager.default.temporaryDirectory.appendingPathComponent("argos-\(UUID().uuidString).html")
        do { try html.write(to: tmp, atomically: true, encoding: .utf8) } catch { return "No pude preparar el documento." }
        defer { try? FileManager.default.removeItem(at: tmp) }

        switch format {
        case "docx":
            let r = await ProcessRunner.run("/usr/bin/textutil", ["-convert", "docx", "-output", destination.path, tmp.path],
                                            cwd: tmp.deletingLastPathComponent(), timeout: 60)
            return r.exitCode == 0 ? nil : "textutil no pudo generar el .docx: \(r.output.prefix(200))"
        case "rtf":
            let r = await ProcessRunner.run("/usr/bin/textutil", ["-convert", "rtf", "-output", destination.path, tmp.path],
                                            cwd: tmp.deletingLastPathComponent(), timeout: 60)
            return r.exitCode == 0 ? nil : "textutil no pudo generar el .rtf."
        case "pdf":
            return await MainActor.run { renderPDF(html: html, to: destination) }
        default:
            return "Formato no soportado."
        }
    }

    @MainActor
    private static func renderPDF(html: String, to destination: URL) -> String? {
        guard let data = html.data(using: .utf8),
              let attributed = try? NSAttributedString(data: data,
                                                       options: [.documentType: NSAttributedString.DocumentType.html,
                                                                 .characterEncoding: String.Encoding.utf8.rawValue],
                                                       documentAttributes: nil) else {
            return "No pude interpretar el HTML para el PDF."
        }
        let printInfo = NSPrintInfo()
        printInfo.paperSize = NSSize(width: 595, height: 842)
        printInfo.topMargin = 56; printInfo.bottomMargin = 56; printInfo.leftMargin = 56; printInfo.rightMargin = 56
        printInfo.jobDisposition = .save
        printInfo.dictionary()[NSPrintInfo.AttributeKey.jobSavingURL] = destination
        let width = printInfo.paperSize.width - 112
        let view = NSTextView(frame: NSRect(x: 0, y: 0, width: width, height: 10))
        view.textStorage?.setAttributedString(attributed)
        view.textContainer?.containerSize = NSSize(width: width, height: .greatestFiniteMagnitude)
        view.textContainer?.widthTracksTextView = true
        view.sizeToFit()
        let op = NSPrintOperation(view: view, printInfo: printInfo)
        op.showsPrintPanel = false
        op.showsProgressPanel = false
        return op.run() ? nil : "No pude generar el PDF."
    }
}
