import Foundation

/// Herramientas que el agente propio puede usar. Cada una se ejecuta dentro de la carpeta del proyecto.
enum WorkToolName: String, CaseIterable {
    case listDir = "list_dir", readFile = "read_file", search = "search"
    case writeFile = "write_file", editFile = "edit_file", deleteFile = "delete_file"
    case runCommand = "run_command", createDocument = "create_document", finish = "finish"
}

struct WorkToolCall {
    var name: String
    var args: [String: String]
}

/// Ejecuta herramientas del agente. Las escrituras NO tocan el disco: devuelven cambios propuestos.
struct WorkToolbox {
    let sandbox: WorkspaceSandbox
    let allowed: Set<String>
    let isolated: Bool
    /// Cambios propuestos durante la tarea (se aplican solo tras aprobación).
    var proposed: [String: ProposedChange] = [:]
    var commands: [String] = []

    static let maxReadBytes = 60_000

    init(sandbox: WorkspaceSandbox, allowed: [String], isolated: Bool) {
        self.sandbox = sandbox
        self.allowed = Set(allowed)
        self.isolated = isolated
    }

    /// Catálogo en texto para el prompt del modelo.
    static func catalogPrompt(allowed: [String]) -> String {
        let all: [(String, String)] = [
            ("list_dir", "path: lista archivos y carpetas de una ruta relativa (\".\" para la raíz)."),
            ("read_file", "path: lee un archivo de texto (hasta 60 KB)."),
            ("search", "query: busca texto en el proyecto y devuelve archivo:línea."),
            ("write_file", "path, content: crea o reemplaza un archivo (queda como cambio propuesto)."),
            ("edit_file", "path, old, new: reemplaza un fragmento único del archivo (queda como cambio propuesto)."),
            ("delete_file", "path: borra un archivo (queda como cambio propuesto)."),
            ("run_command", "command: un comando de la lista segura (p. ej. swift build, npm test, git status)."),
            ("create_document", "path, content: crea un documento; .docx, .rtf y .pdf se generan desde HTML."),
            ("finish", "summary: termina la tarea con un resumen.")
        ]
        return all.filter { allowed.contains($0.0) }.map { "- \($0.0): \($0.1)" }.joined(separator: "\n")
    }

    /// Ejecuta una herramienta y devuelve el texto de resultado para el modelo.
    mutating func execute(_ call: WorkToolCall, log: (String) -> Void) async -> String {
        guard allowed.contains(call.name) else {
            return "Herramienta no permitida en este modo: \(call.name)."
        }
        switch call.name {
        case "list_dir": return listDir(call.args["path"] ?? ".")
        case "read_file": return readFile(call.args["path"] ?? "")
        case "search": return await search(call.args["query"] ?? "")
        case "write_file": return stage(path: call.args["path"] ?? "", newText: call.args["content"] ?? "", kind: .create)
        case "edit_file": return edit(path: call.args["path"] ?? "", old: call.args["old"] ?? "", new: call.args["new"] ?? "")
        case "delete_file": return deleteFile(call.args["path"] ?? "")
        case "create_document": return stageDocument(path: call.args["path"] ?? "", content: call.args["content"] ?? "")
        case "run_command":
            return await runCommand(call.args["command"] ?? "", log: log)
        default:
            return "Herramienta desconocida: \(call.name)."
        }
    }

    // MARK: Lectura

    private func listDir(_ path: String) -> String {
        do {
            let url = path == "." || path.isEmpty ? sandbox.root : try sandbox.resolve(path)
            let items = try FileManager.default.contentsOfDirectory(at: url, includingPropertiesForKeys: [.isDirectoryKey])
                .filter { !WorkspaceSandbox.ignoredDirectories.contains($0.lastPathComponent) && !WorkspaceSandbox.isSensitive($0) }
                .sorted { $0.lastPathComponent < $1.lastPathComponent }
            let lines = items.prefix(300).map { item -> String in
                let isDir = (try? item.resourceValues(forKeys: [.isDirectoryKey]).isDirectory) ?? false
                return (isDir ? "[dir] " : "      ") + item.lastPathComponent
            }
            return lines.isEmpty ? "(vacío)" : lines.joined(separator: "\n")
        } catch { return "Error: \(error.localizedDescription)" }
    }

    private func readFile(_ path: String) -> String {
        do {
            let url = try sandbox.resolve(path)
            guard !WorkspaceSandbox.isSensitive(url) else { return "Ese archivo parece contener secretos y no se lee." }
            let data = try Data(contentsOf: url)
            guard data.count <= Self.maxReadBytes * 2 else { return "Archivo demasiado grande (\(data.count) bytes)." }
            guard let text = String(data: data, encoding: .utf8) else { return "El archivo no es texto UTF-8." }
            return String(text.prefix(Self.maxReadBytes))
        } catch { return "Error: \(error.localizedDescription)" }
    }

    private func search(_ query: String) async -> String {
        let q = query.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !q.isEmpty else { return "Búsqueda vacía." }
        let r = await ProcessRunner.run("/usr/bin/grep",
                                        ["-rIn", "--exclude-dir=.git", "--exclude-dir=node_modules", "--exclude-dir=.build",
                                         "--exclude-dir=DerivedData", "-F", "-m", "5", "--", q, "."],
                                        cwd: sandbox.root, timeout: 30, maxBytes: 40_000)
        let lines = r.output.split(separator: "\n").prefix(80)
        return lines.isEmpty ? "Sin resultados." : lines.joined(separator: "\n")
    }

    // MARK: Escritura propuesta (no toca el disco)

    private mutating func stage(path: String, newText: String, kind: ChangeKind, oldText: String? = nil) -> String {
        do {
            let url = try sandbox.resolve(path)
            guard !sandbox.isInsideGitDirectory(url) else { return "No se puede modificar .git." }
            guard !WorkspaceSandbox.isSensitive(url) else { return "No se escriben archivos de secretos." }
            let before = oldText ?? (try? String(contentsOf: url, encoding: .utf8))
            let rel = sandbox.relativePath(url)
            let d = DiffEngine.unified(old: before, new: newText, path: rel)
            let change = ProposedChange(kind: before == nil ? .create : kind, path: rel, oldText: before,
                                        newText: newText, exportFormat: nil, added: d.added, removed: d.removed, diff: d.text)
            proposed[rel] = change
            return "Cambio propuesto en \(rel) (+\(d.added) −\(d.removed)). Se aplicará si el usuario lo aprueba."
        } catch { return "Error: \(error.localizedDescription)" }
    }

    private mutating func edit(path: String, old: String, new: String) -> String {
        do {
            let url = try sandbox.resolve(path)
            let current = try String(contentsOf: url, encoding: .utf8)
            let count = current.components(separatedBy: old).count - 1
            guard !old.isEmpty else { return "El fragmento a reemplazar está vacío." }
            guard count == 1 else { return "El fragmento aparece \(count) veces; amplía el contexto para que sea único." }
            let updated = current.replacingOccurrences(of: old, with: new)
            return stage(path: path, newText: updated, kind: .modify, oldText: current)
        } catch { return "Error: \(error.localizedDescription)" }
    }

    private mutating func deleteFile(_ path: String) -> String {
        do {
            let url = try sandbox.resolve(path)
            guard !sandbox.isInsideGitDirectory(url) else { return "No se puede borrar .git." }
            guard let before = try? String(contentsOf: url, encoding: .utf8) else { return "No existe o no es texto." }
            let rel = sandbox.relativePath(url)
            let d = DiffEngine.unified(old: before, new: nil, path: rel)
            proposed[rel] = ProposedChange(kind: .delete, path: rel, oldText: before, newText: nil, exportFormat: nil,
                                           added: 0, removed: d.removed, diff: d.text)
            return "Borrado propuesto de \(rel). Se aplicará si el usuario lo aprueba."
        } catch { return "Error: \(error.localizedDescription)" }
    }

    private mutating func stageDocument(path: String, content: String) -> String {
        let ext = (path as NSString).pathExtension.lowercased()
        guard ["md", "txt", "html", "csv", "json", "docx", "rtf", "pdf"].contains(ext) else {
            return "Formato no soportado: .\(ext)."
        }
        let r = stage(path: path, newText: content, kind: .create)
        if ["docx", "rtf", "pdf"].contains(ext), var c = proposed[path.hasPrefix("./") ? String(path.dropFirst(2)) : path] {
            c.exportFormat = ext
            proposed[c.path] = c
        }
        return r
    }

    // MARK: Comandos

    private mutating func runCommand(_ raw: String, log: (String) -> Void) async -> String {
        let (argv, decision) = CommandPolicy.evaluate(raw, isolated: isolated)
        switch decision {
        case .deny(let why): return "Comando bloqueado: \(why)"
        case .ask(let why):
            return "Este comando necesita aprobación del usuario (\(why)). No se ejecutó. Continúa sin él o termina la tarea."
        case .allow:
            guard let exe = ProcessRunner.findExecutable(argv[0]) else {
                return "No encuentro el ejecutable «\(argv[0])»."
            }
            commands.append(raw)
            log("$ \(raw)")
            let r = await ProcessRunner.run(exe, Array(argv.dropFirst()), cwd: sandbox.root, timeout: 300, maxBytes: 60_000)
            let tail = String(r.output.suffix(6_000))
            let status = r.timedOut ? "Tiempo agotado." : "Código de salida \(r.exitCode)."
            return "\(status)\n\(tail)"
        }
    }
}
