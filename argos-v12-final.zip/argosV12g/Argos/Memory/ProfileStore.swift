import Foundation
import Combine

/// Perfil persistente y explícito del usuario. Solo guarda datos que Argos haya
/// aprendido por una instrucción explícita o por una regla heurística clara.
@MainActor
final class ProfileStore: ObservableObject {
    struct Profile: Codable, Equatable {
        var preferredResponseStyle: String = ""
        var projects: [String] = []
        var importantPeople: [String: String] = [:]
        var preferences: [String: String] = [:]
        var habitualHours: [String: String] = [:]
        var updatedAt: Date = Date()
    }

    @Published private(set) var profile = Profile()

    private static var storageURL: URL {
        let base = FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask).first
            ?? URL(fileURLWithPath: NSHomeDirectory()).appendingPathComponent("Library/Application Support")
        return base.appendingPathComponent("Argos", isDirectory: true).appendingPathComponent("profile.json")
    }

    func load() {
        guard let data = try? Data(contentsOf: Self.storageURL),
              let value = try? JSONDecoder().decode(Profile.self, from: data) else { return }
        profile = value
    }

    func save() {
        do {
            let dir = Self.storageURL.deletingLastPathComponent()
            try FileManager.default.createDirectory(at: dir, withIntermediateDirectories: true)
            try JSONEncoder().encode(profile).write(to: Self.storageURL, options: [.atomic])
        } catch { }
    }

    func setPreference(_ key: String, value: String) {
        profile.preferences[key] = value
        profile.updatedAt = Date()
        save()
    }

    func setPerson(_ name: String, relation: String) {
        let cleanName = name.trimmingCharacters(in: .whitespacesAndNewlines)
        let cleanRelation = relation.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !cleanName.isEmpty, !cleanRelation.isEmpty else { return }
        profile.importantPeople[cleanRelation] = cleanName
        profile.updatedAt = Date()
        save()
    }

    func addProject(_ project: String) {
        let clean = project.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !clean.isEmpty else { return }
        if !profile.projects.contains(where: { $0.caseInsensitiveCompare(clean) == .orderedSame }) {
            profile.projects.append(clean)
            profile.updatedAt = Date()
            save()
        }
    }

    func summary() -> String {
        var rows: [String] = []
        if !profile.preferredResponseStyle.isEmpty { rows.append("Estilo: \(profile.preferredResponseStyle)") }
        if !profile.projects.isEmpty { rows.append("Proyectos: \(profile.projects.joined(separator: ", "))") }
        for (relation, name) in profile.importantPeople.sorted(by: { $0.key < $1.key }) {
            rows.append("\(relation): \(name)")
        }
        for (key, value) in profile.preferences.sorted(by: { $0.key < $1.key }) {
            rows.append("Preferencia \(key): \(value)")
        }
        return rows.joined(separator: "\n")
    }

    func clear() {
        profile = Profile()
        save()
    }
}
