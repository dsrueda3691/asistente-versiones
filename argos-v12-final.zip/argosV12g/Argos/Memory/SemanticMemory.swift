import Foundation

/// Memoria semántica local. Los embeddings se generan con Ollama; si Ollama no
/// está disponible, la búsqueda degrada a coincidencia textual sin enviar datos.
@MainActor
final class SemanticMemory {
    struct Item: Codable, Equatable, Identifiable {
        let id: UUID
        let text: String
        let kind: String
        let createdAt: Date
        var embedding: [Double]?
    }

    struct Match: Equatable {
        let item: Item
        let score: Double
    }

    private(set) var items: [Item] = []
    private let ollama = OllamaClient()
    private let embeddingModel: String
    private static var storageURL: URL {
        let base = FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask).first
            ?? URL(fileURLWithPath: NSHomeDirectory()).appendingPathComponent("Library/Application Support")
        return base.appendingPathComponent("Argos", isDirectory: true).appendingPathComponent("semantic-memory.json")
    }

    init() {
        let configured = UserDefaults.standard.string(forKey: "argos.embeddingModel")?.trimmingCharacters(in: .whitespacesAndNewlines) ?? ""
        embeddingModel = configured.isEmpty ? "nomic-embed-text" : configured
    }

    func load() {
        guard let data = try? Data(contentsOf: Self.storageURL),
              let value = try? JSONDecoder().decode([Item].self, from: data) else { return }
        items = value
    }

    func add(_ text: String, kind: String = "fact", generateEmbedding: Bool = true) async {
        let clean = text.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !clean.isEmpty else { return }
        if items.contains(where: { $0.text.caseInsensitiveCompare(clean) == .orderedSame }) { return }
        var item = Item(id: UUID(), text: clean, kind: kind, createdAt: Date(), embedding: nil)
        if generateEmbedding {
            item.embedding = try? await ollama.embedding(text: clean, model: embeddingModel)
        }
        items.append(item)
        save()
    }

    func remove(matching query: String) {
        let q = query.trimmingCharacters(in: .whitespacesAndNewlines).lowercased()
        guard !q.isEmpty else { return }
        items.removeAll { $0.text.lowercased().contains(q) }
        save()
    }

    func clear() {
        items.removeAll()
        save()
    }

    func search(_ query: String, limit: Int = 6) async -> [Match] {
        let q = query.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !q.isEmpty, !items.isEmpty else { return [] }
        if let vector = try? await ollama.embedding(text: q, model: embeddingModel) {
            return items.map { item in
                Match(item: item, score: cosine(vector, item.embedding ?? []))
            }.filter { $0.score > 0.15 }
                .sorted { $0.score > $1.score }
                .prefix(limit)
                .map { $0 }
        }
        let tokens = Set(q.lowercased().split(whereSeparator: { !$0.isLetter && !$0.isNumber }).map(String.init))
        return items.map { item in
            let itemTokens = Set(item.text.lowercased().split(whereSeparator: { !$0.isLetter && !$0.isNumber }).map(String.init))
            let overlap = Double(tokens.intersection(itemTokens).count)
            let score = overlap / Double(max(tokens.count, 1))
            return Match(item: item, score: score)
        }.filter { $0.score > 0 }.sorted { $0.score > $1.score }.prefix(limit).map { $0 }
    }

    private func cosine(_ a: [Double], _ b: [Double]) -> Double {
        guard !a.isEmpty, a.count == b.count else { return 0 }
        var dot = 0.0, aa = 0.0, bb = 0.0
        for i in a.indices {
            dot += a[i] * b[i]
            aa += a[i] * a[i]
            bb += b[i] * b[i]
        }
        guard aa > 0, bb > 0 else { return 0 }
        return dot / (sqrt(aa) * sqrt(bb))
    }

    private func save() {
        do {
            let dir = Self.storageURL.deletingLastPathComponent()
            try FileManager.default.createDirectory(at: dir, withIntermediateDirectories: true)
            try JSONEncoder().encode(items).write(to: Self.storageURL, options: [.atomic])
        } catch { }
    }
}
