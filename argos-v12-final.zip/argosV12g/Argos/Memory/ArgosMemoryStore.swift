import Foundation
import Combine

/// Fachada de memoria de largo plazo: perfil + memoria semántica + reglas de
/// extracción conservadoras. La memoria se mantiene local y es revisable.
@MainActor
final class ArgosMemoryStore: ObservableObject {
    let profile = ProfileStore()
    let semantic = SemanticMemory()

    func load() {
        profile.load()
        semantic.load()
    }

    func remember(_ text: String, kind: String = "fact") async {
        await semantic.add(text, kind: kind)
    }

    func recall(_ query: String, limit: Int = 6) async -> String {
        let matches = await semantic.search(query, limit: limit)
        var rows: [String] = []
        let profileText = profile.summary()
        if !profileText.isEmpty { rows.append("PERFIL:\n\(profileText)") }
        if !matches.isEmpty {
            rows.append("MEMORIA:\n" + matches.map { "- \($0.item.text)" }.joined(separator: "\n"))
        }
        return rows.joined(separator: "\n\n")
    }

    func forget(_ query: String) {
        semantic.remove(matching: query)
    }

    func clear() {
        profile.clear()
        semantic.clear()
    }

    /// Extrae solo patrones inequívocos escritos por el usuario. No manda el
    /// texto a la nube ni inventa relaciones.
    func considerExplicitPatterns(_ text: String) async {
        let clean = text.trimmingCharacters(in: .whitespacesAndNewlines)
        let lower = clean.lowercased()
        if lower.hasPrefix("recuerda que ") {
            let fact = String(clean.dropFirst("recuerda que ".count))
            await remember(fact, kind: "explicit")
            return
        }
        if lower.hasPrefix("mi jefe se llama ") {
            let name = String(clean.dropFirst("mi jefe se llama ".count))
            profile.setPerson(name, relation: "jefe")
            await remember("El jefe del usuario se llama \(name)", kind: "profile")
            return
        }
        if lower.hasPrefix("prefiero ") {
            let value = String(clean.dropFirst("prefiero ".count))
            profile.setPreference("general", value: value)
            await remember("El usuario prefiere \(value)", kind: "preference")
            return
        }
        if lower.hasPrefix("estoy trabajando en ") {
            let project = String(clean.dropFirst("estoy trabajando en ".count))
            profile.addProject(project)
            await remember("El usuario está trabajando en \(project)", kind: "project")
        }
    }
}
