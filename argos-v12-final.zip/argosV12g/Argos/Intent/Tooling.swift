import Foundation

enum ArgosToolRisk: String, Codable {
    case readOnly
    case approvalRequired
    case localSensitive
}

struct ArgosToolDefinition: Identifiable, Equatable {
    let id: String
    let description: String
    let risk: ArgosToolRisk
    let enabled: Bool
}

/// Catálogo estable para que el Brain y AgentMode hablen en términos de
/// herramientas, no de comandos arbitrarios.
struct ArgosToolCatalog {
    static let all: [ArgosToolDefinition] = [
        .init(id: "search_memory", description: "Buscar recuerdos semánticos y perfil", risk: .readOnly, enabled: true),
        .init(id: "get_calendar", description: "Consultar calendario", risk: .readOnly, enabled: true),
        .init(id: "get_goals", description: "Consultar objetivos", risk: .readOnly, enabled: true),
        .init(id: "search_mail", description: "Consultar correo permitido", risk: .readOnly, enabled: true),
        .init(id: "read_document", description: "Leer un documento que el usuario adjuntó o autorizó", risk: .localSensitive, enabled: true),
        .init(id: "draft_email", description: "Preparar un correo sin enviarlo", risk: .approvalRequired, enabled: true),
        .init(id: "create_reminder", description: "Crear recordatorio", risk: .approvalRequired, enabled: true),
        .init(id: "create_calendar_event", description: "Crear evento", risk: .approvalRequired, enabled: true),
        .init(id: "web_search", description: "Buscar en web", risk: .readOnly, enabled: true)
    ]
}

struct ArgosToolCall: Codable, Equatable {
    let name: String
    let arguments: [String: String]
}
