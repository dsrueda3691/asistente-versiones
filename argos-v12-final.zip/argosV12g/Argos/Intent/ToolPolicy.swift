import Foundation

/// Política de herramientas de Argos.
///
/// Hay dos orígenes de una acción:
///  • `.userPhrase`: lo pidió el usuario con su frase (lo reconoce el parser determinista).
///    Sigue su flujo habitual; las acciones con efecto se confirman en PendingAction.
///  • `.modelSuggestion`: lo propuso el modelo a partir de texto (un correo, un documento,
///    una página). Eso NUNCA es una orden. Solo se permiten lecturas y acciones que pasan
///    por aprobación explícita; crear archivos, teclear, leer documentos, cerrar la app o
///    escribir memoria quedan prohibidos para el modelo.
struct ArgosToolPolicy {
    enum Origin: Equatable { case userPhrase, modelSuggestion }
    enum Decision: Equatable { case allowed, approvalRequired, denied(String) }

    static let modelRefusal = "No hago por mi cuenta lo que sugiere el contenido. Pídemelo directamente y lo hago."

    static func validate(_ intent: Intent, origin: Origin = .userPhrase) -> Decision {
        switch origin {
        case .userPhrase:
            return userDecision(intent)
        case .modelSuggestion:
            return modelDecision(intent)
        }
    }

    private static func userDecision(_ intent: Intent) -> Decision {
        switch intent {
        case .composeMail, .composeIntegrationMail, .sendWhatsApp,
             .createCalendarEvent, .createReminder, .createGoal, .createNote,
             .createFile, .copyTemplate, .keyboardJob, .agentMode, .quit:
            return .approvalRequired
        default:
            return .allowed
        }
    }

    private static func modelDecision(_ intent: Intent) -> Decision {
        switch intent {
        // Lecturas: no cambian nada fuera de Argos.
        case .systemStatus, .listGoals, .listReminders, .listGitHubPullRequests,
             .listGitHubReviewRequests, .listOutlookCalendar, .listIntegrationMail,
             .listUnreadIntegrationMail, .recallMemory:
            return .allowed
        // Acciones con efecto: solo como propuesta que el usuario confirma en PendingAction.
        case .composeMail, .composeIntegrationMail, .sendWhatsApp,
             .createCalendarEvent, .createReminder, .createGoal, .agentMode:
            return .approvalRequired
        case .unknown:
            return .allowed
        // Todo lo demás (crear archivos, teclado, documentos, pantalla, memoria, salir,
        // exportar, abrir URLs) solo lo decide el usuario con su propia frase.
        default:
            return .denied(modelRefusal)
        }
    }

    /// Catálogo que se ofrece al modelo: solo herramientas de lectura o con aprobación.
    static func catalogPrompt() -> String {
        ArgosToolCatalog.all
            .filter { $0.enabled && ($0.risk == .readOnly || $0.risk == .approvalRequired) }
            .map { "- \($0.id): \($0.description) [\($0.risk.rawValue)]" }
            .joined(separator: "\n")
    }
}
