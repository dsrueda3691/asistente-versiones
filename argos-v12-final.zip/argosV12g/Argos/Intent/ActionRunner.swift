import Foundation
import AppKit

struct ActionOutcome {
    let spoken: String
    var detail: String? = nil
    var shouldQuit: Bool = false
}

/// Ejecuta intents locales. Nunca borra archivos. Nunca lanza shell arbitrario.
@MainActor
final class ActionRunner {
    private let fileManager = FileManager.default

    func run(_ intent: Intent) async -> ActionOutcome {
        switch intent {
        case .greet:
            return ActionOutcome(spoken: "Hola. Argos, en línea.")
        case .whoAmI:
            return ActionOutcome(spoken: "Argos. Un compañero de escritorio para Mac: manos libres, memoria, documentos, audio local con Whisper si lo tienes, agente corto y cerebro Local u Astra.")
        case .help:
            return ActionOutcome(
                spoken: "Manos libres, wake opcional, memoria, documentos, transcribir audio o video local, correo con confirmación, calendario, agente de hasta cinco pasos, pantalla y teclado.",
                detail: Self.helpDetail
            )
        case .time:
            return ActionOutcome(spoken: "Son las \(Self.formatTime(Date())).")
        case .date:
            return ActionOutcome(spoken: "Hoy es \(Self.formatDate(Date())).")
        case .openApp(let bundleID, let displayName):
            let ok = openApplication(bundleID: bundleID, named: displayName)
            if ok {
                return ActionOutcome(spoken: "Abriendo \(displayName).")
            }
            return ActionOutcome(spoken: "No pude abrir \(displayName).")
        case .webSearch(let query):
            openWebSearch(query)
            return ActionOutcome(spoken: "Buscando eso.")
        case .createFile(let name, let contents):
            do {
                let url = try createTextFile(named: name, contents: contents)
                return ActionOutcome(
                    spoken: "Archivo creado.",
                    detail: url.path
                )
            } catch {
                return ActionOutcome(spoken: "No pude crear el archivo.")
            }
        case .listDesktop:
            let listing = listDesktop()
            return ActionOutcome(spoken: listing.spoken, detail: listing.detail)
        case .copyTemplate(let kind):
            let code = CodeSnippets.snippet(kind)
            NSPasteboard.general.clearContents()
            NSPasteboard.general.setString(code, forType: .string)
            return ActionOutcome(spoken: "Ya está en el portapapeles.")
        case .readClipboard:
            let text = NSPasteboard.general.string(forType: .string)?
                .trimmingCharacters(in: .whitespacesAndNewlines) ?? ""
            if text.isEmpty {
                return ActionOutcome(spoken: "El portapapeles está vacío.")
            }
            let spoken: String
            if text.count > 280 {
                spoken = "El portapapeles dice: " + String(text.prefix(280)) + "…"
            } else {
                spoken = "El portapapeles dice: " + text
            }
            return ActionOutcome(spoken: spoken, detail: text)
        case .quit:
            return ActionOutcome(spoken: "Hasta luego.", shouldQuit: true)
        case .analyzeScreen:
            // La captura + visión la ejecuta AppDelegate; no debería llegar aquí.
            return ActionOutcome(spoken: "Dame un segundo para mirar la pantalla.")
        case .keyboardJob:
            // Lo ejecuta AppDelegate + KeyboardController.
            return ActionOutcome(spoken: "Empiezo el trabajo de teclado.")
        case .composeMail:
            // Borrador + confirmación en AppDelegate. Nunca envía desde aquí.
            return ActionOutcome(spoken: "Borrador listo. Confirma Enviar o Cancelar.")
        case .composeIntegrationMail:
            return ActionOutcome(spoken: "Borrador listo. Confirma Enviar o Cancelar.")
        case .listIntegrationMail, .listUnreadIntegrationMail, .openIntegrationMail, .listGitHubPullRequests, .listGitHubReviewRequests, .listOutlookCalendar:
            // Lectura de integraciones: AppDelegate + Brain.
            return ActionOutcome(spoken: "Reviso la integración.")
        case .sendWhatsApp:
            return ActionOutcome(spoken: "Mensaje listo. Confirma Enviar o Cancelar.")
        case .createCalendarEvent:
            return ActionOutcome(spoken: "Evento listo. Confirma o Cancelar.")
        case .createReminder:
            return ActionOutcome(spoken: "Recordatorio listo. Confirma o Cancelar.")
        case .createGoal:
            return ActionOutcome(spoken: "Objetivo listo. Confirma o Cancelar.")
        case .listGoals:
            return ActionOutcome(spoken: "Reviso tus objetivos.")
        case .listReminders:
            // Lo ejecuta AppDelegate (EventKit lectura).
            return ActionOutcome(spoken: "Reviso tus recordatorios.")
        case .createNote:
            // Lo ejecuta AppDelegate (AppleScript Notas).
            return ActionOutcome(spoken: "Creo la nota.")
        case .work:
            return ActionOutcome(spoken: "Lo llevo en la pestaña Actividad.")
        case .agentMode:
            return ActionOutcome(spoken: "Preparo un plan corto. Confirma antes de ejecutar.")
        case .resetMemory:
            return ActionOutcome(spoken: "Memoria de esta conversación borrada. Empezamos de cero.")
        case .exportCopyDraft, .exportSaveDraft, .exportPasteDraft, .readDocument, .understandMedia:
            // Lo ejecuta AppDelegate (necesita ConversationMemory / DocumentReader / MediaUnderstander).
            return ActionOutcome(spoken: "Un momento.")
        case .handsFreeStart, .handsFreeEnd, .systemStatus:
            return ActionOutcome(spoken: "Un momento.")
        case .unknown:
            return ActionOutcome(
                spoken: "Eso no lo resolví con reglas. Con Ollama o Astra puedo razonar; si no, prueba: qué hora es, abre Safari, o busca recetas de arepas.",
                detail: Self.helpDetail
            )
        }
    }

    private func openApplication(bundleID: String, named displayName: String) -> Bool {
        let workspace = NSWorkspace.shared
        let config = NSWorkspace.OpenConfiguration()
        config.activates = true
        if !bundleID.isEmpty {
            var ids = [bundleID]
            if bundleID == "com.apple.systempreferences" {
                ids.append("com.apple.Preferences")
            }
            for id in ids {
                if let url = workspace.urlForApplication(withBundleIdentifier: id) {
                    workspace.openApplication(at: url, configuration: config) { _, _ in }
                    return true
                }
            }
        }
        if let url = Self.urlForApp(named: displayName) {
            workspace.openApplication(at: url, configuration: config) { _, _ in }
            return true
        }
        return false
    }

    /// Busca App.app en /Applications, /System/Applications y ~/Applications. Sin shell.
    static func urlForApp(named raw: String) -> URL? {
        let workspace = NSWorkspace.shared
        let name = raw.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !name.isEmpty else { return nil }

        let aliases: [String: String] = [
            "xcode": "com.apple.dt.Xcode",
            "pages": "com.apple.iWork.Pages",
            "numbers": "com.apple.iWork.Numbers",
            "keynote": "com.apple.iWork.Keynote",
            "preview": "com.apple.Preview",
            "vista previa": "com.apple.Preview",
            "music": "com.apple.Music",
            "musica": "com.apple.Music",
            "messages": "com.apple.MobileSMS",
            "mensajes": "com.apple.MobileSMS",
            "cursor": "com.todesktop.230313mzl4w4u92",
            "safari": "com.apple.Safari",
            "finder": "com.apple.finder",
            "terminal": "com.apple.Terminal",
            "mail": "com.apple.mail",
            "notas": "com.apple.Notes",
            "notes": "com.apple.Notes",
            "calendario": "com.apple.iCal"
        ]
        let key = name.folding(options: [.diacriticInsensitive, .caseInsensitive], locale: Locale(identifier: "es")).lowercased()
        if let bid = aliases[key], let url = workspace.urlForApplication(withBundleIdentifier: bid) {
            return url
        }

        let fm = FileManager.default
        var roots = [
            URL(fileURLWithPath: "/Applications"),
            URL(fileURLWithPath: "/System/Applications"),
            URL(fileURLWithPath: "/System/Applications/Utilities")
        ]
        if let homeApps = fm.urls(for: .applicationDirectory, in: .userDomainMask).first {
            roots.append(homeApps)
        }
        let needle = name.replacingOccurrences(of: ".app", with: "", options: .caseInsensitive)
        for root in roots {
            let direct = root.appendingPathComponent(needle + ".app")
            if fm.fileExists(atPath: direct.path) { return direct }
            guard let items = try? fm.contentsOfDirectory(
                at: root,
                includingPropertiesForKeys: nil,
                options: [.skipsHiddenFiles]
            ) else { continue }
            for url in items where url.pathExtension.lowercased() == "app" {
                let base = url.deletingPathExtension().lastPathComponent
                if base.compare(needle, options: [.caseInsensitive, .diacriticInsensitive]) == .orderedSame {
                    return url
                }
                if base.localizedCaseInsensitiveContains(needle) {
                    return url
                }
            }
        }
        return nil
    }

    /// Nunca sobrescribe: foo.txt → foo-2.txt → foo-3.txt …
    static func uniqueWritableURL(in directory: URL, preferredName: String) -> URL {
        let fm = FileManager.default
        let safe = sanitizeFileName(preferredName)
        var url = directory.appendingPathComponent(safe)
        if !fm.fileExists(atPath: url.path) { return url }
        let ns = safe as NSString
        let base = ns.deletingPathExtension
        let ext = ns.pathExtension
        var n = 2
        while n < 1000 {
            let candidate = ext.isEmpty ? "\(base)-\(n)" : "\(base)-\(n).\(ext)"
            url = directory.appendingPathComponent(candidate)
            if !fm.fileExists(atPath: url.path) { return url }
            n += 1
        }
        let stamp = ISO8601DateFormatter().string(from: Date()).replacingOccurrences(of: ":", with: "-")
        let fallback = ext.isEmpty ? "\(base)-\(stamp)" : "\(base)-\(stamp).\(ext)"
        return directory.appendingPathComponent(fallback)
    }


    private func openWebSearch(_ query: String) {
        var allowed = CharacterSet.urlQueryAllowed
        allowed.remove(charactersIn: "&+=")
        let encoded = query.addingPercentEncoding(withAllowedCharacters: allowed) ?? query
        let urlString = "https://www.google.com/search?q=\(encoded)"
        if let url = URL(string: urlString) {
            NSWorkspace.shared.open(url)
        }
    }

    private func createTextFile(named rawName: String, contents: String) throws -> URL {
        let safe = Self.sanitizeFileName(rawName)
        let desktop = fileManager.urls(for: .desktopDirectory, in: .userDomainMask).first
        let documents = fileManager.urls(for: .documentDirectory, in: .userDomainMask).first
        let fallbackDir = documents?.appendingPathComponent("Argos", isDirectory: true)

        let directory: URL
        if let desktop, fileManager.fileExists(atPath: desktop.path) {
            directory = desktop
        } else if let fallbackDir {
            try fileManager.createDirectory(at: fallbackDir, withIntermediateDirectories: true)
            directory = fallbackDir
        } else {
            throw NSError(domain: "Argos", code: 1, userInfo: [NSLocalizedDescriptionKey: "Sin carpeta destino"])
        }

        var url = directory.appendingPathComponent(safe)
        if fileManager.fileExists(atPath: url.path) {
            let stamp = ISO8601DateFormatter().string(from: Date()).replacingOccurrences(of: ":", with: "-")
            let base = (safe as NSString).deletingPathExtension
            let ext = (safe as NSString).pathExtension
            let extra = ext.isEmpty ? "\(base)-\(stamp)" : "\(base)-\(stamp).\(ext)"
            url = directory.appendingPathComponent(extra)
        }

        let body = contents.isEmpty ? "Creado por Argos.\n" : (contents.hasSuffix("\n") ? contents : contents + "\n")
        try body.write(to: url, atomically: true, encoding: .utf8)
        return url
    }

    private func listDesktop() -> (spoken: String, detail: String) {
        let desktop = fileManager.urls(for: .desktopDirectory, in: .userDomainMask).first
        guard let desktop else {
            return ("No encuentro el escritorio.", "")
        }
        let keys: [URLResourceKey] = [.isRegularFileKey, .isDirectoryKey, .nameKey]
        guard let items = try? fileManager.contentsOfDirectory(
            at: desktop,
            includingPropertiesForKeys: keys,
            options: [.skipsHiddenFiles]
        ) else {
            return ("No pude leer el escritorio.", "")
        }
        let names = items
            .map(\.lastPathComponent)
            .sorted { $0.localizedCaseInsensitiveCompare($1) == .orderedAscending }
        let count = names.count
        if count == 0 {
            return ("El escritorio está vacío.", "")
        }
        let preview = Array(names.prefix(15))
        let spokenPreview = Array(names.prefix(5)).joined(separator: ", ")
        let spoken = "\(count) elementos en el escritorio. Entre ellos: \(spokenPreview)."
        return (spoken, preview.joined(separator: "\n"))
    }

    static func copyDraftToPasteboard(_ draft: String) -> ActionOutcome {
        let text = draft.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !text.isEmpty else {
            return ActionOutcome(spoken: "No hay borrador que copiar. Pídeme un ensayo o ideas primero.")
        }
        NSPasteboard.general.clearContents()
        NSPasteboard.general.setString(text, forType: .string)
        return ActionOutcome(spoken: "Borrador copiado al portapapeles.", detail: String(text.prefix(500)))
    }

    static func sanitizeFileName(_ raw: String) -> String {
        var name = raw.trimmingCharacters(in: .whitespacesAndNewlines)
        name = name.replacingOccurrences(of: "/", with: "-")
        name = name.replacingOccurrences(of: ":", with: "-")
        name = name.replacingOccurrences(of: "\\", with: "-")
        name = (name as NSString).lastPathComponent
        name = name.replacingOccurrences(of: "..", with: ".")
        let banned = CharacterSet(charactersIn: "<>|?*\"\0")
        name = name.components(separatedBy: banned).joined()
        name = name.trimmingCharacters(in: .whitespacesAndNewlines)
        if name.isEmpty { name = "nota-argos" }
        if name.count > 80 {
            name = String(name.prefix(80))
        }
        let ext = (name as NSString).pathExtension.lowercased()
        if ext.isEmpty {
            name += ".txt"
        }
        return name
    }

    static func formatTime(_ date: Date) -> String {
        let f = DateFormatter()
        f.locale = Locale(identifier: "es_CO")
        f.timeStyle = .short
        f.dateStyle = .none
        return f.string(from: date)
    }

    static func formatDate(_ date: Date) -> String {
        let f = DateFormatter()
        f.locale = Locale(identifier: "es_CO")
        f.dateFormat = "EEEE d 'de' MMMM 'de' yyyy"
        return f.string(from: date)
    }

    static let helpDetail = """
    Ejemplos:
    • Manos libres: tras wake/hotkey (preferencia ON) o «modo manos libres» / «quédate escuchando»
    • Fin manos libres: «adiós» / «corta» / «modo normal» / «deja de escuchar» (o botón HUD)
    • Wake (si ON): «Argos» / «oye Argos» / «hey Argos» → entra a manos libres si está habilitado
    • «transcribe esto» / «qué dice el audio» / «explica el video» / «resume el video» (Whisper local)
    • «estado del sistema» / «cómo estás» — batería, mute, wake, manos libres, cerebro (datos reales)
    • hola / quién eres / ayuda / «olvida» / export borrador / lee README o PDF
    • abre Safari / Xcode / Cursor · mira la pantalla · usa el teclado…
    • correo / evento / recordatorio / nota (con confirmación donde aplica)
    • agente: … — plan hasta 5 pasos (analyze, type, openApp, webSearch, clipboard, draft, openURL)
    • Follow-ups con memoria persistente · adiós (sale de la app si no estás en manos libres)
    """
}


enum CodeSnippets {
    static func snippet(_ kind: CodeTemplate) -> String {
        switch kind {
        case .landingHTML:
            return landing
        case .navbarHTML:
            return navbar
        }
    }

    static let landing = """
    <!DOCTYPE html>
    <html lang="es">
    <head>
      <meta charset="utf-8" />
      <meta name="viewport" content="width=device-width, initial-scale=1" />
      <title>Landing</title>
      <style>
        :root { color-scheme: light dark; --accent: #0a84ff; }
        * { box-sizing: border-box; }
        body { margin: 0; font-family: system-ui, sans-serif; }
        header { min-height: 70vh; display: grid; place-items: center; padding: 3rem 1.5rem; text-align: center; }
        h1 { font-size: clamp(2rem, 6vw, 3.4rem); margin: 0 0 0.6rem; }
        p { opacity: 0.8; max-width: 36rem; }
        a.cta { display: inline-block; margin-top: 1.4rem; padding: 0.85rem 1.4rem; background: var(--accent); color: #fff; border-radius: 999px; text-decoration: none; }
      </style>
    </head>
    <body>
      <header>
        <div>
          <h1>Hola, mundo</h1>
          <p>Landing mínima lista para editar. Generada por Argos.</p>
          <a class="cta" href="#contacto">Empezar</a>
        </div>
      </header>
    </body>
    </html>
    """

    static let navbar = """
    <nav class="nav">
      <a class="logo" href="/">Argos</a>
      <ul>
        <li><a href="#inicio">Inicio</a></li>
        <li><a href="#proyectos">Proyectos</a></li>
        <li><a href="#contacto">Contacto</a></li>
      </ul>
    </nav>
    <style>
      .nav { display: flex; justify-content: space-between; align-items: center; padding: 0.9rem 1.4rem; font-family: system-ui, sans-serif; }
      .nav ul { display: flex; gap: 1.2rem; list-style: none; margin: 0; padding: 0; }
      .nav a { color: inherit; text-decoration: none; }
      .logo { font-weight: 700; }
    </style>
    """
}
