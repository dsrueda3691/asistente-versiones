import Foundation

enum CodeTemplate: Equatable {
    case landingHTML
    case navbarHTML
}

enum Intent: Equatable {
    case greet
    case whoAmI
    case help
    case time
    case date
    case openApp(bundleID: String, displayName: String)
    case webSearch(query: String)
    case createFile(name: String, contents: String)
    case listDesktop
    case copyTemplate(CodeTemplate)
    case readClipboard
    case analyzeScreen(question: String)
    case keyboardJob(instruction: String)
    case composeMail(to: String, subject: String, body: String, cc: String?)
    case composeIntegrationMail(provider: ArgosIntegration, to: String, subject: String, body: String, cc: String?)
    case listIntegrationMail(provider: ArgosIntegration)
    case listUnreadIntegrationMail(provider: ArgosIntegration)
    case openIntegrationMail(provider: ArgosIntegration, query: String)
    case listGitHubPullRequests
    case listGitHubReviewRequests
    case listOutlookCalendar
    case sendWhatsApp(to: String, body: String)
    case createCalendarEvent(title: String, startHint: String, endHint: String, notes: String?, location: String?)
    case createReminder(title: String, dueHint: String?)
    case createGoal(title: String, dueHint: String?, project: String?)
    case listGoals
    case listReminders
    case createNote(title: String, body: String)
    case agentMode(goal: String)
    /// Trabajo en un modo: "programar", "documentos" o "revisar" (solo por frase del usuario).
    case work(mode: String, goal: String)
    /// Borra memoria de conversación de esta sesión.
    case resetMemory
    /// Guarda un hecho explícito en la memoria de largo plazo.
    case remember(text: String)
    /// Busca memoria semántica y perfil.
    case recallMemory(query: String)
    /// Olvida coincidencias concretas de la memoria de largo plazo.
    case forgetMemory(query: String)
    /// Copia lastDraft al portapapeles.
    case exportCopyDraft
    /// Guarda lastDraft a Disco (Desktop o ~/Documents/Argos).
    case exportSaveDraft(filename: String?)
    /// Pega lastDraft en la app frontal (clipboard + Cmd+V).
    case exportPasteDraft
    /// Lee archivo / PDF / página y razona con el contenido.
    case readDocument(phrase: String)
    /// V10: transcribe / resume audio o video vía Whisper local.
    case understandMedia(phrase: String)
    /// V10: activar sesión manos libres.
    case handsFreeStart
    /// V10: terminar sesión manos libres (sin salir de la app).
    case handsFreeEnd
    /// V10: estado real del sistema (batería, mute, wake, manos libres, cerebro).
    case systemStatus
    case quit
    case unknown(original: String)
}

/// Intents locales, en español, sin red. Quita vocativos tipo «Argos», «oye», «hola».
struct IntentParser {
    func parse(_ raw: String) -> Intent {
        let cleaned = Self.stripVocative(Self.normalize(raw))
        if cleaned.isEmpty {
            return .greet
        }
        if let work = Self.workIntent(cleaned) { return work }

        // Orden V10: hands-free, systemStatus, quit, who, memory-reset, export,
        // media, mail, agent, calendar, reminder, note, screen, keyboard,
        // help, greet, time, date, clipboard, desktop, templates, openApp,
        // webSearch, createFile, readDocument → unknown→Brain.
        if Self.isHandsFreeEnd(cleaned) { return .handsFreeEnd }
        if Self.isHandsFreeStart(cleaned) { return .handsFreeStart }
        if Self.isSystemStatus(cleaned) { return .systemStatus }
        if Self.isQuit(cleaned) { return .quit }
        if Self.isWho(cleaned) { return .whoAmI }
        if let memory = Self.longTermMemory(cleaned, original: raw) { return memory }
        if Self.isResetMemory(cleaned) { return .resetMemory }
        if let export = Self.exportDraft(cleaned, original: raw) { return export }
        if let media = Self.understandMedia(cleaned, original: raw) { return media }
        if let integration = Self.integrationIntent(cleaned, original: raw) { return integration }
        if let mail = Self.composeMail(cleaned, original: raw) { return mail }
        if let agent = Self.agentMode(cleaned, original: raw) { return agent }
        if let cal = Self.createCalendarEvent(cleaned, original: raw) { return cal }
        if let goal = Self.createGoal(cleaned, original: raw) { return goal }
        if Self.isListGoals(cleaned) { return .listGoals }
        if let rem = Self.createReminder(cleaned, original: raw) { return rem }
        if Self.isListReminders(cleaned) { return .listReminders }
        if let note = Self.createNote(cleaned, original: raw) { return note }
        if let screen = Self.analyzeScreen(cleaned, original: raw) { return screen }
        if let job = Self.keyboardJob(cleaned, original: raw) { return job }
        if Self.isHelp(cleaned) { return .help }
        if Self.isGreet(cleaned) { return .greet }
        if Self.isTime(cleaned) { return .time }
        if Self.isDate(cleaned) { return .date }
        if Self.isClipboard(cleaned) { return .readClipboard }
        if Self.isListDesktop(cleaned) { return .listDesktop }
        if let template = Self.codeTemplate(cleaned) { return .copyTemplate(template) }
        if let app = Self.openApp(cleaned, original: raw) { return app }
        if let search = Self.webSearch(cleaned) { return search }
        if let file = Self.createFile(cleaned) { return file }
        if let doc = Self.readDocument(cleaned, original: raw) { return doc }

        return .unknown(original: raw)
    }

    static func normalize(_ text: String) -> String {
        text.folding(options: [.diacriticInsensitive, .caseInsensitive], locale: Locale(identifier: "es"))
            .replacingOccurrences(of: "¿", with: "")
            .replacingOccurrences(of: "?", with: "")
            .replacingOccurrences(of: "¡", with: "")
            .replacingOccurrences(of: "!", with: "")
            .replacingOccurrences(of: ",", with: " ")
            .replacingOccurrences(of: ".", with: " ")
            .replacingOccurrences(of: "  ", with: " ")
            .trimmingCharacters(in: .whitespacesAndNewlines)
            .lowercased()
    }

    static func stripVocative(_ text: String) -> String {
        var s = text
        let prefixes = [
            "oye argos ", "hola argos ", "hey argos ", "ok argos ",
            "bueno argos ", "bien argos ", "argos ", "hola ", "oye ",
            "hey ", "ok ", "bueno ", "a ver "
        ]
        var changed = true
        while changed {
            changed = false
            for p in prefixes where s.hasPrefix(p) {
                s = String(s.dropFirst(p.count))
                changed = true
            }
        }
        if s == "argos" || s == "oye" || s == "hola" {
            return s == "hola" ? "hola" : ""
        }
        return s.trimmingCharacters(in: .whitespacesAndNewlines)
    }

    private static func isQuit(_ s: String) -> Bool {
        let keys = [
            "adios", "hasta luego", "hasta pronto", "chao", "chau",
            "cierra", "cierra argos", "cierra la app", "cierra la aplicacion",
            "sal", "salir", "apagate", "apagate argos", "termina",
            "cierra te", "quit", "exit"
        ]
        return keys.contains(s) || s.hasPrefix("cierra argos") || s.hasPrefix("apagate")
    }

    private static func isWho(_ s: String) -> Bool {
        s.contains("quien eres") || s.contains("como te llamas") ||
        s.contains("cual es tu nombre") || s.contains("quien es argos") ||
        s.contains("que eres") || s.contains("presentate") || s == "quien eres tu"
    }

    private static func isHelp(_ s: String) -> Bool {
        // Evitar confundir «qué estoy haciendo» con ayuda.
        if s.contains("que estoy haciendo") || s.contains("que estoy viendo") { return false }
        return s.contains("que puedes") || s.contains("que sabes") ||
        s.contains("ayuda") || s.contains("que haces") ||
        s.contains("comandos") || s.contains("que se puede")
    }

    private static func isGreet(_ s: String) -> Bool {
        // «cómo estás» / «como estas» → systemStatus (V10), no saludo.
        let keys = ["hola", "buenas", "buenos dias", "buenas tardes", "buenas noches", "hey", "que tal", "holi"]
        return keys.contains(s)
    }

    private static func isSystemStatus(_ s: String) -> Bool {
        if s == "como estas" || s == "como estas tu" || s == "como te encuentras" { return true }
        if s.contains("estado del sistema") || s.contains("estado del sistema") { return true }
        if s.contains("status del sistema") || s == "estado" || s == "status" { return true }
        if s.contains("sistemas listos") || s.contains("reporte de estado") { return true }
        if (s.contains("como estas") || s.contains("como andas")) && !s.contains("pantalla") { return true }
        return false
    }

    private static func isHandsFreeStart(_ s: String) -> Bool {
        HandsFreeSession.isStartPhrase(s)
    }

    private static func isHandsFreeEnd(_ s: String) -> Bool {
        // Solo frases explícitas de fin de sesión (no «adiós» aquí: «adiós» sigue siendo quit
        // fuera de manos libres; dentro de sesión lo intercepta AppDelegate).
        let keys = ["corta", "modo normal", "deja de escuchar", "deja de oirme",
                    "para de escuchar", "sal del modo manos libres", "manos libres off",
                    "modo manos libres off", "termina sesion", "corta la sesion"]
        if keys.contains(s) { return true }
        if s.contains("deja de escuchar") || s.contains("modo normal") { return true }
        if s == "corta" || s.hasPrefix("corta la sesion") { return true }
        return false
    }

    private static func understandMedia(_ s: String, original: String) -> Intent? {
        let triggers = [
            "transcribe esto", "transcribe el audio", "transcribe el video",
            "transcribeme", "transcribir", "que dice el audio", "que dice el video",
            "explicame el video", "explica el video", "explica el audio",
            "resume el video", "resume el audio", "resumen del video",
            "resumen del audio", "que dice esto", "escucha el audio",
            "entiende el video", "entiende el audio", "subtitulos del video"
        ]
        if triggers.contains(where: { s.contains($0) || s == $0 }) {
            return .understandMedia(phrase: original)
        }
        // «transcribe …» + media hint
        let mediaHint = s.contains("audio") || s.contains("video") || s.contains("mp3") ||
            s.contains("mp4") || s.contains("mov") || s.contains("wav") || s.contains("podcast")
        if (s.contains("transcrib") || s.contains("subtitul")) && mediaHint {
            return .understandMedia(phrase: original)
        }
        if (s.contains("resume") || s.contains("explica")) && (s.contains("video") || s.contains("audio")) {
            // Evitar choque con documentos PDF
            if s.contains("pdf") || s.contains("documento") || s.contains("readme") { return nil }
            return .understandMedia(phrase: original)
        }
        return nil
    }

    private static func words(_ s: String) -> [String] {
        s.split(whereSeparator: { $0.isWhitespace || $0.isPunctuation }).map(String.init)
    }

    private static func isTime(_ s: String) -> Bool {
        let w = Set(words(s))
        return w.contains("hora") || s.contains("que hora") || s.contains("la hora")
    }

    private static func isDate(_ s: String) -> Bool {
        s.contains("fecha") || s.contains("que dia") || s.contains("que dia es") ||
        s.contains("dia de hoy") || s.contains("a cuanto estamos")
    }

    private static func isClipboard(_ s: String) -> Bool {
        s.contains("portapapeles") || s.contains("clipboard") ||
        s.contains("que copie") || s.contains("lee lo que copie") ||
        s.contains("di lo del porta") || (s.contains("lee") && s.contains("porta"))
    }

    private static func isListDesktop(_ s: String) -> Bool {
        // Solo archivos del Escritorio, no «pantalla».
        if s.contains("pantalla") || s.contains("screen") { return false }
        return (s.contains("escritorio") || s.contains("desktop")) &&
        (s.contains("lista") || s.contains("enumera") || s.contains("archivos") ||
         s.contains("que hay") || s.contains("muestra") || s.contains("cuantos"))
    }




    private static func longTermMemory(_ s: String, original: String) -> Intent? {
        if s.hasPrefix("recuerda que ") {
            let marker = "recuerda que "
            let lowerOriginal = original.lowercased()
            if let range = lowerOriginal.range(of: marker) {
                let start = original.index(original.startIndex, offsetBy: lowerOriginal.distance(from: lowerOriginal.startIndex, to: range.upperBound))
                let clean = String(original[start...]).trimmingCharacters(in: .whitespacesAndNewlines)
                return clean.isEmpty ? nil : .remember(text: clean)
            }
            let clean = String(s.dropFirst(marker.count)).trimmingCharacters(in: .whitespacesAndNewlines)
            return clean.isEmpty ? nil : .remember(text: clean)
        }
        let recallKeys = ["que recuerdas de ", "que recuerdas sobre ", "busca en tu memoria ", "recuerda algo sobre ", "que sabes sobre mi "]
        for key in recallKeys where s.hasPrefix(key) {
            let query = String(original.dropFirst(key.count)).trimmingCharacters(in: .whitespacesAndNewlines)
            return query.isEmpty ? .recallMemory(query: "perfil") : .recallMemory(query: query)
        }
        let forgetKeys = ["olvida de tu memoria ", "olvida de la memoria ", "olvida el recuerdo de ", "borra de tu memoria "]
        for key in forgetKeys where s.hasPrefix(key) {
            let query = String(original.dropFirst(key.count)).trimmingCharacters(in: .whitespacesAndNewlines)
            return query.isEmpty ? nil : .forgetMemory(query: query)
        }
        if s == "que recuerdas de mi" || s == "que recuerdas de mí" || s == "muestrame tu memoria" || s == "muestra mi perfil" {
            return .recallMemory(query: "perfil")
        }
        return nil
    }

    private static func isResetMemory(_ s: String) -> Bool {
        let keys = [
            "olvida", "olvida todo", "borra la memoria", "borra memoria",
            "nueva conversacion", "empezar de cero", "empieza de cero",
            "reinicia la memoria", "reset memoria", "limpia la memoria", "limpia memoria",
            "borra el contexto", "olvidate", "olvidate de todo", "olvidate todo"
        ]
        if keys.contains(s) { return true }
        // «olvidalo» solo si habla de memoria/conversación (si no, puede ser cancelar pendiente).
        if s == "olvidalo" || s == "olvidalo todo" {
            return s.contains("todo")
        }
        if s.hasPrefix("olvida") && (s.contains("memoria") || s.contains("conversacion") || s.contains("todo") || s == "olvida") {
            return true
        }
        if s.contains("nueva conversacion") || s.contains("empezar de cero") || s.contains("empieza de cero") {
            return true
        }
        if s.contains("borra") && s.contains("memoria") { return true }
        return false
    }

    /// Export del lastDraft: copia / guarda / pega. No captura el «copia» suelto ni jobs de teclado.
    private static func exportDraft(_ s: String, original: String) -> Intent? {
        // Pegar borrador
        let pasteTriggers = [
            "pegalo", "pega lo", "pega el borrador", "pega el ensayo", "pega el texto",
            "escribelo", "escribe lo", "escribe el borrador", "escribe el ensayo",
            "pega borrador", "pegar el borrador", "pegar borrador"
        ]
        if pasteTriggers.contains(where: { s == $0 || s.hasPrefix($0) || s.contains($0) }) {
            // Evitar choque con keyboard job «escribe en la app…»
            if s.contains("usa el teclado") || s.contains("mientras ") { return nil }
            if s.hasPrefix("escribe en ") || s.contains("escribe en la") { return nil }
            return .exportPasteDraft
        }

        // Guardar
        let saveTriggers = [
            "guardalo", "guarda lo", "guarda el borrador", "guarda el ensayo",
            "guarda el texto", "guardar el borrador", "guardar el ensayo",
            "guardalo en el escritorio", "guarda como "
        ]
        if saveTriggers.contains(where: { s.contains($0) }) || s.hasPrefix("guarda como ") || s.hasPrefix("guardalo como ") {
            var filename: String? = nil
            for key in [" como ", " llamado ", " nombre "] {
                if let r = s.range(of: key) {
                    var rest = String(s[r.upperBound...]).trimmingCharacters(in: .whitespaces)
                    rest = rest.replacingOccurrences(of: " por favor", with: "")
                    rest = rest.trimmingCharacters(in: .whitespacesAndNewlines)
                    if !rest.isEmpty { filename = rest; break }
                }
            }
            // También desde original con extensión
            if filename == nil {
                let pattern = #"([A-Za-z0-9_\-\.]+\.(?:txt|md|swift|html?|json|csv))"#
                if let regex = try? NSRegularExpression(pattern: pattern, options: [.caseInsensitive]) {
                    let range = NSRange(original.startIndex..<original.endIndex, in: original)
                    if let match = regex.firstMatch(in: original, options: [], range: range),
                       let swiftRange = Range(match.range(at: 1), in: original) {
                        filename = String(original[swiftRange])
                    }
                }
            }
            return .exportSaveDraft(filename: filename)
        }

        // Copiar al portapapeles (frases explícitas de borrador; no «copia» suelto)
        let copyTriggers = [
            "copia el borrador", "copia el ensayo", "copia el texto", "copialo",
            "copia lo", "copiar el borrador", "copiar el ensayo",
            "al portapapeles", "al porta papeles", "ponlo en el portapapeles",
            "copia borrador", "copiar borrador"
        ]
        if copyTriggers.contains(where: { s.contains($0) || s == $0 }) {
            return .exportCopyDraft
        }
        // «cópialo» sin tilde ya cubierto; «copia eso» / «copia eso al portapapeles»
        if (s.hasPrefix("copia ") || s == "copialo") &&
            (s.contains("borrador") || s.contains("ensayo") || s.contains("texto") ||
             s.contains("portapapeles") || s.contains("eso") || s.contains("eso al") ||
             s == "copialo" || s == "copia lo") {
            return .exportCopyDraft
        }
        return nil
    }

    private static func readDocument(_ s: String, original: String) -> Intent? {
        let readVerbs = s.contains("lee") || s.contains("leer") || s.contains("documenta") ||
            s.contains("explica") || s.contains("resume") || s.contains("analiza el") ||
            s.contains("que dice") || s.contains("qué dice")
        let docHints = s.contains("readme") || s.contains("archivo") || s.contains("documento") ||
            s.contains("pdf") || s.contains("pagina") || s.contains("página") ||
            s.contains("este pdf") || s.contains("esta pagina") || s.contains("esta página") ||
            s.contains(".txt") || s.contains(".md") || s.contains(".pdf") || s.contains(".swift") ||
            s.contains(".html") || s.contains(".json") || s.contains(".csv") ||
            s.contains("ensayo con") || s.contains("con este")
        // Frases canónicas
        let phrases = [
            "lee el readme", "documenta esta pagina", "documenta esta página",
            "ensayo con este pdf", "explica este documento", "lee este documento",
            "lee el pdf", "lee este pdf", "lee la pagina", "lee esta pagina",
            "resume este documento", "resume el pdf", "que dice este documento"
        ]
        if phrases.contains(where: { s.contains($0) }) {
            return .readDocument(phrase: original)
        }
        if readVerbs && docHints {
            // Evitar choque con clipboard «lee el portapapeles»
            if s.contains("portapapeles") || s.contains("clipboard") { return nil }
            // Evitar pantalla
            if s.contains("pantalla") || s.contains("screen") { return nil }
            return .readDocument(phrase: original)
        }
        return nil
    }

    private static func agentMode(_ s: String, original: String) -> Intent? {
        let triggers = [
            "haz esto en pantalla", "haz esto en la pantalla",
            "agente:", "modo agente", "agent:", "agente ",
            "resuelve esto en pantalla", "arregla esto en pantalla",
            "hazlo en pantalla", "actua en pantalla"
        ]
        guard triggers.contains(where: { s.contains($0) || s.hasPrefix($0.trimmingCharacters(in: .whitespaces)) }) else {
            // "agente: …" con prefijo
            if s.hasPrefix("agente") || s.hasPrefix("agent") {
                var goal = original.trimmingCharacters(in: .whitespacesAndNewlines)
                if let r = goal.range(of: ":") {
                    goal = String(goal[r.upperBound...]).trimmingCharacters(in: .whitespacesAndNewlines)
                } else {
                    goal = s.replacingOccurrences(of: "agente", with: "")
                        .replacingOccurrences(of: "agent", with: "")
                        .trimmingCharacters(in: .whitespacesAndNewlines)
                }
                if goal.isEmpty { goal = original }
                return .agentMode(goal: goal)
            }
            return nil
        }
        var goal = original.trimmingCharacters(in: .whitespacesAndNewlines)
        for p in ["agente:", "Agente:", "agent:", "Agent:"] {
            if let r = goal.range(of: p) {
                goal = String(goal[r.upperBound...]).trimmingCharacters(in: .whitespacesAndNewlines)
                break
            }
        }
        if goal.isEmpty { goal = "Haz lo que se ve en pantalla." }
        return .agentMode(goal: goal)
    }

    private static func createCalendarEvent(_ s: String, original: String) -> Intent? {
        let triggers = [
            "crea un evento", "crear un evento", "agenda un evento", "agendar un evento",
            "nuevo evento", "anade un evento", "añade un evento", "pon un evento",
            "crea evento", "agendar ", "agenda reunion", "agenda una reunion",
            "crea una cita", "nueva cita", "calendar event"
        ]
        guard triggers.contains(where: { s.contains($0) }) else { return nil }
        var title = "Evento"
        var startHint = ""
        var endHint = ""
        var notes: String? = nil
        var location: String? = nil

        if let r = s.range(of: " llamado ") ?? s.range(of: " titulado ") ?? s.range(of: " titulo ") ?? s.range(of: " que se llame ") {
            var rest = String(s[r.upperBound...]).trimmingCharacters(in: .whitespaces)
            let cuts = [" manana", " hoy", " a las", " el ", " desde", " hasta", " en ", " notas ", " ubicacion ", " lugar "]
            var end = rest.endIndex
            for c in cuts {
                if let f = rest.range(of: c), f.lowerBound < end { end = f.lowerBound }
            }
            let t = String(rest[..<end]).trimmingCharacters(in: .whitespacesAndNewlines)
            if !t.isEmpty { title = t }
        } else if let r = s.range(of: "evento ") {
            var rest = String(s[r.upperBound...]).trimmingCharacters(in: .whitespaces)
            for prefix in ["llamado ", "de ", "para "] {
                if rest.hasPrefix(prefix) { rest = String(rest.dropFirst(prefix.count)) }
            }
            let cuts = [" manana", " hoy", " a las", " el "]
            var end = rest.endIndex
            for c in cuts {
                if let f = rest.range(of: c), f.lowerBound < end { end = f.lowerBound }
            }
            let t = String(rest[..<end]).trimmingCharacters(in: .whitespacesAndNewlines)
            if !t.isEmpty && t.count < 80 { title = t }
        }

        // Tiempo
        for key in [" manana", " hoy", " pasado manana", " a las ", " el lunes", " el martes", " el miercoles", " el jueves", " el viernes"] {
            if s.contains(key.trimmingCharacters(in: .whitespaces)) {
                startHint = s // el servicio parsea loose
                break
            }
        }
        if startHint.isEmpty { startHint = original }

        if let r = s.range(of: " hasta ") ?? s.range(of: " hasta las ") {
            endHint = String(s[r.lowerBound...])
        }
        if let r = s.range(of: " en ") ?? s.range(of: " lugar ") ?? s.range(of: " ubicacion ") {
            var loc = String(s[r.upperBound...]).trimmingCharacters(in: .whitespaces)
            if let cut = loc.range(of: " notas ") { loc = String(loc[..<cut.lowerBound]) }
            location = loc.trimmingCharacters(in: .whitespacesAndNewlines)
        }
        if let r = s.range(of: " notas ") ?? s.range(of: " nota ") ?? s.range(of: " diciendo ") {
            notes = String(s[r.upperBound...]).trimmingCharacters(in: .whitespacesAndNewlines)
        }
        return .createCalendarEvent(title: title, startHint: startHint, endHint: endHint, notes: notes, location: location)
    }

    private static func createGoal(_ s: String, original: String) -> Intent? {
        let triggers = ["guarda como objetivo", "crea un objetivo", "crear objetivo", "nuevo objetivo", "anota como objetivo", "objetivo pendiente"]
        guard triggers.contains(where: { s.contains($0) }) else { return nil }
        var title = original
        for trigger in triggers where s.contains(trigger) {
            if let range = title.range(of: trigger, options: [.caseInsensitive, .diacriticInsensitive]) {
                title = String(title[range.upperBound...])
                break
            }
        }
        title = title.trimmingCharacters(in: .whitespacesAndNewlines)
        var dueHint: String?
        if let r = title.range(of: " para ", options: [.caseInsensitive, .diacriticInsensitive]) {
            dueHint = String(title[r.upperBound...]).trimmingCharacters(in: .whitespacesAndNewlines)
            title = String(title[..<r.lowerBound]).trimmingCharacters(in: .whitespacesAndNewlines)
        }
        if title.isEmpty { title = "Objetivo" }
        return .createGoal(title: title, dueHint: dueHint, project: nil)
    }

    private static func isListGoals(_ s: String) -> Bool {
        ["mis objetivos", "lista de objetivos", "objetivos pendientes", "que objetivos tengo", "qué objetivos tengo", "objetivos"].contains(s)
    }

    private static func createReminder(_ s: String, original: String) -> Intent? {
        // Evitar choque con list
        if isListReminders(s) { return nil }
        let triggers = [
            "crea un recordatorio", "crear un recordatorio", "recuerdame", "recuerda me",
            "nuevo recordatorio", "pon un recordatorio", "anade un recordatorio",
            "añade un recordatorio", "create reminder", "remind me"
        ]
        guard triggers.contains(where: { s.contains($0) }) else { return nil }
        var title = "Recordatorio"
        var dueHint: String? = nil

        if let r = s.range(of: "recuerdame ") ?? s.range(of: "remind me ") ?? s.range(of: "recordatorio ") {
            var rest = String(s[r.upperBound...]).trimmingCharacters(in: .whitespaces)
            for p in ["que ", "de ", "llamado "] {
                if rest.hasPrefix(p) { rest = String(rest.dropFirst(p.count)) }
            }
            title = rest
            // Separar due
            for key in [" manana", " hoy", " el ", " a las ", " para el "] {
                if let f = rest.range(of: key) {
                    title = String(rest[..<f.lowerBound]).trimmingCharacters(in: .whitespaces)
                    dueHint = String(rest[f.lowerBound...]).trimmingCharacters(in: .whitespaces)
                    break
                }
            }
        }
        title = title.trimmingCharacters(in: .whitespacesAndNewlines)
        if title.isEmpty { title = "Recordatorio" }
        if dueHint == nil {
            for key in ["manana", "hoy", "a las"] where s.contains(key) {
                dueHint = s
                break
            }
        }
        return .createReminder(title: title, dueHint: dueHint)
    }

    private static func isListReminders(_ s: String) -> Bool {
        let listish = s.contains("lista") || s.contains("muestra") || s.contains("que recordatorios") ||
            s.contains("proximos recordatorios") || s.contains("mis recordatorios") ||
            s.contains("list reminders") || s.contains("recordatorios pendientes")
        return listish && s.contains("recordator")
    }

    private static func createNote(_ s: String, original: String) -> Intent? {
        let triggers = [
            "crea una nota", "crear una nota", "nueva nota", "haz una nota",
            "anade una nota", "añade una nota", "nota en notes", "create note",
            "escribe una nota", "guardar nota", "guarda una nota"
        ]
        guard triggers.contains(where: { s.contains($0) }) else { return nil }
        var title = "Nota Argos"
        var body = ""

        if let r = s.range(of: " llamada ") ?? s.range(of: " titulada ") ?? s.range(of: " titulo ") ?? s.range(of: " llamado ") {
            var rest = String(s[r.upperBound...]).trimmingCharacters(in: .whitespaces)
            if let con = rest.range(of: " que diga ") ?? rest.range(of: " con ") ?? rest.range(of: " cuerpo ") ?? rest.range(of: " body ") {
                title = String(rest[..<con.lowerBound]).trimmingCharacters(in: .whitespaces)
                body = String(rest[con.upperBound...]).trimmingCharacters(in: .whitespaces)
            } else {
                title = rest
            }
        } else if let r = s.range(of: " que diga ") ?? s.range(of: " diciendo ") ?? s.range(of: " con texto ") {
            body = String(s[r.upperBound...]).trimmingCharacters(in: .whitespacesAndNewlines)
        } else if let r = s.range(of: "nota ") {
            let rest = String(s[r.upperBound...]).trimmingCharacters(in: .whitespaces)
            if !rest.isEmpty && rest.count < 60 { title = rest }
        }
        if title.isEmpty { title = "Nota Argos" }
        return .createNote(title: title, body: body)
    }

    /// «envía un correo a…», «manda un mail…», «redacta un correo…».
    /// Parsea lo que pueda; campos vacíos los puede completar el Brain.
    private static func hasExplicitPullRequestTerm(_ s: String) -> Bool {
        let tokens = Set(s.split(whereSeparator: { $0.isWhitespace || $0.isPunctuation }).map(String.init))
        return tokens.contains("pr") || tokens.contains("prs") ||
            s.contains("pull request") || s.contains("pull requests") ||
            s.contains("solicitud de extraccion") || s.contains("solicitudes de extraccion")
    }

    private static func integrationIntent(_ s: String, original: String) -> Intent? {
        let wantsList = s.contains("lista") || s.contains("revisa") || s.contains("revisar") || s.contains("ultimos") || s.contains("bandeja") || s.contains("correos") || s.contains("mensajes")
        if s.contains("github") && (s.contains("por revisar") || s.contains("me pidieron revisar") || s.contains("esperan mi revision") || s.contains("esperan revision")) {
            return .listGitHubReviewRequests
        }
        if s.contains("github") && Self.hasExplicitPullRequestTerm(s) {
            return .listGitHubPullRequests
        }
        if s.contains("outlook") && (s.contains("calendario") || s.contains("agenda") || s.contains("eventos")) {
            return .listOutlookCalendar
        }
        if (s.contains("gmail") || s.contains("outlook")) && (s.contains("sin leer") || s.contains("no leidos") || s.contains("no leido") || s.contains("unread")) {
            return .listUnreadIntegrationMail(provider: s.contains("outlook") ? .outlook : .gmail)
        }
        if (s.contains("gmail") || s.contains("outlook")) && (s.contains("abre el correo") || s.contains("abre un correo") || s.contains("abre el mail") || s.contains("abrir el correo") || s.contains("leer el correo")) {
            let provider: ArgosIntegration = s.contains("outlook") ? .outlook : .gmail
            var query = original
            let markers = ["asunto:", "asunto ", "con asunto "]
            for marker in markers {
                if let r = original.range(of: marker, options: .caseInsensitive) {
                    query = String(original[r.upperBound...]).trimmingCharacters(in: .whitespacesAndNewlines)
                    break
                }
            }
            query = query.replacingOccurrences(of: "abrir el correo", with: "", options: .caseInsensitive)
                .replacingOccurrences(of: "abre el correo", with: "", options: .caseInsensitive)
                .replacingOccurrences(of: "abre un correo", with: "", options: .caseInsensitive)
                .trimmingCharacters(in: .whitespacesAndNewlines)
            if !query.isEmpty { return .openIntegrationMail(provider: provider, query: query) }
        }
        if s.contains("gmail") && wantsList { return .listIntegrationMail(provider: .gmail) }
        if s.contains("outlook") && wantsList { return .listIntegrationMail(provider: .outlook) }

        if s.contains("whatsapp") && (s.contains("manda") || s.contains("envia") || s.contains("enviar") || s.contains("mensaje") || s.contains("dile") || (s.contains("whatsapp") && s.contains(":"))) {
            let phonePattern = #"(?:\+?\d[\d\s().-]{7,20}\d)"#
            guard let regex = try? NSRegularExpression(pattern: phonePattern),
                  let match = regex.firstMatch(in: original, range: NSRange(location: 0, length: original.utf16.count)),
                  let phoneRange = Range(match.range, in: original) else { return nil }
            let phone = String(original[phoneRange]).trimmingCharacters(in: .whitespacesAndNewlines)

            // Parsear el cuerpo SOLO después del teléfono. Esto evita que el
            // "mensaje" de "manda un mensaje ..." sea confundido con el
            // contenido real. También evita aplicar índices de `original`
            // sobre una cadena recortada, que podía producir offsets inválidos.
            let afterPhone = String(original[phoneRange.upperBound...])
            let bodyMarkers = [" diciendo ", " que diga ", " dile "]
            var body = ""
            let trimmedAfterPhone = afterPhone.trimmingCharacters(in: .whitespacesAndNewlines)
            if trimmedAfterPhone.hasPrefix(":") || trimmedAfterPhone.hasPrefix(";") {
                body = String(trimmedAfterPhone.dropFirst()).trimmingCharacters(in: .whitespacesAndNewlines)
            } else {
                for marker in bodyMarkers {
                    if let r = afterPhone.range(of: marker, options: .caseInsensitive) {
                        body = String(afterPhone[r.upperBound...]).trimmingCharacters(in: .whitespacesAndNewlines)
                        break
                    }
                }
            }
            if body.isEmpty {
                body = afterPhone.trimmingCharacters(in: .whitespacesAndNewlines)
                    .replacingOccurrences(of: "^[,;: ]+", with: "", options: .regularExpression)
            }
            guard !body.isEmpty else { return nil }
            return .sendWhatsApp(to: phone, body: body)
        }

        if s.contains("gmail") || s.contains("outlook") {
            let triggers = ["envia un correo", "enviar un correo", "manda un correo", "manda un mail", "envia correo", "enviar correo", "enviar mail", "send mail", "send email"]
            if triggers.contains(where: { s.contains($0) }) {
                let provider: ArgosIntegration = s.contains("outlook") ? .outlook : .gmail
                if let mail = composeMail(s, original: original) {
                    if case .composeMail(let to, let subject, let body, let cc) = mail {
                        return .composeIntegrationMail(provider: provider, to: to, subject: subject, body: body, cc: cc)
                    }
                }
            }
        }
        return nil
    }

    private static func composeMail(_ s: String, original: String) -> Intent? {
        let triggers = [
            "envia un correo", "enviar un correo", "envia un mail", "enviar un mail",
            "manda un correo", "mandar un correo", "manda un mail", "mandar un mail",
            "redacta un correo", "redactar un correo", "redacta un mail", "redactar un mail",
            "escribe un correo", "escribir un correo", "escribe un mail", "escribir un mail",
            "manda correo", "envia correo", "envio un correo", "envio un mail",
            "compose mail", "send mail", "send email", "enviar correo", "enviar mail"
        ]
        guard triggers.contains(where: { s.contains($0) }) else { return nil }

        var to = ""
        var subject = ""
        var body = ""
        var cc: String? = nil

        // Destinatario: "a X" / "para X" / "to X"
        if let r = s.range(of: " a ") ?? s.range(of: " para ") ?? s.range(of: " to ") {
            var rest = String(s[r.upperBound...]).trimmingCharacters(in: .whitespaces)
            // Cortar en con asunto / que diga / diciendo / sobre / subject / cuerpo / cc
            let cutKeys = [" con asunto ", " asunto ", " que diga ", " diciendo ", " sobre ",
                           " subject ", " cuerpo ", " body ", " cc ", " con copia "]
            var cutAt: String.Index? = nil
            for key in cutKeys {
                if let found = rest.range(of: key) {
                    if cutAt == nil || found.lowerBound < cutAt! {
                        cutAt = found.lowerBound
                    }
                }
            }
            if let cutAt {
                to = String(rest[..<cutAt]).trimmingCharacters(in: .whitespaces)
            } else {
                // Puede ser solo email/nombre al final de un disparador corto
                to = rest.trimmingCharacters(in: .whitespaces)
            }
            // Limpiar restos de puntuación / "por favor"
            to = to.replacingOccurrences(of: " por favor", with: "")
                .trimmingCharacters(in: CharacterSet.whitespacesAndNewlines.union(.punctuationCharacters))
        }

        // Asunto
        for key in [" con asunto ", " asunto ", " subject "] {
            if let r = s.range(of: key) {
                var rest = String(s[r.upperBound...]).trimmingCharacters(in: .whitespaces)
                let cutKeys = [" que diga ", " diciendo ", " cuerpo ", " body ", " y cuerpo ", " cc "]
                var end = rest.endIndex
                for ck in cutKeys {
                    if let found = rest.range(of: ck), found.lowerBound < end {
                        end = found.lowerBound
                    }
                }
                subject = String(rest[..<end]).trimmingCharacters(in: .whitespacesAndNewlines)
                break
            }
        }

        // Cuerpo: "que diga", "diciendo", "cuerpo", "body"
        for key in [" que diga ", " diciendo ", " cuerpo ", " body ", " y diga ", " texto "] {
            if let r = s.range(of: key) {
                body = String(s[r.upperBound...]).trimmingCharacters(in: .whitespacesAndNewlines)
                // Quitar un posible "cc …" al final
                if let ccRange = body.range(of: " cc ") {
                    let maybeCC = String(body[ccRange.upperBound...]).trimmingCharacters(in: .whitespaces)
                    body = String(body[..<ccRange.lowerBound]).trimmingCharacters(in: .whitespaces)
                    if !maybeCC.isEmpty { cc = maybeCC }
                }
                break
            }
        }

        // Cc explícito
        if cc == nil, let r = s.range(of: " cc ") ?? s.range(of: " con copia a ") ?? s.range(of: " copia a ") {
            cc = String(s[r.upperBound...]).trimmingCharacters(in: .whitespacesAndNewlines)
        }

        // Si no hay "a X" pero hay un email en la frase, úsalo
        if to.isEmpty {
            let pattern = #"[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}"#
            if let regex = try? NSRegularExpression(pattern: pattern, options: [.caseInsensitive]) {
                let range = NSRange(s.startIndex..<s.endIndex, in: s)
                if let match = regex.firstMatch(in: s, options: [], range: range),
                   let swiftRange = Range(match.range, in: s) {
                    to = String(s[swiftRange])
                }
            }
        }

        // Si no logramos casi nada, aún devolvemos composeMail con lo que hay
        // (Brain puede enriquecer si vino por unknown; aquí ya detectamos la intención).
        return .composeMail(to: to, subject: subject, body: body, cc: cc)
    }

    /// «mira la pantalla», «qué hay en pantalla», «qué estoy haciendo», etc.
    private static func keyboardJob(_ s: String, original: String) -> Intent? {
        let triggers = [
            "usa el teclado", "usar el teclado", "con el teclado",
            "mientras como", "mientras salgo", "mientras no estoy",
            "deja haciendo", "deja escribiendo", "sigue escribiendo",
            "escribe en la app", "escribe esto", "tipea", "tipear",
            "trabajo de teclado", "modo teclado", "keyboard"
        ]
        guard triggers.contains(where: { s.contains($0) }) else { return nil }
        var instruction = s
        for prefix in ["argos ", "oye ", "por favor "] {
            if instruction.hasPrefix(prefix) {
                instruction = String(instruction.dropFirst(prefix.count))
            }
        }
        instruction = instruction.trimmingCharacters(in: .whitespacesAndNewlines)
        if instruction.isEmpty {
            instruction = original.trimmingCharacters(in: .whitespacesAndNewlines)
        }
        return .keyboardJob(instruction: instruction)
    }

    private static func analyzeScreen(_ s: String, original: String) -> Intent? {
        let question = original.trimmingCharacters(in: .whitespacesAndNewlines)
        let fallbackQ = question.isEmpty ? "¿Qué hay en pantalla?" : question

        let whatAmIDoing =
            s.contains("que estoy haciendo") ||
            s.contains("que estoy viendo") ||
            s.contains("en que estoy") ||
            s.contains("que hago ahora") ||
            s.contains("que tengo abierto") ||
            s.contains("que tengo en pantalla")

        if whatAmIDoing {
            return .analyzeScreen(question: fallbackQ)
        }

        let hasScreen =
            s.contains("pantalla") ||
            s.contains("screen") ||
            s.contains("monitor") ||
            s.contains("display")

        let lookVerb =
            s.contains("mira") || s.contains("mirar") ||
            s.contains("observa") || s.contains("observar") ||
            s.contains("describe") || s.contains("describeme") ||
            s.contains("ve la") || s.contains("ves la") ||
            s.contains("ve mi") || s.contains("ves mi") ||
            s.contains("que hay") || s.contains("que se ve") ||
            s.contains("dime que") || s.contains("analiza") ||
            s.contains("revisa") || s.contains("chequea") ||
            s.contains("echale un vistazo") || s.contains("un vistazo")

        if hasScreen && lookVerb {
            return .analyzeScreen(question: fallbackQ)
        }

        // «mira lo que estoy haciendo / viendo» sin decir pantalla.
        if (s.contains("mira") || s.contains("observa") || s.contains("revisa")) &&
            (s.contains("haciendo") || s.contains("viendo") || s.contains("trabajo")) {
            return .analyzeScreen(question: fallbackQ)
        }

        return nil
    }

    private static func codeTemplate(_ s: String) -> CodeTemplate? {
        if s.contains("navbar") || s.contains("barra de navegacion") || s.contains("nav bar") ||
            (s.contains("codigo") && s.contains("nav")) {
            return .navbarHTML
        }
        if s.contains("landing") || s.contains("pagina de aterrizaje") ||
            (s.contains("html") && (s.contains("pagina") || s.contains("web") || s.contains("landing"))) ||
            s.contains("preparame un html") || s.contains("prepara un html") {
            return .landingHTML
        }
        if s.contains("codigo de navbar") { return .navbarHTML }
        return nil
    }

    private static let apps: [(names: [String], bundle: String, display: String)] = [
        (["safari"], "com.apple.Safari", "Safari"),
        (["finder", "el finder"], "com.apple.finder", "Finder"),
        (["notas", "notes", "la app notas"], "com.apple.Notes", "Notas"),
        (["mail", "correo", "el correo"], "com.apple.mail", "Mail"),
        (["calendario", "calendar"], "com.apple.iCal", "Calendario"),
        (["terminal"], "com.apple.Terminal", "Terminal"),
        (["ajustes del sistema", "preferencias del sistema", "system settings",
          "ajustes", "configuracion"], "com.apple.systempreferences", "Ajustes del Sistema"),
        (["xcode"], "com.apple.dt.Xcode", "Xcode"),
        (["pages"], "com.apple.iWork.Pages", "Pages"),
        (["numbers"], "com.apple.iWork.Numbers", "Numbers"),
        (["keynote"], "com.apple.iWork.Keynote", "Keynote"),
        (["preview", "vista previa"], "com.apple.Preview", "Vista Previa"),
        (["music", "musica"], "com.apple.Music", "Music"),
        (["messages", "mensajes"], "com.apple.MobileSMS", "Mensajes"),
        (["cursor"], "com.todesktop.230313mzl4w4u92", "Cursor")
    ]

    private static func openApp(_ s: String, original: String) -> Intent? {
        let triggers = ["abre", "abrir", "abra", "lanzar", "lanza", "abreme", "iniciame", "inicia"]
        let looksLikeOpen = triggers.contains(where: { s.hasPrefix($0) || s.contains(" \($0) ") })
            || s.hasPrefix("abre ") || s.hasPrefix("abrir ") || s.hasPrefix("lanza ")
        guard looksLikeOpen else { return nil }

        for app in apps {
            for name in app.names {
                if s.contains(name) {
                    return .openApp(bundleID: app.bundle, displayName: app.display)
                }
            }
        }

        // V7: abrir cualquier app por nombre («abre Xcode», «abre Cursor», «abre Pages»).
        var name = s
        for t in ["abreme ", "abre me ", "abre ", "abrir ", "abra ", "lanza ", "lanzar ", "iniciame ", "inicia "] {
            if name.hasPrefix(t) {
                name = String(name.dropFirst(t.count))
                break
            }
        }
        name = name.trimmingCharacters(in: .whitespacesAndNewlines)
        for junk in ["por favor", "please", "la app", "la aplicacion", "el programa"] {
            name = name.replacingOccurrences(of: junk, with: "")
        }
        name = name.trimmingCharacters(in: .whitespacesAndNewlines)
        // Quitar artículo inicial
        for art in ["el ", "la ", "los ", "las ", "app "] {
            if name.hasPrefix(art) { name = String(name.dropFirst(art.count)) }
        }
        name = name.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !name.isEmpty, name.count < 60 else { return nil }
        // Capitalizar para display; bundle vacío → ActionRunner resuelve por nombre.
        let display = original.split(separator: " ").drop(while: {
            let w = $0.lowercased()
            return ["abre", "abrir", "abra", "lanza", "lanzar", "abreme", "oye", "argos", "por", "favor", "el", "la"].contains(w)
        }).joined(separator: " ")
        let displayName = display.isEmpty ? name : String(display).trimmingCharacters(in: .whitespacesAndNewlines)
        return .openApp(bundleID: "", displayName: displayName.isEmpty ? name : displayName)
    }

    private static func webSearch(_ s: String) -> Intent? {
        let patterns = ["busca en google ", "buscar en google ", "busca en internet ",
                        "busca por ", "buscar ", "busca ", "googlea ", "google "]
        for p in patterns where s.hasPrefix(p) {
            let q = String(s.dropFirst(p.count)).trimmingCharacters(in: .whitespaces)
            if !q.isEmpty { return .webSearch(query: q) }
        }
        if s.hasPrefix("busca") {
            let q = String(s.dropFirst(5)).trimmingCharacters(in: .whitespaces)
            if !q.isEmpty { return .webSearch(query: q) }
        }
        return nil
    }

    private static func createFile(_ s: String) -> Intent? {
        guard s.contains("archivo") || s.contains("fichero") || s.contains("nota en el escritorio") else {
            return nil
        }
        guard s.contains("crea") || s.contains("crear") || s.contains("haz un") ||
                s.contains("escribe") || s.contains("guardame") || s.contains("nuevo archivo") else {
            return nil
        }

        var name = "nota-argos"
        var contents = "Creado por Argos.\n"

        if let range = s.range(of: "llamado ") ?? s.range(of: "que se llame ") ?? s.range(of: "con nombre ") {
            var rest = String(s[range.upperBound...]).trimmingCharacters(in: .whitespaces)
            if let con = rest.range(of: " con ") {
                name = String(rest[..<con.lowerBound])
                contents = String(rest[con.upperBound...]).trimmingCharacters(in: .whitespaces)
                if contents.isEmpty { contents = "Creado por Argos.\n" }
            } else {
                name = rest
            }
        } else if s.contains("archivo ") {
            if let r = s.range(of: "archivo ") {
                var rest = String(s[r.upperBound...]).trimmingCharacters(in: .whitespaces)
                rest = rest.replacingOccurrences(of: "en el escritorio", with: "")
                    .trimmingCharacters(in: .whitespaces)
                if !rest.isEmpty && rest != "de texto" && rest != "txt" {
                    name = rest
                }
            }
        }

        name = name.trimmingCharacters(in: .whitespacesAndNewlines)
        if name.isEmpty { name = "nota-argos" }
        return .createFile(name: name, contents: contents)
    }

    /// "modo programar: <tarea>", "modo documentos <tarea>", "modo revisar <tarea>".
    static func workIntent(_ cleaned: String) -> Intent? {
        let prefixes: [(String, String)] = [
            ("modo programar", "programar"), ("modo documentos", "documentos"), ("modo revisar", "revisar")
        ]
        for (prefix, mode) in prefixes where cleaned.hasPrefix(prefix) {
            let rest = String(cleaned.dropFirst(prefix.count))
            let goal = rest.trimmingCharacters(in: CharacterSet(charactersIn: " :,.-"))
            return goal.isEmpty ? nil : .work(mode: mode, goal: goal)
        }
        return nil
    }
}
