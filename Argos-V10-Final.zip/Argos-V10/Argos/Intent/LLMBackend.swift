import Foundation

/// Contrato compartido para Ollama (local) y OpenAI Astra (nube).
struct ChatMessage: Equatable {
    let role: String  // "user" | "assistant" | "system"
    let content: String
}

protocol LLMBackend {
    /// Nombre corto para UI (ej. "llama3.2" o "gpt-6-astra").
    var displayModelName: String { get }
    /// Nombre del modelo de visión (puede ser el mismo en cloud).
    var displayVisionModelName: String { get }

    /// Chat con JSON forzado cuando el backend lo soporta (Brain reason).
    func chat(system: String, user: String) async throws -> String
    /// Chat con historial de sesión (roles user/assistant) + mensaje user actual.
    func chat(system: String, history: [ChatMessage], user: String, forceJSON: Bool) async throws -> String
    /// Texto libre (keyboard job, etc.).
    func plainChat(system: String, user: String) async throws -> String
    /// Visión multimodal: JPEG + pregunta.
    func chatVision(system: String, user: String, imageJPEG: Data) async throws -> String
}

/// Proveedor de cerebro: local, solo Astra, o auto (Astra con fallback a Ollama).
enum BrainProvider: String, CaseIterable, Identifiable {
    case local
    case astra
    case auto

    static let defaultsKey = "argos.brainProvider"
    static let defaultValue: BrainProvider = .auto

    var id: String { rawValue }

    var menuTitle: String {
        switch self {
        case .local: return "Local"
        case .astra: return "Astra"
        case .auto: return "Auto"
        }
    }

    var shortLabel: String {
        switch self {
        case .local: return "Local"
        case .astra: return "Astra"
        case .auto: return "Auto"
        }
    }

    static var current: BrainProvider {
        let defaults = UserDefaults.standard
        let raw = (defaults.string(forKey: defaultsKey) ?? defaults.string(forKey: "viernes.brainProvider"))?
            .trimmingCharacters(in: .whitespacesAndNewlines)
            .lowercased() ?? ""
        let value = BrainProvider(rawValue: raw) ?? .auto
        if defaults.string(forKey: defaultsKey) == nil { defaults.set(value.rawValue, forKey: defaultsKey) }
        return value
    }

    static func setCurrent(_ provider: BrainProvider) {
        UserDefaults.standard.set(provider.rawValue, forKey: defaultsKey)
    }
}

/// Errores unificados del cerebro (español para TTS/UI).
enum BrainBackendError: Error, LocalizedError {
    case missingAPIKey
    case unauthorized
    case rateLimited
    case network
    case emptyResponse
    case badStatus(Int)
    case decodeFailed
    case unreachableLocal
    case bothFailed(astraMessage: String, localMessage: String)

    var errorDescription: String? { userMessage }

    var userMessage: String {
        switch self {
        case .missingAPIKey:
            return "No hay API key de OpenAI en el Keychain. Guárdala en Ajustes o con el comando security."
        case .unauthorized:
            return "La API key de OpenAI fue rechazada (401). Revisa la clave en el Keychain."
        case .rateLimited:
            return "OpenAI está limitando peticiones (rate limit). Espera un momento o usa Local."
        case .network:
            return "No hay red o OpenAI no responde. Prueba de nuevo o usa Local."
        case .emptyResponse:
            return "El modelo no devolvió una respuesta útil."
        case .badStatus(let code):
            return "El servicio respondió con código \(code)."
        case .decodeFailed:
            return "No pude leer la respuesta del modelo."
        case .unreachableLocal:
            return "Ollama no está corriendo o el modelo no está instalado."
        case .bothFailed(let astraMessage, let localMessage):
            return "Ni Astra ni Ollama respondieron. Astra: \(astraMessage) Local: \(localMessage)"
        }
    }
}
