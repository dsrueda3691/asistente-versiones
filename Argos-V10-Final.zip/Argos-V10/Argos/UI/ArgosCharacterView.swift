import SwiftUI
import AppKit

/// Personaje original de Argos. La geometría se dibuja en Canvas para mantener
/// la misma silueta en todos los estados y animar únicamente detalles/expresión.
struct ArgosCharacterView: View {
    let activity: ArgosRuntimeState.Activity
    let compact: Bool
    let onDragChanged: () -> Void
    let onDragEnded: () -> Void

    @State private var dragging = false

    private var accent: Color {
        switch activity {
        case .idle: return Color(red: 0.64, green: 0.47, blue: 1.0)
        case .listening: return Color(red: 0.34, green: 0.92, blue: 0.72)
        case .thinking: return Color(red: 1.0, green: 0.72, blue: 0.22)
        case .working: return Color(red: 0.34, green: 0.68, blue: 1.0)
        case .waitingApproval: return Color(red: 0.68, green: 0.48, blue: 1.0)
        case .success: return Color(red: 0.38, green: 0.94, blue: 0.55)
        case .error: return Color(red: 1.0, green: 0.32, blue: 0.42)
        }
    }

    var body: some View {
        TimelineView(.animation(minimumInterval: 1.0 / 60.0, paused: false)) { timeline in
            Canvas { context, size in
                let t = timeline.date.timeIntervalSinceReferenceDate
                let scale = compact ? 0.70 : 1.0
                let cx = size.width * 0.5
                let cy = size.height * (compact ? 0.53 : 0.50)
                let s = min(size.width, size.height) * 0.39 * scale
                let bob = CGFloat(sin(t * (activity == .working ? 5.0 : 1.7)) * (activity == .working ? 2.2 : 0.9))
                let blink = (t.truncatingRemainder(dividingBy: 5.1) > 4.84)
                let pulse = CGFloat((sin(t * 2.4) + 1) * 0.5)

                // Aura / partículas: muy discreta para que el personaje siga leyendo bien dentro del notch.
                if !compact {
                    let aura = Path(ellipseIn: CGRect(x: cx - s * 1.28, y: cy - s * 1.30, width: s * 2.56, height: s * 2.56))
                    context.stroke(aura, with: .color(accent.opacity(0.12)), style: StrokeStyle(lineWidth: 1, dash: [5, 9]))
                }

                let particles: [(CGFloat, CGFloat, CGFloat)] = [(-1.14, -0.82, 3), (1.18, -0.58, 3), (-1.20, 0.42, 2.5), (1.10, 0.65, 2.2)]
                for (px, py, r) in particles {
                    let drift = CGFloat(sin(t * 0.9 + Double(px * 4))) * 3
                    context.fill(Path(ellipseIn: CGRect(x: cx + s * px - r / 2, y: cy + s * py + drift - r / 2, width: r, height: r)), with: .color(accent.opacity(0.55)))
                }

                // Cuerpo / cabeza de Argos: una silueta puntiaguda única, propia del proyecto.
                var body = Path()
                body.move(to: CGPoint(x: cx - s * 0.72, y: cy + s * 0.94 + bob))
                body.addCurve(to: CGPoint(x: cx - s * 0.98, y: cy - s * 0.70 + bob), control1: CGPoint(x: cx - s * 0.96, y: cy + s * 0.45), control2: CGPoint(x: cx - s * 1.02, y: cy - s * 0.20))
                body.addLine(to: CGPoint(x: cx - s * 0.42, y: cy - s * 0.54 + bob))
                body.addLine(to: CGPoint(x: cx - s * 0.27, y: cy - s * 1.08 + bob))
                body.addLine(to: CGPoint(x: cx - s * 0.02, y: cy - s * 0.56 + bob))
                body.addLine(to: CGPoint(x: cx + s * 0.34, y: cy - s * 1.15 + bob))
                body.addLine(to: CGPoint(x: cx + s * 0.33, y: cy - s * 0.54 + bob))
                body.addLine(to: CGPoint(x: cx + s * 0.94, y: cy - s * 0.74 + bob))
                body.addCurve(to: CGPoint(x: cx + s * 0.74, y: cy + s * 0.94 + bob), control1: CGPoint(x: cx + s * 1.00, y: cy + s * 0.18), control2: CGPoint(x: cx + s * 0.90, y: cy + s * 0.68))
                body.addCurve(to: CGPoint(x: cx + s * 0.22, y: cy + s * 1.24 + bob), control1: CGPoint(x: cx + s * 0.55, y: cy + s * 1.08), control2: CGPoint(x: cx + s * 0.40, y: cy + s * 1.23))
                body.addCurve(to: CGPoint(x: cx - s * 0.03, y: cy + s * 0.94 + bob), control1: CGPoint(x: cx + s * 0.08, y: cy + s * 1.35), control2: CGPoint(x: cx - s * 0.02, y: cy + s * 1.17))
                body.addCurve(to: CGPoint(x: cx - s * 0.72, y: cy + s * 0.94 + bob), control1: CGPoint(x: cx - s * 0.30, y: cy + s * 1.28), control2: CGPoint(x: cx - s * 0.54, y: cy + s * 1.10))
                body.closeSubpath()
                context.fill(body, with: .color(Color(red: 0.08, green: 0.065, blue: 0.15)))
                context.stroke(body, with: .color(Color(red: 0.25, green: 0.20, blue: 0.42)), lineWidth: max(1.2, s * 0.032))

                // Pequeños bigotes / líneas laterales.
                if !compact {
                    let whisker = Path { p in
                        p.move(to: CGPoint(x: cx - s * 0.66, y: cy + s * 0.22 + bob)); p.addLine(to: CGPoint(x: cx - s * 0.98, y: cy + s * 0.18 + bob))
                        p.move(to: CGPoint(x: cx - s * 0.67, y: cy + s * 0.38 + bob)); p.addLine(to: CGPoint(x: cx - s * 1.02, y: cy + s * 0.46 + bob))
                        p.move(to: CGPoint(x: cx + s * 0.66, y: cy + s * 0.22 + bob)); p.addLine(to: CGPoint(x: cx + s * 0.98, y: cy + s * 0.18 + bob))
                        p.move(to: CGPoint(x: cx + s * 0.67, y: cy + s * 0.38 + bob)); p.addLine(to: CGPoint(x: cx + s * 1.02, y: cy + s * 0.46 + bob))
                    }
                    context.stroke(whisker, with: .color(accent.opacity(0.55)), lineWidth: 1.7)
                }

                // Gema central.
                var gem = Path()
                gem.move(to: CGPoint(x: cx, y: cy - s * 0.60 + bob))
                gem.addLine(to: CGPoint(x: cx + s * 0.13, y: cy - s * 0.39 + bob))
                gem.addLine(to: CGPoint(x: cx, y: cy - s * 0.17 + bob))
                gem.addLine(to: CGPoint(x: cx - s * 0.13, y: cy - s * 0.39 + bob))
                gem.closeSubpath()
                context.fill(gem, with: .color(accent.opacity(0.95)))

                // Mirada: pequeños movimientos hacia el puntero/actividad sin depender de una segunda vista.
                let mouse = NSEvent.mouseLocation
                let horizontal = max(-1.0, min(1.0, (mouse.x - (NSScreen.main?.frame.midX ?? mouse.x)) / 500.0))
                let vertical = max(-1.0, min(1.0, (mouse.y - (NSScreen.main?.frame.midY ?? mouse.y)) / 400.0))
                let lookX = CGFloat(horizontal) * s * 0.07
                let lookY = CGFloat(vertical) * s * 0.035
                let eyeY = cy - s * 0.06 + bob + lookY
                let eyeW = s * 0.39
                let eyeH: CGFloat
                switch activity {
                case .listening: eyeH = s * 0.18
                case .thinking: eyeH = s * 0.13
                case .error: eyeH = s * 0.11
                default: eyeH = s * 0.15
                }

                if !blink {
                    drawEye(context: &context, center: CGPoint(x: cx - s * 0.31 + lookX, y: eyeY), width: eyeW, height: eyeH, angry: activity == .error, closed: activity == .working)
                    drawEye(context: &context, center: CGPoint(x: cx + s * 0.31 + lookX, y: eyeY), width: eyeW, height: eyeH, angry: activity == .error, closed: activity == .working)
                } else {
                    let blinkPath = Path { p in
                        p.move(to: CGPoint(x: cx - s * 0.56, y: eyeY)); p.addLine(to: CGPoint(x: cx - s * 0.08, y: eyeY))
                        p.move(to: CGPoint(x: cx + s * 0.08, y: eyeY)); p.addLine(to: CGPoint(x: cx + s * 0.56, y: eyeY))
                    }
                    context.stroke(blinkPath, with: .color(accent.opacity(0.9)), lineWidth: max(1.5, s * 0.035))
                }

                // Boca según estado.
                var mouth = Path()
                switch activity {
                case .listening:
                    mouth.addEllipse(in: CGRect(x: cx - s * 0.08, y: cy + s * 0.29 + bob, width: s * 0.16, height: s * 0.16))
                    context.fill(mouth, with: .color(accent.opacity(0.9)))
                case .error:
                    mouth.move(to: CGPoint(x: cx - s * 0.25, y: cy + s * 0.34 + bob)); mouth.addLine(to: CGPoint(x: cx - s * 0.08, y: cy + s * 0.28 + bob)); mouth.addLine(to: CGPoint(x: cx + s * 0.08, y: cy + s * 0.36 + bob)); mouth.addLine(to: CGPoint(x: cx + s * 0.25, y: cy + s * 0.29 + bob))
                    context.stroke(mouth, with: .color(accent), lineWidth: max(1.5, s * 0.035))
                case .waitingApproval:
                    mouth.move(to: CGPoint(x: cx - s * 0.22, y: cy + s * 0.31 + bob)); mouth.addQuadCurve(to: CGPoint(x: cx, y: cy + s * 0.40 + bob), control: CGPoint(x: cx - s * 0.10, y: cy + s * 0.47 + bob)); mouth.addQuadCurve(to: CGPoint(x: cx + s * 0.22, y: cy + s * 0.31 + bob), control: CGPoint(x: cx + s * 0.10, y: cy + s * 0.47 + bob))
                    context.stroke(mouth, with: .color(accent), lineWidth: max(1.5, s * 0.03))
                case .success, .idle:
                    mouth.move(to: CGPoint(x: cx - s * 0.23, y: cy + s * 0.30 + bob)); mouth.addQuadCurve(to: CGPoint(x: cx, y: cy + s * 0.43 + bob), control: CGPoint(x: cx - s * 0.10, y: cy + s * 0.47 + bob)); mouth.addQuadCurve(to: CGPoint(x: cx + s * 0.23, y: cy + s * 0.30 + bob), control: CGPoint(x: cx + s * 0.10, y: cy + s * 0.47 + bob))
                    context.stroke(mouth, with: .color(accent), lineWidth: max(1.5, s * 0.03))
                case .thinking:
                    mouth.move(to: CGPoint(x: cx - s * 0.18, y: cy + s * 0.36 + bob)); mouth.addLine(to: CGPoint(x: cx + s * 0.18, y: cy + s * 0.36 + bob))
                    context.stroke(mouth, with: .color(accent), lineWidth: max(1.5, s * 0.028))
                case .working:
                    mouth.move(to: CGPoint(x: cx - s * 0.20, y: cy + s * 0.35 + bob)); mouth.addLine(to: CGPoint(x: cx + s * 0.20, y: cy + s * 0.35 + bob))
                    context.stroke(mouth, with: .color(accent), lineWidth: max(1.5, s * 0.028))
                }

                if !compact {
                    switch activity {
                    case .thinking:
                        for i in 0..<3 {
                            let y = cy - s * (1.12 + CGFloat(i) * 0.17)
                            let x = cx + s * (0.62 + CGFloat(i) * 0.12)
                            context.fill(Path(ellipseIn: CGRect(x: x - 2.5, y: y - 2.5, width: 5, height: 5)), with: .color(accent.opacity(0.45 + 0.2 * Double(i) / 3)))
                        }
                    case .working:
                        for i in 0..<3 {
                            let phase = t * 4 + Double(i) * 1.9
                            let x = cx + CGFloat(cos(phase)) * s * 1.12
                            let y = cy + CGFloat(sin(phase)) * s * 0.72
                            context.fill(Path(ellipseIn: CGRect(x: x - 2, y: y - 2, width: 4, height: 4)), with: .color(accent.opacity(0.65)))
                        }
                    case .error:
                        let mark = Path { p in
                            p.move(to: CGPoint(x: cx - s * 1.08, y: cy + s * 0.65)); p.addLine(to: CGPoint(x: cx - s * 0.92, y: cy + s * 0.49))
                            p.move(to: CGPoint(x: cx + s * 1.08, y: cy + s * 0.58)); p.addLine(to: CGPoint(x: cx + s * 0.94, y: cy + s * 0.43))
                        }
                        context.stroke(mark, with: .color(accent.opacity(0.8)), lineWidth: 2)
                    case .success:
                        let ring = Path(ellipseIn: CGRect(x: cx - s * (0.92 + pulse * 0.06), y: cy - s * (0.92 + pulse * 0.06), width: s * (1.84 + pulse * 0.12), height: s * (1.84 + pulse * 0.12)))
                        context.stroke(ring, with: .color(accent.opacity(0.16 * (1 - pulse))), lineWidth: 2)
                    default: break
                    }
                }
            }
        }
        .frame(width: compact ? 70 : 120, height: compact ? 42 : 84)
        .contentShape(Rectangle())
        .gesture(
            DragGesture(minimumDistance: 5)
                .onChanged { _ in
                    if !dragging { dragging = true; onDragChanged() }
                }
                .onEnded { _ in
                    dragging = false
                    onDragEnded()
                }
        )
        .scaleEffect(dragging ? 1.06 : 1)
        .animation(.easeOut(duration: 0.15), value: dragging)
        .accessibilityLabel("Argos, estado \(activity.title). Arrastra el personaje sobre una ventana para usarla como contexto.")
    }

    private func drawEye(context: inout GraphicsContext, center: CGPoint, width: CGFloat, height: CGFloat, angry: Bool, closed: Bool) {
        var eye = Path()
        let tilt: CGFloat = angry ? 0.11 : 0
        eye.move(to: CGPoint(x: center.x - width * 0.48, y: center.y - tilt * width))
        eye.addQuadCurve(to: CGPoint(x: center.x + width * 0.48, y: center.y + height), control: CGPoint(x: center.x, y: center.y + height * 1.35))
        eye.addQuadCurve(to: CGPoint(x: center.x - width * 0.48, y: center.y - tilt * width), control: CGPoint(x: center.x, y: center.y - height * 0.55))
        context.fill(eye, with: .color(accent))
        if !closed {
            let pupil = Path(ellipseIn: CGRect(x: center.x - width * 0.055, y: center.y + height * 0.10, width: width * 0.11, height: max(3, height * 0.50)))
            context.fill(pupil, with: .color(Color.black.opacity(0.88)))
        }
    }
}
