import AppKit
import ApplicationServices

struct WindowContext: Equatable {
    let application: String
    let title: String
    let pid: pid_t
    let frame: CGRect

    var summary: String {
        let app = application.isEmpty ? "Aplicación" : application
        let t = title.isEmpty ? "Ventana sin título" : title
        return "Ventana: \(app) · \(t)"
    }
}

enum ArgosWindowContextProvider {
    static func requestAccessibility() -> Bool {
        if AXIsProcessTrusted() { return true }
        let options = [kAXTrustedCheckOptionPrompt.takeUnretainedValue() as String: true] as CFDictionary
        return AXIsProcessTrustedWithOptions(options)
    }

    static func contextAtCurrentMouse(requestAccessibility: Bool = false) -> WindowContext? {
        if requestAccessibility { _ = self.requestAccessibility() }
        return context(atQuartzPoint: currentQuartzMouseLocation())
    }

    static func context(atScreenPoint point: CGPoint) -> WindowContext? {
        // Compatibilidad para llamadas antiguas que entreguen coordenadas AppKit.
        let quartz = quartzPoint(fromAppKitPoint: point)
        return context(atQuartzPoint: quartz)
    }

    private static func context(atQuartzPoint point: CGPoint) -> WindowContext? {
        guard let list = CGWindowListCopyWindowInfo([.optionOnScreenOnly, .excludeDesktopElements], kCGNullWindowID) as? [[String: Any]] else { return nil }
        let currentPID = NSRunningApplication.current.processIdentifier

        for info in list {
            guard let layer = info[kCGWindowLayer as String] as? Int, layer == 0 else { continue }
            guard let ownerPID = info[kCGWindowOwnerPID as String] as? pid_t, ownerPID != currentPID else { continue }
            let ownerName = info[kCGWindowOwnerName as String] as? String ?? ""
            let windowName = info[kCGWindowName as String] as? String ?? ""
            guard let boundsDict = info[kCGWindowBounds as String] as? NSDictionary,
                  let bounds = CGRect(dictionaryRepresentation: boundsDict as CFDictionary),
                  bounds.width > 80, bounds.height > 50,
                  bounds.contains(point) else { continue }

            let axTitle = accessibilityWindowTitle(at: point, expectedPID: ownerPID)
                ?? accessibilityFocusedWindowTitle(pid: ownerPID)
                ?? windowName
            return WindowContext(application: ownerName, title: axTitle, pid: ownerPID, frame: bounds)
        }
        return nil
    }

    private static func accessibilityWindowTitle(at point: CGPoint, expectedPID: pid_t) -> String? {
        guard AXIsProcessTrusted() else { return nil }
        let system = AXUIElementCreateSystemWide()
        var element: AXUIElement?
        guard AXUIElementCopyElementAtPosition(system, Float(point.x), Float(point.y), &element) == .success,
              let element else { return nil }
        var pid: pid_t = 0
        guard AXUIElementGetPid(element, &pid) == .success, pid == expectedPID else { return nil }
        var value: CFTypeRef?
        guard AXUIElementCopyAttributeValue(element, kAXTitleAttribute as CFString, &value) == .success else { return nil }
        return value as? String
    }

    private static func accessibilityFocusedWindowTitle(pid: pid_t) -> String? {
        guard AXIsProcessTrusted() else { return nil }
        let app = AXUIElementCreateApplication(pid)
        var value: CFTypeRef?
        guard AXUIElementCopyAttributeValue(app, kAXFocusedWindowAttribute as CFString, &value) == .success,
              let window = value else { return nil }
        var title: CFTypeRef?
        guard AXUIElementCopyAttributeValue(window as! AXUIElement, kAXTitleAttribute as CFString, &title) == .success else { return nil }
        return title as? String
    }

    private static func currentQuartzMouseLocation() -> CGPoint {
        if let event = CGEvent(source: nil) {
            return event.location
        }
        return CGPoint(x: 0, y: 0)
    }

    private static func quartzPoint(fromAppKitPoint point: CGPoint) -> CGPoint {
        guard let screen = NSScreen.screens.first(where: { $0.frame.contains(point) }) ?? NSScreen.main else { return point }
        return CGPoint(x: point.x, y: screen.frame.maxY - point.y)
    }
}
