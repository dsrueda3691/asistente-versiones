# Argos V10

Argos es un compañero de escritorio nativo para macOS. Evoluciona el Core de Viernes V9 sin sustituir su cerebro, memoria ni AgentMode: la transformación principal está en la experiencia del notch, el runtime visual y la relación entre agente, contexto y aprobaciones.

## Qué incluye esta versión

- `NSPanel` sin bordes anclado a la zona superior/notch, con modo compacto y expandido.
- Aparición al acercar el puntero y ocultado automático cuando Argos está inactivo.
- Máquina de estados visual: reposo, escucha, pensamiento, trabajo, aprobación, éxito y error.
- Personaje original dibujado con SwiftUI `Canvas` + `TimelineView`.
- Actividad del agente en tiempo real con pasos, progreso y estado de error.
- Aprobaciones de `PendingAction` con tipo de riesgo y detalle del plan.
- Chat con historial de memoria local dentro del panel expandido.
- Drag & drop de texto/PDF/archivos, imágenes y audio/video.
- Audio/video soltados: transcripción local mediante los motores que ya soporta `MediaUnderstander`.
- Drag del personaje sobre una ventana para asociar esa ventana como contexto.
- Captura puntual de la ventana seleccionada con ScreenCaptureKit.
- Contextos múltiples, eliminables desde la pestaña Contexto.
- Conserva el Core: Brain local/nube, Memory, ActionRunner, AgentMode, voz, Calendar, Reminders, Mail y Notes.
- Migración transparente de preferencias y API key de V9 cuando los datos antiguos siguen disponibles.
- AppIcon original de Argos.
- Sin dependencias de terceros.

## Arquitectura

```text
Core existente
  Brain / Memory / LLM / AgentMode / Actions
                  |
          Argos Runtime Bridge
                  |
       +----------+----------+
       |          |          |
     Notch     Activity   Approval
       |          |          |
       +----------+----------+
                  |
             NSPanel/AppKit
                  |
            SwiftUI / Canvas
```

El Core no conoce la UI del notch. La UI recibe eventos y estado a través de `ArgosRuntimeState`.

## Estados

```text
IDLE
LISTENING
THINKING
WORKING
WAITING_APPROVAL
SUCCESS
ERROR
```

## Contexto

- Arrastra un archivo al notch para adjuntarlo.
- Arrastra el personaje sobre una ventana para identificarla y capturarla.
- El contexto queda en memoria de sesión hasta que se elimina desde Contexto.
- Para audio/video se intenta transcribir de forma local con Whisper/whisper.cpp/Ollama cuando están instalados.

## Permisos

Según las funciones usadas, macOS puede solicitar:

- Micrófono
- Reconocimiento de voz
- Grabación de pantalla
- Accesibilidad
- Calendario
- Recordatorios
- Automatización de Mail/Notas

Argos no añade shell arbitrario ni acciones destructivas al AgentMode existente.

## Compilación

Requiere macOS 14 o posterior y Xcode compatible con Swift 5. El entorno de desarrollo debe tener las capacidades/permisos de macOS que utilicen las funciones que quieras probar.

No se puede realizar un build real de Xcode fuera de macOS. Antes de distribuir, ejecuta el target `Argos`, prueba permisos y revisa firma/notarización con tu cuenta de desarrollo.

## Referencia de UX

La arquitectura visual de compañero en notch toma ideas de proyectos públicos como Coucou, pero Argos utiliza nombre, personaje, iconografía y código propios.
