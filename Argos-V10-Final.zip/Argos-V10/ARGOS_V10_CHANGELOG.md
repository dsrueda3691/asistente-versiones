# Argos V10 — cambios de esta revisión

## Corregido

- Eliminada la llamada inexistente `showpanel()`.
- El clic del icono de la barra ya no activa escucha accidentalmente.
- Estados de éxito/error/cancelación separados en el runtime.
- Errores de voz, pantalla, documentos, teclado, media y acciones confirmables reflejados en la expresión de Argos cuando corresponde.
- Drag del personaje usa monitores locales y globales; el movimiento sigue al puntero incluso sobre la propia aplicación.
- Coordenadas de ventanas calculadas en coordenadas Quartz para evitar el eje Y invertido de AppKit.
- Se solicita Accesibilidad cuando el usuario usa el contexto de ventana.
- Título de ventana obtenido mediante Accessibility cuando está disponible, con fallback a CGWindowList.
- El panel compacto usa la geometría de la zona superior/notch de `NSScreen` cuando macOS la expone.
- El panel compacto no anima el cambio físico de tamaño; las animaciones quedan en SwiftUI/Canvas.
- Aparición por proximidad del puntero y ocultado automático en reposo.

## UI nueva

- Personaje Argos redibujado en Canvas con expresiones por estado.
- Mirada dinámica, parpadeo, partículas, aura, gema y animaciones de trabajo/pensamiento/error/éxito.
- Chat con historial de `ConversationMemory`.
- Pestañas Argos / Actividad / Contexto.
- Aprobaciones con riesgo, detalle y plan de agente.
- Progreso de agente con barra, estados `✓ ● ○ ✗` y `Paso X/Y`.
- Contextos múltiples con eliminación individual.

## Contexto

- Varios archivos por drag & drop.
- Imágenes para visión.
- Texto/PDF/documentos mediante `DocumentReader`.
- Audio/video soltados directamente: transcripción mediante `MediaUnderstander.understand(url:)`.
- Ventana seleccionada: captura puntual mediante ScreenCaptureKit.

## Migración

- UserDefaults de `viernes.*` se copian a `argos.*` si todavía no existen.
- Keychain busca también servicios legacy de Viernes y migra la clave encontrada a Argos.
- La memoria busca el directorio anterior `Viernes` y la copia a Argos al guardar.
- AppIcon original de Argos generado para todas las variantes macOS.

## Validación realizada

- Todos los `.swift` pasan `swiftc -parse` en el entorno de validación.
- No se detectan referencias a `showpanel()` ni a `PopoverView` en el código fuente.
- No se pudo ejecutar `xcodebuild` porque la validación se realizó fuera de macOS/Xcode.
