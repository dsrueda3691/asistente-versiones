# Viernes

Asistente local de barra de menús para macOS. Habla en español, te escucha cuando se lo pides, y responde con voz. Inspirado en Friday (MCU), seco y breve. **V1 no necesita internet ni APIs de pago.**

Viernes es una herramienta personal. **No está pensada para el App Store**: el sandbox está desactivado para poder leer y crear archivos en el Escritorio.

## Requisitos

- Mac con **macOS 14** o posterior (MacBook Air M5 sirve).
- **Xcode** gratis desde el App Store (cuenta Apple personal, sin pago).
- Micrófono.
- Opcional: reconocimiento de voz en español **en el dispositivo** (Ajustes → Apple Intelligence / Siri y dictado, o descargar idioma español para Dictado).

No hace falta Cursor de pago, Origin, ni un LLM en la nube.

## Cómo abrirlo y ejecutarlo

1. Instala **Xcode** desde el App Store (gratis) y ábrelo una vez para aceptar la licencia.
2. Abre **`Viernes.xcodeproj`** (no un Swift Package: es una app nativa).
3. Arriba, elige el destino **My Mac**.
4. En el target **Viernes** → pestaña **Signing & Capabilities**:
   - *Automatically manage signing* debe estar activo.
   - **Team** → inicia sesión con tu **Apple ID** (gratis) y elige **Personal Team**.
   - El bundle id es `com.danielrueda.Viernes`.
5. **Product → Run** (⌘R).
6. La primera vez macOS pedirá **micrófono** y **reconocimiento de voz**. Acepta ambos. Los textos del permiso son honestos: Viernes no queda escuchando siempre.
7. No verás icono en el Dock (`LSUIElement`). Busca **✦ / V** en la barra de menús, a la derecha.

Si Xcode se queja de *Signing for Viernes requires a development team*: es normal hasta que elijas el Personal Team. No hace falta cuenta de pago de desarrollador para correr en *tu* Mac.

## Cómo usarlo

- Clic en el icono **o** atajo **⌥Espacio** (Option + Espacio) → empieza a escuchar.
- Habla en español. Puedes empezar con «Viernes», «oye» u «hola»; se ignoran.
- Viernes parsea la frase con reglas locales, actúa, y responde en voz alta (TTS).

### Frases de ejemplo

| Intent | Prueba a decir |
| --- | --- |
| Saludo | «hola», «quién eres» |
| Hora / fecha | «qué hora es», «qué fecha es hoy» |
| Abrir app | «abre Safari», «abre Finder», «abre Notas», «abre Mail», «abre Calendario», «abre Terminal», «abre Ajustes» |
| Buscar en la web | «busca recetas de arepas» |
| Crear archivo | «crea un archivo llamado tareas» |
| Listar escritorio | «lista el escritorio», «qué hay en el escritorio» |
| Código al portapapeles | «prepárame un html de landing», «código de navbar» |
| Leer portapapeles | «lee el portapapeles» |
| Salir | «adiós», «cierra Viernes» |
| Ayuda | «qué puedes hacer» |

Si no entiende, lo admite y te da tres ejemplos.

## Permisos y atajo

| Permiso | Para qué | Obligatorio en V1 |
| --- | --- | --- |
| Micrófono | Solo mientras escuchas (clic o atajo) | Sí |
| Reconocimiento de voz | Pasar audio a texto (on-device si Apple lo permite) | Sí |
| Accesibilidad | Que **⌥Espacio** funcione *desde otras apps* | No. El clic en la barra de menús siempre sirve. |

Si el atajo no funciona desde Safari u otra app:

**Ajustes del Sistema → Privacidad y seguridad → Accesibilidad →** activa **Viernes**.

Viernes registra el atajo de tres maneras: monitor local (si la app tiene foco), monitor global (Accesibilidad) y `RegisterEventHotKey` de Carbon. Si una falla, las otras o el clic cubren.

## Qué hace V1 (y qué no)

**Sí**

- Icono de barra de menús, sin Dock.
- Voz de entrada (Speech) y de salida (AVSpeechSynthesizer), español.
- Intents con reglas locales: saludo, hora, abrir apps de Apple, búsqueda web, archivo de texto en Escritorio, listar Escritorio, plantillas HTML al portapapeles, leer portapapeles, salir.
- Crear archivos **solo** en el Escritorio. Si eso falla, en `~/Documents/Viernes`.
- Stub de protocolo `LocalLLMClient` / `OllamaClient` para más adelante. **No se llama.** La app arranca sin Ollama y sin red.

**No (a propósito, y por qué)**

- **Wake word siempre encendido** («Oye Viernes» 24/7): gasta batería y micrófono continuo. En V1 escuchas solo con clic o atajo.
- **Grabación de pantalla**: invasivo, permisos pesados, no hace falta para comandos de voz.
- **Correo / Mail automation**: fácil de hacer mal (enviar algo que no querías). Queda para una versión con confirmación explícita.
- **Inyectar código en Cursor / VS Code**: requiere accesibilidad agresiva o extensiones; no es V1.
- **Borrar archivos**: V1 **nunca** borra. Tampoco ejecuta shell arbitrario a partir de lo que dices.
- **LLM de pago / red**: cero coste de API. Ollama en localhost es el siguiente paso, opcional.

**Sandbox OFF.** Es una herramienta tuya, no un binario de tienda. No subas esta app al App Store tal cual.

**Hardened Runtime OFF** para que *Run* local con Personal Team sea más simple. Cuando firmes para distribuir (fuera de la tienda) puedes activarlo.

## Reconocimiento on-device

Viernes pide `requiresOnDeviceRecognition` cuando el reconocedor lo soporta, con locale **es-CO** y si no **es-ES**.

Matices:

- La primera vez, macOS puede descargar datos de dictado. Necesitas red *para esa descarga del sistema*, no para un servidor de Viernes.
- Si Apple no puede procesar en el dispositivo, el framework Speech **puede** usar los servidores de Apple. El `Info.plist` lo dice. Viernes no tiene backend propio.
- Si el reconocimiento falla, instala español en Dictado / teclado y vuelve a intentar. El clic en el icono sigue funcionando.

## Estructura

```
viernes-mac/
  README.md
  Viernes.xcodeproj          ← ábrelo con Xcode
  Viernes/
    ViernesApp.swift         ← @main, AppDelegate, estado
    StatusBarController.swift
    Speech/Listener.swift
    Speech/Speaker.swift
    Intent/IntentParser.swift
    Intent/ActionRunner.swift   (incluye stub Ollama)
    UI/PopoverView.swift
    Info.plist
    Viernes.entitlements     ← sandbox false
    Assets.xcassets
```

Mínimo macOS 14. Swift + SwiftUI + AppKit.

## Siguientes pasos (cuando V1 te sirva)

1. **Ollama en localhost** — implementar `OllamaClient.complete` contra `http://127.0.0.1:11434` y usarlo solo si el intent es `.unknown`. Seguir sin requerirlo para arrancar.
2. **Extensión de Cursor / VS Code** — un puente local (socket o archivo) para «pega esto en el editor». No inyectar por Accesibilidad.
3. **Mail** — leer o redactar con confirmación en el popover, nunca enviar solo con la voz.
4. **Wake word** — opcional, con un modelo local pequeño y un interruptor bien visible; no por defecto, por batería.

## Licencia

Uso personal de Daniel Rueda Mier. Haz lo que quieras con el código en tu Mac.
