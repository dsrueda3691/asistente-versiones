import SwiftUI
import AppKit
import AVFoundation
import Speech

@main
struct ViernesApp: App {
    @NSApplicationDelegateAdaptor(AppDelegate.self) private var appDelegate

    var body: some Scene {
        // Sin ventana principal: Viernes vive en la barra de menús (LSUIElement).
        Settings {
            SettingsHelpView()
        }
    }
}

@MainActor
final class AppDelegate: NSObject, NSApplicationDelegate {
    private var statusBar: StatusBarController?
    let state = AppState()
    let listener = Listener()
    let speaker = Speaker()
    let parser = IntentParser()
    let runner = ActionRunner()

    func applicationDidFinishLaunching(_ notification: Notification) {
        NSApp.setActivationPolicy(.accessory)
        listener.onPartialTranscript = { [weak self] text in
            self?.state.transcript = text
        }
        statusBar = StatusBarController(
            state: state,
            onListen: { [weak self] in
                self?.toggleListening()
            },
            onQuit: { [weak self] in
                self?.quitApp()
            }
        )
        speaker.speak("Viernes en línea.")
    }

    func applicationWillTerminate(_ notification: Notification) {
        listener.stopListening()
        speaker.stop()
    }

    func toggleListening() {
        if state.isListening {
            listener.stopListening()
            state.isListening = false
            state.statusMessage = "Listo"
            return
        }
        startListening()
    }

    func startListening() {
        speaker.stop()
        state.isListening = true
        state.statusMessage = "Te escucho…"
        state.transcript = ""
        statusBar?.showPopover()

        Task { @MainActor in
            let permitted = await PermissionGate.requestSpeechAndMicrophone()
            guard permitted else {
                self.state.isListening = false
                self.state.statusMessage = "Faltan permisos"
                let reply = "Necesito micrófono y reconocimiento de voz. Actívalos en Ajustes del Sistema."
                self.state.lastReply = reply
                self.speaker.speak(reply)
                return
            }

            do {
                let phrase = try await self.listener.listen(maxDuration: 12)
                self.state.transcript = phrase
                self.state.isListening = false
                if phrase.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
                    let reply = "No te escuché. Prueba otra vez."
                    self.state.lastReply = reply
                    self.state.statusMessage = "Listo"
                    self.speaker.speak(reply)
                    return
                }
                await self.handle(phrase: phrase)
            } catch {
                self.state.isListening = false
                let reply: String
                if let listenError = error as? ListenerError {
                    reply = listenError.userMessage
                } else {
                    reply = "No pude escucharte. Revisa el micrófono."
                }
                self.state.lastReply = reply
                self.state.statusMessage = "Listo"
                self.speaker.speak(reply)
            }
        }
    }

    func handle(phrase: String) async {
        state.statusMessage = "Pensando…"
        let intent = parser.parse(phrase)
        let outcome = await runner.run(intent)
        state.lastReply = outcome.spoken
        state.statusMessage = "Listo"
        if let extra = outcome.detail {
            state.detail = extra
        }
        speaker.speak(outcome.spoken)
        if outcome.shouldQuit {
            DispatchQueue.main.asyncAfter(deadline: .now() + 1.6) {
                NSApp.terminate(nil)
            }
        }
    }

    func quitApp() {
        speaker.speak("Hasta luego.")
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.8) {
            NSApp.terminate(nil)
        }
    }
}

@MainActor
final class AppState: ObservableObject {
    @Published var isListening = false
    @Published var statusMessage = "Listo"
    @Published var transcript = ""
    @Published var lastReply = "Viernes, en línea. Pulsa ⌥Espacio o el icono y habla."
    @Published var detail = ""
}

struct SettingsHelpView: View {
    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            Text("Viernes")
                .font(.title2.weight(.semibold))
            Text("Asistente local en la barra de menús. No necesita red para V1.")
                .foregroundStyle(.secondary)
            Text("Atajo: ⌥Espacio. Si no responde desde otras apps, da Accesibilidad a Viernes en Ajustes del Sistema.")
                .font(.callout)
        }
        .padding(20)
        .frame(width: 360)
    }
}

enum PermissionGate {
    static func requestSpeechAndMicrophone() async -> Bool {
        let mic = await requestMicrophone()
        let speech = await requestSpeech()
        return mic && speech
    }

    private static func requestMicrophone() async -> Bool {
        await withCheckedContinuation { continuation in
            AVAudioApplication.requestRecordPermission { granted in
                continuation.resume(returning: granted)
            }
        }
    }

    private static func requestSpeech() async -> Bool {
        await withCheckedContinuation { continuation in
            SFSpeechRecognizer.requestAuthorization { status in
                continuation.resume(returning: status == .authorized)
            }
        }
    }
}
