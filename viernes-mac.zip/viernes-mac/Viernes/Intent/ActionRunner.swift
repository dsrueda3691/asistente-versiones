import Foundation
import AppKit

struct ActionOutcome {
    let spoken: String
    var detail: String? = nil
    var shouldQuit: Bool = false
}

/// Ejecuta intents locales. Nunca borra archivos. Nunca lanza shell arbitrario.
@MainActor
final class ActionRunner {
    private let fileManager = FileManager.default

    func run(_ intent: Intent) async -> ActionOutcome {
        switch intent {
        case .greet:
            return ActionOutcome(spoken: "Hola. Viernes, en línea.")
        case .whoAmI:
            return ActionOutcome(spoken: "Viernes. Asistente local de Daniel. Sin nube de por medio.")
        case .help:
            return ActionOutcome(
                spoken: "Puedo decir la hora, abrir Safari o Finder, buscar en la web, crear un archivo en el escritorio, copiar un HTML al portapapeles o leerte lo que copiaste.",
                detail: Self.helpDetail
            )
        case .time:
            return ActionOutcome(spoken: "Son las \(Self.formatTime(Date())).")
        case .date:
            return ActionOutcome(spoken: "Hoy es \(Self.formatDate(Date())).")
        case .openApp(let bundleID, let displayName):
            let ok = openApplication(bundleID: bundleID, named: displayName)
            if ok {
                return ActionOutcome(spoken: "Abriendo \(displayName).")
            }
            return ActionOutcome(spoken: "No pude abrir \(displayName).")
        case .webSearch(let query):
            openWebSearch(query)
            return ActionOutcome(spoken: "Buscando eso.")
        case .createFile(let name, let contents):
            do {
                let url = try createTextFile(named: name, contents: contents)
                return ActionOutcome(
                    spoken: "Archivo creado.",
                    detail: url.path
                )
            } catch {
                return ActionOutcome(spoken: "No pude crear el archivo.")
            }
        case .listDesktop:
            let listing = listDesktop()
            return ActionOutcome(spoken: listing.spoken, detail: listing.detail)
        case .copyTemplate(let kind):
            let code = CodeSnippets.snippet(kind)
            NSPasteboard.general.clearContents()
            NSPasteboard.general.setString(code, forType: .string)
            return ActionOutcome(spoken: "Ya está en el portapapeles.")
        case .readClipboard:
            let text = NSPasteboard.general.string(forType: .string)?
                .trimmingCharacters(in: .whitespacesAndNewlines) ?? ""
            if text.isEmpty {
                return ActionOutcome(spoken: "El portapapeles está vacío.")
            }
            let spoken: String
            if text.count > 280 {
                spoken = "El portapapeles dice: " + String(text.prefix(280)) + "…"
            } else {
                spoken = "El portapapeles dice: " + text
            }
            return ActionOutcome(spoken: spoken, detail: text)
        case .quit:
            return ActionOutcome(spoken: "Hasta luego.", shouldQuit: true)
        case .unknown:
            return ActionOutcome(
                spoken: "Eso no lo tengo en V1. Prueba: qué hora es, abre Safari, o busca recetas de arepas.",
                detail: Self.helpDetail
            )
        }
    }

    private func openApplication(bundleID: String, named displayName: String) -> Bool {
        let workspace = NSWorkspace.shared
        let config = NSWorkspace.OpenConfiguration()
        config.activates = true
        var ids = [bundleID]
        if bundleID == "com.apple.systempreferences" {
            ids.append("com.apple.Preferences")
        }
        for id in ids {
            if let url = workspace.urlForApplication(withBundleIdentifier: id) {
                workspace.openApplication(at: url, configuration: config) { _, _ in }
                return true
            }
        }
        return false
    }

    private func openWebSearch(_ query: String) {
        var allowed = CharacterSet.urlQueryAllowed
        allowed.remove(charactersIn: "&+=")
        let encoded = query.addingPercentEncoding(withAllowedCharacters: allowed) ?? query
        let urlString = "https://www.google.com/search?q=\(encoded)"
        if let url = URL(string: urlString) {
            NSWorkspace.shared.open(url)
        }
    }

    private func createTextFile(named rawName: String, contents: String) throws -> URL {
        let safe = Self.sanitizeFileName(rawName)
        let desktop = fileManager.urls(for: .desktopDirectory, in: .userDomainMask).first
        let documents = fileManager.urls(for: .documentDirectory, in: .userDomainMask).first
        let fallbackDir = documents?.appendingPathComponent("Viernes", isDirectory: true)

        let directory: URL
        if let desktop, fileManager.fileExists(atPath: desktop.path) {
            directory = desktop
        } else if let fallbackDir {
            try fileManager.createDirectory(at: fallbackDir, withIntermediateDirectories: true)
            directory = fallbackDir
        } else {
            throw NSError(domain: "Viernes", code: 1, userInfo: [NSLocalizedDescriptionKey: "Sin carpeta destino"])
        }

        var url = directory.appendingPathComponent(safe)
        if fileManager.fileExists(atPath: url.path) {
            let stamp = ISO8601DateFormatter().string(from: Date()).replacingOccurrences(of: ":", with: "-")
            let base = (safe as NSString).deletingPathExtension
            let ext = (safe as NSString).pathExtension
            let extra = ext.isEmpty ? "\(base)-\(stamp)" : "\(base)-\(stamp).\(ext)"
            url = directory.appendingPathComponent(extra)
        }

        let body = contents.isEmpty ? "Creado por Viernes.\n" : (contents.hasSuffix("\n") ? contents : contents + "\n")
        try body.write(to: url, atomically: true, encoding: .utf8)
        return url
    }

    private func listDesktop() -> (spoken: String, detail: String) {
        let desktop = fileManager.urls(for: .desktopDirectory, in: .userDomainMask).first
        guard let desktop else {
            return ("No encuentro el escritorio.", "")
        }
        let keys: [URLResourceKey] = [.isRegularFileKey, .isDirectoryKey, .nameKey]
        guard let items = try? fileManager.contentsOfDirectory(
            at: desktop,
            includingPropertiesForKeys: keys,
            options: [.skipsHiddenFiles]
        ) else {
            return ("No pude leer el escritorio.", "")
        }
        let names = items
            .map(\.lastPathComponent)
            .sorted { $0.localizedCaseInsensitiveCompare($1) == .orderedAscending }
        let count = names.count
        if count == 0 {
            return ("El escritorio está vacío.", "")
        }
        let preview = Array(names.prefix(15))
        let spokenPreview = Array(names.prefix(5)).joined(separator: ", ")
        let spoken = "\(count) elementos en el escritorio. Entre ellos: \(spokenPreview)."
        return (spoken, preview.joined(separator: "\n"))
    }

    static func sanitizeFileName(_ raw: String) -> String {
        var name = raw.trimmingCharacters(in: .whitespacesAndNewlines)
        name = name.replacingOccurrences(of: "/", with: "-")
        name = name.replacingOccurrences(of: ":", with: "-")
        name = name.replacingOccurrences(of: "\\", with: "-")
        name = (name as NSString).lastPathComponent
        name = name.replacingOccurrences(of: "..", with: ".")
        let banned = CharacterSet(charactersIn: "<>|?*\"\0")
        name = name.components(separatedBy: banned).joined()
        name = name.trimmingCharacters(in: .whitespacesAndNewlines)
        if name.isEmpty { name = "nota-viernes" }
        if name.count > 80 {
            name = String(name.prefix(80))
        }
        let ext = (name as NSString).pathExtension.lowercased()
        if ext.isEmpty {
            name += ".txt"
        }
        return name
    }

    static func formatTime(_ date: Date) -> String {
        let f = DateFormatter()
        f.locale = Locale(identifier: "es_CO")
        f.timeStyle = .short
        f.dateStyle = .none
        return f.string(from: date)
    }

    static func formatDate(_ date: Date) -> String {
        let f = DateFormatter()
        f.locale = Locale(identifier: "es_CO")
        f.dateFormat = "EEEE d 'de' MMMM 'de' yyyy"
        return f.string(from: date)
    }

    static let helpDetail = """
    Ejemplos:
    • hola / quién eres
    • qué hora es / qué fecha es
    • abre Safari / Finder / Notas / Mail / Calendario / Terminal / Ajustes
    • busca recetas de arepas
    • crea un archivo llamado tareas
    • lista el escritorio
    • prepárame un html de landing
    • código de navbar
    • lee el portapapeles
    • adiós
    """
}

enum CodeSnippets {
    static func snippet(_ kind: CodeTemplate) -> String {
        switch kind {
        case .landingHTML:
            return landing
        case .navbarHTML:
            return navbar
        }
    }

    static let landing = """
    <!DOCTYPE html>
    <html lang="es">
    <head>
      <meta charset="utf-8" />
      <meta name="viewport" content="width=device-width, initial-scale=1" />
      <title>Landing</title>
      <style>
        :root { color-scheme: light dark; --accent: #0a84ff; }
        * { box-sizing: border-box; }
        body { margin: 0; font-family: system-ui, sans-serif; }
        header { min-height: 70vh; display: grid; place-items: center; padding: 3rem 1.5rem; text-align: center; }
        h1 { font-size: clamp(2rem, 6vw, 3.4rem); margin: 0 0 0.6rem; }
        p { opacity: 0.8; max-width: 36rem; }
        a.cta { display: inline-block; margin-top: 1.4rem; padding: 0.85rem 1.4rem; background: var(--accent); color: #fff; border-radius: 999px; text-decoration: none; }
      </style>
    </head>
    <body>
      <header>
        <div>
          <h1>Hola, mundo</h1>
          <p>Landing mínima lista para editar. Generada por Viernes.</p>
          <a class="cta" href="#contacto">Empezar</a>
        </div>
      </header>
    </body>
    </html>
    """

    static let navbar = """
    <nav class="nav">
      <a class="logo" href="/">Viernes</a>
      <ul>
        <li><a href="#inicio">Inicio</a></li>
        <li><a href="#proyectos">Proyectos</a></li>
        <li><a href="#contacto">Contacto</a></li>
      </ul>
    </nav>
    <style>
      .nav { display: flex; justify-content: space-between; align-items: center; padding: 0.9rem 1.4rem; font-family: system-ui, sans-serif; }
      .nav ul { display: flex; gap: 1.2rem; list-style: none; margin: 0; padding: 0; }
      .nav a { color: inherit; text-decoration: none; }
      .logo { font-weight: 700; }
    </style>
    """
}

// MARK: - Stub Ollama (V1 no lo usa; el app arranca sin red y sin Ollama)

/// Contrato para un LLM local futuro (Ollama en localhost). No se llama en V1.
protocol LocalLLMClient {
    func complete(prompt: String) async throws -> String
}

enum OllamaError: Error {
    case notEnabledInV1
    case unreachable
}

/// Cliente de Ollama a http://127.0.0.1:11434. Stub: lanza notEnabledInV1.
struct OllamaClient: LocalLLMClient {
    var baseURL = URL(string: "http://127.0.0.1:11434")!

    func complete(prompt: String) async throws -> String {
        // V1 es solo reglas locales. No hay llamadas de red.
        throw OllamaError.notEnabledInV1
    }
}
