import AppKit
import SwiftUI
import Carbon

/// Icono de barra de menús, popover y atajo ⌥Espacio.
///
/// El atajo se registra de tres formas:
/// 1. Monitor local (siempre, si Viernes tiene el foco).
/// 2. Monitor global (necesita Accesibilidad para otras apps).
/// 3. Carbon RegisterEventHotKey (atajo de sistema; suele ir sin Accesibilidad).
final class StatusBarController: NSObject {
    private let statusItem: NSStatusItem
    private let popover = NSPopover()
    private let state: AppState
    private let onListen: () -> Void
    private let onQuit: () -> Void

    private var localMonitor: Any?
    private var globalMonitor: Any?
    private var carbonHotKey: EventHotKeyRef?
    private var carbonHandler: EventHandlerRef?
    private var lastHotKeyAt = Date.distantPast

    init(state: AppState, onListen: @escaping () -> Void, onQuit: @escaping () -> Void) {
        self.state = state
        self.onListen = onListen
        self.onQuit = onQuit
        self.statusItem = NSStatusBar.system.statusItem(withLength: NSStatusItem.variableLength)
        super.init()
        configureStatusItem()
        configurePopover()
        installHotkeys()
    }

    deinit {
        if let localMonitor {
            NSEvent.removeMonitor(localMonitor)
        }
        if let globalMonitor {
            NSEvent.removeMonitor(globalMonitor)
        }
        if let carbonHotKey {
            UnregisterEventHotKey(carbonHotKey)
        }
        if let carbonHandler {
            RemoveEventHandler(carbonHandler)
        }
    }

    func showPopover() {
        guard let button = statusItem.button else { return }
        if !popover.isShown {
            popover.show(relativeTo: button.bounds, of: button, preferredEdge: .minY)
        }
    }

    func hidePopover() {
        popover.performClose(nil)
    }

    @objc private func statusItemClicked(_ sender: Any?) {
        showPopover()
        onListen()
    }

    private func configureStatusItem() {
        guard let button = statusItem.button else { return }
        if let image = NSImage(systemSymbolName: "sparkles", accessibilityDescription: "Viernes") {
            image.isTemplate = true
            button.image = image
            button.title = ""
        } else if let image = NSImage(systemSymbolName: "waveform", accessibilityDescription: "Viernes") {
            image.isTemplate = true
            button.image = image
            button.title = ""
        } else {
            button.title = "V"
        }
        button.toolTip = "Viernes — pulsa o ⌥Espacio para hablar"
        button.target = self
        button.action = #selector(statusItemClicked(_:))
        button.sendAction(on: [.leftMouseUp])
    }

    private func configurePopover() {
        popover.behavior = .transient
        popover.animates = true
        popover.contentSize = NSSize(width: 340, height: 280)
        let root = PopoverView(
            state: state,
            onListen: { [weak self] in self?.onListen() },
            onQuit: { [weak self] in self?.onQuit() }
        )
        popover.contentViewController = NSHostingController(rootView: root)
    }

    private func installHotkeys() {
        localMonitor = NSEvent.addLocalMonitorForEvents(matching: .keyDown) { [weak self] event in
            guard let self, Self.isOptionSpace(event) else { return event }
            self.handleHotKey()
            return nil
        }

        globalMonitor = NSEvent.addGlobalMonitorForEvents(matching: .keyDown) { [weak self] event in
            guard let self, Self.isOptionSpace(event) else { return }
            self.handleHotKey()
        }

        registerCarbonOptionSpace()
    }

    private static func isOptionSpace(_ event: NSEvent) -> Bool {
        let flags = event.modifierFlags.intersection(.deviceIndependentFlagsMask)
        let wantsOption = flags.contains(.option)
        let extras = flags.intersection([.command, .control, .shift])
        return event.keyCode == UInt16(kVK_Space) && wantsOption && extras.isEmpty
    }

    fileprivate func handleHotKey() {
        let now = Date()
        guard now.timeIntervalSince(lastHotKeyAt) > 0.45 else { return }
        lastHotKeyAt = now
        if Thread.isMainThread {
            onListen()
        } else {
            DispatchQueue.main.async { [weak self] in
                self?.onListen()
            }
        }
    }

    private func registerCarbonOptionSpace() {
        var hotKeyID = EventHotKeyID(signature: OSType(0x56524E53), id: 1) // 'VRNS'
        var eventType = EventTypeSpec(
            eventClass: OSType(kEventClassKeyboard),
            eventKind: UInt32(kEventHotKeyPressed)
        )
        let context = Unmanaged.passUnretained(self).toOpaque()
        var handler: EventHandlerRef?
        let installed = InstallEventHandler(
            GetApplicationEventTarget(),
            carbonHotKeyCallback,
            1,
            &eventType,
            context,
            &handler
        )
        if installed == noErr {
            carbonHandler = handler
        }
        var hotKey: EventHotKeyRef?
        let registered = RegisterEventHotKey(
            UInt32(kVK_Space),
            UInt32(optionKey),
            hotKeyID,
            GetApplicationEventTarget(),
            0,
            &hotKey
        )
        if registered == noErr {
            carbonHotKey = hotKey
        }
    }
}

private let carbonHotKeyCallback: EventHandlerProcPtr = { _, _, userData in
    guard let userData else { return noErr }
    let controller = Unmanaged<StatusBarController>.fromOpaque(userData).takeUnretainedValue()
    DispatchQueue.main.async {
        controller.handleHotKey()
    }
    return noErr
}
