import SwiftUI

struct PopoverView: View {
    @ObservedObject var state: AppState
    var onListen: () -> Void
    var onQuit: () -> Void

    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack(alignment: .firstTextBaseline) {
                Image(systemName: state.isListening ? "waveform" : "sparkles")
                    .symbolRenderingMode(.hierarchical)
                    .foregroundStyle(.tint)
                Text("Viernes")
                    .font(.title3.weight(.semibold))
                Spacer()
                Text(state.statusMessage)
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }

            Group {
                if state.isListening {
                    HStack(spacing: 8) {
                        ProgressView()
                            .controlSize(.small)
                        Text("Te escucho…")
                            .font(.callout)
                    }
                } else {
                    Text("⌥Espacio o pulsa Escuchar. Habla en español.")
                        .font(.callout)
                        .foregroundStyle(.secondary)
                }
            }

            labeledBlock(title: "Tú", text: state.transcript.isEmpty ? "—" : state.transcript)
            labeledBlock(title: "Viernes", text: state.lastReply.isEmpty ? "—" : state.lastReply)

            if !state.detail.isEmpty {
                ScrollView {
                    Text(state.detail)
                        .font(.caption.monospaced())
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .textSelection(.enabled)
                }
                .frame(maxHeight: 72)
            }

            HStack {
                Button(state.isListening ? "Detener" : "Escuchar") {
                    onListen()
                }
                .keyboardShortcut(.space, modifiers: [])
                .buttonStyle(.borderedProminent)

                Spacer()

                Button("Salir") {
                    onQuit()
                }
                .buttonStyle(.borderless)
            }

            Text("Si ⌥Espacio no funciona desde otras apps: Ajustes → Privacidad y seguridad → Accesibilidad → Viernes.")
                .font(.caption2)
                .foregroundStyle(.tertiary)
                .fixedSize(horizontal: false, vertical: true)
        }
        .padding(16)
        .frame(width: 340)
    }

    @ViewBuilder
    private func labeledBlock(title: String, text: String) -> some View {
        VStack(alignment: .leading, spacing: 4) {
            Text(title.uppercased())
                .font(.caption2.weight(.semibold))
                .foregroundStyle(.secondary)
            Text(text)
                .font(.body)
                .fixedSize(horizontal: false, vertical: true)
        }
    }
}
