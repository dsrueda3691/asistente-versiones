import Foundation
import AVFoundation

/// Síntesis de voz en español (es-CO, luego es-ES).
final class Speaker: NSObject, AVSpeechSynthesizerDelegate {
    private let synthesizer = AVSpeechSynthesizer()

    override init() {
        super.init()
        synthesizer.delegate = self
    }

    func speak(_ text: String) {
        let trimmed = text.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmed.isEmpty else { return }
        stop()
        let utterance = AVSpeechUtterance(string: trimmed)
        utterance.voice = Self.preferredSpanishVoice()
        utterance.rate = AVSpeechUtteranceDefaultSpeechRate * 0.96
        utterance.pitchMultiplier = 1.02
        utterance.volume = 1.0
        utterance.prefersAssistiveTechnologySettings = false
        synthesizer.speak(utterance)
    }

    func stop() {
        if synthesizer.isSpeaking {
            synthesizer.stopSpeaking(at: .immediate)
        }
    }

    static func preferredSpanishVoice() -> AVSpeechSynthesisVoice? {
        let voices = AVSpeechSynthesisVoice.speechVoices()
        let preferred = ["es-CO", "es-ES", "es-MX", "es-US", "es-AR", "es-CL"]
        for quality in [AVSpeechSynthesisVoiceQuality.premium, .enhanced, .default] {
            for lang in preferred {
                if let match = voices.first(where: { $0.language == lang && $0.quality == quality }) {
                    return match
                }
            }
        }
        for lang in preferred {
            if let voice = AVSpeechSynthesisVoice(language: lang) {
                return voice
            }
        }
        return AVSpeechSynthesisVoice(language: "es")
    }
}
