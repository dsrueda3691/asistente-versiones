import SwiftUI
import AppKit
import AVFoundation
import Speech

@main
struct ViernesApp: App {
    @NSApplicationDelegateAdaptor(AppDelegate.self) private var appDelegate

    var body: some Scene {
        Settings {
            SettingsHelpView()
        }
    }
}

@MainActor
final class AppDelegate: NSObject, NSApplicationDelegate {
    private var statusBar: StatusBarController?
    let state = AppState()
    let listener = Listener()
    let speaker = Speaker()
    let parser = IntentParser()
    let runner = ActionRunner()
    let brain = Brain()
    let keyboard = KeyboardController()

    func applicationDidFinishLaunching(_ notification: Notification) {
        NSApp.setActivationPolicy(.accessory)
        state.ollamaModel = OllamaClient.configuredModelName
        state.visionModel = OllamaClient.configuredVisionModelName
        state.isMuted = UserDefaults.standard.bool(forKey: AppState.mutedDefaultsKey)

        speaker.onSpeakingChanged = { [weak self] speaking in
            self?.state.isSpeaking = speaking
        }
        listener.onPartialTranscript = { [weak self] text in
            self?.state.transcript = text
        }
        statusBar = StatusBarController(
            state: state,
            onListen: { [weak self] in
                self?.toggleListening()
            },
            onQuit: { [weak self] in
                self?.quitApp()
            },
            onSendChat: { [weak self] text in
                self?.submitTyped(text)
            },
            onToggleMute: { [weak self] in
                self?.toggleMute()
            },
            onStopJob: { [weak self] in
                self?.stopKeyboardJob()
            },
            onOpenSettings: { [weak self] in
                self?.openSettings()
            }
        )
        keyboard.onProgress = { [weak self] msg in
            self?.state.statusMessage = msg
            self?.state.isKeyboardJobRunning = true
        }
        speakReply("Viernes en línea.")
    }

    func applicationWillTerminate(_ notification: Notification) {
        keyboard.cancel()
        listener.stopListening()
        speaker.stop()
    }

    func stopKeyboardJob() {
        keyboard.cancel()
        state.isKeyboardJobRunning = false
        state.statusMessage = "Listo"
        let reply = "Paré el trabajo de teclado."
        state.lastReply = reply
        speakReply(reply)
    }

    func openSettings() {
        NSApp.sendAction(Selector(("showSettingsWindow:")), to: nil, from: nil)
        NSApp.activate(ignoringOtherApps: true)
    }

    func toggleMute() {
        state.isMuted.toggle()
        UserDefaults.standard.set(state.isMuted, forKey: AppState.mutedDefaultsKey)
        if state.isMuted {
            speaker.stop()
            state.isSpeaking = false
        }
    }

    func speakReply(_ text: String) {
        speaker.speak(text, muted: state.isMuted)
        if state.isMuted {
            state.isSpeaking = false
        }
    }

    func submitTyped(_ text: String) {
        let trimmed = text.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmed.isEmpty else { return }
        if state.isListening {
            listener.stopListening()
            state.isListening = false
        }
        speaker.stop()
        state.transcript = trimmed
        statusBar?.showPopover()
        Task { @MainActor in
            await self.handle(phrase: trimmed)
        }
    }

    func toggleListening() {
        if state.isListening {
            listener.stopListening()
            state.isListening = false
            state.statusMessage = "Listo"
            return
        }
        startListening()
    }

    func startListening() {
        speaker.stop()
        state.isListening = true
        state.statusMessage = "Te escucho…"
        state.transcript = ""
        statusBar?.showPopover()

        Task { @MainActor in
            let permitted = await PermissionGate.requestSpeechAndMicrophone()
            guard permitted else {
                self.state.isListening = false
                self.state.statusMessage = "Faltan permisos"
                let reply = "Necesito micrófono y reconocimiento de voz. Actívalos en Ajustes del Sistema."
                self.state.lastReply = reply
                self.speakReply(reply)
                return
            }

            do {
                let phrase = try await self.listener.listen(maxDuration: 12)
                self.state.transcript = phrase
                self.state.isListening = false
                if phrase.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
                    let reply = "No te escuché. Prueba otra vez."
                    self.state.lastReply = reply
                    self.state.statusMessage = "Listo"
                    self.speakReply(reply)
                    return
                }
                await self.handle(phrase: phrase)
            } catch {
                self.state.isListening = false
                let reply: String
                if let listenError = error as? ListenerError {
                    reply = listenError.userMessage
                } else {
                    reply = "No pude escucharte. Revisa el micrófono."
                }
                self.state.lastReply = reply
                self.state.statusMessage = "Listo"
                self.speakReply(reply)
            }
        }
    }

    func handle(phrase: String) async {
        state.statusMessage = "Pensando…"
        state.ollamaModel = OllamaClient.configuredModelName
        state.visionModel = OllamaClient.configuredVisionModelName
        let intent = parser.parse(phrase)

        if case .analyzeScreen(let question) = intent {
            await handleAnalyzeScreen(question: question)
            return
        }

        if case .keyboardJob(let instruction) = intent {
            await handleKeyboardJob(instruction: instruction)
            return
        }

        if case .unknown = intent {
            await handleUnknown(phrase: phrase)
            return
        }

        let outcome = await runner.run(intent)
        state.lastReply = outcome.spoken
        state.statusMessage = "Listo"
        if let extra = outcome.detail {
            state.detail = extra
        } else {
            state.detail = ""
        }
        speakReply(outcome.spoken)
        if outcome.shouldQuit {
            DispatchQueue.main.asyncAfter(deadline: .now() + 1.6) {
                NSApp.terminate(nil)
            }
        }
    }


    private func handleKeyboardJob(instruction: String) async {
        state.isKeyboardJobRunning = true
        state.statusMessage = "Trabajo en curso…"
        state.detail = "Instrucción: \(instruction)\nApp: \(keyboard.frontmostAppName())"
        speakReply("Empiezo. Avísame si paro.")
        do {
            let result = try await keyboard.runJob(instruction: instruction) { instr in
                let client = OllamaClient()
                let system = "Eres Viernes. Generas SOLO el texto que hay que escribir o pegar en la app de adelante. Sin JSON, sin markdown, sin explicaciones ni comillas envolventes."
                let user = "Tarea del usuario:\n\(instr)"
                return try await client.plainChat(system: system, user: user)
            }
            state.lastReply = result.spoken
            state.detail = result.detail
            state.statusMessage = "Listo"
            state.isKeyboardJobRunning = false
            speakReply(result.spoken)
        } catch let err as KeyboardError {
            state.lastReply = err.userMessage
            if case .notTrusted = err {
                state.detail = "Ajustes del Sistema → Privacidad y seguridad → Accesibilidad → activa Viernes."
            } else {
                state.detail = ""
            }
            state.statusMessage = "Listo"
            state.isKeyboardJobRunning = false
            speakReply(err.userMessage)
        } catch {
            let msg = "No pude completar el trabajo de teclado."
            state.lastReply = msg
            state.statusMessage = "Listo"
            state.isKeyboardJobRunning = false
            speakReply(msg)
        }
    }

    private func handleAnalyzeScreen(question: String) async {
        state.statusMessage = "Mirando pantalla…"
        state.detail = ""
        do {
            let jpeg = try await ScreenCapture.captureMainDisplayJPEG()
            state.statusMessage = "Pensando…"
            let reply = await brain.analyzeScreen(question: question, imageJPEG: jpeg)
            state.lastReply = reply.speak
            state.detail = reply.detail ?? ""
            state.statusMessage = "Listo"
            speakReply(reply.speak)
        } catch let err as ScreenCaptureError {
            state.lastReply = err.userMessage
            state.detail = "Ajustes del Sistema → Privacidad y seguridad → Grabación de pantalla → activa Viernes."
            state.statusMessage = "Listo"
            speakReply(err.userMessage)
        } catch {
            let msg = "No pude capturar la pantalla."
            state.lastReply = msg
            state.statusMessage = "Listo"
            speakReply(msg)
        }
    }

    /// Frase sin regla → Brain (Ollama). Si pide analyzeScreen u otra acción, se ejecuta.
    private func handleUnknown(phrase: String) async {
        state.statusMessage = "Pensando…"
        let reply = await brain.reason(phrase: phrase)

        if let mapped = reply.intent {
            if case .analyzeScreen(let question) = mapped {
                await handleAnalyzeScreen(question: question)
                return
            }
            if case .keyboardJob(let instruction) = mapped {
                await handleKeyboardJob(instruction: instruction)
                return
            }
            let outcome = await runner.run(mapped)
            var spoken = outcome.spoken
            let brainSpeak = reply.speak.trimmingCharacters(in: .whitespacesAndNewlines)
            if !brainSpeak.isEmpty && brainSpeak != spoken {
                spoken = brainSpeak
            }
            state.lastReply = spoken
            var detailParts: [String] = []
            if let d = reply.detail, !d.isEmpty { detailParts.append(d) }
            if let d = outcome.detail, !d.isEmpty { detailParts.append(d) }
            state.detail = detailParts.joined(separator: "\n")
            state.statusMessage = "Listo"
            speakReply(spoken)
            if outcome.shouldQuit {
                DispatchQueue.main.asyncAfter(deadline: .now() + 1.6) {
                    NSApp.terminate(nil)
                }
            }
            return
        }

        state.lastReply = reply.speak
        state.detail = reply.detail ?? ""
        state.statusMessage = "Listo"
        speakReply(reply.speak)
    }

    func quitApp() {
        speakReply("Hasta luego.")
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.8) {
            NSApp.terminate(nil)
        }
    }
}

@MainActor
final class AppState: ObservableObject {
    static let mutedDefaultsKey = "viernes.muted"

    @Published var isListening = false
    @Published var isSpeaking = false
    @Published var isMuted = false
    @Published var isKeyboardJobRunning = false
    @Published var statusMessage = "Listo"
    @Published var transcript = ""
    @Published var lastReply = "Viernes, en línea. Pulsa ⌥Espacio, escribe, o el icono."
    @Published var detail = ""
    @Published var ollamaModel = OllamaClient.defaultModel
    @Published var visionModel = OllamaClient.defaultVisionModel
}

struct SettingsHelpView: View {
    private var modelName: String { OllamaClient.configuredModelName }
    private var visionName: String { OllamaClient.configuredVisionModelName }

    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            Text("Viernes V4")
                .font(.title2.weight(.semibold))
            Text("Asistente local: reglas + Ollama + visión bajo demanda + teclado bajo pedido. Chat, mute y UI al estilo del sistema.")
                .foregroundStyle(.secondary)
            Text("Atajo: ⌥Espacio. Si no responde desde otras apps, da Accesibilidad a Viernes en Ajustes del Sistema.")
                .font(.callout)
            Divider()
            Text("Voz y mute")
                .font(.headline)
            Text("Por defecto habla las respuestas (TTS). El botón Con voz / Sin voz en el popover silencia el audio; el texto sigue en el chat. No existe la voz exacta de FRIDAY del MCU en macOS: se usa la mejor voz española femenina premium/enhanced disponible (es-CO / es-ES / es-MX).")
                .font(.callout)
                .fixedSize(horizontal: false, vertical: true)
            Divider()
            Text("Pantalla (bajo demanda)")
                .font(.headline)
            Text("Di «mira la pantalla» o escribe lo mismo. Una sola captura → Ollama visión. Activa Grabación de pantalla: Ajustes → Privacidad y seguridad → Grabación de pantalla → Viernes.")
                .font(.callout)
                .fixedSize(horizontal: false, vertical: true)
            Divider()
            Text("Teclado (bajo pedido)")
                .font(.headline)
            Text("Di «usa el teclado…» o «mientras como, escribe…». Necesita Accesibilidad. Tope ~10 min / 12k caracteres. Botón Detener trabajo. No escribe en campos de contraseña.")
                .font(.callout)
                .fixedSize(horizontal: false, vertical: true)
            Divider()
            Text("Ollama")
                .font(.headline)
            Text("1. Instala Ollama (ollama.com)\n2. ollama pull \(modelName)\n3. ollama pull \(visionName)\n4. Deja Ollama corriendo\nTexto: \(modelName) (`viernes.ollamaModel`)\nVisión: \(visionName) (`viernes.ollamaVisionModel`)")
                .font(.callout)
                .fixedSize(horizontal: false, vertical: true)
            Text("Sin Ollama, las reglas locales siguen. Sin modelo de visión o sin permiso de pantalla: error claro en español.")
                .font(.caption)
                .foregroundStyle(.secondary)
        }
        .padding(20)
        .frame(width: 400)
    }
}

enum PermissionGate {
    static func requestSpeechAndMicrophone() async -> Bool {
        let mic = await requestMicrophone()
        let speech = await requestSpeech()
        return mic && speech
    }

    private static func requestMicrophone() async -> Bool {
        await withCheckedContinuation { continuation in
            AVAudioApplication.requestRecordPermission { granted in
                continuation.resume(returning: granted)
            }
        }
    }

    private static func requestSpeech() async -> Bool {
        await withCheckedContinuation { continuation in
            SFSpeechRecognizer.requestAuthorization { status in
                continuation.resume(returning: status == .authorized)
            }
        }
    }
}
