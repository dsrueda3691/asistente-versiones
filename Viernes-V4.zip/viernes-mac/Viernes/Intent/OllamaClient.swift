import Foundation

/// Contrato para un LLM local (Ollama en localhost).
protocol LocalLLMClient {
    func complete(prompt: String) async throws -> String
    func chat(system: String, user: String) async throws -> String
}

enum OllamaError: Error, LocalizedError {
    case unreachable
    case emptyResponse
    case badStatus(Int)
    case decodeFailed

    var errorDescription: String? {
        switch self {
        case .unreachable:
            return "Ollama no está corriendo en localhost."
        case .emptyResponse:
            return "Ollama devolvió una respuesta vacía."
        case .badStatus(let code):
            return "Ollama respondió con código \(code)."
        case .decodeFailed:
            return "No pude leer la respuesta de Ollama."
        }
    }
}

/// Cliente real contra http://127.0.0.1:11434/api/chat.
/// Texto: UserDefaults `viernes.ollamaModel` → `llama3.2`
/// Visión: UserDefaults `viernes.ollamaVisionModel` → `llava`
struct OllamaClient: LocalLLMClient {
    static let modelDefaultsKey = "viernes.ollamaModel"
    static let visionModelDefaultsKey = "viernes.ollamaVisionModel"
    static let defaultModel = "llama3.2"
    static let defaultVisionModel = "llava"

    var baseURL = URL(string: "http://127.0.0.1:11434")!
    var timeout: TimeInterval = 45
    var visionTimeout: TimeInterval = 90

    var model: String {
        let stored = UserDefaults.standard.string(forKey: Self.modelDefaultsKey)?
            .trimmingCharacters(in: .whitespacesAndNewlines) ?? ""
        return stored.isEmpty ? Self.defaultModel : stored
    }

    var visionModel: String {
        let stored = UserDefaults.standard.string(forKey: Self.visionModelDefaultsKey)?
            .trimmingCharacters(in: .whitespacesAndNewlines) ?? ""
        return stored.isEmpty ? Self.defaultVisionModel : stored
    }

    static var configuredModelName: String {
        let stored = UserDefaults.standard.string(forKey: modelDefaultsKey)?
            .trimmingCharacters(in: .whitespacesAndNewlines) ?? ""
        return stored.isEmpty ? defaultModel : stored
    }

    static var configuredVisionModelName: String {
        let stored = UserDefaults.standard.string(forKey: visionModelDefaultsKey)?
            .trimmingCharacters(in: .whitespacesAndNewlines) ?? ""
        return stored.isEmpty ? defaultVisionModel : stored
    }

    func complete(prompt: String) async throws -> String {
        try await chat(system: "Eres un asistente útil. Responde en español, breve.", user: prompt)
    }

    func chat(system: String, user: String) async throws -> String {
        try await chat(
            system: system,
            user: user,
            imagesBase64: nil,
            modelOverride: nil,
            timeoutOverride: nil,
            forceJSON: true
        )
    }

    /// Texto libre (sin forzar JSON). Útil para generar contenido a tipear.
    func plainChat(system: String, user: String, timeout: TimeInterval = 90) async throws -> String {
        try await chat(
            system: system,
            user: user,
            imagesBase64: nil,
            modelOverride: nil,
            timeoutOverride: timeout,
            forceJSON: false
        )
    }

    /// Chat multimodal: imágenes en base64 (JPEG/PNG) en el mensaje de usuario (formato Ollama).
    func chatVision(system: String, user: String, imageJPEG: Data) async throws -> String {
        let b64 = imageJPEG.base64EncodedString()
        return try await chat(
            system: system,
            user: user,
            imagesBase64: [b64],
            modelOverride: visionModel,
            timeoutOverride: visionTimeout,
            forceJSON: false
        )
    }

    private func chat(
        system: String,
        user: String,
        imagesBase64: [String]?,
        modelOverride: String?,
        timeoutOverride: TimeInterval?,
        forceJSON: Bool
    ) async throws -> String {
        let url = baseURL.appendingPathComponent("api/chat")
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.timeoutInterval = timeoutOverride ?? timeout

        var userMessage: [String: Any] = [
            "role": "user",
            "content": user
        ]
        if let imagesBase64, !imagesBase64.isEmpty {
            userMessage["images"] = imagesBase64
        }

        var body: [String: Any] = [
            "model": modelOverride ?? model,
            "stream": false,
            "messages": [
                ["role": "system", "content": system],
                userMessage
            ],
            "options": [
                "temperature": imagesBase64 == nil ? 0.4 : 0.2
            ]
        ]
        if forceJSON {
            body["format"] = "json"
        }

        request.httpBody = try JSONSerialization.data(withJSONObject: body)

        let data: Data
        let response: URLResponse
        do {
            (data, response) = try await URLSession.shared.data(for: request)
        } catch {
            throw OllamaError.unreachable
        }

        if let http = response as? HTTPURLResponse, !(200...299).contains(http.statusCode) {
            if http.statusCode == 404 {
                throw OllamaError.unreachable
            }
            throw OllamaError.badStatus(http.statusCode)
        }

        guard let json = try? JSONSerialization.jsonObject(with: data) as? [String: Any] else {
            throw OllamaError.decodeFailed
        }

        if let message = json["message"] as? [String: Any],
           let content = message["content"] as? String {
            let trimmed = content.trimmingCharacters(in: .whitespacesAndNewlines)
            if trimmed.isEmpty { throw OllamaError.emptyResponse }
            return trimmed
        }

        if let content = json["response"] as? String {
            let trimmed = content.trimmingCharacters(in: .whitespacesAndNewlines)
            if trimmed.isEmpty { throw OllamaError.emptyResponse }
            return trimmed
        }

        throw OllamaError.emptyResponse
    }
}
