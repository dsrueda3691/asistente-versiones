# Viernes (V4)

Asistente local de barra de menús para macOS. Habla en español, te escucha cuando se lo pides, responde con voz, y **puede mirar la pantalla solo cuando se lo pides**. Inspirado en Friday (MCU): seco, breve, competente.

**V3** = V2 (reglas locales + Ollama) **+** visión de pantalla bajo demanda **+** mute de TTS **+** chat escrito en el popover **+** ondas al hablar **+** colores que siguen claro/oscuro del sistema.

Viernes es una herramienta personal. **No está pensada para el App Store**: el sandbox está desactivado para poder leer y crear archivos en el Escritorio.


## Qué cambió en V4

- UI del popover más cercana al mockup: filas Tú/Viernes, punto de estado, ondas más marcadas, chat con enviar, mute naranja, engranaje de ayuda. Sigue claro/oscuro del sistema.
- **Teclado bajo pedido**: di o escribe frases como «usa el teclado…», «mientras como, escribe…», «deja escribiendo…». Viernes genera texto con Ollama y lo pega en la app de adelante (Cmd+V).
- Requiere **Accesibilidad** (Ajustes → Privacidad y seguridad → Accesibilidad → Viernes).
- Tope ~10 minutos / ~12 000 caracteres. Botón **Detener trabajo**. No escribe en campos de contraseña. Sin keylogging ni control siempre encendido.
- Sigue sin borrar archivos, sin shell arbitrario, sin enviar Mail.

## Qué cambió en V3

- **Pantalla bajo demanda**: «mira la pantalla», «qué hay en pantalla», «qué estoy haciendo», etc. → una captura puntual (ScreenCaptureKit) → modelo de visión local en Ollama → respuesta en español. **No** graba en continuo ni en segundo plano.
- **Mute**: botón «Con voz / Sin voz» en el popover. Con mute, no hay TTS; el texto sigue en el chat. Persistido en UserDefaults `viernes.muted`.
- **Chat escrito**: campo de texto + Enviar; mismo pipeline que la voz (reglas, Brain, pantalla).
- **Ondas al hablar**: barras animadas (cyan/azul) mientras TTS suena; sutiles al escuchar; calmadas en idle. Sin animación de “hablando” si está muteado.
- **Apariencia**: popover y controles usan colores semánticos de macOS (claro/oscuro del sistema). Sin fondo blanco/negro forzado.
- Marketing version **3.0**.

## Voz (honestidad vs MCU)

**No existe la voz exacta de FRIDAY del MCU en macOS.** Viernes elige la mejor voz **española femenina** disponible: prioriza `es-CO` → `es-ES` → `es-MX`, calidad **premium** → **enhanced** → default, género femenino cuando el sistema lo reporta. Rate/pitch un poco más crisp. Si instalas voces de calidad mejorada en Ajustes → Accesibilidad → Contenido hablado, Viernes las usará automáticamente.

## Requisitos

- Mac con **macOS 14** o posterior.
- **Xcode** gratis desde el App Store (cuenta Apple personal, sin pago).
- Micrófono (para voz).
- Opcional: reconocimiento de voz en español en el dispositivo.
- **Opcional:** [Ollama](https://ollama.com) para chat libre y visión.
- **Para mirar la pantalla:** permiso de **Grabación de pantalla** + modelo de visión en Ollama.

## Ollama

### Texto (Brain / chat libre)

```bash
ollama pull llama3.2
```

Modelo por defecto: `llama3.2` (`viernes.ollamaModel`). Timeout ~45 s.

```bash
defaults write com.danielrueda.Viernes viernes.ollamaModel -string "qwen2.5:7b"
ollama pull qwen2.5:7b
```

### Visión (pantalla)

```bash
ollama pull llava
```

Modelo por defecto: `llava` (`viernes.ollamaVisionModel`). Timeout ~90 s. Alternativa razonable: `qwen2.5vl`.

```bash
defaults write com.danielrueda.Viernes viernes.ollamaVisionModel -string "qwen2.5vl"
ollama pull qwen2.5vl
```

Sin Ollama, las **reglas locales** (hora, abrir apps, buscar…) siguen funcionando. Sin modelo de visión o sin permiso de pantalla: error claro en español; el resto de V1/V2 no se rompe.

## Cómo abrirlo

1. Instala **Xcode** y ábrelo una vez para aceptar la licencia.
2. Abre **`Viernes.xcodeproj`**.
3. Destino **My Mac**.
4. Signing: Personal Team, bundle id `com.danielrueda.Viernes`.
5. **Product → Run** (⌘R).
6. Primera vez: micrófono y reconocimiento de voz. Si pides mirar la pantalla, macOS pedirá **Grabación de pantalla**.
7. Busca **✦** en la barra de menús (`LSUIElement`, sin Dock).

## Cómo usarlo

- Clic en el icono **o** **⌥Espacio** → escucha.
- **Escribe** en el popover y pulsa Enviar (mismas reglas / Brain / pantalla).
- **Mute**: «Sin voz» / «Con voz» — solo corta el audio.
- Frases de pantalla: «mira la pantalla», «qué hay en pantalla», «qué estoy haciendo».

### Frases de ejemplo (reglas, sin Ollama)

| Intent | Prueba |
| --- | --- |
| Saludo | «hola», «quién eres» |
| Hora / fecha | «qué hora es», «qué fecha es hoy» |
| Abrir app | «abre Safari», «abre Finder», … |
| Buscar | «busca recetas de arepas» |
| Crear archivo | «crea un archivo llamado tareas» |
| Listar escritorio | «lista el escritorio» |
| **Mirar pantalla** | «mira la pantalla», «qué hay en pantalla» (necesita Ollama visión + permiso) |
| Código | «prepárame un html de landing» |
| Portapapeles | «lee el portapapeles» |
| Salir | «adiós» |

## Permisos

| Permiso | Para qué | Obligatorio |
| --- | --- | --- |
| Micrófono | Solo mientras escuchas | Sí (voz) |
| Reconocimiento de voz | Audio → texto | Sí (voz) |
| **Grabación de pantalla** | Solo cuando pides mirar la pantalla | Solo para visión |
| Accesibilidad | Que ⌥Espacio funcione desde otras apps | No |

### Activar Grabación de pantalla

**Ajustes del Sistema → Privacidad y seguridad → Grabación de pantalla →** activa **Viernes**.

La captura es **una foto en memoria** (JPEG, lado largo ~1280) enviada a Ollama en localhost. No se guarda a disco por defecto.

## Qué hace V3 (y qué no)

**Sí**

- Barra de menús, sin Dock; claro/oscuro del sistema.
- Voz entrada/salida; mute persistente; chat escrito.
- Reglas locales + Brain (Ollama texto) + visión bajo demanda.
- Ondas al hablar (si no está muteado).
- Una acción segura por turno del catálogo conocido.

**No (a propósito)**

- Wake word 24/7.
- Grabación de pantalla continua / siempre encendida.
- Enviar correo / Mail automation sin confirmación.
- Borrar archivos.
- Shell arbitrario.
- LLM remoto de pago — solo `127.0.0.1:11434`.

**Sandbox OFF.** **Hardened Runtime OFF** para Run local con Personal Team.

`Info.plist`: `NSAllowsLocalNetworking` para Ollama; `NSScreenCaptureUsageDescription` en español (solo cuando pide mirar).

## Estructura

```
viernes-mac/
  README.md
  Viernes.xcodeproj
  Viernes/
    ViernesApp.swift            ← handle, mute, chat tipado, analyzeScreen
    StatusBarController.swift
    Speech/Listener.swift
    Speech/Speaker.swift        ← voz femenina ES + isSpeaking delegate
    Intent/IntentParser.swift   ← analyzeScreen
    Intent/ActionRunner.swift
    Intent/OllamaClient.swift   ← chat + chatVision (base64)
    Intent/Brain.swift          ← reason + analyzeScreen visión
    Capture/ScreenCapture.swift ← ScreenCaptureKit, JPEG en memoria
    UI/PopoverView.swift        ← mute, chat, waveform, tema sistema
    Info.plist
    Viernes.entitlements
    Assets.xcassets
```

Mínimo macOS 14. Marketing version 3.0.

## Siguientes pasos

1. Puente Cursor / VS Code local.
2. Mail con confirmación en el popover.
3. Wake word opcional con interruptor.
4. Selector de modelos en el popover.

## Licencia

Uso personal de Daniel Rueda Mier. Haz lo que quieras con el código en tu Mac.
