# Viernes

Asistente de interfaz local. Sin servidor propio, sin APIs de pago y sin claves.

## Cómo abrir

**Opción A — archivo directo**

Abre `index.html` en Chrome (doble clic o arrástralo a una ventana).

La interfaz y los comandos escritos funcionan así. El micrófono, en cambio, suele estar bloqueado en `file://`.

**Opción B — servidor mínimo (recomendado para voz)**

En esta carpeta:

```bash
python3 -m http.server 8000
```

Luego abre [http://localhost:8000](http://localhost:8000) en Chrome.

## Cómo permitir el micrófono

1. Usa Chrome (Web Speech API).
2. Abre la demo por `http://localhost:8000`, no como archivo.
3. Pulsa **Mantén o pulsa para hablar**. Chrome pedirá permiso: elige **Permitir**.
4. Si lo denegaste, el candado de la barra de direcciones → Sitio → Micrófono → Permitir, y recarga.

Sin micrófono igual puedes escribir comandos. Si el navegador deja sintetizar voz, Viernes responde en voz alta.

## Qué es V1

Sigue siendo un parser de intenciones local (reglas, no un LLM). No hay WebLLM, no hay Ollama en este zip y no hay llamadas a la nube: es deliberadamente liviano y 100 % offline.

Lo que cambió: el vocabulario de la landing es mucho más amplio. Puedes pedir colores, textos, secciones y layout en español, con frases flexibles — no solo cinco comandos fijos. Viernes reconstruye el HTML/CSS de la vista previa a partir del estado, con deshacer y reinicio.

Código arbitrario de verdad (cualquier HTML/CSS/JS que se te ocurra, sin vocabulario) sigue necesitando un modelo local más adelante, por ejemplo Ollama en Mac.

## Ejemplos

### Los de siempre

- `pon el navbar oscuro`
- `agrega un hero con botón`
- `cambia el título a Aurora`
- `fondo claro` / `fondo oscuro`
- `deshaz`

Si empiezas con «Viernes», lo ignora.

### Colores

Nombres en español (rojo, azul, verde, morado, rosa, naranja, amarillo, blanco, negro, gris, cian, dorado) o hex `#rrggbb`:

- `pon el fondo de azul`
- `el navbar en negro`
- `título de dorado`
- `pon el texto de blanco`
- `botón en rojo`
- `color de acento morado`
- `fondo #1a1a2e`

### Textos

- `cambia el subtítulo a Un producto serio`
- `cambia el texto del botón a Comenzar`
- `cambia el nombre de la marca a Helios`

### Secciones

Cada una se puede añadir una vez (si ya está, Viernes lo dice):

- `agrega tres tarjetas`
- `pon un footer`
- `formulario de contacto`
- `agrega precios`
- `agrega testimonios`

Para quitar: `quita el CTA` · `quita el footer` · `quita las cards` · `quita el formulario`

### Layout

- `título más grande` / `título más pequeño`
- `centra el hero`
- `navbar más alto` / `navbar más fino`

### Reset

- `vuelve al inicio`
- `reinicia la landing`
