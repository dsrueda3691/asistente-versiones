import Foundation

/// Política única de herramientas. No concede permisos: solo valida que una
/// intención pertenezca al catálogo y que las acciones con efecto sigan usando
/// PendingAction en AppDelegate.
struct ArgosToolPolicy {
    enum Decision: Equatable { case allowed, approvalRequired, denied(String) }

    static func validate(_ intent: Intent) -> Decision {
        switch intent {
        case .composeMail, .composeIntegrationMail, .sendWhatsApp,
             .createCalendarEvent, .createReminder, .createGoal, .createNote,
             .createFile, .copyTemplate, .keyboardJob, .agentMode, .quit:
            return .approvalRequired
        case .readDocument, .analyzeScreen, .understandMedia:
            return .allowed
        default:
            return .allowed
        }
    }

    static func catalogPrompt() -> String {
        ArgosToolCatalog.all.filter(\.enabled).map {
            "- \($0.id): \($0.description) [\($0.risk.rawValue)]"
        }.joined(separator: "\n")
    }
}
