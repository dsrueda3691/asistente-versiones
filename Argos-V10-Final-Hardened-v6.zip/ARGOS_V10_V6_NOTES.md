# Argos V10 — Hardened v6

## Seguridad del puente iPhone / Atajos
- `/v1/ask` ya no puede confirmar ni cancelar una acción pendiente.
- Si existe una acción pendiente, se rechazan nuevas peticiones remotas hasta resolverla.
- Las peticiones remotas se restringen a `127.0.0.1`/`::1` y al rango IPv4 de Tailscale `100.64.0.0/10`; no se acepta el LAN Wi‑Fi ordinario.
- Hay límite de intentos de autenticación por host y bloqueo temporal tras 5 fallos.
- Las conexiones tienen timeout de 30 s.
- Existe `/v1/approve` separado para aprobaciones remotas.
- La aprobación remota está desactivada por defecto.
- El PIN es de 6 dígitos, se guarda como hash con salt en Keychain, nunca viaja ni se persiste en UserDefaults.
- 3 PIN incorrectos bloquean aprobaciones remotas durante 10 minutos.
- Cada aprobación usa un ID de un solo uso con expiración de 2 minutos.
- El `contentCode` se deriva del resumen exacto de la acción pendiente y se comprueba antes de ejecutar.
- El endpoint de cancelación remota está deshabilitado.
- No se pueden aprobar desde iPhone acciones de pantalla, teclado, documentos ni agente.
- Las respuestas del puente incluyen el resumen completo, ID y código de contenido cuando corresponde.
- Las peticiones remotas no provocan TTS en el Mac.

## Monitor de correo
- Guarda todos los IDs ya puntuados, no solo los alertados, para evitar repetir el mismo correo cada 20 minutos.
- Añadida opción de modo **solo local** para el monitor.
- El fallback local usa señales múltiples y puede alcanzar el umbral sin depender de cuatro palabras de urgencia.
- Las alertas habladas respetan horas de silencio 22:00–07:00.

## Objetivos
- El resumen matutino automático solo se anuncia entre 07:00 y 10:59, evitando que abrir Argos por la noche dispare un resumen hablado.

## Validación
- 36/36 archivos Swift pasan `swiftc -parse`.
- No se afirma compilación real de Xcode; requiere macOS/Xcode.
