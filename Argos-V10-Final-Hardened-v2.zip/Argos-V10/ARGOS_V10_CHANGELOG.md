# Argos V10 — revisión de producto

## Correcciones
- `NSPanel` compacto con geometría segura para Macs con y sin notch.
- `auxiliaryTopLeftArea` / `auxiliaryTopRightArea` ahora se desenvuelven correctamente.
- El modo expandido se posiciona debajo del área reservada del notch y no anima el frame del panel.
- La UI usa `ArgosRuntimeState.activity` como única fuente de verdad visual.
- Éxito, error y cancelación siguen siendo resultados distintos.
- Arrastrar Argos sobre una ventana asciende al `kAXWindowAttribute` para obtener el título real.
- Se solicita Accesibilidad cuando la función lo necesita.
- Se mantiene el monitor local durante el drag para no depender de eventos globales de la propia app.
- Los adjuntos ya pueden alimentar rutas de documento, media, visión y agente como contexto textual adicional.
- Soltar un archivo ya no se representa como «tarea completada»; queda como contexto listo para la siguiente acción.
- Los adjuntos pueden eliminarse individualmente.
- Migración real desde el persistent domain de `com.danielrueda.Viernes` / `Viernes`.
- Migración de API key antigua del Keychain y hotkey antiguo.
- Pantalla de primeros pasos para permisos.
- Hub de accesos para Gmail, Outlook, GitHub y WhatsApp sin almacenar credenciales externas.
- Personaje Argos con humo, filos de luz, ceño, gema, estados diferenciados y animación continua.
- Eliminadas referencias visibles de «V9» y «popover».

## Nota sobre integraciones externas
Gmail, Outlook, GitHub y WhatsApp tienen accesos de servicio en la UI, pero las integraciones API autenticadas no se pueden considerar «conectadas» sin credenciales/configuración del usuario o de una aplicación OAuth. Argos no inventa una conexión ni guarda secretos externos por defecto.

## Hardening pass — 2026-10-03

- Compact notch panel re-anchored to a stable display instead of the mouse display; the compact island now sits below the physical notch safe area while remaining visually attached to it.
- Added screen-configuration tracking so the panel follows the selected display only when macOS changes the display topology.
- Agent planning now receives the transient context snapshot, including text and visual attachments; the plan stores that context inside `PendingAgentPlan` so approval/execution remain deterministic.
- Transient file/window/media context is consumed after the user operation and cleared from both runtime and app state. It no longer silently affects every future question.
- Legacy model preferences migrated: `viernes.ollamaModel`, `viernes.ollamaVisionModel`, and `viernes.openaiModel`.
- Removed automatic probing of the legacy Viernes Keychain service to avoid an unsolicited macOS credential prompt. Argos now uses its own Keychain service; explicit re-entry is required if the old credential is not already available under Argos.
- Rebuilt the character geometry around the Cresta silhouette: pointed crown, separate lower silhouette, almond/angled eyes, gem, fangs, whiskers, smoke and state effects.
- Added explicit `speaking` runtime state and a compact approval badge.
- Added real integration service layer for Gmail, Outlook/Microsoft Graph, GitHub and WhatsApp Business Cloud API. Tokens are stored in Keychain. Outbound Gmail/Outlook/WhatsApp actions use `PendingAction` and therefore require notch approval.
- Added read-only Gmail/Outlook inbox queries and GitHub open-PR query; sending remains approval-gated.
- Added OAuth configuration UI and provider connection flows. Provider credentials/client IDs still have to be registered by the developer/account owner; no fake credentials are embedded.

## Hardening pass 2 — OAuth / integración / parser
- `OAuthToken` dejó de ser `private` para que `IntegrationKeychain` pueda usarlo en sus APIs internas sin violar el control de acceso de Swift.
- OAuth form POST ahora solicita `Accept: application/json`; GitHub Device Flow maneja explícitamente `authorization_pending`, `slow_down`, `access_denied`, `expired_token` e `incorrect_device_code`.
- Gmail codifica asuntos UTF-8 mediante RFC 2047 antes de construir el mensaje MIME.
- WhatsApp conserva el texto original del usuario (acentos, mayúsculas y ñ) y acepta teléfonos formateados como `+57 300 123 4567`; la API recibe únicamente los dígitos normalizados.
- El parser de GitHub exige términos explícitos `pr`, `prs`, `pull request` o equivalentes; ya no dispara por coincidencias como `proyecto`.
- La pantalla de Gmail aclara que el OAuth Client debe ser de tipo **Desktop**, no iOS. Google documenta el flujo de aplicaciones instaladas y los métodos de redirección para escritorio.
- Verificación sintáctica: 36/36 archivos Swift pasan `swiftc -parse`.
