import AppKit
import ApplicationServices

struct WindowContext: Equatable {
    let application: String
    let title: String
    let pid: pid_t
    let frame: CGRect

    var summary: String {
        let app = application.isEmpty ? "Aplicación" : application
        let t = title.isEmpty ? "Ventana sin título" : title
        return "Ventana: \(app) · \(t)"
    }
}

enum ArgosWindowContextProvider {
    static func requestAccessibility() -> Bool {
        if AXIsProcessTrusted() { return true }
        let options = [kAXTrustedCheckOptionPrompt.takeUnretainedValue() as String: true] as CFDictionary
        return AXIsProcessTrustedWithOptions(options)
    }

    static func contextAtCurrentMouse(requestAccessibility: Bool = false) -> WindowContext? {
        if requestAccessibility { _ = self.requestAccessibility() }
        return context(atQuartzPoint: currentQuartzMouseLocation())
    }

    private static func context(atQuartzPoint point: CGPoint) -> WindowContext? {
        guard let list = CGWindowListCopyWindowInfo([.optionOnScreenOnly, .excludeDesktopElements], kCGNullWindowID) as? [[String: Any]] else { return nil }
        let currentPID = NSRunningApplication.current.processIdentifier

        for info in list {
            guard let layer = info[kCGWindowLayer as String] as? Int, layer == 0 else { continue }
            guard let ownerPID = info[kCGWindowOwnerPID as String] as? pid_t, ownerPID != currentPID else { continue }
            let ownerName = info[kCGWindowOwnerName as String] as? String ?? ""
            let windowName = info[kCGWindowName as String] as? String ?? ""
            guard let boundsDict = info[kCGWindowBounds as String] as? NSDictionary,
                  let bounds = CGRect(dictionaryRepresentation: boundsDict as CFDictionary),
                  bounds.width > 80, bounds.height > 50,
                  bounds.contains(point) else { continue }

            let title = accessibilityWindowTitleAtPoint(point, expectedPID: ownerPID)
                ?? accessibilityFocusedWindowTitle(pid: ownerPID)
                ?? windowName
            return WindowContext(application: ownerName, title: title, pid: ownerPID, frame: bounds)
        }
        return nil
    }

    /// Obtiene el elemento bajo el cursor y asciende por kAXWindowAttribute.
    /// Esto evita devolver el título de un botón/campo en lugar del de la ventana.
    private static func accessibilityWindowTitleAtPoint(_ point: CGPoint, expectedPID: pid_t) -> String? {
        guard AXIsProcessTrusted() else { return nil }
        let system = AXUIElementCreateSystemWide()
        var elementRef: AXUIElement?
        guard AXUIElementCopyElementAtPosition(system, Float(point.x), Float(point.y), &elementRef) == .success,
              let element = elementRef else { return nil }

        var pid: pid_t = 0
        guard AXUIElementGetPid(element, &pid) == .success, pid == expectedPID else { return nil }

        var windowRef: CFTypeRef?
        guard AXUIElementCopyAttributeValue(element, kAXWindowAttribute as CFString, &windowRef) == .success,
              let windowRef,
              CFGetTypeID(windowRef) == AXUIElementGetTypeID() else { return nil }

        let window = windowRef as! AXUIElement
        return axTitle(of: window)
    }

    private static func accessibilityFocusedWindowTitle(pid: pid_t) -> String? {
        guard AXIsProcessTrusted() else { return nil }
        let app = AXUIElementCreateApplication(pid)
        var value: CFTypeRef?
        guard AXUIElementCopyAttributeValue(app, kAXFocusedWindowAttribute as CFString, &value) == .success,
              let value,
              CFGetTypeID(value) == AXUIElementGetTypeID() else { return nil }
        let window = value as! AXUIElement
        return axTitle(of: window)
    }

    private static func axTitle(of window: AXUIElement) -> String? {
        var title: CFTypeRef?
        guard AXUIElementCopyAttributeValue(window, kAXTitleAttribute as CFString, &title) == .success else { return nil }
        return title as? String
    }

    private static func currentQuartzMouseLocation() -> CGPoint {
        CGEvent(source: nil)?.location ?? CGPoint(x: 0, y: 0)
    }
}
