import Foundation
import AppKit
import IOKit.ps

/// Presencia / estado local real: batería, app frontal, mute, wake, manos libres, cerebro.
/// Sin métricas inventadas ni hologramas.
enum SystemPresence {
    /// Nombre de la app frontal (quieto, para HUD idle).
    static func frontmostAppName() -> String {
        NSWorkspace.shared.frontmostApplication?.localizedName ?? "—"
    }

    /// Porcentaje de batería si hay batería interna; nil en iMac / sin UPS.
    static func batteryPercent() -> Int? {
        guard let snapshot = IOPSCopyPowerSourcesInfo()?.takeRetainedValue(),
              let list = IOPSCopyPowerSourcesList(snapshot)?.takeRetainedValue() as? [CFTypeRef] else {
            return nil
        }
        for source in list {
            guard let desc = IOPSGetPowerSourceDescription(snapshot, source)?.takeUnretainedValue() as? [String: Any] else {
                continue
            }
            if let cap = desc[kIOPSCurrentCapacityKey] as? Int {
                return cap
            }
        }
        // Fallback pmset (solo lectura local).
        let task = Process()
        task.executableURL = URL(fileURLWithPath: "/usr/bin/pmset")
        task.arguments = ["-g", "batt"]
        let pipe = Pipe()
        task.standardOutput = pipe
        task.standardError = Pipe()
        do {
            try task.run()
            task.waitUntilExit()
            let data = pipe.fileHandleForReading.readDataToEndOfFile()
            let text = String(data: data, encoding: .utf8) ?? ""
            if let regex = try? NSRegularExpression(pattern: #"(\d+)\s*%"#),
               let match = regex.firstMatch(in: text, range: NSRange(text.startIndex..., in: text)),
               let r = Range(match.range(at: 1), in: text) {
                return Int(text[r])
            }
        } catch {
            return nil
        }
        return nil
    }

    static func statusLine(
        muted: Bool,
        wakeOn: Bool,
        handsFreeOn: Bool,
        handsFreeActive: Bool,
        brainMode: String
    ) -> (spoken: String, detail: String) {
        let app = frontmostAppName()
        var parts: [String] = []
        if let bat = batteryPercent() {
            parts.append("batería \(bat) %")
        } else {
            parts.append("sin batería interna (o no legible)")
        }
        parts.append(muted ? "mute ON" : "voz ON")
        parts.append(wakeOn ? "wake ON" : "wake OFF")
        if handsFreeActive {
            parts.append("manos libres activo")
        } else {
            parts.append(handsFreeOn ? "manos libres preferencia ON" : "manos libres preferencia OFF")
        }
        parts.append("cerebro \(brainMode)")
        parts.append("app frontal \(app)")
        let spoken = "Sistemas listos. " + parts.joined(separator: ". ") + "."
        let detail = parts.joined(separator: "\n")
        return (spoken, detail)
    }

    static func idleStatusHint() -> String {
        let app = frontmostAppName()
        if app == "—" || app.isEmpty { return "Listo" }
        return "Listo · \(app)"
    }
}
