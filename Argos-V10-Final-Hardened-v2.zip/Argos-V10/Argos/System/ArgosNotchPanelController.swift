import AppKit
import SwiftUI
import UniformTypeIdentifiers

final class ArgosNotchPanel: NSPanel {
    override var canBecomeKey: Bool { true }
    override var canBecomeMain: Bool { false }
}

@MainActor
final class ArgosNotchPanelController: NSObject {
    private let state: AppState
    private let runtime: ArgosRuntimeState
    private let onListen: () -> Void
    private let onSendChat: (String) -> Void
    private let onToggleMute: () -> Void
    private let onStopJob: () -> Void
    private let onOpenSettings: () -> Void
    private let onProviderChange: (String) -> Void
    private let onConfirmPending: () -> Void
    private let onCancelPending: () -> Void
    private let onToggleWakeWord: () -> Void
    private let onEndHandsFree: () -> Void
    private let onFileDrop: (URL) -> Void
    private let onWindowContext: (WindowContext) -> Void
    private var panel: ArgosNotchPanel!
    private var hosting: NSHostingController<ArgosNotchRootView>!
    private var dragLocalMonitor: Any?
    private var dragGlobalMonitor: Any?
    private var dragEndLocalMonitor: Any?
    private var dragEndGlobalMonitor: Any?
    private var pointerMonitor: Any?
    private var pointerLocalMonitor: Any?
    private var autoHideTask: Task<Void, Never>?
    private var anchorDisplayID: CGDirectDisplayID?

    init(
        state: AppState,
        runtime: ArgosRuntimeState,
        onListen: @escaping () -> Void,
        onSendChat: @escaping (String) -> Void,
        onToggleMute: @escaping () -> Void,
        onStopJob: @escaping () -> Void,
        onOpenSettings: @escaping () -> Void,
        onProviderChange: @escaping (String) -> Void,
        onConfirmPending: @escaping () -> Void,
        onCancelPending: @escaping () -> Void,
        onToggleWakeWord: @escaping () -> Void,
        onEndHandsFree: @escaping () -> Void,
        onFileDrop: @escaping (URL) -> Void,
        onWindowContext: @escaping (WindowContext) -> Void
    ) {
        self.state = state
        self.runtime = runtime
        self.onListen = onListen
        self.onSendChat = onSendChat
        self.onToggleMute = onToggleMute
        self.onStopJob = onStopJob
        self.onOpenSettings = onOpenSettings
        self.onProviderChange = onProviderChange
        self.onConfirmPending = onConfirmPending
        self.onCancelPending = onCancelPending
        self.onToggleWakeWord = onToggleWakeWord
        self.onEndHandsFree = onEndHandsFree
        self.onFileDrop = onFileDrop
        self.onWindowContext = onWindowContext
        super.init()
        buildPanel()
        anchorDisplayID = Self.preferredDisplayID()
        installScreenConfigurationMonitor()
        installPointerMonitor()
    }

    deinit {
        [dragLocalMonitor, dragGlobalMonitor, dragEndLocalMonitor, dragEndGlobalMonitor, pointerMonitor, pointerLocalMonitor].compactMap { $0 }.forEach(NSEvent.removeMonitor)
        NotificationCenter.default.removeObserver(self)
        autoHideTask?.cancel()
    }

    func showCompact() {
        autoHideTask?.cancel()
        runtime.presentation = .compact
        positionPanel(expanded: false, animate: false)
        panel.orderFrontRegardless()
        scheduleAutoHide()
    }

    func toggleExpanded() {
        if runtime.presentation == .expanded { collapse() } else { expand() }
    }

    func expand() {
        autoHideTask?.cancel()
        runtime.presentation = .expanded
        positionPanel(expanded: true, animate: false)
        panel.makeKeyAndOrderFront(nil)
    }

    func collapse() {
        runtime.presentation = .compact
        positionPanel(expanded: false, animate: false)
        panel.orderFrontRegardless()
        scheduleAutoHide()
    }

    func hide() {
        autoHideTask?.cancel()
        runtime.presentation = .hidden
        panel.orderOut(nil)
    }

    func showForActivity() {
        autoHideTask?.cancel()
        if runtime.presentation == .hidden { runtime.presentation = .compact }
        positionPanel(expanded: runtime.presentation == .expanded, animate: false)
        panel.orderFrontRegardless()
    }

    private func scheduleAutoHide() {
        autoHideTask?.cancel()
        guard state.pendingAction == nil,
              !state.isListening,
              !state.isAgentRunning,
              !state.isKeyboardJobRunning,
              !runtime.isDraggingCharacter else { return }
        autoHideTask = Task { @MainActor [weak self] in
            try? await Task.sleep(nanoseconds: 6_000_000_000)
            guard let self, !Task.isCancelled else { return }
            guard self.runtime.presentation == .compact,
                  !self.runtime.isHoveringNotch,
                  self.state.pendingAction == nil,
                  !self.state.isListening,
                  !self.state.isAgentRunning,
                  !self.state.isKeyboardJobRunning else { return }
            self.hide()
        }
    }

    private func installScreenConfigurationMonitor() {
        NotificationCenter.default.addObserver(
            self,
            selector: #selector(screenConfigurationChanged),
            name: NSApplication.didChangeScreenParametersNotification,
            object: nil
        )
    }

    @objc private func screenConfigurationChanged() {
        anchorDisplayID = Self.preferredDisplayID()
        if runtime.presentation != .hidden {
            positionPanel(expanded: runtime.presentation == .expanded, animate: false)
        }
    }

    private static func preferredDisplayID() -> CGDirectDisplayID? {
        let candidates = NSScreen.screens
        if let notched = candidates.first(where: {
            $0.auxiliaryTopLeftArea != nil && $0.auxiliaryTopRightArea != nil
        }) {
            return notched.deviceDescription[NSDeviceDescriptionKey(rawValue: "NSScreenNumber")] as? CGDirectDisplayID
        }
        let main = NSScreen.main ?? candidates.first
        return main?.deviceDescription[NSDeviceDescriptionKey(rawValue: "NSScreenNumber")] as? CGDirectDisplayID
    }

    private func anchoredScreen() -> NSScreen? {
        if let id = anchorDisplayID,
           let screen = NSScreen.screens.first(where: {
               ($0.deviceDescription[NSDeviceDescriptionKey(rawValue: "NSScreenNumber")] as? CGDirectDisplayID) == id
           }) {
            return screen
        }
        anchorDisplayID = Self.preferredDisplayID()
        return NSScreen.screens.first(where: {
            ($0.deviceDescription[NSDeviceDescriptionKey(rawValue: "NSScreenNumber")] as? CGDirectDisplayID) == anchorDisplayID
        }) ?? NSScreen.main
    }

    private func installPointerMonitor() {
        pointerMonitor = NSEvent.addGlobalMonitorForEvents(matching: [.mouseMoved]) { [weak self] event in
            guard let self else { return }
            Task { @MainActor in self.handlePointer(event) }
        }
        pointerLocalMonitor = NSEvent.addLocalMonitorForEvents(matching: [.mouseMoved]) { [weak self] event in
            guard let self else { return event }
            Task { @MainActor in self.handlePointer(event) }
            return event
        }
    }

    private func handlePointer(_ event: NSEvent) {
        guard let screen = screenContaining(event: event) else { return }
        let mouse = event.locationInWindow
        let point = event.window == nil ? NSEvent.mouseLocation : event.window?.convertToScreen(mouse) ?? NSEvent.mouseLocation
        let hit = notchRect(for: screen).insetBy(dx: -20, dy: -14).contains(point)
        if hit && runtime.presentation == .hidden {
            showCompact()
        }
    }

    private func screenContaining(event: NSEvent) -> NSScreen? {
        let point = event.window?.convertToScreen(event.locationInWindow) ?? NSEvent.mouseLocation
        return NSScreen.screens.first(where: { $0.frame.contains(point) }) ?? NSScreen.main
    }

    private func beginCharacterDrag() {
        guard dragLocalMonitor == nil else { return }
        runtime.isDraggingCharacter = true
        autoHideTask?.cancel()

        dragLocalMonitor = NSEvent.addLocalMonitorForEvents(matching: [.leftMouseDragged, .mouseMoved]) { [weak self] event in
            guard let self, self.runtime.isDraggingCharacter else { return event }
            Task { @MainActor in self.movePanelToMouse() }
            return event
        }
        dragGlobalMonitor = NSEvent.addGlobalMonitorForEvents(matching: [.leftMouseDragged, .mouseMoved]) { [weak self] _ in
            guard let self, self.runtime.isDraggingCharacter else { return }
            Task { @MainActor in self.movePanelToMouse() }
        }
        dragEndLocalMonitor = NSEvent.addLocalMonitorForEvents(matching: [.leftMouseUp]) { [weak self] event in
            guard let self, self.runtime.isDraggingCharacter else { return event }
            Task { @MainActor in self.endCharacterDrag() }
            return event
        }
        dragEndGlobalMonitor = NSEvent.addGlobalMonitorForEvents(matching: [.leftMouseUp]) { [weak self] _ in
            guard let self, self.runtime.isDraggingCharacter else { return }
            Task { @MainActor in self.endCharacterDrag() }
        }
    }

    private func endCharacterDrag() {
        guard runtime.isDraggingCharacter else { return }
        runtime.isDraggingCharacter = false
        [dragLocalMonitor, dragGlobalMonitor, dragEndLocalMonitor, dragEndGlobalMonitor].compactMap { $0 }.forEach(NSEvent.removeMonitor)
        dragLocalMonitor = nil; dragGlobalMonitor = nil; dragEndLocalMonitor = nil; dragEndGlobalMonitor = nil

        if let context = ArgosWindowContextProvider.contextAtCurrentMouse(requestAccessibility: true) {
            onWindowContext(context)
        } else {
            positionPanel(expanded: runtime.presentation == .expanded, animate: false)
        }
    }

    private func movePanelToMouse() {
        guard let panel else { return }
        let point = NSEvent.mouseLocation
        let size = panel.frame.size
        panel.setFrameOrigin(NSPoint(x: point.x - size.width / 2, y: point.y - size.height / 2), display: true)
    }

    private func buildPanel() {
        let root = ArgosNotchRootView(
            state: state,
            runtime: runtime,
            onListen: onListen,
            onSendChat: onSendChat,
            onToggleMute: onToggleMute,
            onStopJob: onStopJob,
            onOpenSettings: onOpenSettings,
            onProviderChange: onProviderChange,
            onConfirmPending: onConfirmPending,
            onCancelPending: onCancelPending,
            onToggleWakeWord: onToggleWakeWord,
            onEndHandsFree: onEndHandsFree,
            onCharacterDragChanged: { [weak self] in self?.beginCharacterDrag() },
            onCharacterDragEnded: { [weak self] in self?.endCharacterDrag() },
            onExpand: { [weak self] in self?.toggleExpanded() },
            onCollapse: { [weak self] in self?.collapse() },
            onFileDrop: onFileDrop
        )
        hosting = NSHostingController(rootView: root)
        hosting.view.wantsLayer = true
        hosting.view.layer?.backgroundColor = NSColor.clear.cgColor

        panel = ArgosNotchPanel(
            contentRect: CGRect(x: 0, y: 0, width: 300, height: 44),
            styleMask: [.borderless, .nonactivatingPanel],
            backing: .buffered,
            defer: false
        )
        panel.isOpaque = false
        panel.backgroundColor = .clear
        panel.hasShadow = false
        panel.level = .statusBar
        panel.collectionBehavior = [.canJoinAllSpaces, .fullScreenAuxiliary, .ignoresCycle]
        panel.hidesOnDeactivate = false
        panel.isMovable = false
        panel.ignoresMouseEvents = false
        panel.contentView = hosting.view
        hosting.view.frame = panel.contentView?.bounds ?? .zero
        hosting.view.autoresizingMask = [.width, .height]
        panel.isReleasedWhenClosed = false
    }

    private func notchRect(for screen: NSScreen) -> CGRect {
        // auxiliaryTopLeftArea / auxiliaryTopRightArea son opcionales en macOS.
        // Cuando existen, el espacio entre ambos describe la zona reservada por el notch.
        if let left = screen.auxiliaryTopLeftArea,
           let right = screen.auxiliaryTopRightArea,
           right.minX > left.maxX {
            let notchWidth = right.minX - left.maxX
            let center = left.maxX + notchWidth / 2
            let width = min(max(notchWidth + 120, 300), 390)
            // El panel se extiende unos puntos por debajo del notch físico.
            // El centro visual ya no queda exactamente sobre el borde inferior del notch.
            let height: CGFloat = 74
            let topInset = min(max(screen.safeAreaInsets.top, 0), 74)
            let y = screen.frame.maxY - height - max(10, min(18, topInset * 0.22))
            return CGRect(
                x: center - width / 2,
                y: y,
                width: width,
                height: height
            )
        }

        let width: CGFloat = min(340, screen.frame.width - 48)
        let height: CGFloat = 74
        let y = screen.frame.maxY - height - 12
        return CGRect(
            x: screen.frame.midX - width / 2,
            y: y,
            width: width,
            height: height
        )
    }

    private func positionPanel(expanded: Bool, animate: Bool) {
        guard let screen = anchoredScreen() else { return }

        if expanded {
            let width = min(720, screen.frame.width - 36)
            let height = min(690, screen.frame.height - max(90, screen.safeAreaInsets.top + 44))
            let x = screen.frame.midX - width / 2
            let y = screen.frame.maxY - screen.safeAreaInsets.top - height - 10
            panel.setFrame(NSRect(x: x, y: y, width: width, height: height), display: true, animate: false)
        } else {
            // La ventana ocupa una zona suficientemente ancha para mostrar al compañero;
            // su centro queda alineado con el notch físico y el fondo negro se funde con él.
            panel.setFrame(notchRect(for: screen), display: true, animate: false)
        }
    }
}

private struct ArgosNotchBackground: View {
    let expanded: Bool
    let highlighted: Bool

    var body: some View {
        RoundedRectangle(cornerRadius: expanded ? 26 : 20, style: .continuous)
            .fill(Color.black.opacity(expanded ? 0.92 : 0.98))
            .overlay(
                RoundedRectangle(cornerRadius: expanded ? 26 : 20, style: .continuous)
                    .stroke(Color.white.opacity(highlighted ? 0.18 : 0.08), lineWidth: 1)
            )
            .shadow(color: .black.opacity(expanded ? 0.38 : 0.20), radius: expanded ? 28 : 12, y: 8)
    }
}

struct ArgosNotchRootView: View {
    @ObservedObject var state: AppState
    @ObservedObject var runtime: ArgosRuntimeState
    let onListen: () -> Void
    let onSendChat: (String) -> Void
    let onToggleMute: () -> Void
    let onStopJob: () -> Void
    let onOpenSettings: () -> Void
    let onProviderChange: (String) -> Void
    let onConfirmPending: () -> Void
    let onCancelPending: () -> Void
    let onToggleWakeWord: () -> Void
    let onEndHandsFree: () -> Void
    let onCharacterDragChanged: () -> Void
    let onCharacterDragEnded: () -> Void
    let onExpand: () -> Void
    let onCollapse: () -> Void
    let onFileDrop: (URL) -> Void

    @State private var draft = ""
    @State private var isDropTargeted = false
    @State private var selectedTab = 0
    @FocusState private var focused: Bool

    private var expanded: Bool { runtime.presentation == .expanded }

    private var activity: ArgosRuntimeState.Activity {
        // Una única fuente de verdad para la representación visual.
        // AppDelegate actualiza este estado cuando cambia la operación real.
        runtime.activity
    }

    var body: some View {
        ZStack {
            ArgosNotchBackground(expanded: expanded, highlighted: isDropTargeted)
            if expanded { expandedView } else { compactView }
        }
        .onHover { hovering in
            runtime.isHoveringNotch = hovering
            if hovering && runtime.presentation == .hidden { onExpand() }
        }
        .onDrop(of: [UTType.fileURL.identifier], isTargeted: $isDropTargeted) { providers in
            for provider in providers {
                provider.loadDataRepresentation(forTypeIdentifier: UTType.fileURL.identifier) { data, _ in
                    guard let data, let url = URL(dataRepresentation: data, relativeTo: nil) else { return }
                    DispatchQueue.main.async { onFileDrop(url) }
                }
            }
            return !providers.isEmpty
        }
        .onChange(of: isDropTargeted) { _, value in runtime.isFileDropTargeted = value }
    }

    private var compactView: some View {
        HStack(spacing: 6) {
            ArgosCharacterView(activity: activity, compact: true, onDragChanged: onCharacterDragChanged, onDragEnded: onCharacterDragEnded)
                .frame(width: 70, height: 42)
            VStack(alignment: .leading, spacing: 0) {
                Text("Argos").font(.system(size: 11, weight: .bold, design: .rounded)).foregroundStyle(.white)
                Text(activity.title).font(.system(size: 9, weight: .medium, design: .rounded)).foregroundStyle(.white.opacity(0.58)).lineLimit(1)
            }
            Spacer(minLength: 2)
            if state.pendingAction != nil {
                Image(systemName: "checkmark.shield.fill").foregroundStyle(.purple)
            } else if activity == .working || activity == .thinking || activity == .speaking {
                ProgressView().controlSize(.small).tint(.white)
            }
            Button(action: onExpand) {
                Image(systemName: "plus").font(.system(size: 12, weight: .bold)).foregroundStyle(.white)
                    .frame(width: 27, height: 27)
                    .background(Color.white.opacity(0.10), in: Circle())
            }.buttonStyle(.plain)
        }
        .padding(.horizontal, 9)
        .contentShape(Rectangle())
    }

    private var expandedView: some View {
        VStack(spacing: 0) {
            header
            Picker("", selection: $selectedTab) {
                Text("Argos").tag(0)
                Text("Actividad").tag(1)
                Text("Contexto").tag(2)
            }
            .pickerStyle(.segmented)
            .padding(.horizontal, 14)
            .padding(.top, 8)

            ScrollView(showsIndicators: false) {
                VStack(spacing: 12) {
                    if selectedTab == 0 { conversationTab }
                    else if selectedTab == 1 { activityTab }
                    else { contextTab }
                }
                .padding(14)
            }

            composer
            controls
        }
        .foregroundStyle(.white)
    }

    private var header: some View {
        HStack(spacing: 12) {
            ArgosCharacterView(activity: activity, compact: false, onDragChanged: onCharacterDragChanged, onDragEnded: onCharacterDragEnded)
                .frame(width: 96, height: 84)
            VStack(alignment: .leading, spacing: 3) {
                HStack(spacing: 7) {
                    Text("Argos").font(.system(size: 20, weight: .bold, design: .rounded))
                    Circle().fill(activityColor).frame(width: 7, height: 7)
                }
                Text(activity.title).font(.system(size: 11, weight: .semibold, design: .rounded)).foregroundStyle(activityColor)
                Text(runtime.activityMessage.isEmpty ? state.statusMessage : runtime.activityMessage)
                    .font(.system(size: 11, weight: .regular, design: .rounded))
                    .foregroundStyle(.white.opacity(0.55)).lineLimit(2)
            }
            Spacer()
            Button(action: onCollapse) {
                Image(systemName: "minus").font(.system(size: 13, weight: .bold)).foregroundStyle(.white.opacity(0.7))
                    .frame(width: 30, height: 30).background(Color.white.opacity(0.08), in: Circle())
            }.buttonStyle(.plain)
        }
        .padding(.horizontal, 14)
        .padding(.top, 10)
    }

    private var activityColor: Color {
        switch activity {
        case .idle: return Color(red: 0.65, green: 0.48, blue: 1)
        case .listening: return Color(red: 0.36, green: 0.95, blue: 0.76)
        case .thinking: return Color(red: 0.98, green: 0.74, blue: 0.30)
        case .working: return Color(red: 0.32, green: 0.68, blue: 1)
        case .waitingApproval: return Color(red: 0.72, green: 0.50, blue: 1)
        case .speaking: return Color(red: 0.45, green: 0.82, blue: 1)
        case .success: return Color(red: 0.35, green: 0.95, blue: 0.55)
        case .error: return Color(red: 1, green: 0.32, blue: 0.42)
        }
    }

    private var conversationTab: some View {
        VStack(alignment: .leading, spacing: 10) {
            if runtime.chatTurns.isEmpty {
                VStack(spacing: 8) {
                    Image(systemName: "sparkles").font(.system(size: 25)).foregroundStyle(.purple)
                    Text("¿Qué hacemos?").font(.headline)
                    Text("Argos puede conversar, mirar la pantalla, trabajar con archivos y ejecutar acciones que requieran tu aprobación.")
                        .font(.caption).foregroundStyle(.white.opacity(0.55)).multilineTextAlignment(.center)
                }.frame(maxWidth: .infinity).padding(.vertical, 18)
            } else {
                ForEach(runtime.chatTurns) { turn in
                    HStack {
                        if turn.role == "user" { Spacer(minLength: 34) }
                        Text(turn.content)
                            .font(.system(size: 12, design: .rounded))
                            .foregroundStyle(.white.opacity(0.92))
                            .textSelection(.enabled)
                            .padding(10)
                            .background((turn.role == "user" ? Color.purple.opacity(0.26) : Color.white.opacity(0.07)), in: RoundedRectangle(cornerRadius: 13, style: .continuous))
                        if turn.role != "user" { Spacer(minLength: 34) }
                    }
                }
            }
            if state.pendingAction == nil, !state.detail.isEmpty {
                Text(state.detail).font(.system(size: 10, design: .monospaced)).foregroundStyle(.white.opacity(0.52))
                    .textSelection(.enabled).padding(10).background(Color.white.opacity(0.04), in: RoundedRectangle(cornerRadius: 12))
            }
        }
    }

    private var activityTab: some View {
        VStack(alignment: .leading, spacing: 12) {
            if !runtime.agentSteps.isEmpty {
                ArgosAgentActivityView(runtime: runtime)
            } else {
                Label("Sin una tarea de agente activa", systemImage: "checkmark.circle")
                    .font(.caption).foregroundStyle(.white.opacity(0.55))
            }
            if let pending = state.pendingAction {
                ArgosApprovalView(pending: pending, onConfirm: onConfirmPending, onCancel: onCancelPending)
            }
        }
    }

    private var contextTab: some View {
        VStack(alignment: .leading, spacing: 10) {
            HStack {
                Text("Contexto").font(.headline)
                Spacer()
                if !runtime.contextAttachments.isEmpty {
                    Button("Limpiar") {
                        runtime.clearAttachments()
                        state.contextText = nil
                        state.contextImageJPEG = nil
                    }.buttonStyle(.plain).foregroundStyle(.purple)
                }
            }
            if runtime.contextAttachments.isEmpty {
                ContentUnavailableView("Sin contexto", systemImage: "paperclip", description: Text("Arrastra un archivo al notch o arrastra Argos sobre una ventana."))
                    .frame(maxWidth: .infinity).padding(.vertical, 20)
            } else {
                ForEach(runtime.contextAttachments) { item in
                    HStack(spacing: 9) {
                        Image(systemName: icon(for: item.kind)).foregroundStyle(.purple)
                        VStack(alignment: .leading, spacing: 2) {
                            Text(item.name).font(.caption.weight(.semibold)).lineLimit(1)
                            Text(item.kind.rawValue.capitalized).font(.caption2).foregroundStyle(.white.opacity(0.45))
                        }
                        Spacer()
                        Button { removeContext(item) } label: { Image(systemName: "xmark.circle.fill") }.buttonStyle(.plain).foregroundStyle(.white.opacity(0.45))
                    }
                    .padding(9)
                    .background(Color.white.opacity(0.05), in: RoundedRectangle(cornerRadius: 12))
                }
                Text("El contexto se usa en la siguiente conversación y permanece en memoria hasta que lo retires.")
                    .font(.caption2).foregroundStyle(.white.opacity(0.42))
            }
        }
    }

    private var composer: some View {
        HStack(spacing: 8) {
            Button(action: onListen) {
                Image(systemName: state.isListening ? "stop.fill" : "mic.fill")
                    .foregroundStyle(state.isListening ? .red : .white)
                    .frame(width: 34, height: 34).background(Color.white.opacity(0.08), in: Circle())
            }.buttonStyle(.plain)
            TextField("Habla con Argos…", text: $draft, axis: .vertical)
                .textFieldStyle(.plain).foregroundStyle(.white)
                .padding(.horizontal, 10).padding(.vertical, 8)
                .background(Color.white.opacity(0.07), in: RoundedRectangle(cornerRadius: 13))
                .lineLimit(1...4).focused($focused).onSubmit(sendDraft)
            Button(action: sendDraft) {
                Image(systemName: "arrow.up").font(.system(size: 13, weight: .bold)).foregroundStyle(.black)
                    .frame(width: 32, height: 32).background(Color.white, in: Circle())
            }.buttonStyle(.plain).disabled(draft.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty).opacity(draft.isEmpty ? 0.45 : 1)
        }
        .padding(.horizontal, 14).padding(.top, 8)
    }

    private var controls: some View {
        HStack(spacing: 7) {
            Button(action: onToggleMute) { Image(systemName: state.isMuted ? "speaker.slash.fill" : "speaker.wave.2.fill") }.buttonStyle(.plain)
            Button(action: onToggleWakeWord) { Image(systemName: state.wakeWordEnabled ? "ear.fill" : "ear") }.buttonStyle(.plain)
            if state.isHandsFreeActive { Button(action: onEndHandsFree) { Image(systemName: "hand.raised.fill") }.buttonStyle(.plain) }
            if state.isAgentRunning || state.isKeyboardJobRunning { Button(action: onStopJob) { Image(systemName: "stop.fill") }.buttonStyle(.plain).foregroundStyle(.red) }
            Spacer()
            Text(state.modeLine).font(.caption2).foregroundStyle(.white.opacity(0.45)).lineLimit(1)
            Button(action: onOpenSettings) { Image(systemName: "gearshape") }.buttonStyle(.plain).foregroundStyle(.white.opacity(0.65))
        }
        .padding(.horizontal, 16).padding(.vertical, 9)
    }

    private func icon(for kind: ArgosRuntimeState.ContextAttachment.Kind) -> String {
        switch kind { case .text: return "doc.text"; case .image: return "photo"; case .audio: return "waveform"; case .video: return "video"; case .window: return "macwindow" }
    }

    private func removeContext(_ item: ArgosRuntimeState.ContextAttachment) {
        runtime.removeAttachment(id: item.id)
        state.contextText = runtime.contextText
        if item.kind == .image { state.contextImageJPEG = nil }
        if runtime.contextAttachments.isEmpty { state.contextText = nil; state.contextImageJPEG = nil }
    }

    private func sendDraft() {
        let value = draft.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !value.isEmpty else { return }
        draft = ""
        onSendChat(value)
    }
}
