import Foundation
import AppKit
import ScreenCaptureKit
import CoreGraphics
import ImageIO
import UniformTypeIdentifiers

enum ScreenCaptureError: Error, LocalizedError {
    case noDisplay
    case permissionDenied
    case captureFailed(String)
    case encodeFailed

    var userMessage: String {
        switch self {
        case .noDisplay:
            return "No encuentro una pantalla para capturar."
        case .permissionDenied:
            return "Necesito permiso de Grabación de pantalla. Actívalo en Ajustes del Sistema → Privacidad y seguridad → Grabación de pantalla → Argos."
        case .captureFailed:
            return "No pude capturar la pantalla."
        case .encodeFailed:
            return "No pude preparar la imagen de la pantalla."
        }
    }

    var errorDescription: String? { userMessage }
}

/// Captura puntual de pantalla (una vez, en memoria). No graba en continuo ni guarda a disco por defecto.
enum ScreenCapture {
    /// Lado más largo máximo del JPEG enviado a Ollama.
    static let maxLongestSide: CGFloat = 1280
    static let jpegQuality: CGFloat = 0.72

    /// Captura la pantalla principal (o la primera disponible) como JPEG en memoria.
    static func captureMainDisplayJPEG() async throws -> Data {
        let content: SCShareableContent
        do {
            content = try await SCShareableContent.excludingDesktopWindows(false, onScreenWindowsOnly: true)
        } catch {
            throw mapShareableError(error)
        }

        guard let display = preferredDisplay(from: content.displays) else {
            throw ScreenCaptureError.noDisplay
        }

        let filter = SCContentFilter(display: display, excludingWindows: [])
        let scale = scaleFactor(for: display)
        let pixelWidth = CGFloat(display.width) * scale
        let pixelHeight = CGFloat(display.height) * scale
        let longest = max(pixelWidth, pixelHeight)
        let factor = longest > maxLongestSide ? (maxLongestSide / longest) : 1.0

        let config = SCStreamConfiguration()
        config.width = max(1, Int(pixelWidth * factor))
        config.height = max(1, Int(pixelHeight * factor))
        config.scalesToFit = true
        config.showsCursor = true
        config.captureResolution = .best

        let cgImage: CGImage
        do {
            cgImage = try await SCScreenshotManager.captureImage(
                contentFilter: filter,
                configuration: config
            )
        } catch {
            throw mapShareableError(error)
        }

        guard let jpeg = encodeJPEG(cgImage, quality: jpegQuality) else {
            throw ScreenCaptureError.encodeFailed
        }
        return jpeg
    }


    /// Captura una ventana concreta para usarla como contexto visual.
    static func captureWindowJPEG(pid: pid_t, title: String?) async throws -> Data {
        let content: SCShareableContent
        do {
            content = try await SCShareableContent.excludingDesktopWindows(false, onScreenWindowsOnly: true)
        } catch {
            throw mapShareableError(error)
        }
        let candidates = content.windows.filter { window in
            guard window.owningApplication?.processID == pid else { return false }
            if let title, !title.isEmpty {
                return window.title == title || window.title.localizedCaseInsensitiveContains(title)
            }
            return true
        }
        guard let window = candidates.first else { throw ScreenCaptureError.captureFailed("No encontré la ventana seleccionada.") }
        let filter = SCContentFilter(desktopIndependentWindow: window)
        let width = max(1, Int(min(CGFloat(window.frame.width) * 2.0, maxLongestSide)))
        let height = max(1, Int(min(CGFloat(window.frame.height) * 2.0, maxLongestSide)))
        let config = SCStreamConfiguration()
        config.width = width
        config.height = height
        config.scalesToFit = true
        config.showsCursor = true
        config.captureResolution = .best
        do {
            let image = try await SCScreenshotManager.captureImage(contentFilter: filter, configuration: config)
            guard let jpeg = encodeJPEG(image, quality: jpegQuality) else { throw ScreenCaptureError.encodeFailed }
            return jpeg
        } catch let error as ScreenCaptureError {
            throw error
        } catch {
            throw mapShareableError(error)
        }
    }

    /// Convierte una imagen local en JPEG para contexto multimodal.
    static func encodeImageFileJPEG(at url: URL) throws -> Data {
        guard let image = NSImage(contentsOf: url) else { throw ScreenCaptureError.encodeFailed }
        var rect = CGRect(origin: .zero, size: image.size)
        guard let cgImage = image.cgImage(forProposedRect: &rect, context: nil, hints: nil),
              let jpeg = encodeJPEG(cgImage, quality: jpegQuality) else {
            throw ScreenCaptureError.encodeFailed
        }
        return jpeg
    }
    private static func preferredDisplay(from displays: [SCDisplay]) -> SCDisplay? {
        let mainID = CGMainDisplayID()
        if let match = displays.first(where: { $0.displayID == mainID }) {
            return match
        }
        // Fallback: la más grande
        return displays.max(by: { ($0.width * $0.height) < ($1.width * $1.height) }) ?? displays.first
    }

    private static func scaleFactor(for display: SCDisplay) -> CGFloat {
        // SCDisplay width/height ya suelen ser en puntos lógicos en algunas APIs;
        // pedimos un factor razonable vía NSScreen si coincide.
        let screens = NSScreen.screens
        if let screen = screens.first(where: {
            ($0.deviceDescription[NSDeviceDescriptionKey("NSScreenNumber")] as? NSNumber)?.uint32Value == display.displayID
        }) {
            return screen.backingScaleFactor
        }
        return NSScreen.main?.backingScaleFactor ?? 2.0
    }

    private static func encodeJPEG(_ image: CGImage, quality: CGFloat) -> Data? {
        let data = NSMutableData()
        guard let dest = CGImageDestinationCreateWithData(
            data as CFMutableData,
            UTType.jpeg.identifier as CFString,
            1,
            nil
        ) else { return nil }
        let props: [CFString: Any] = [
            kCGImageDestinationLossyCompressionQuality: quality
        ]
        CGImageDestinationAddImage(dest, image, props as CFDictionary)
        guard CGImageDestinationFinalize(dest) else { return nil }
        return data as Data
    }

    private static func mapShareableError(_ error: Error) -> ScreenCaptureError {
        let ns = error as NSError
        let text = (ns.localizedDescription + " " + (ns.localizedFailureReason ?? "")).lowercased()
        // Códigos frecuentes de denegación / cancelación en ScreenCaptureKit
        let denialCodes: Set<Int> = [-3801, -3802, -3805, -3808, -3815]
        if ns.domain == SCStreamErrorDomain ||
            denialCodes.contains(ns.code) ||
            text.contains("denied") ||
            text.contains("permission") ||
            text.contains("not authorized") ||
            text.contains("no autorizado") ||
            text.contains("privacidad") ||
            text.contains("declined") ||
            text.contains("not trusted") {
            return .permissionDenied
        }
        return .captureFailed(ns.localizedDescription)
    }
}
