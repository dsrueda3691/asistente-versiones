import Foundation
import Speech
import AVFoundation

/// Escucha continua (o casi) del micrófono buscando «Argos» / «oye Argos» / «hey Argos».
/// Usa el mismo stack Speech on-device preferido que `Listener`. No es un wake word de hardware MCU:
/// el micrófono queda activo mientras el usuario lo habilita; gasta batería y puede haber falsos positivos.
final class WakeWordMonitor: NSObject, SFSpeechRecognizerDelegate {
    /// UserDefaults key (compartida con AppState).
    static let defaultsKey = "argos.wakeWordEnabled"

    /// Frases normalizadas (sin acentos, minúsculas).
    static let phrases: [String] = [
        "oye argos",
        "hey argos",
        "argos"
    ]

    var onWakeDetected: (() -> Void)?
    var onPermissionDenied: ((String) -> Void)?
    /// `true` cuando el motor está realmente capturando (no solo «enabled»).
    var onListeningChanged: ((Bool) -> Void)?

    private let audioEngine = AVAudioEngine()
    private var speechRecognizer: SFSpeechRecognizer?
    private var recognitionRequest: SFSpeechAudioBufferRecognitionRequest?
    private var recognitionTask: SFSpeechRecognitionTask?
    private var tapInstalled = false
    private var restartTimer: Timer?
    private var sessionTimer: Timer?

    private var enabled = false
    private var paused = false
    private var running = false
    private var lastWakeAt = Date.distantPast
    private let debounceInterval: TimeInterval = 2.0
    /// SFSpeechRecognizer se degrada en sesiones largas; reiniciamos periódicamente.
    private let sessionMaxDuration: TimeInterval = 45

    private let queue = DispatchQueue(label: "com.danielrueda.Argos.wakeword")

    override init() {
        super.init()
        speechRecognizer = Listener.makeRecognizer()
        speechRecognizer?.delegate = self
    }

    var isEnabled: Bool { enabled }
    var isActivelyListening: Bool { running && !paused }

    // MARK: - Public control

    func setEnabled(_ value: Bool) {
        DispatchQueue.main.async {
            self.enabled = value
            UserDefaults.standard.set(value, forKey: Self.defaultsKey)
            if value {
                self.paused = false
                Task { @MainActor in
                    await self.startIfNeeded()
                }
            } else {
                self.stopEngine(notify: true)
            }
        }
    }

    /// Pausa temporal (comando, TTS, teclado, agente). No cambia el toggle del usuario.
    func pause() {
        DispatchQueue.main.async {
            self.paused = true
            self.stopEngine(notify: true)
        }
    }

    func resumeIfNeeded() {
        DispatchQueue.main.async {
            guard self.enabled else { return }
            self.paused = false
            Task { @MainActor in
                // Pequeño margen para soltar el micrófono del Listener / TTS.
                try? await Task.sleep(nanoseconds: 350_000_000)
                await self.startIfNeeded()
            }
        }
    }

    /// Marca debounce tras manejar un wake (también lo hace `emitWake` internamente).
    func noteWakeHandled() {
        lastWakeAt = Date()
    }

    // MARK: - Matching

    /// Detecta wake normalizando acentos/caso. No trata el resto de la frase como comando.
    static func containsWakePhrase(_ raw: String) -> Bool {
        let n = IntentParser.normalize(raw)
        guard !n.isEmpty else { return false }
        // Preferir frases largas primero.
        for phrase in phrases {
            if n == phrase { return true }
            if n.hasPrefix(phrase + " ") { return true }
            if n.hasSuffix(" " + phrase) { return true }
            if n.contains(" " + phrase + " ") { return true }
        }
        return false
    }

    // MARK: - Engine

    @MainActor
    private func startIfNeeded() async {
        guard enabled, !paused, !running else { return }

        let permitted = await PermissionGate.requestSpeechAndMicrophone()
        guard permitted else {
            enabled = false
            UserDefaults.standard.set(false, forKey: Self.defaultsKey)
            onPermissionDenied?(
                "Sin permiso de micrófono o reconocimiento de voz. Wake word desactivado. Actívalos en Ajustes del Sistema."
            )
            onListeningChanged?(false)
            return
        }

        beginSession()
    }

    private func beginSession() {
        guard enabled, !paused else { return }
        stopEngine(notify: false)

        if speechRecognizer == nil || speechRecognizer?.isAvailable == false {
            speechRecognizer = Listener.makeRecognizer()
            speechRecognizer?.delegate = self
        }
        guard let recognizer = speechRecognizer, recognizer.isAvailable else {
            scheduleRestart(after: 2.0)
            return
        }

        let request = SFSpeechAudioBufferRecognitionRequest()
        request.shouldReportPartialResults = true
        request.taskHint = .search
        if recognizer.supportsOnDeviceRecognition {
            request.requiresOnDeviceRecognition = true
        }
        recognitionRequest = request

        let inputNode = audioEngine.inputNode
        let format = inputNode.outputFormat(forBus: 0)
        guard format.sampleRate > 0, format.channelCount > 0 else {
            scheduleRestart(after: 2.0)
            return
        }

        inputNode.installTap(onBus: 0, bufferSize: 1024, format: format) { [weak self] buffer, _ in
            self?.recognitionRequest?.append(buffer)
        }
        tapInstalled = true

        audioEngine.prepare()
        do {
            try audioEngine.start()
        } catch {
            teardownTapOnly()
            scheduleRestart(after: 2.0)
            return
        }

        running = true
        DispatchQueue.main.async { [weak self] in
            self?.onListeningChanged?(true)
        }

        recognitionTask = recognizer.recognitionTask(with: request) { [weak self] result, error in
            guard let self else { return }
            if let result {
                let text = result.bestTranscription.formattedString
                if Self.containsWakePhrase(text) {
                    DispatchQueue.main.async {
                        self.emitWake()
                    }
                    return
                }
            }
            if error != nil || (result?.isFinal == true) {
                DispatchQueue.main.async {
                    guard self.enabled, !self.paused else { return }
                    self.stopEngine(notify: false)
                    self.scheduleRestart(after: 0.4)
                }
            }
        }

        sessionTimer?.invalidate()
        sessionTimer = Timer.scheduledTimer(withTimeInterval: sessionMaxDuration, repeats: false) { [weak self] _ in
            guard let self, self.enabled, !self.paused else { return }
            self.stopEngine(notify: false)
            self.scheduleRestart(after: 0.3)
        }
    }

    private func emitWake() {
        let now = Date()
        guard now.timeIntervalSince(lastWakeAt) >= debounceInterval else { return }
        lastWakeAt = now
        // Parar ya para liberar el mic al Listener de comando.
        stopEngine(notify: true)
        paused = true
        onWakeDetected?()
    }

    private func scheduleRestart(after delay: TimeInterval) {
        restartTimer?.invalidate()
        restartTimer = Timer.scheduledTimer(withTimeInterval: delay, repeats: false) { [weak self] _ in
            guard let self, self.enabled, !self.paused else { return }
            self.beginSession()
        }
    }

    private func stopEngine(notify: Bool) {
        restartTimer?.invalidate()
        restartTimer = nil
        sessionTimer?.invalidate()
        sessionTimer = nil

        recognitionTask?.cancel()
        recognitionTask = nil
        recognitionRequest?.endAudio()
        recognitionRequest = nil

        if audioEngine.isRunning {
            audioEngine.stop()
        }
        teardownTapOnly()
        running = false
        if notify {
            DispatchQueue.main.async { [weak self] in
                self?.onListeningChanged?(false)
            }
        }
    }

    private func teardownTapOnly() {
        if tapInstalled {
            audioEngine.inputNode.removeTap(onBus: 0)
            tapInstalled = false
        }
    }

    func speechRecognizer(_ speechRecognizer: SFSpeechRecognizer, availabilityDidChange available: Bool) {
        if available, enabled, !paused, !running {
            scheduleRestart(after: 0.5)
        }
    }
}
