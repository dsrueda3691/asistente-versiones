import Foundation
import Speech
import AVFoundation

enum ListenerError: Error {
    case recognizerUnavailable
    case notAuthorized
    case noInputDevice
    case engineFailed(String)
    case timeout
    case cancelled

    var userMessage: String {
        switch self {
        case .recognizerUnavailable:
            return "El reconocimiento de voz no está disponible en este Mac."
        case .notAuthorized:
            return "Sin permiso de reconocimiento de voz. Actívalo en Ajustes."
        case .noInputDevice:
            return "No encuentro un micrófono."
        case .engineFailed:
            return "No pude iniciar el micrófono."
        case .timeout:
            return "No te escuché. Prueba otra vez."
        case .cancelled:
            return "Cancelado."
        }
    }
}

/// Reconocimiento de voz con Speech. Prefiere es-CO, luego es-ES, y on-device si existe.
final class Listener: NSObject, SFSpeechRecognizerDelegate {
    var onPartialTranscript: ((String) -> Void)?

    private let audioEngine = AVAudioEngine()
    private var speechRecognizer: SFSpeechRecognizer?
    private var recognitionRequest: SFSpeechAudioBufferRecognitionRequest?
    private var recognitionTask: SFSpeechRecognitionTask?
    private var silenceTimer: Timer?
    private var maxTimer: Timer?
    private var continuation: CheckedContinuation<String, Error>?
    private var lastPartial = ""
    private var gotSpeech = false
    private var tapInstalled = false

    override init() {
        super.init()
        speechRecognizer = Self.makeRecognizer()
        speechRecognizer?.delegate = self
    }

    static func makeRecognizer() -> SFSpeechRecognizer? {
        if let co = SFSpeechRecognizer(locale: Locale(identifier: "es-CO")), co.isAvailable {
            return co
        }
        if let es = SFSpeechRecognizer(locale: Locale(identifier: "es-ES")), es.isAvailable {
            return es
        }
        if let anyES = SFSpeechRecognizer.supportedLocales().first(where: { $0.identifier.hasPrefix("es") }) {
            return SFSpeechRecognizer(locale: anyES)
        }
        return SFSpeechRecognizer()
    }

    func listen(maxDuration: TimeInterval) async throws -> String {
        try await withCheckedThrowingContinuation { continuation in
            DispatchQueue.main.async {
                self.begin(maxDuration: maxDuration, continuation: continuation)
            }
        }
    }

    func stopListening() {
        DispatchQueue.main.async {
            if self.continuation != nil {
                self.finish(with: .success(self.lastPartial))
            }
        }
    }

    private func begin(maxDuration: TimeInterval, continuation: CheckedContinuation<String, Error>) {
        if self.continuation != nil {
            let previous = self.continuation
            self.continuation = nil
            previous?.resume(throwing: ListenerError.cancelled)
        }
        self.continuation = continuation
        lastPartial = ""
        gotSpeech = false

        guard SFSpeechRecognizer.authorizationStatus() == .authorized else {
            finish(with: .failure(ListenerError.notAuthorized))
            return
        }

        if speechRecognizer == nil || speechRecognizer?.isAvailable == false {
            speechRecognizer = Self.makeRecognizer()
            speechRecognizer?.delegate = self
        }
        guard let recognizer = speechRecognizer, recognizer.isAvailable else {
            finish(with: .failure(ListenerError.recognizerUnavailable))
            return
        }

        teardownEngine()

        let request = SFSpeechAudioBufferRecognitionRequest()
        request.shouldReportPartialResults = true
        request.taskHint = .dictation
        if recognizer.supportsOnDeviceRecognition {
            request.requiresOnDeviceRecognition = true
        }
        recognitionRequest = request

        let inputNode = audioEngine.inputNode
        let format = inputNode.outputFormat(forBus: 0)
        guard format.sampleRate > 0, format.channelCount > 0 else {
            finish(with: .failure(ListenerError.noInputDevice))
            return
        }

        inputNode.installTap(onBus: 0, bufferSize: 1024, format: format) { [weak self] buffer, _ in
            self?.recognitionRequest?.append(buffer)
        }
        tapInstalled = true

        audioEngine.prepare()
        do {
            try audioEngine.start()
        } catch {
            finish(with: .failure(ListenerError.engineFailed(error.localizedDescription)))
            return
        }

        recognitionTask = recognizer.recognitionTask(with: request) { [weak self] result, error in
            guard let self else { return }
            DispatchQueue.main.async {
                if let result {
                    let text = result.bestTranscription.formattedString
                    self.lastPartial = text
                    self.gotSpeech = !text.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty
                    self.onPartialTranscript?(text)
                    if result.isFinal {
                        self.finish(with: .success(text))
                        return
                    }
                    if self.gotSpeech {
                        self.bumpSilenceTimer()
                    }
                }
                if error != nil, self.continuation != nil {
                    if self.gotSpeech {
                        self.finish(with: .success(self.lastPartial))
                    } else {
                        self.finish(with: .failure(ListenerError.timeout))
                    }
                }
            }
        }

        maxTimer?.invalidate()
        maxTimer = Timer.scheduledTimer(withTimeInterval: maxDuration, repeats: false) { [weak self] _ in
            guard let self else { return }
            if self.gotSpeech {
                self.finish(with: .success(self.lastPartial))
            } else {
                self.finish(with: .failure(ListenerError.timeout))
            }
        }
    }

    private func bumpSilenceTimer() {
        silenceTimer?.invalidate()
        silenceTimer = Timer.scheduledTimer(withTimeInterval: 1.7, repeats: false) { [weak self] _ in
            guard let self else { return }
            self.finish(with: .success(self.lastPartial))
        }
    }

    private func teardownEngine() {
        recognitionTask?.cancel()
        recognitionTask = nil
        recognitionRequest = nil
        if audioEngine.isRunning {
            audioEngine.stop()
        }
        if tapInstalled {
            audioEngine.inputNode.removeTap(onBus: 0)
            tapInstalled = false
        }
    }

    private func finish(with result: Result<String, Error>) {
        guard let cont = continuation else { return }
        continuation = nil
        silenceTimer?.invalidate()
        silenceTimer = nil
        maxTimer?.invalidate()
        maxTimer = nil

        recognitionRequest?.endAudio()
        teardownEngine()

        cont.resume(with: result)
    }

    func speechRecognizer(_ speechRecognizer: SFSpeechRecognizer, availabilityDidChange available: Bool) {
        // El siguiente listen() reintenta crear el recognizer.
    }
}
