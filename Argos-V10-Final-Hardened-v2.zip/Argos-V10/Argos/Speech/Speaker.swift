import Foundation
import AVFoundation

/// Síntesis de voz en español — preferencia femenina premium/enhanced (estilo Friday / MCU).
/// Nota: no existe la voz exacta de FRIDAY del MCU en macOS; usamos la mejor voz española
/// femenina disponible (es-CO / es-ES / es-MX, premium o enhanced si está instalada).
final class Speaker: NSObject, AVSpeechSynthesizerDelegate {
    private let synthesizer = AVSpeechSynthesizer()

    /// Se llama en el hilo principal cuando empieza / termina de hablar.
    var onSpeakingChanged: ((Bool) -> Void)?

    override init() {
        super.init()
        synthesizer.delegate = self
    }

    /// Habla texto. Si `muted` es true, no emite audio ni marca isSpeaking.
    func speak(_ text: String, muted: Bool = false) {
        let trimmed = text.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmed.isEmpty else { return }
        stop()
        guard !muted else {
            notifySpeaking(false)
            return
        }
        let utterance = AVSpeechUtterance(string: trimmed)
        utterance.voice = Self.preferredSpanishVoice()
        // Un poco más crisp / competente que el default.
        utterance.rate = AVSpeechUtteranceDefaultSpeechRate * 1.02
        utterance.pitchMultiplier = 1.06
        utterance.volume = 1.0
        utterance.prefersAssistiveTechnologySettings = false
        notifySpeaking(true)
        synthesizer.speak(utterance)
    }

    func stop() {
        if synthesizer.isSpeaking {
            synthesizer.stopSpeaking(at: .immediate)
        }
        notifySpeaking(false)
    }

    private func notifySpeaking(_ value: Bool) {
        if Thread.isMainThread {
            onSpeakingChanged?(value)
        } else {
            DispatchQueue.main.async { [weak self] in
                self?.onSpeakingChanged?(value)
            }
        }
    }

    func speechSynthesizer(_ synthesizer: AVSpeechSynthesizer, didFinish utterance: AVSpeechUtterance) {
        notifySpeaking(false)
    }

    func speechSynthesizer(_ synthesizer: AVSpeechSynthesizer, didCancel utterance: AVSpeechUtterance) {
        notifySpeaking(false)
    }

    /// Mejor voz española femenina disponible: premium → enhanced → default; es-CO → es-ES → es-MX…
    static func preferredSpanishVoice() -> AVSpeechSynthesisVoice? {
        let voices = AVSpeechSynthesisVoice.speechVoices()
        let preferredLangs = ["es-CO", "es-ES", "es-MX", "es-US", "es-AR", "es-CL", "es-PE"]
        let qualities: [AVSpeechSynthesisVoiceQuality] = [.premium, .enhanced, .default]

        // 1) Femenina + idioma preferido + calidad
        for quality in qualities {
            for lang in preferredLangs {
                let matches = voices.filter { $0.language == lang && $0.quality == quality }
                if let female = matches.first(where: { $0.gender == .female }) {
                    return female
                }
            }
        }
        // 2) Cualquier femenina en español
        for quality in qualities {
            if let female = voices.first(where: {
                $0.language.hasPrefix("es") && $0.quality == quality && $0.gender == .female
            }) {
                return female
            }
        }
        // 3) Nombres conocidos de voces femeninas en español (por si gender no filtra)
        let femaleNameHints = ["paulina", "monica", "mónica", "sabina", "francisca", "maria", "maría", "carmen", "soledad", "angelica", "angélica", "montserrat"]
        for quality in qualities {
            for lang in preferredLangs {
                if let match = voices.first(where: { v in
                    v.language == lang && v.quality == quality &&
                    femaleNameHints.contains(where: { v.name.lowercased().contains($0) })
                }) {
                    return match
                }
            }
        }
        // 4) Cualquier voz del idioma preferido
        for quality in qualities {
            for lang in preferredLangs {
                if let match = voices.first(where: { $0.language == lang && $0.quality == quality }) {
                    return match
                }
            }
        }
        for lang in preferredLangs {
            if let voice = AVSpeechSynthesisVoice(language: lang) {
                return voice
            }
        }
        return AVSpeechSynthesisVoice(language: "es")
    }
}
