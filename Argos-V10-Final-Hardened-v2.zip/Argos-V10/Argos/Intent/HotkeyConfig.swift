import Foundation
import AppKit
import Carbon

/// Atajo global configurable. Persistido en UserDefaults `argos.hotkey`.
struct HotkeyConfig: Equatable, Codable {
    static let defaultsKey = "argos.hotkey"

    /// Carbon virtual key code.
    var keyCode: UInt32
    /// Carbon modifiers: controlKey | optionKey | cmdKey | shiftKey
    var carbonModifiers: UInt32
    /// Etiqueta para UI, p. ej. "⌃⌥⌘V"
    var display: String

    static let `default` = HotkeyConfig(
        keyCode: UInt32(kVK_ANSI_V),
        carbonModifiers: UInt32(controlKey | optionKey | cmdKey),
        display: "⌃⌥⌘V"
    )

    static let presets: [HotkeyConfig] = [
        .default,
        HotkeyConfig(keyCode: UInt32(kVK_Space), carbonModifiers: UInt32(controlKey | optionKey | cmdKey), display: "⌃⌥⌘Space"),
        HotkeyConfig(keyCode: UInt32(kVK_ANSI_F), carbonModifiers: UInt32(controlKey | optionKey | cmdKey), display: "⌃⌥⌘F"),
        HotkeyConfig(keyCode: UInt32(kVK_ANSI_V), carbonModifiers: UInt32(controlKey | optionKey | shiftKey), display: "⌃⌥⇧V"),
        HotkeyConfig(keyCode: UInt32(kVK_ANSI_J), carbonModifiers: UInt32(controlKey | optionKey | cmdKey), display: "⌃⌥⌘J"),
        // Legacy (documentado como reemplazado)
        HotkeyConfig(keyCode: UInt32(kVK_Space), carbonModifiers: UInt32(optionKey), display: "⌥Espacio (antiguo)")
    ]

    static var current: HotkeyConfig {
        get {
            let defaults = UserDefaults.standard
            let legacyDomain = defaults.persistentDomain(forName: "com.danielrueda.Viernes")
                ?? defaults.persistentDomain(forName: "Viernes")
            let legacyData = legacyDomain?["viernes.hotkey"] as? Data
            let data = defaults.data(forKey: defaultsKey) ?? legacyData
            guard let data, let decoded = try? JSONDecoder().decode(HotkeyConfig.self, from: data) else { return .default }
            if defaults.data(forKey: defaultsKey) == nil { defaults.set(data, forKey: defaultsKey) }
            return decoded
        }
        set {
            if let data = try? JSONEncoder().encode(newValue) {
                UserDefaults.standard.set(data, forKey: defaultsKey)
            }
        }
    }

    var nsEventModifiers: NSEvent.ModifierFlags {
        var flags: NSEvent.ModifierFlags = []
        if carbonModifiers & UInt32(controlKey) != 0 { flags.insert(.control) }
        if carbonModifiers & UInt32(optionKey) != 0 { flags.insert(.option) }
        if carbonModifiers & UInt32(cmdKey) != 0 { flags.insert(.command) }
        if carbonModifiers & UInt32(shiftKey) != 0 { flags.insert(.shift) }
        return flags
    }

    func matches(_ event: NSEvent) -> Bool {
        guard event.keyCode == UInt16(keyCode) else { return false }
        let flags = event.modifierFlags.intersection(.deviceIndependentFlagsMask)
        let wanted = nsEventModifiers
        // Exact match on control/option/command/shift
        let interesting: NSEvent.ModifierFlags = [.control, .option, .command, .shift]
        return flags.intersection(interesting) == wanted
    }
}
