import Foundation
import EventKit

enum CalendarServiceError: Error, LocalizedError {
    case accessDenied
    case saveFailed(String)
    case invalidDates

    var errorDescription: String? { userMessage }
    var userMessage: String {
        switch self {
        case .accessDenied:
            return "Necesito acceso a Calendario. Actívalo en Ajustes → Privacidad y seguridad → Calendarios."
        case .saveFailed(let m):
            return "No pude crear el evento. \(m)"
        case .invalidDates:
            return "Las fechas del evento no son válidas."
        }
    }
}

enum CalendarService {
    private static let store = EKEventStore()

    static func requestAccess() async throws {
        let granted: Bool
        if #available(macOS 14.0, *) {
            granted = try await store.requestFullAccessToEvents()
        } else {
            granted = try await store.requestAccess(to: .event)
        }
        guard granted else { throw CalendarServiceError.accessDenied }
    }

    /// Solo tras confirmación del usuario.
    static func createEvent(_ pending: PendingCalendarEvent) async throws -> String {
        try await requestAccess()
        guard pending.end > pending.start else { throw CalendarServiceError.invalidDates }
        let event = EKEvent(eventStore: store)
        event.title = pending.title
        event.startDate = pending.start
        event.endDate = pending.end
        event.notes = pending.notes
        event.location = pending.location
        event.calendar = store.defaultCalendarForNewEvents
        do {
            try store.save(event, span: .thisEvent, commit: true)
        } catch {
            throw CalendarServiceError.saveFailed(error.localizedDescription)
        }
        return "Evento creado: \(pending.title)."
    }

    /// Parsea fechas relativas simples en español a partir de ahora.
    static func parseStartEnd(from args: [String: String], now: Date = Date()) -> (Date, Date)? {
        let cal = Calendar.current
        if let startISO = args["startISO"], let endISO = args["endISO"],
           let s = ISO8601DateFormatter().date(from: startISO),
           let e = ISO8601DateFormatter().date(from: endISO) {
            return (s, e)
        }
        // "mañana a las 10" / "hoy 15:00" / duración horas
        var start = now.addingTimeInterval(3600)
        if let startText = args["start"] ?? args["when"] ?? args["inicio"] {
            if let d = parseLooseDate(startText, relativeTo: now) { start = d }
        }
        var end = start.addingTimeInterval(3600)
        if let endText = args["end"] ?? args["fin"] {
            if let d = parseLooseDate(endText, relativeTo: now) { end = d }
        } else if let hours = Double(args["durationHours"] ?? args["horas"] ?? "") {
            end = start.addingTimeInterval(hours * 3600)
        } else if let mins = Double(args["durationMinutes"] ?? args["minutos"] ?? "") {
            end = start.addingTimeInterval(mins * 60)
        }
        if end <= start { end = start.addingTimeInterval(3600) }
        _ = cal
        return (start, end)
    }

    static func parseLooseDate(_ text: String, relativeTo now: Date) -> Date? {
        let s = text.folding(options: [.diacriticInsensitive, .caseInsensitive], locale: Locale(identifier: "es"))
            .lowercased()
            .trimmingCharacters(in: .whitespacesAndNewlines)
        let cal = Calendar.current
        var base = now
        if s.contains("manana") {
            base = cal.date(byAdding: .day, value: 1, to: cal.startOfDay(for: now)) ?? now
        } else if s.contains("pasado manana") {
            base = cal.date(byAdding: .day, value: 2, to: cal.startOfDay(for: now)) ?? now
        } else if s.contains("hoy") {
            base = cal.startOfDay(for: now)
        }

        // Hora: 10, 10:30, 15:00, 3pm
        let pattern = #"(\d{1,2})(?::(\d{2}))?\s*(am|pm|a\.m\.|p\.m\.)?"#
        if let regex = try? NSRegularExpression(pattern: pattern, options: .caseInsensitive) {
            let range = NSRange(s.startIndex..<s.endIndex, in: s)
            if let m = regex.firstMatch(in: s, options: [], range: range),
               let hRange = Range(m.range(at: 1), in: s) {
                var hour = Int(s[hRange]) ?? 9
                var minute = 0
                if m.range(at: 2).location != NSNotFound, let minR = Range(m.range(at: 2), in: s) {
                    minute = Int(s[minR]) ?? 0
                }
                if m.range(at: 3).location != NSNotFound, let ampmR = Range(m.range(at: 3), in: s) {
                    let ampm = s[ampmR]
                    if ampm.contains("p"), hour < 12 { hour += 12 }
                    if ampm.contains("a"), hour == 12 { hour = 0 }
                }
                return cal.date(bySettingHour: min(hour, 23), minute: min(minute, 59), second: 0, of: base)
            }
        }
        if s.contains("manana") || s.contains("hoy") {
            return cal.date(bySettingHour: 9, minute: 0, second: 0, of: base)
        }
        return nil
    }
}
