import Foundation
import AppKit
import AuthenticationServices
import CryptoKit
import Security

// MARK: - Shared integration models

enum ArgosIntegration: String, CaseIterable, Identifiable {
    case gmail
    case outlook
    case github
    case whatsapp

    var id: String { rawValue }
    var title: String {
        switch self {
        case .gmail: return "Gmail"
        case .outlook: return "Outlook"
        case .github: return "GitHub"
        case .whatsapp: return "WhatsApp"
        }
    }
}

struct IntegrationMessage: Identifiable, Equatable {
    let id: String
    let sender: String
    let subject: String
    let preview: String
    let date: String
}

struct GitHubPullRequest: Identifiable, Equatable {
    let id: Int
    let title: String
    let repository: String
    let state: String
    let url: URL?
    let updatedAt: String
}

enum IntegrationError: Error, LocalizedError {
    case notConfigured(String)
    case notConnected(String)
    case authenticationFailed(String)
    case network(String)
    case badResponse(Int, String)
    case invalidResponse
    case missingField(String)

    var errorDescription: String? {
        switch self {
        case .notConfigured(let message), .notConnected(let message), .authenticationFailed(let message), .network(let message):
            return message
        case .badResponse(let status, let message):
            return "Servicio respondió \(status): \(message)"
        case .invalidResponse:
            return "La respuesta del servicio no tiene un formato válido."
        case .missingField(let field):
            return "Falta el campo requerido: \(field)."
        }
    }
}

struct OAuthToken: Codable {
    var accessToken: String
    var refreshToken: String?
    var expiresAt: Date?
    var scope: String?
}

// MARK: - Keychain

enum IntegrationKeychain {
    private static let service = "com.danielrueda.Argos.integrations"

    static func save(_ token: OAuthToken, for integration: ArgosIntegration) {
        guard let data = try? JSONEncoder().encode(token) else { return }
        let query: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: service,
            kSecAttrAccount as String: integration.rawValue
        ]
        SecItemDelete(query as CFDictionary)
        var add = query
        add[kSecValueData as String] = data
        add[kSecAttrAccessible as String] = kSecAttrAccessibleWhenUnlockedThisDeviceOnly
        _ = SecItemAdd(add as CFDictionary, nil)
    }

    static func load(_ integration: ArgosIntegration) -> OAuthToken? {
        let query: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: service,
            kSecAttrAccount as String: integration.rawValue,
            kSecReturnData as String: true,
            kSecMatchLimit as String: kSecMatchLimitOne
        ]
        var item: CFTypeRef?
        guard SecItemCopyMatching(query as CFDictionary, &item) == errSecSuccess,
              let data = item as? Data else { return nil }
        return try? JSONDecoder().decode(OAuthToken.self, from: data)
    }

    static func delete(_ integration: ArgosIntegration) {
        let query: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: service,
            kSecAttrAccount as String: integration.rawValue
        ]
        _ = SecItemDelete(query as CFDictionary)
    }
}

// MARK: - OAuth browser / PKCE

private final class OAuthBrowser: NSObject, ASWebAuthenticationPresentationContextProviding {
    static let shared = OAuthBrowser()
    private var session: ASWebAuthenticationSession?

    func presentationAnchor(for session: ASWebAuthenticationSession) -> ASPresentationAnchor {
        if let window = NSApp.keyWindow ?? NSApp.mainWindow ?? NSApp.windows.first {
            return window
        }
        return NSWindow(contentRect: .zero, styleMask: .borderless, backing: .buffered, defer: true)
    }

    func authenticate(url: URL, callbackScheme: String) async throws -> URL {
        try await withCheckedThrowingContinuation { continuation in
            let session = ASWebAuthenticationSession(url: url, callbackURLScheme: callbackScheme) { url, error in
                if let url {
                    continuation.resume(returning: url)
                } else if let error {
                    continuation.resume(throwing: IntegrationError.authenticationFailed(error.localizedDescription))
                } else {
                    continuation.resume(throwing: IntegrationError.authenticationFailed("La autenticación fue cancelada."))
                }
            }
            session.presentationContextProvider = self
            session.prefersEphemeralWebBrowserSession = false
            self.session = session
            if !session.start() {
                continuation.resume(throwing: IntegrationError.authenticationFailed("No pude abrir el navegador para autenticar.") )
            }
        }
    }
}

private enum PKCE {
    static func verifier() -> String {
        let bytes = (0..<48).map { _ in UInt8.random(in: 0...255) }
        return Data(bytes).base64EncodedString()
            .replacingOccurrences(of: "+", with: "-")
            .replacingOccurrences(of: "/", with: "_")
            .replacingOccurrences(of: "=", with: "")
    }

    static func challenge(for verifier: String) -> String {
        let digest = SHA256.hash(data: Data(verifier.utf8))
        return Data(digest).base64EncodedString()
            .replacingOccurrences(of: "+", with: "-")
            .replacingOccurrences(of: "/", with: "_")
            .replacingOccurrences(of: "=", with: "")
    }

    static func state() -> String {
        verifier()
    }
}

private enum OAuthHTTP {
    static func formPost(url: URL, fields: [String: String], headers: [String: String] = [:]) async throws -> [String: Any] {
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.setValue("application/x-www-form-urlencoded", forHTTPHeaderField: "Content-Type")
        request.setValue("application/json", forHTTPHeaderField: "Accept")
        for (key, value) in headers { request.setValue(value, forHTTPHeaderField: key) }
        var components = URLComponents()
        components.queryItems = fields.map { URLQueryItem(name: $0.key, value: $0.value) }
        request.httpBody = components.percentEncodedQuery?.data(using: .utf8)
        return try await json(request)
    }

    static func json(_ request: URLRequest) async throws -> [String: Any] {
        let data: Data
        let response: URLResponse
        do {
            (data, response) = try await URLSession.shared.data(for: request)
        } catch {
            throw IntegrationError.network(error.localizedDescription)
        }
        guard let http = response as? HTTPURLResponse else { throw IntegrationError.invalidResponse }
        guard (200...299).contains(http.statusCode) else {
            let object = (try? JSONSerialization.jsonObject(with: data)) as? [String: Any]
            let message = (object?["error_description"] as? String) ?? (object?["message"] as? String) ?? (object?["error"] as? String) ?? String(data: data, encoding: .utf8) ?? "Error desconocido"
            throw IntegrationError.badResponse(http.statusCode, message)
        }
        if data.isEmpty { return [:] }
        guard let object = try? JSONSerialization.jsonObject(with: data) as? [String: Any] else {
            throw IntegrationError.badResponse(http.statusCode, String(data: data, encoding: .utf8) ?? "Respuesta no JSON")
        }
        return object
    }

    static func authenticatedJSON(url: URL, token: String, method: String = "GET", body: Data? = nil, contentType: String = "application/json", headers: [String: String] = [:]) async throws -> [String: Any] {
        var request = URLRequest(url: url)
        request.httpMethod = method
        request.setValue("Bearer \(token)", forHTTPHeaderField: "Authorization")
        request.setValue("application/json", forHTTPHeaderField: "Accept")
        if let body {
            request.httpBody = body
            request.setValue(contentType, forHTTPHeaderField: "Content-Type")
        }
        for (key, value) in headers { request.setValue(value, forHTTPHeaderField: key) }
        return try await json(request)
    }
}

// MARK: - Gmail

@MainActor
final class GmailIntegration {
    static let clientIDKey = "argos.gmail.clientID"
    static let callbackScheme = "com.danielrueda.Argos"
    static let redirectURI = "com.danielrueda.Argos:/oauth2redirect"
    static let scopes = [
        "https://www.googleapis.com/auth/gmail.readonly",
        "https://www.googleapis.com/auth/gmail.send"
    ]

    static var configured: Bool {
        !(UserDefaults.standard.string(forKey: clientIDKey) ?? "").trimmingCharacters(in: .whitespacesAndNewlines).isEmpty
    }

    static var connected: Bool { IntegrationKeychain.load(.gmail) != nil }

    static func connect() async throws {
        guard let clientID = UserDefaults.standard.string(forKey: clientIDKey), !clientID.isEmpty else {
            throw IntegrationError.notConfigured("Configura el Client ID de Gmail en Ajustes → Integraciones.")
        }
        let verifier = PKCE.verifier()
        let state = PKCE.state()
        var components = URLComponents(string: "https://accounts.google.com/o/oauth2/v2/auth")!
        components.queryItems = [
            URLQueryItem(name: "client_id", value: clientID),
            URLQueryItem(name: "redirect_uri", value: redirectURI),
            URLQueryItem(name: "response_type", value: "code"),
            URLQueryItem(name: "scope", value: scopes.joined(separator: " ")),
            URLQueryItem(name: "access_type", value: "offline"),
            URLQueryItem(name: "prompt", value: "consent"),
            URLQueryItem(name: "code_challenge", value: PKCE.challenge(for: verifier)),
            URLQueryItem(name: "code_challenge_method", value: "S256"),
            URLQueryItem(name: "state", value: state)
        ]
        let callback = try await OAuthBrowser.shared.authenticate(url: components.url!, callbackScheme: callbackScheme)
        let items = URLComponents(url: callback, resolvingAgainstBaseURL: false)?.queryItems ?? []
        guard let returnedState = items.first(where: { $0.name == "state" })?.value, returnedState == state else {
            throw IntegrationError.authenticationFailed("El estado OAuth de Gmail no coincide.")
        }
        guard let code = items.first(where: { $0.name == "code" })?.value else {
            throw IntegrationError.authenticationFailed(items.first(where: { $0.name == "error_description" })?.value ?? "Google no devolvió un código.")
        }
        let json = try await OAuthHTTP.formPost(
            url: URL(string: "https://oauth2.googleapis.com/token")!,
            fields: [
                "client_id": clientID,
                "code": code,
                "code_verifier": verifier,
                "grant_type": "authorization_code",
                "redirect_uri": redirectURI
            ]
        )
        guard let access = json["access_token"] as? String else { throw IntegrationError.invalidResponse }
        let expires = (json["expires_in"] as? NSNumber).map { Date().addingTimeInterval($0.doubleValue) }
        let token = OAuthToken(accessToken: access, refreshToken: json["refresh_token"] as? String, expiresAt: expires, scope: json["scope"] as? String)
        IntegrationKeychain.save(token, for: .gmail)
    }

    static func listInbox(maxResults: Int = 8) async throws -> [IntegrationMessage] {
        let token = try await validToken()
        var components = URLComponents(string: "https://gmail.googleapis.com/gmail/v1/users/me/messages")!
        components.queryItems = [URLQueryItem(name: "labelIds", value: "INBOX"), URLQueryItem(name: "maxResults", value: String(maxResults))]
        let list = try await OAuthHTTP.authenticatedJSON(url: components.url!, token: token)
        guard let messages = list["messages"] as? [[String: Any]] else { return [] }
        var result: [IntegrationMessage] = []
        for message in messages.prefix(maxResults) {
            guard let id = message["id"] as? String else { continue }
            var detailURL = URL(string: "https://gmail.googleapis.com/gmail/v1/users/me/messages/\(id)")!
            var detailComponents = URLComponents(url: detailURL, resolvingAgainstBaseURL: false)!
            detailComponents.queryItems = [URLQueryItem(name: "format", value: "metadata"), URLQueryItem(name: "metadataHeaders", value: "From"), URLQueryItem(name: "metadataHeaders", value: "Subject"), URLQueryItem(name: "metadataHeaders", value: "Date")]
            detailURL = detailComponents.url!
            let detail = try await OAuthHTTP.authenticatedJSON(url: detailURL, token: token)
            let payload = detail["payload"] as? [String: Any]
            let headers = payload?["headers"] as? [[String: Any]] ?? []
            func header(_ name: String) -> String { headers.first(where: { ($0["name"] as? String)?.caseInsensitiveCompare(name) == .orderedSame })?["value"] as? String ?? "" }
            result.append(IntegrationMessage(id: id, sender: header("From"), subject: header("Subject"), preview: detail["snippet"] as? String ?? "", date: header("Date")))
        }
        return result
    }

    static func send(to: String, subject: String, body: String, cc: String? = nil) async throws -> String {
        let token = try await validToken()
        let encodedSubject = Self.rfc2047Header(subject)
        var safeHeaders = ["To: \(to)", "Subject: \(encodedSubject)", "MIME-Version: 1.0", "Content-Type: text/plain; charset=UTF-8"]
        if let cc, !cc.isEmpty { safeHeaders.append("Cc: \(cc)") }
        let mime = safeHeaders.joined(separator: "\r\n") + "\r\n\r\n" + body
        let raw = Data(mime.utf8).base64EncodedString()
            .replacingOccurrences(of: "+", with: "-")
            .replacingOccurrences(of: "/", with: "_")
            .replacingOccurrences(of: "=", with: "")
        let data = try JSONSerialization.data(withJSONObject: ["raw": raw])
        let json = try await OAuthHTTP.authenticatedJSON(url: URL(string: "https://gmail.googleapis.com/gmail/v1/users/me/messages/send")!, token: token, method: "POST", body: data)
        return "Gmail envió el correo a \(to). ID: \(json["id"] as? String ?? "ok")"
    }

    private static func rfc2047Header(_ value: String) -> String {
        let clean = value.replacingOccurrences(of: "\r", with: " ").replacingOccurrences(of: "\n", with: " ")
        if clean.unicodeScalars.allSatisfy({ $0.value < 128 }) { return clean }
        let encoded = Data(clean.utf8).base64EncodedString()
        return "=?UTF-8?B?\(encoded)?="
    }

    private static func validToken() async throws -> String {
        guard var token = IntegrationKeychain.load(.gmail) else { throw IntegrationError.notConnected("Gmail no está conectado.") }
        if let expires = token.expiresAt, expires.timeIntervalSinceNow > 60 { return token.accessToken }
        guard let refresh = token.refreshToken,
              let clientID = UserDefaults.standard.string(forKey: clientIDKey), !clientID.isEmpty else {
            return token.accessToken
        }
        let json = try await OAuthHTTP.formPost(url: URL(string: "https://oauth2.googleapis.com/token")!, fields: ["client_id": clientID, "refresh_token": refresh, "grant_type": "refresh_token"])
        guard let access = json["access_token"] as? String else { throw IntegrationError.authenticationFailed("Google no pudo renovar la sesión.") }
        token.accessToken = access
        token.expiresAt = (json["expires_in"] as? NSNumber).map { Date().addingTimeInterval($0.doubleValue) }
        IntegrationKeychain.save(token, for: .gmail)
        return access
    }
}

// MARK: - Outlook / Microsoft Graph

@MainActor
final class OutlookIntegration {
    static let clientIDKey = "argos.outlook.clientID"
    static let tenantKey = "argos.outlook.tenant"
    static let callbackScheme = "msauth.com.danielrueda.Argos"
    static let redirectURI = "msauth.com.danielrueda.Argos://auth"
    static let scopes = ["openid", "profile", "offline_access", "User.Read", "Mail.Read", "Mail.Send"]

    static var configured: Bool {
        !(UserDefaults.standard.string(forKey: clientIDKey) ?? "").trimmingCharacters(in: .whitespacesAndNewlines).isEmpty
    }
    static var connected: Bool { IntegrationKeychain.load(.outlook) != nil }

    static func connect() async throws {
        guard let clientID = UserDefaults.standard.string(forKey: clientIDKey), !clientID.isEmpty else {
            throw IntegrationError.notConfigured("Configura el Client ID de Microsoft Entra en Ajustes → Integraciones.")
        }
        let tenant = UserDefaults.standard.string(forKey: tenantKey)?.isEmpty == false ? UserDefaults.standard.string(forKey: tenantKey)! : "common"
        let verifier = PKCE.verifier()
        let state = PKCE.state()
        var components = URLComponents(string: "https://login.microsoftonline.com/\(tenant)/oauth2/v2.0/authorize")!
        components.queryItems = [
            URLQueryItem(name: "client_id", value: clientID),
            URLQueryItem(name: "response_type", value: "code"),
            URLQueryItem(name: "redirect_uri", value: redirectURI),
            URLQueryItem(name: "response_mode", value: "query"),
            URLQueryItem(name: "scope", value: scopes.joined(separator: " ")),
            URLQueryItem(name: "state", value: state),
            URLQueryItem(name: "code_challenge", value: PKCE.challenge(for: verifier)),
            URLQueryItem(name: "code_challenge_method", value: "S256"),
            URLQueryItem(name: "prompt", value: "select_account")
        ]
        let callback = try await OAuthBrowser.shared.authenticate(url: components.url!, callbackScheme: callbackScheme)
        let items = URLComponents(url: callback, resolvingAgainstBaseURL: false)?.queryItems ?? []
        guard let returnedState = items.first(where: { $0.name == "state" })?.value, returnedState == state else { throw IntegrationError.authenticationFailed("El estado OAuth de Outlook no coincide.") }
        guard let code = items.first(where: { $0.name == "code" })?.value else { throw IntegrationError.authenticationFailed(items.first(where: { $0.name == "error_description" })?.value ?? "Microsoft no devolvió un código.") }
        let json = try await OAuthHTTP.formPost(url: URL(string: "https://login.microsoftonline.com/\(tenant)/oauth2/v2.0/token")!, fields: ["client_id": clientID, "code": code, "redirect_uri": redirectURI, "grant_type": "authorization_code", "code_verifier": verifier, "scope": scopes.joined(separator: " ")])
        guard let access = json["access_token"] as? String else { throw IntegrationError.invalidResponse }
        let expires = (json["expires_in"] as? NSNumber).map { Date().addingTimeInterval($0.doubleValue) }
        IntegrationKeychain.save(OAuthToken(accessToken: access, refreshToken: json["refresh_token"] as? String, expiresAt: expires, scope: json["scope"] as? String), for: .outlook)
    }

    static func listInbox(maxResults: Int = 8) async throws -> [IntegrationMessage] {
        let token = try await validToken()
        var components = URLComponents(string: "https://graph.microsoft.com/v1.0/me/mailFolders/inbox/messages")!
        components.queryItems = [URLQueryItem(name: "$top", value: String(maxResults)), URLQueryItem(name: "$select", value: "id,subject,from,receivedDateTime,bodyPreview"), URLQueryItem(name: "$orderby", value: "receivedDateTime desc")]
        let json = try await OAuthHTTP.authenticatedJSON(url: components.url!, token: token)
        guard let values = json["value"] as? [[String: Any]] else { return [] }
        return values.compactMap { item in
            guard let id = item["id"] as? String else { return nil }
            let from = ((item["from"] as? [String: Any])?["emailAddress"] as? [String: Any])?["address"] as? String ?? ""
            return IntegrationMessage(id: id, sender: from, subject: item["subject"] as? String ?? "(sin asunto)", preview: item["bodyPreview"] as? String ?? "", date: item["receivedDateTime"] as? String ?? "")
        }
    }

    static func send(to: String, subject: String, body: String, cc: String? = nil) async throws -> String {
        let token = try await validToken()
        func recipient(_ address: String) -> [String: Any] { ["emailAddress": ["address": address]] }
        let recipients = to.split(whereSeparator: { $0 == "," || $0 == ";" }).map { recipient(String($0).trimmingCharacters(in: .whitespacesAndNewlines)) }
        var message: [String: Any] = ["subject": subject, "body": ["contentType": "Text", "content": body], "toRecipients": recipients]
        if let cc, !cc.isEmpty { message["ccRecipients"] = cc.split(whereSeparator: { $0 == "," || $0 == ";" }).map { recipient(String($0).trimmingCharacters(in: .whitespacesAndNewlines)) } }
        let data = try JSONSerialization.data(withJSONObject: ["message": message, "saveToSentItems": true])
        _ = try await OAuthHTTP.authenticatedJSON(url: URL(string: "https://graph.microsoft.com/v1.0/me/sendMail")!, token: token, method: "POST", body: data)
        return "Outlook envió el correo a \(to)."
    }

    private static func validToken() async throws -> String {
        guard var token = IntegrationKeychain.load(.outlook) else { throw IntegrationError.notConnected("Outlook no está conectado.") }
        if let expires = token.expiresAt, expires.timeIntervalSinceNow > 60 { return token.accessToken }
        guard let refresh = token.refreshToken,
              let clientID = UserDefaults.standard.string(forKey: clientIDKey), !clientID.isEmpty else { return token.accessToken }
        let tenant = UserDefaults.standard.string(forKey: tenantKey)?.isEmpty == false ? UserDefaults.standard.string(forKey: tenantKey)! : "common"
        let json = try await OAuthHTTP.formPost(url: URL(string: "https://login.microsoftonline.com/\(tenant)/oauth2/v2.0/token")!, fields: ["client_id": clientID, "refresh_token": refresh, "grant_type": "refresh_token", "scope": scopes.joined(separator: " ")])
        guard let access = json["access_token"] as? String else { throw IntegrationError.authenticationFailed("Microsoft no pudo renovar la sesión.") }
        token.accessToken = access
        token.expiresAt = (json["expires_in"] as? NSNumber).map { Date().addingTimeInterval($0.doubleValue) }
        IntegrationKeychain.save(token, for: .outlook)
        return access
    }
}

// MARK: - GitHub

@MainActor
final class GitHubIntegration {
    static let clientIDKey = "argos.github.clientID"
    static var configured: Bool { !(UserDefaults.standard.string(forKey: clientIDKey) ?? "").trimmingCharacters(in: .whitespacesAndNewlines).isEmpty }
    static var connected: Bool { IntegrationKeychain.load(.github) != nil }

    static func connect() async throws {
        guard let clientID = UserDefaults.standard.string(forKey: clientIDKey), !clientID.isEmpty else { throw IntegrationError.notConfigured("Configura el Client ID de GitHub en Ajustes → Integraciones.") }
        let requestURL = URL(string: "https://github.com/login/device/code")!
        let json = try await OAuthHTTP.formPost(url: requestURL, fields: ["client_id": clientID, "scope": "read:user repo"], headers: ["Accept": "application/json"])
        guard let deviceCode = json["device_code"] as? String,
              let userCode = json["user_code"] as? String,
              let verificationURI = json["verification_uri"] as? String else { throw IntegrationError.invalidResponse }
        if let url = URL(string: verificationURI) { NSWorkspace.shared.open(url) }
        let alert = NSAlert()
        alert.messageText = "Autoriza Argos en GitHub"
        alert.informativeText = "GitHub abrió el navegador. Introduce este código: \(userCode)"
        alert.addButton(withTitle: "Ya lo autoricé")
        alert.runModal()
        let expires = (json["expires_in"] as? NSNumber)?.doubleValue ?? 900
        let interval = max((json["interval"] as? NSNumber)?.doubleValue ?? 5, 5)
        let started = Date()
        while Date().timeIntervalSince(started) < expires {
            try await Task.sleep(nanoseconds: UInt64(interval * 1_000_000_000))
            do {
                let token = try await OAuthHTTP.formPost(url: URL(string: "https://github.com/login/oauth/access_token")!, fields: ["client_id": clientID, "device_code": deviceCode, "grant_type": "urn:ietf:params:oauth:grant-type:device_code"], headers: ["Accept": "application/json"])
                if let error = token["error"] as? String {
                    switch error {
                    case "authorization_pending": break
                    case "slow_down": try await Task.sleep(nanoseconds: 5_000_000_000)
                    case "access_denied": throw IntegrationError.authenticationFailed("Autorización de GitHub cancelada.")
                    case "expired_token": throw IntegrationError.authenticationFailed("El código de GitHub expiró. Vuelve a conectar.")
                    case "incorrect_device_code": throw IntegrationError.authenticationFailed("El código de dispositivo de GitHub no es válido.")
                    default: throw IntegrationError.authenticationFailed("GitHub no pudo completar la autorización: \(error).")
                    }
                    continue
                }
                if let access = token["access_token"] as? String {
                    IntegrationKeychain.save(OAuthToken(accessToken: access, refreshToken: nil, expiresAt: nil, scope: token["scope"] as? String), for: .github)
                    return
                }
            } catch let error as IntegrationError {
                switch error {
                case .badResponse(_, let message) where message == "authorization_pending":
                    break
                case .badResponse(_, let message) where message == "slow_down":
                    try await Task.sleep(nanoseconds: 5_000_000_000)
                case .badResponse(_, let message) where message == "expired_token":
                    throw IntegrationError.authenticationFailed("El código de GitHub expiró. Vuelve a conectar.")
                case .badResponse(_, let message) where message == "access_denied":
                    throw IntegrationError.authenticationFailed("Autorización de GitHub cancelada.")
                default:
                    throw error
                }
            }
            _ = userCode
        }
        throw IntegrationError.authenticationFailed("Se agotó el código de GitHub. Vuelve a conectar.")
    }

    static func listMyPullRequests(maxResults: Int = 10) async throws -> [GitHubPullRequest] {
        guard let token = IntegrationKeychain.load(.github)?.accessToken else { throw IntegrationError.notConnected("GitHub no está conectado.") }
        let user = try await OAuthHTTP.authenticatedJSON(url: URL(string: "https://api.github.com/user")!, token: token, headers: ["X-GitHub-Api-Version": "2026-03-10"])
        guard let login = user["login"] as? String, !login.isEmpty else { throw IntegrationError.invalidResponse }
        var components = URLComponents(string: "https://api.github.com/search/issues")!
        components.queryItems = [URLQueryItem(name: "q", value: "is:pr is:open author:\(login)"), URLQueryItem(name: "per_page", value: String(maxResults)), URLQueryItem(name: "sort", value: "updated"), URLQueryItem(name: "order", value: "desc")]
        let json = try await OAuthHTTP.authenticatedJSON(url: components.url!, token: token, headers: ["X-GitHub-Api-Version": "2026-03-10"])
        guard let items = json["items"] as? [[String: Any]] else { return [] }
        return items.compactMap { item in
            guard let id = item["id"] as? Int else { return nil }
            let title = item["title"] as? String ?? "(sin título)"
            let html = URL(string: item["html_url"] as? String ?? "")
            let repo = (item["repository_url"] as? String)?.split(separator: "/").suffix(2).joined(separator: "/") ?? ""
            return GitHubPullRequest(id: id, title: title, repository: repo, state: item["state"] as? String ?? "open", url: html, updatedAt: item["updated_at"] as? String ?? "")
        }
    }
}

// MARK: - WhatsApp Cloud API

@MainActor
final class WhatsAppIntegration {
    static let phoneNumberIDKey = "argos.whatsapp.phoneNumberID"
    static let graphVersionKey = "argos.whatsapp.graphVersion"
    static let tokenAccount = "whatsapp_cloud_access_token"

    static var configured: Bool {
        let id = UserDefaults.standard.string(forKey: phoneNumberIDKey) ?? ""
        return !id.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty && loadToken() != nil
    }

    static func saveAccessToken(_ token: String) {
        guard let data = token.trimmingCharacters(in: .whitespacesAndNewlines).data(using: .utf8), !data.isEmpty else { return }
        let service = "com.danielrueda.Argos.whatsapp"
        let query: [String: Any] = [kSecClass as String: kSecClassGenericPassword, kSecAttrService as String: service, kSecAttrAccount as String: tokenAccount]
        SecItemDelete(query as CFDictionary)
        var add = query
        add[kSecValueData as String] = data
        add[kSecAttrAccessible as String] = kSecAttrAccessibleWhenUnlockedThisDeviceOnly
        _ = SecItemAdd(add as CFDictionary, nil)
    }

    static func sendText(to phone: String, message: String) async throws -> String {
        guard let phoneNumberID = UserDefaults.standard.string(forKey: phoneNumberIDKey), !phoneNumberID.isEmpty else { throw IntegrationError.notConfigured("Configura el Phone Number ID de WhatsApp Business.") }
        guard let token = loadToken() else { throw IntegrationError.notConnected("Configura el token de WhatsApp Cloud API.") }
        let version = UserDefaults.standard.string(forKey: graphVersionKey)?.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty == false ? UserDefaults.standard.string(forKey: graphVersionKey)! : "v23.0"
        let url = URL(string: "https://graph.facebook.com/\(version)/\(phoneNumberID)/messages")!
        let normalizedPhone = normalizePhone(phone)
        guard normalizedPhone.count >= 8 && normalizedPhone.count <= 15 else {
            throw IntegrationError.notConfigured("El teléfono de WhatsApp debe incluir el código de país, por ejemplo +57 300 123 4567.")
        }
        let body: [String: Any] = ["messaging_product": "whatsapp", "to": normalizedPhone, "type": "text", "text": ["preview_url": false, "body": message]]
        let data = try JSONSerialization.data(withJSONObject: body)
        let json = try await OAuthHTTP.authenticatedJSON(url: url, token: token, method: "POST", body: data)
        let id = ((json["messages"] as? [[String: Any]])?.first?["id"] as? String) ?? "ok"
        return "WhatsApp envió el mensaje a +\(normalizedPhone). ID: \(id)"
    }

    private static func loadToken() -> String? {
        let service = "com.danielrueda.Argos.whatsapp"
        let query: [String: Any] = [kSecClass as String: kSecClassGenericPassword, kSecAttrService as String: service, kSecAttrAccount as String: tokenAccount, kSecReturnData as String: true, kSecMatchLimit as String: kSecMatchLimitOne]
        var item: CFTypeRef?
        guard SecItemCopyMatching(query as CFDictionary, &item) == errSecSuccess, let data = item as? Data else { return nil }
        return String(data: data, encoding: .utf8)
    }

    private static func normalizePhone(_ raw: String) -> String {
        let digits = raw.filter(\.isNumber)
        return String(digits.prefix(15))
    }
}
