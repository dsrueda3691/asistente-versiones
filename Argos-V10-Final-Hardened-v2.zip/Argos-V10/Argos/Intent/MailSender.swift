import Foundation
import AppKit

struct PendingMail: Equatable {
    var to: String
    var subject: String
    var body: String
    var cc: String?

    var summary: String {
        var lines = [
            "Para: \(to)",
            "Asunto: \(subject.isEmpty ? "(sin asunto)" : subject)"
        ]
        if let cc, !cc.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
            lines.append("Cc: \(cc)")
        }
        let preview = body.trimmingCharacters(in: .whitespacesAndNewlines)
        if preview.isEmpty {
            lines.append("Cuerpo: (vacío)")
        } else if preview.count > 280 {
            lines.append("Cuerpo: \(String(preview.prefix(280)))…")
        } else {
            lines.append("Cuerpo: \(preview)")
        }
        return lines.joined(separator: "\n")
    }
}

enum MailSendError: Error, LocalizedError {
    case emptyTo
    case appleScriptFailed(String)
    case cancelled

    var errorDescription: String? { userMessage }

    var userMessage: String {
        switch self {
        case .emptyTo:
            return "Falta el destinatario. No envié nada."
        case .appleScriptFailed(let detail):
            let trimmed = detail.trimmingCharacters(in: .whitespacesAndNewlines)
            if trimmed.isEmpty {
                return "No pude enviar el correo con Mail. Revisa Automatización (Mail) en Privacidad y seguridad."
            }
            return "No pude enviar el correo. \(trimmed)"
        case .cancelled:
            return "Cancelado."
        }
    }
}

/// Crea y envía un mensaje vía Mail.app con AppleScript. Solo tras confirmación explícita en la UI.
enum MailSender {
    /// Crea el mensaje en Mail y lo envía. Requiere permiso de Automatización para controlar Mail.
    @discardableResult
    static func send(_ draft: PendingMail) throws -> String {
        let to = draft.to.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !to.isEmpty else { throw MailSendError.emptyTo }

        let subject = draft.subject
        let body = draft.body
        let cc = draft.cc?.trimmingCharacters(in: .whitespacesAndNewlines) ?? ""

        let script = buildAppleScript(to: to, subject: subject, body: body, cc: cc)
        var error: NSDictionary?
        guard let appleScript = NSAppleScript(source: script) else {
            throw MailSendError.appleScriptFailed("No pude preparar el script de Mail.")
        }
        let result = appleScript.executeAndReturnError(&error)
        if let error {
            let msg = (error[NSAppleScript.errorMessage] as? String)
                ?? (error["NSAppleScriptErrorMessage"] as? String)
                ?? "Error de Automatización / Mail."
            throw MailSendError.appleScriptFailed(msg)
        }
        _ = result
        return "Correo enviado a \(to)."
    }

    private static func buildAppleScript(to: String, subject: String, body: String, cc: String) -> String {
        let toLit = appleStringLiteral(to)
        let subjectLit = appleStringLiteral(subject)
        let bodyLit = appleStringLiteral(body.hasSuffix("\n") ? body : body + "\n")
        var lines: [String] = []
        lines.append("tell application \"Mail\"")
        lines.append("  activate")
        lines.append("  set newMessage to make new outgoing message with properties {subject:\(subjectLit), content:\(bodyLit), visible:true}")
        lines.append("  tell newMessage")
        // Varios destinatarios separados por coma o punto y coma.
        for addr in splitAddresses(to) {
            let a = appleStringLiteral(addr)
            lines.append("    make new to recipient at end of to recipients with properties {address:\(a)}")
        }
        if !cc.isEmpty {
            for addr in splitAddresses(cc) {
                let a = appleStringLiteral(addr)
                lines.append("    make new cc recipient at end of cc recipients with properties {address:\(a)}")
            }
        }
        lines.append("  end tell")
        lines.append("  send newMessage")
        lines.append("end tell")
        return lines.joined(separator: "\n")
    }

    private static func splitAddresses(_ raw: String) -> [String] {
        raw
            .split(whereSeparator: { $0 == "," || $0 == ";" })
            .map { $0.trimmingCharacters(in: .whitespacesAndNewlines) }
            .filter { !$0.isEmpty }
    }

    /// Escapa para literal AppleScript entre comillas.
    private static func appleStringLiteral(_ value: String) -> String {
        var escaped = ""
        for ch in value {
            switch ch {
            case "\\": escaped += "\\\\"
            case "\"": escaped += "\\\""
            case "\n": escaped += "\\n"
            case "\r": escaped += "\\r"
            case "\t": escaped += "\\t"
            default: escaped.append(ch)
            }
        }
        return "\"\(escaped)\""
    }
}
