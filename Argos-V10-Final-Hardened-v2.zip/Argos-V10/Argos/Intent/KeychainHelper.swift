import Foundation
import Security

/// Almacena el API key de OpenAI en el Keychain de macOS.
/// Nunca hardcodear ni loguear la clave.
enum KeychainHelper {
    static let service = "com.danielrueda.Argos"
    static let openAIAccount = "openai_api_key"

    static func saveOpenAIKey(_ key: String) -> Bool {
        let trimmed = key.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmed.isEmpty else {
            _ = deleteOpenAIKey()
            return true
        }
        guard let data = trimmed.data(using: .utf8) else { return false }

        let query: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: service,
            kSecAttrAccount as String: openAIAccount
        ]
        SecItemDelete(query as CFDictionary)

        var add = query
        add[kSecValueData as String] = data
        add[kSecAttrAccessible as String] = kSecAttrAccessibleWhenUnlockedThisDeviceOnly
        let status = SecItemAdd(add as CFDictionary, nil)
        return status == errSecSuccess
    }

    static func loadOpenAIKey() -> String? {
        func load(serviceName: String) -> String? {
            let query: [String: Any] = [
                kSecClass as String: kSecClassGenericPassword,
                kSecAttrService as String: serviceName,
                kSecAttrAccount as String: openAIAccount,
                kSecReturnData as String: true,
                kSecMatchLimit as String: kSecMatchLimitOne
            ]
            var item: CFTypeRef?
            guard SecItemCopyMatching(query as CFDictionary, &item) == errSecSuccess,
                  let data = item as? Data,
                  let key = String(data: data, encoding: .utf8) else { return nil }
            let trimmed = key.trimmingCharacters(in: .whitespacesAndNewlines)
            return trimmed.isEmpty ? nil : trimmed
        }
        // No sondeamos el servicio de Keychain de V9 automáticamente: un cambio de
        // identidad de aplicación puede provocar un prompt de credenciales del sistema.
        // La clave se vuelve a guardar explícitamente en el servicio propio de Argos.
        return load(serviceName: service)
    }

    static func hasOpenAIKey() -> Bool {
        loadOpenAIKey() != nil
    }

    @discardableResult
    static func deleteOpenAIKey() -> Bool {
        let query: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: service,
            kSecAttrAccount as String: openAIAccount
        ]
        let status = SecItemDelete(query as CFDictionary)
        return status == errSecSuccess || status == errSecItemNotFound
    }
}
