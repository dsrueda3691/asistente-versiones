import Foundation

/// Confirmación unificada en el popover (Enviar/Confirmar + Cancelar).
enum PendingAction: Equatable {
    case mail(PendingMail)
    case integrationMail(ArgosIntegration, PendingMail)
    case whatsapp(PendingWhatsApp)
    case calendar(PendingCalendarEvent)
    case reminder(PendingReminder)
    case agent(PendingAgentPlan)

    var confirmButtonTitle: String {
        switch self {
        case .mail, .integrationMail, .whatsapp: return "Enviar"
        case .calendar, .reminder, .agent: return "Confirmar"
        }
    }

    var speakPrompt: String {
        switch self {
        case .mail(let m):
            let dest = m.to.trimmingCharacters(in: .whitespacesAndNewlines)
            let label = dest.isEmpty ? "(sin destinatario)" : dest
            return "Borrador listo para \(label). Confirma Enviar o Cancelar."
        case .integrationMail(let provider, let m):
            let dest = m.to.trimmingCharacters(in: .whitespacesAndNewlines)
            return "Borrador de \(provider.title) listo para \(dest.isEmpty ? "(sin destinatario)" : dest). Confirma Enviar o Cancelar."
        case .whatsapp(let w):
            return "Mensaje de WhatsApp listo para \(w.to). Confirma Enviar o Cancelar."
        case .calendar(let e):
            return "Evento listo: \(e.title). Confirma o Cancelar."
        case .reminder(let r):
            return "Recordatorio listo: \(r.title). Confirma o Cancelar."
        case .agent(let p):
            return "Plan de \(p.steps.count) paso\(p.steps.count == 1 ? "" : "s"). Confirma o Cancelar."
        }
    }

    var detailSummary: String {
        switch self {
        case .mail(let m): return m.summary
        case .integrationMail(let provider, let m): return "Servicio: \(provider.title)\n" + m.summary
        case .whatsapp(let w): return w.summary
        case .calendar(let e): return e.summary
        case .reminder(let r): return r.summary
        case .agent(let p): return p.summary
        }
    }

    var statusLabel: String {
        switch self {
        case .mail: return "Confirma correo"
        case .integrationMail(let provider, _): return "Confirma \(provider.title)"
        case .whatsapp: return "Confirma WhatsApp"
        case .calendar: return "Confirma evento"
        case .reminder: return "Confirma recordatorio"
        case .agent: return "Confirma plan"
        }
    }
}


struct PendingWhatsApp: Equatable {
    var to: String
    var body: String

    var summary: String {
        "Destinatario: \(to)\nMensaje: \(body)"
    }
}

struct PendingCalendarEvent: Equatable {
    var title: String
    var start: Date
    var end: Date
    var notes: String?
    var location: String?

    var summary: String {
        let f = DateFormatter()
        f.locale = Locale(identifier: "es_CO")
        f.dateStyle = .medium
        f.timeStyle = .short
        var lines = [
            "Título: \(title)",
            "Inicio: \(f.string(from: start))",
            "Fin: \(f.string(from: end))"
        ]
        if let location, !location.isEmpty { lines.append("Lugar: \(location)") }
        if let notes, !notes.isEmpty {
            let preview = notes.count > 200 ? String(notes.prefix(200)) + "…" : notes
            lines.append("Notas: \(preview)")
        }
        return lines.joined(separator: "\n")
    }
}

struct PendingReminder: Equatable {
    var title: String
    var due: Date?

    var summary: String {
        var lines = ["Título: \(title)"]
        if let due {
            let f = DateFormatter()
            f.locale = Locale(identifier: "es_CO")
            f.dateStyle = .medium
            f.timeStyle = .short
            lines.append("Vence: \(f.string(from: due))")
        } else {
            lines.append("Vence: (sin fecha)")
        }
        return lines.joined(separator: "\n")
    }
}

struct AgentStep: Equatable, Identifiable {
    var id: Int
    var kind: Kind
    var detail: String

    enum Kind: String, Equatable {
        case analyze
        case type
        case openApp
        case webSearch
        case readClipboard
        case copyDraft
        case saveDraft
        case openURL
    }

    var line: String {
        switch kind {
        case .analyze: return "\(id). Mirar: \(detail)"
        case .type: return "\(id). Escribir: \(detail)"
        case .openApp: return "\(id). Abrir: \(detail)"
        case .webSearch: return "\(id). Buscar: \(detail)"
        case .readClipboard: return "\(id). Leer portapapeles"
        case .copyDraft: return "\(id). Copiar borrador"
        case .saveDraft: return "\(id). Guardar borrador: \(detail)"
        case .openURL: return "\(id). Abrir URL: \(detail)"
        }
    }
}

struct PendingAgentPlan: Equatable {
    var goal: String
    var steps: [AgentStep]
    /// JPEG de la captura usada para planificar (no se persiste a disco).
    var screenJPEGBase64: String?
    /// Contexto adjunto consumido por el plan, retenido solo dentro de la acción pendiente.
    var contextText: String?
    var contextImageJPEGBase64: String?

    var summary: String {
        var lines = ["Objetivo: \(goal)", "Pasos (máx. 5):"]
        lines.append(contentsOf: steps.map(\.line))
        if let contextText, !contextText.isEmpty {
            lines.append("Contexto adjunto: \(String(contextText.prefix(600)))")
        } else if contextImageJPEGBase64 != nil {
            lines.append("Contexto adjunto: imagen")
        }
        lines.append("Tope: 5 pasos · ~3 min. Detener cancela. Sin borrar, shell ni envío de correo.")
        return lines.joined(separator: "\n")
    }
}
