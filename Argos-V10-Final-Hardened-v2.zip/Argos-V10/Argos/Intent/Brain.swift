import Foundation

/// Respuesta estructurada del LLM (local o nube).
struct BrainReply {
    let speak: String
    let detail: String?
    let intent: Intent?
    /// Backend que produjo la respuesta (para UI).
    var usedBackendLabel: String? = nil
}

/// Razona con el proveedor seleccionado solo cuando IntentParser no reconoce la frase.
/// El modelo puede pedir UNA acción del catálogo seguro de ActionRunner.
@MainActor
final class Brain {
    private let ollama: OllamaClient
    private let openAI: OpenAIClient

    init(ollama: OllamaClient = OllamaClient(), openAI: OpenAIClient = OpenAIClient()) {
        self.ollama = ollama
        self.openAI = openAI
    }

    var provider: BrainProvider { BrainProvider.current }

    /// Etiqueta corta para la interfaz: "Auto · Astra", "Local · llama3.2", etc.
    var modeLineLabel: String {
        let p = provider
        switch p {
        case .local:
            return "Local · \(ollama.displayModelName)"
        case .astra:
            return "Astra · \(openAI.displayModelName)"
        case .auto:
            if KeychainHelper.hasOpenAIKey() {
                return "Auto · Astra"
            }
            return "Auto · \(ollama.displayModelName)"
        }
    }

    var localModelName: String { ollama.displayModelName }
    var localVisionModelName: String { ollama.displayVisionModelName }
    var cloudModelName: String { openAI.displayModelName }

    func reason(phrase: String, context: String? = nil, history: [ChatMessage] = []) async -> BrainReply {
        let system = Self.systemPrompt
        var user = "Frase del usuario: \(phrase)"
        if let context, !context.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
            user += "\nContexto breve: \(context)"
        }
        user += "\nResponde SOLO con el JSON pedido. Habla corto en speak; pon ensayos/ideas largas en detail."

        do {
            let (raw, label) = try await runChat { backend in
                if history.isEmpty {
                    return try await backend.chat(system: system, user: user)
                }
                return try await backend.chat(system: system, history: history, user: user, forceJSON: true)
            }
            var reply = Self.parse(raw: raw, fallbackPhrase: phrase)
            reply.usedBackendLabel = label
            return reply
        } catch let err as BrainBackendError {
            return Self.fallback(for: err)
        } catch let err as OllamaError {
            return Self.fallback(for: err.asBrainError)
        } catch {
            return Self.fallback(for: .network)
        }
    }

    /// Pregunta sobre un documento/página ya leído (texto adjunto este turno).
    func askAboutDocument(phrase: String, sourceLabel: String, documentText: String, additionalContext: String? = nil, history: [ChatMessage] = []) async -> BrainReply {
        let system = Self.systemPrompt
        let clipped = String(documentText.prefix(12_000))
        var user = """
        El usuario pidió: \(phrase)
        Acabo de leer este documento/página (fuente: \(sourceLabel)). Úsalo como evidencia de archivo/página; no inventes que leíste otra cosa.
        --- DOCUMENTO ---
        \(clipped)
        --- FIN ---
        """
        if let additionalContext, !additionalContext.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
            user += "\nContexto adicional aportado por el usuario:\n" + String(additionalContext.prefix(8_000))
        }
        user += "\nResponde SOLO con el JSON pedido. speak = resumen breve; detail = respuesta larga / ensayo / explicación si aplica."
        do {
            let (raw, label) = try await runChat { backend in
                if history.isEmpty {
                    return try await backend.chat(system: system, user: user)
                }
                return try await backend.chat(system: system, history: history, user: user, forceJSON: true)
            }
            var reply = Self.parse(raw: raw, fallbackPhrase: phrase)
            reply.usedBackendLabel = label
            return reply
        } catch let err as BrainBackendError {
            return Self.fallback(for: err)
        } catch let err as OllamaError {
            return Self.fallback(for: err.asBrainError)
        } catch {
            return Self.fallback(for: .network)
        }
    }

    /// Visión on-demand: describe/responde sobre una captura JPEG (sin JSON de acciones).
    func analyzeScreen(question: String, imageJPEG: Data, additionalContext: String? = nil, history: [ChatMessage] = []) async -> BrainReply {
        let system = Self.visionSystemPrompt
        var user = """
        Pregunta del usuario sobre lo que hay en pantalla ahora:
        \(question)

        Responde en español colombiano, breve (1–3 oraciones), como si hablaras en voz alta.
        Describe solo lo necesario para responder. No inventes texto ilegible. No enumeres toda la UI.
        """
        if let additionalContext, !additionalContext.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
            user += "\n\nContexto adjunto del usuario:\n" + String(additionalContext.prefix(6_000))
        }
        if !history.isEmpty {
            // La visión suele ir sin historial multimodal; inyectamos resumen textual breve.
            let prior = history.suffix(6).map { "\($0.role): \($0.content)" }.joined(separator: "\n")
            user += "\n\nContexto de conversación reciente (texto):\n\(String(prior.prefix(2000)))"
        }
        do {
            let (raw, label) = try await runChat { backend in
                try await backend.chatVision(system: system, user: user, imageJPEG: imageJPEG)
            }
            let speak = String(raw.prefix(500)).trimmingCharacters(in: .whitespacesAndNewlines)
            return BrainReply(
                speak: speak.isEmpty ? "No pude interpretar la pantalla." : speak,
                detail: raw.count > 500 ? raw : nil,
                intent: nil,
                usedBackendLabel: label
            )
        } catch let err as BrainBackendError {
            return Self.visionFallback(for: err)
        } catch let err as OllamaError {
            return Self.visionFallback(for: err.asBrainError)
        } catch {
            return Self.visionFallback(for: .network)
        }
    }

    /// Genera texto libre usando visión cuando el plan necesita comprender un adjunto visual.
    func generatePlainTextVision(system: String, user: String, imageJPEG: Data) async throws -> String {
        let (raw, _) = try await runChat { backend in
            try await backend.chatVision(system: system, user: user, imageJPEG: imageJPEG)
        }
        return raw
    }

    /// Genera texto libre (keyboard job / borradores) con el proveedor activo.
    func generatePlainText(system: String, user: String, history: [ChatMessage] = []) async throws -> String {
        let (raw, _) = try await runChat { backend in
            if history.isEmpty {
                return try await backend.plainChat(system: system, user: user)
            }
            return try await backend.chat(system: system, history: history, user: user, forceJSON: false)
        }
        return raw
    }

    // MARK: - Provider routing

    private func runChat(_ work: (any LLMBackend) async throws -> String) async throws -> (String, String) {
        switch provider {
        case .local:
            do {
                let result = try await work(ollama)
                return (result, "Local · \(ollama.displayModelName)")
            } catch let err as OllamaError {
                throw err.asBrainError
            }

        case .astra:
            let result = try await work(openAI)
            return (result, "Astra · \(openAI.displayModelName)")

        case .auto:
            let hasKey = KeychainHelper.hasOpenAIKey()
            if hasKey {
                do {
                    let result = try await work(openAI)
                    return (result, "Auto · Astra")
                } catch let astraErr {
                    let astraMsg = (astraErr as? BrainBackendError)?.userMessage
                        ?? astraErr.localizedDescription
                    do {
                        let result = try await work(ollama)
                        return (result, "Auto · \(ollama.displayModelName)")
                    } catch let localErr {
                        let localMsg: String
                        if let o = localErr as? OllamaError {
                            localMsg = o.asBrainError.userMessage
                        } else if let b = localErr as? BrainBackendError {
                            localMsg = b.userMessage
                        } else {
                            localMsg = localErr.localizedDescription
                        }
                        throw BrainBackendError.bothFailed(astraMessage: astraMsg, localMessage: localMsg)
                    }
                }
            } else {
                do {
                    let result = try await work(ollama)
                    return (result, "Auto · \(ollama.displayModelName)")
                } catch let err as OllamaError {
                    throw err.asBrainError
                }
            }
        }
    }

    private static func fallback(for error: BrainBackendError) -> BrainReply {
        switch error {
        case .missingAPIKey:
            return BrainReply(
                speak: error.userMessage,
                detail: "Terminal: security add-generic-password -a openai_api_key -s com.danielrueda.Argos -w 'sk-...' -U\nO pégala en Ajustes (engranaje).",
                intent: nil
            )
        case .unauthorized, .rateLimited, .network, .badStatus, .bothFailed:
            return BrainReply(speak: error.userMessage, detail: nil, intent: nil)
        case .unreachableLocal:
            return BrainReply(
                speak: "Ollama no está corriendo o el modelo no está instalado. Los comandos con reglas siguen funcionando.",
                detail: "Instala Ollama, ejecuta `ollama pull \(OllamaClient.configuredModelName)` y déjalo abierto. Modelo: \(OllamaClient.configuredModelName).",
                intent: nil
            )
        case .emptyResponse, .decodeFailed:
            return BrainReply(
                speak: "El modelo no me dio una respuesta útil. Prueba otra vez o usa un comando conocido.",
                detail: nil,
                intent: nil
            )
        }
    }

    private static func visionFallback(for error: BrainBackendError) -> BrainReply {
        switch error {
        case .missingAPIKey:
            return BrainReply(
                speak: error.userMessage,
                detail: "Sin clave Astra, usa modo Local/Auto con Ollama visión (`ollama pull \(OllamaClient.configuredVisionModelName)`).",
                intent: nil
            )
        case .unreachableLocal:
            return BrainReply(
                speak: "No tengo el modelo de visión de Ollama. Instálalo con ollama pull \(OllamaClient.configuredVisionModelName).",
                detail: "Modelo de visión: \(OllamaClient.configuredVisionModelName) (UserDefaults `argos.ollamaVisionModel`). Ollama debe estar corriendo en localhost.",
                intent: nil
            )
        default:
            return BrainReply(speak: error.userMessage, detail: nil, intent: nil)
        }
    }

    private static func parse(raw: String, fallbackPhrase: String) -> BrainReply {
        let jsonText = extractJSONObject(from: raw) ?? raw
        guard let data = jsonText.data(using: .utf8),
              let obj = try? JSONSerialization.jsonObject(with: data) as? [String: Any] else {
            let speak = String(raw.prefix(280)).trimmingCharacters(in: .whitespacesAndNewlines)
            return BrainReply(
                speak: speak.isEmpty ? "No entendí. Prueba otra vez." : speak,
                detail: raw.count > 280 ? raw : nil,
                intent: nil
            )
        }

        let speak = (obj["speak"] as? String)?
            .trimmingCharacters(in: .whitespacesAndNewlines)
            ?? "Listo."
        let detail = (obj["detail"] as? String)?
            .trimmingCharacters(in: .whitespacesAndNewlines)
        let detailOrNil = (detail?.isEmpty == false) ? detail : nil

        let intent = mapAction(obj["action"])
        let safeSpeak = speak.isEmpty ? "Listo." : speak
        return BrainReply(speak: safeSpeak, detail: detailOrNil, intent: intent)
    }

    private static func extractJSONObject(from text: String) -> String? {
        guard let start = text.firstIndex(of: "{"),
              let end = text.lastIndex(of: "}"),
              start < end else { return nil }
        return String(text[start...end])
    }

    private static func mapAction(_ raw: Any?) -> Intent? {
        guard let dict = raw as? [String: Any] else { return nil }
        let type = ((dict["type"] as? String) ?? "")
            .trimmingCharacters(in: .whitespacesAndNewlines)
            .lowercased()
        if type.isEmpty { return nil }

        let args = dict["args"] as? [String: Any] ?? [:]

        switch type {
        case "greet":
            return .greet
        case "whoami", "who_am_i":
            return .whoAmI
        case "help":
            return .help
        case "time":
            return .time
        case "date":
            return .date
        case "listdesktop", "list_desktop":
            return .listDesktop
        case "readclipboard", "read_clipboard":
            return .readClipboard
        case "quit":
            return .quit
        case "analyzescreen", "analyze_screen", "lookatscreen", "look_at_screen", "screen":
            let question = stringArg(args, keys: ["question", "query", "q", "text", "prompt"]) ?? "¿Qué hay en pantalla?"
            let q = question.trimmingCharacters(in: .whitespacesAndNewlines)
            return .analyzeScreen(question: q.isEmpty ? "¿Qué hay en pantalla?" : q)
        case "keyboardjob", "keyboard_job", "type", "typing", "usekeyboard", "use_keyboard":
            let instruction = stringArg(args, keys: ["instruction", "task", "text", "prompt", "content"]) ?? ""
            let i = instruction.trimmingCharacters(in: .whitespacesAndNewlines)
            guard !i.isEmpty else { return nil }
            return .keyboardJob(instruction: i)
        case "websearch", "web_search":
            let query = stringArg(args, keys: ["query", "q", "text"]) ?? ""
            let q = query.trimmingCharacters(in: .whitespacesAndNewlines)
            guard !q.isEmpty else { return nil }
            return .webSearch(query: q)
        case "openapp", "open_app":
            return mapOpenApp(args)
        case "createfile", "create_file":
            let name = stringArg(args, keys: ["name", "filename", "file"]) ?? "nota-argos"
            let contents = stringArg(args, keys: ["contents", "content", "text", "body"]) ?? "Creado por Argos.\n"
            return .createFile(name: name, contents: contents)
        case "copytemplate", "copy_template":
            let kind = (stringArg(args, keys: ["kind", "template", "name"]) ?? "landing")
                .lowercased()
            if kind.contains("nav") {
                return .copyTemplate(.navbarHTML)
            }
            return .copyTemplate(.landingHTML)
        case "composemail", "compose_mail", "sendmail", "send_mail", "email", "mail":
            let to = stringArg(args, keys: ["to", "recipient", "email", "address", "para"]) ?? ""
            let subject = stringArg(args, keys: ["subject", "asunto", "title"]) ?? ""
            let body = stringArg(args, keys: ["body", "content", "contents", "text", "message", "cuerpo"]) ?? ""
            let ccRaw = stringArg(args, keys: ["cc", "copia", "copy"])
            let cc = ccRaw?.trimmingCharacters(in: .whitespacesAndNewlines)
            return .composeMail(
                to: to.trimmingCharacters(in: .whitespacesAndNewlines),
                subject: subject.trimmingCharacters(in: .whitespacesAndNewlines),
                body: body,
                cc: (cc?.isEmpty == false) ? cc : nil
            )
        case "createcalendarevent", "create_calendar_event", "calendarevent", "calendar_event", "event":
            let title = stringArg(args, keys: ["title", "name", "titulo"]) ?? "Evento"
            let startHint = stringArg(args, keys: ["start", "startHint", "when", "inicio", "startISO"]) ?? ""
            let endHint = stringArg(args, keys: ["end", "endHint", "fin", "endISO"]) ?? ""
            let notes = stringArg(args, keys: ["notes", "note", "notas"])
            let location = stringArg(args, keys: ["location", "lugar", "ubicacion"])
            return .createCalendarEvent(
                title: title.trimmingCharacters(in: .whitespacesAndNewlines),
                startHint: startHint,
                endHint: endHint,
                notes: notes,
                location: location
            )
        case "createreminder", "create_reminder", "reminder":
            let title = stringArg(args, keys: ["title", "name", "text", "titulo"]) ?? "Recordatorio"
            let due = stringArg(args, keys: ["due", "dueHint", "when", "fecha"])
            return .createReminder(title: title.trimmingCharacters(in: .whitespacesAndNewlines), dueHint: due)
        case "listreminders", "list_reminders":
            return .listReminders
        case "createnote", "create_note", "note":
            let title = stringArg(args, keys: ["title", "name", "titulo"]) ?? "Nota Argos"
            let body = stringArg(args, keys: ["body", "content", "text", "cuerpo"]) ?? ""
            return .createNote(title: title.trimmingCharacters(in: .whitespacesAndNewlines), body: body)
        case "agentmode", "agent_mode", "agent", "shortagent", "short_agent":
            let goal = stringArg(args, keys: ["goal", "task", "instruction", "objetivo", "text"]) ?? ""
            let g = goal.trimmingCharacters(in: .whitespacesAndNewlines)
            guard !g.isEmpty else { return nil }
            return .agentMode(goal: g)
        default:
            return nil
        }
    }

    private static func mapOpenApp(_ args: [String: Any]) -> Intent? {
        let rawName = stringArg(args, keys: ["name", "app", "displayName", "display"]) ?? ""
        let name = rawName
            .folding(options: [.diacriticInsensitive, .caseInsensitive], locale: Locale(identifier: "es"))
            .lowercased()
        let bundle = (stringArg(args, keys: ["bundleID", "bundle", "bundleId"]) ?? "").lowercased()

        for app in knownApps {
            if !bundle.isEmpty, app.bundle.lowercased() == bundle {
                return .openApp(bundleID: app.bundle, displayName: app.display)
            }
            if !name.isEmpty {
                if app.display.folding(options: [.diacriticInsensitive, .caseInsensitive], locale: Locale(identifier: "es"))
                    .lowercased()
                    .contains(name) || name.contains(app.display.lowercased()) {
                    return .openApp(bundleID: app.bundle, displayName: app.display)
                }
                for alias in app.aliases where name.contains(alias) || alias.contains(name) {
                    return .openApp(bundleID: app.bundle, displayName: app.display)
                }
            }
        }
        // V7: cualquier app por nombre (ActionRunner resuelve).
        let display = rawName.trimmingCharacters(in: .whitespacesAndNewlines)
        if !display.isEmpty {
            return .openApp(bundleID: "", displayName: display)
        }
        return nil
    }

    private static func stringArg(_ args: [String: Any], keys: [String]) -> String? {
        for key in keys {
            if let s = args[key] as? String { return s }
            if let n = args[key] as? NSNumber { return n.stringValue }
        }
        return nil
    }

    private static let knownApps: [(aliases: [String], bundle: String, display: String)] = [
        (["safari"], "com.apple.Safari", "Safari"),
        (["finder"], "com.apple.finder", "Finder"),
        (["notas", "notes"], "com.apple.Notes", "Notas"),
        (["mail", "correo"], "com.apple.mail", "Mail"),
        (["calendario", "calendar"], "com.apple.iCal", "Calendario"),
        (["terminal"], "com.apple.Terminal", "Terminal"),
        (["ajustes", "preferencias", "system settings", "configuracion"], "com.apple.systempreferences", "Ajustes del Sistema"),
        (["xcode"], "com.apple.dt.Xcode", "Xcode"),
        (["pages"], "com.apple.iWork.Pages", "Pages"),
        (["cursor"], "com.todesktop.230313mzl4w4u92", "Cursor")
    ]

    static let systemPrompt = """
    Eres Argos, asistente local de Daniel Rueda Mier (estudiante, Colombia). Estilo FRIDAY (MCU): femenina, seca, breve, competente. Español colombiano natural.
    Ayudas con ideas, how-to, documentos, ensayos y seguimiento de conversación. No inventes citas ni fuentes. Nunca digas que viste la pantalla o leíste un archivo salvo que este turno traiga captura o texto de documento adjunto.
    Respuestas para voz: máximo ~2 oraciones en "speak". Sin relleno. "detail" puede ser largo (ensayo, ideas, código) — la UI y lastDraft lo usan.
    Si el usuario dice «ahora más formal», «esa idea 3», «cámbiale el título», «el cierre», usa el historial / borrador previo.
    No inventes acciones peligrosas. Nunca pidas shell ni borrar archivos. Nunca digas que ya enviaste un correo: composeMail solo prepara borrador.
    Si pide mirar pantalla → analyzeScreen. Teclado explícito → keyboardJob. Correo → composeMail. Evento → createCalendarEvent. Recordatorio → createReminder / listReminders. Nota → createNote. Agente corto → agentMode.
    Abrir app (cualquier nombre) → openApp con {"name":"…"}.
    Responde ÚNICAMENTE con JSON válido (sin markdown):
    {"speak":"...","detail":"...opcional o null","action":null}
    O con una sola acción segura:
    {"speak":"...","detail":null,"action":{"type":"TIPO","args":{...}}}

    Tipos de action permitidos (uno solo, o null):
    - greet | whoAmI | help | time | date | listDesktop | readClipboard | quit  (args vacíos {})
    - analyzeScreen args: {"question":"..."}
    - keyboardJob args: {"instruction":"..."}
    - composeMail args: {"to":"...","subject":"...","body":"...","cc":"...opcional"}
    - createCalendarEvent args: {"title":"...","start":"...","end":"...","notes":null,"location":null}
    - createReminder args: {"title":"...","due":"...opcional"}
    - listReminders args: {}
    - createNote args: {"title":"...","body":"..."}
    - agentMode args: {"goal":"..."}
    - webSearch  args: {"query":"..."}
    - openApp    args: {"name":"Safari|Xcode|Cursor|Pages|…"} (cualquier app por nombre)
    - createFile args: {"name":"...","contents":"..."}
    - copyTemplate args: {"kind":"landing"|"navbar"}

    Si solo conversas, action=null. Si no estás seguro, action=null y habla.
    """

    static let visionSystemPrompt = """
    Eres Argos, asistente estilo FRIDAY (MCU): femenina, seca, breve, competente. Español colombiano.
    Te pasan UNA captura de pantalla tomada justo ahora porque el usuario te pidió mirar.
    Responde solo lo necesario para contestar su pregunta. No vuelques toda la interfaz. No inventes texto que no puedas leer.
    Si hay contexto de conversación, úsalo para follow-ups («esa idea», «más formal») sin inventar lo que no se ve.
    Respuesta hablada: 1 a 3 oraciones. Sin markdown innecesario.
    """
}
