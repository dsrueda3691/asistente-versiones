import Foundation
import EventKit

enum RemindersServiceError: Error, LocalizedError {
    case accessDenied
    case saveFailed(String)

    var errorDescription: String? { userMessage }
    var userMessage: String {
        switch self {
        case .accessDenied:
            return "Necesito acceso a Recordatorios. Actívalo en Ajustes → Privacidad y seguridad → Recordatorios."
        case .saveFailed(let m):
            return "No pude crear el recordatorio. \(m)"
        }
    }
}

enum RemindersService {
    private static let store = EKEventStore()

    static func requestAccess() async throws {
        let granted: Bool
        if #available(macOS 14.0, *) {
            granted = try await store.requestFullAccessToReminders()
        } else {
            granted = try await store.requestAccess(to: .reminder)
        }
        guard granted else { throw RemindersServiceError.accessDenied }
    }

    /// Solo tras confirmación.
    static func createReminder(_ pending: PendingReminder) async throws -> String {
        try await requestAccess()
        let reminder = EKReminder(eventStore: store)
        reminder.title = pending.title
        if let due = pending.due {
            reminder.dueDateComponents = Calendar.current.dateComponents(
                [.year, .month, .day, .hour, .minute], from: due
            )
        }
        guard let cal = store.defaultCalendarForNewReminders() else {
            throw RemindersServiceError.saveFailed("No hay lista de recordatorios por defecto.")
        }
        reminder.calendar = cal
        do {
            try store.save(reminder, commit: true)
        } catch {
            throw RemindersServiceError.saveFailed(error.localizedDescription)
        }
        return "Recordatorio creado: \(pending.title)."
    }

    /// Lectura inmediata (sin confirmación).
    static func listUpcoming(limit: Int = 8) async throws -> (spoken: String, detail: String) {
        try await requestAccess()
        let cal = Calendar.current
        let start = cal.startOfDay(for: Date())
        let end = cal.date(byAdding: .day, value: 14, to: start) ?? start.addingTimeInterval(14 * 86400)
        let predicate = store.predicateForIncompleteReminders(
            withDueDateStarting: start,
            ending: end,
            calendars: nil
        )
        let items: [EKReminder] = await withCheckedContinuation { cont in
            store.fetchReminders(matching: predicate) { reminders in
                cont.resume(returning: reminders ?? [])
            }
        }
        let sorted = items.sorted { a, b in
            let da = a.dueDateComponents.flatMap { Calendar.current.date(from: $0) } ?? .distantFuture
            let db = b.dueDateComponents.flatMap { Calendar.current.date(from: $0) } ?? .distantFuture
            return da < db
        }
        let slice = Array(sorted.prefix(limit))
        if slice.isEmpty {
            return ("No hay recordatorios próximos.", "")
        }
        let f = DateFormatter()
        f.locale = Locale(identifier: "es_CO")
        f.dateStyle = .short
        f.timeStyle = .short
        let lines: [String] = slice.map { r in
            let due = r.dueDateComponents.flatMap { Calendar.current.date(from: $0) }
            let dueText = due.map { f.string(from: $0) } ?? "sin fecha"
            return "• \(r.title ?? "(sin título)") — \(dueText)"
        }
        let spokenTitles = slice.prefix(3).compactMap(\.title).joined(separator: ", ")
        let spoken = "\(slice.count) recordatorio\(slice.count == 1 ? "" : "s") próximos. Entre ellos: \(spokenTitles)."
        return (spoken, lines.joined(separator: "\n"))
    }
}
