import Foundation
import AppKit
import ApplicationServices
import CoreGraphics

enum KeyboardError: Error, LocalizedError {
    case notTrusted
    case cancelled
    case secureField
    case emptyContent
    case limitExceeded

    var userMessage: String {
        switch self {
        case .notTrusted:
            return "Necesito Accesibilidad para usar el teclado. Actívala en Ajustes."
        case .cancelled:
            return "Trabajo de teclado cancelado."
        case .secureField:
            return "Hay un campo de contraseña al frente. No escribo ahí."
        case .emptyContent:
            return "No generé texto para escribir."
        case .limitExceeded:
            return "Llegué al tope de tiempo o de caracteres. Paré."
        }
    }

    var errorDescription: String? { userMessage }
}

/// Escribe en la app de adelante solo bajo pedido. Sin keylogging. Sin campos seguros.
@MainActor
final class KeyboardController {
    static let maxCharacters = 12_000
    static let maxDuration: TimeInterval = 10 * 60

    private(set) var isRunning = false
    private var cancelRequested = false

    var onProgress: ((String) -> Void)?

    static func isTrusted(prompt: Bool) -> Bool {
        let opts = [kAXTrustedCheckOptionPrompt.takeUnretainedValue() as String: prompt] as CFDictionary
        return AXIsProcessTrustedWithOptions(opts)
    }

    func cancel() {
        cancelRequested = true
    }

    /// Pega texto ya conocido (export «pégalo») vía portapapeles + Cmd+V. Respeta campo seguro.
    func pasteExistingText(_ text: String) async throws -> (spoken: String, detail: String) {
        cancelRequested = false
        guard Self.isTrusted(prompt: true) else {
            throw KeyboardError.notTrusted
        }
        if isSecureFocused() {
            throw KeyboardError.secureField
        }
        let cleaned = Self.sanitize(text)
        guard !cleaned.isEmpty else { throw KeyboardError.emptyContent }
        // Rechazo suave de payloads tipo contraseña (heurística).
        if Self.looksLikePasswordPayload(cleaned) {
            throw KeyboardError.secureField
        }
        isRunning = true
        defer { isRunning = false }
        let appName = frontmostAppName()
        onProgress?("Pegando en \(appName)…")
        let clipped = String(cleaned.prefix(Self.maxCharacters))
        let start = Date()
        try await pasteText(clipped, startedAt: start)
        let detail = "App: \(appName)\nCaracteres: \(clipped.count)\n\n\(clipped)"
        return (spoken: "Listo. Pegué el borrador en \(appName).", detail: detail)
    }

    static func looksLikePasswordPayload(_ text: String) -> Bool {
        let t = text.trimmingCharacters(in: .whitespacesAndNewlines)
        if t.count < 6 || t.count > 128 { return false }
        if t.contains(" ") || t.contains("\n") { return false }
        let lower = t.lowercased()
        if lower.hasPrefix("password") || lower.hasPrefix("passwd") || lower.hasPrefix("secret=") { return true }
        // Una sola “palabra” con mezcla rara típica de secretos pegados solos.
        let hasLetter = t.unicodeScalars.contains { CharacterSet.letters.contains($0) }
        let hasDigit = t.unicodeScalars.contains { CharacterSet.decimalDigits.contains($0) }
        let hasSym = t.unicodeScalars.contains { CharacterSet.punctuationCharacters.union(.symbols).contains($0) }
        return hasLetter && hasDigit && hasSym && t.count >= 10 && t.count <= 64
    }

    func frontmostAppName() -> String {
        NSWorkspace.shared.frontmostApplication?.localizedName ?? "la app de adelante"
    }

    /// Genera contenido con el closure y lo pega/escribe en la app frontal.
    func runJob(
        instruction: String,
        generate: (String) async throws -> String
    ) async throws -> (spoken: String, detail: String) {
        cancelRequested = false
        guard Self.isTrusted(prompt: true) else {
            throw KeyboardError.notTrusted
        }
        if isSecureFocused() {
            throw KeyboardError.secureField
        }

        isRunning = true
        defer { isRunning = false }

        let appName = frontmostAppName()
        onProgress?("Preparando texto para \(appName)…")
        let raw = try await generate(instruction)
        let text = Self.sanitize(raw)
        guard !text.isEmpty else { throw KeyboardError.emptyContent }

        let clipped = String(text.prefix(Self.maxCharacters))
        if cancelRequested { throw KeyboardError.cancelled }
        if isSecureFocused() { throw KeyboardError.secureField }

        onProgress?("Escribiendo en \(appName)…")
        let start = Date()
        try await pasteText(clipped, startedAt: start)

        if cancelRequested { throw KeyboardError.cancelled }
        let detail = "App: \(appName)\nCaracteres: \(clipped.count)\n\n\(clipped)"
        return (
            spoken: "Listo. Escribí en \(appName).",
            detail: detail
        )
    }

    private func pasteText(_ text: String, startedAt: Date) async throws {
        // Chunk by paragraphs for long text; paste via clipboard + Cmd+V (más fiable que Unicode event a event).
        let chunks = Self.chunk(text, maxChunk: 1800)
        let previous = NSPasteboard.general.string(forType: .string)
        defer {
            NSPasteboard.general.clearContents()
            if let previous {
                NSPasteboard.general.setString(previous, forType: .string)
            }
        }

        for (index, chunk) in chunks.enumerated() {
            if cancelRequested { throw KeyboardError.cancelled }
            if Date().timeIntervalSince(startedAt) > Self.maxDuration {
                throw KeyboardError.limitExceeded
            }
            if isSecureFocused() { throw KeyboardError.secureField }

            NSPasteboard.general.clearContents()
            NSPasteboard.general.setString(chunk, forType: .string)
            try await Task.sleep(nanoseconds: 120_000_000)
            postCommandV()
            onProgress?("Escribiendo… \(index + 1)/\(chunks.count)")
            try await Task.sleep(nanoseconds: 280_000_000)
        }
    }

    private func postCommandV() {
        let source = CGEventSource(stateID: .hidSystemState)
        let keyV: CGKeyCode = 9 // kVK_ANSI_V
        let down = CGEvent(keyboardEventSource: source, virtualKey: keyV, keyDown: true)
        let up = CGEvent(keyboardEventSource: source, virtualKey: keyV, keyDown: false)
        down?.flags = .maskCommand
        up?.flags = .maskCommand
        down?.post(tap: .cghidEventTap)
        up?.post(tap: .cghidEventTap)
    }

    private func isSecureFocused() -> Bool {
        let system = AXUIElementCreateSystemWide()
        var focused: CFTypeRef?
        guard AXUIElementCopyAttributeValue(system, kAXFocusedUIElementAttribute as CFString, &focused) == .success,
              let el = focused else {
            return false
        }
        let element = el as! AXUIElement
        var role: CFTypeRef?
        if AXUIElementCopyAttributeValue(element, kAXRoleAttribute as CFString, &role) == .success,
           let roleStr = role as? String,
           roleStr == (kAXSecureTextFieldRole as String) {
            return true
        }
        var subrole: CFTypeRef?
        if AXUIElementCopyAttributeValue(element, kAXSubroleAttribute as CFString, &subrole) == .success,
           let sub = subrole as? String,
           sub.lowercased().contains("secure") {
            return true
        }
        return false
    }

    static func sanitize(_ text: String) -> String {
        text.trimmingCharacters(in: .whitespacesAndNewlines)
    }

    static func chunk(_ text: String, maxChunk: Int) -> [String] {
        guard text.count > maxChunk else { return [text] }
        var result: [String] = []
        var current = ""
        for paragraph in text.components(separatedBy: "\n") {
            let piece = paragraph + "\n"
            if current.count + piece.count > maxChunk, !current.isEmpty {
                result.append(current)
                current = piece
            } else {
                current += piece
            }
        }
        if !current.isEmpty { result.append(current) }
        return result
    }
}
