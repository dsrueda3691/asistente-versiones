import Foundation
import AppKit

enum NotesServiceError: Error, LocalizedError {
    case appleScriptFailed(String)
    case emptyTitle

    var errorDescription: String? { userMessage }
    var userMessage: String {
        switch self {
        case .emptyTitle:
            return "Falta el título de la nota."
        case .appleScriptFailed(let m):
            let t = m.trimmingCharacters(in: .whitespacesAndNewlines)
            if t.isEmpty {
                return "No pude crear la nota. Revisa Automatización → Notas en Privacidad y seguridad."
            }
            return "No pude crear la nota. \(t)"
        }
    }
}

/// Crea notas en Apple Notes vía AppleScript (inmediato; riesgo bajo).
enum NotesService {
    static func createNote(title: String, body: String) throws -> String {
        let t = title.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !t.isEmpty else { throw NotesServiceError.emptyTitle }
        let b = body.trimmingCharacters(in: .whitespacesAndNewlines)
        let bodyHTML: String
        if b.isEmpty {
            bodyHTML = "<h1>\(escapeHTML(t))</h1>"
        } else {
            let paras = b
                .components(separatedBy: "\n")
                .map { "<p>\(escapeHTML($0))</p>" }
                .joined()
            bodyHTML = "<h1>\(escapeHTML(t))</h1>\(paras)"
        }

        let script = """
        tell application "Notes"
          activate
          tell account 1
            make new note with properties {name:\(appleString(t)), body:\(appleString(bodyHTML))}
          end tell
        end tell
        """
        var error: NSDictionary?
        guard let appleScript = NSAppleScript(source: script) else {
            throw NotesServiceError.appleScriptFailed("No pude preparar el script de Notas.")
        }
        _ = appleScript.executeAndReturnError(&error)
        if let error {
            let msg = (error[NSAppleScript.errorMessage] as? String)
                ?? (error["NSAppleScriptErrorMessage"] as? String)
                ?? "Error de Automatización / Notas."
            throw NotesServiceError.appleScriptFailed(msg)
        }
        return "Nota creada: \(t)."
    }

    private static func escapeHTML(_ s: String) -> String {
        s.replacingOccurrences(of: "&", with: "&amp;")
            .replacingOccurrences(of: "<", with: "&lt;")
            .replacingOccurrences(of: ">", with: "&gt;")
            .replacingOccurrences(of: "\"", with: "&quot;")
    }

    private static func appleString(_ value: String) -> String {
        var escaped = ""
        for ch in value {
            switch ch {
            case "\\": escaped += "\\\\"
            case "\"": escaped += "\\\""
            case "\n": escaped += "\\n"
            case "\r": escaped += "\\r"
            case "\t": escaped += "\\t"
            default: escaped.append(ch)
            }
        }
        return "\"\(escaped)\""
    }
}
