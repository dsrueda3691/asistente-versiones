import Foundation
import SwiftUI

@MainActor
final class ArgosRuntimeState: ObservableObject {
    enum Presentation: Equatable { case hidden, compact, expanded }
    enum Activity: Equatable { case idle, listening, thinking, working, waitingApproval, speaking, success, error }

    struct ContextAttachment: Identifiable, Equatable {
        enum Kind: String { case text, image, audio, video, window }
        let id: UUID
        let name: String
        let kind: Kind
        var detail: String?
    }

    struct ChatTurn: Identifiable, Equatable {
        let id = UUID()
        let role: String
        let content: String
    }

    @Published var presentation: Presentation = .hidden
    @Published var activity: Activity = .idle
    @Published var activityMessage = "Listo"
    @Published var agentSteps: [AgentStep] = []
    @Published var activeAgentStep: Int = 0
    @Published var completedAgentSteps: Set<Int> = []
    @Published var failedAgentStep: Int?
    @Published var contextLabel: String?
    @Published var contextText: String?
    @Published var contextAttachments: [ContextAttachment] = []
    @Published var isFileDropTargeted = false
    @Published var isDraggingCharacter = false
    @Published var lastWindowContext: WindowContext?
    @Published var chatTurns: [ChatTurn] = []
    @Published var isHoveringNotch = false

    func beginPlan(_ plan: PendingAgentPlan) {
        agentSteps = plan.steps
        activeAgentStep = plan.steps.first?.id ?? 0
        completedAgentSteps = []
        failedAgentStep = nil
        activity = .waitingApproval
        activityMessage = "Plan preparado"
    }

    func consumeProgress(_ message: String) {
        activityMessage = message
        activity = .working
        if let range = message.range(of: #"Paso\s+(\d+)\s+de\s+(\d+)"#, options: .regularExpression) {
            let fragment = String(message[range])
            let numbers = fragment.split(whereSeparator: { !$0.isNumber }).compactMap { Int($0) }
            if let current = numbers.first {
                activeAgentStep = current
                if current > 1 { completedAgentSteps.formUnion(1..<current) }
            }
        }
    }

    func markSuccess(_ message: String) {
        activity = .success
        activityMessage = message
        if !agentSteps.isEmpty { completedAgentSteps = Set(agentSteps.map(\.id)) }
        activeAgentStep = 0
        failedAgentStep = nil
    }

    func markError(_ message: String) {
        activity = .error
        activityMessage = message
        if activeAgentStep > 0 { failedAgentStep = activeAgentStep }
    }

    func markCancelled(_ message: String = "Cancelado") {
        activity = .idle
        activityMessage = message
        failedAgentStep = nil
    }

    func resetActivity() {
        activity = .idle
        activityMessage = "Listo"
        activeAgentStep = 0
        failedAgentStep = nil
    }

    func addAttachment(name: String, kind: ContextAttachment.Kind, detail: String? = nil) {
        let normalized = name.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !normalized.isEmpty else { return }
        contextAttachments.removeAll { $0.name.caseInsensitiveCompare(normalized) == .orderedSame }
        contextAttachments.append(ContextAttachment(id: UUID(), name: normalized, kind: kind, detail: detail))
        if contextAttachments.count > 8 { contextAttachments.removeFirst(contextAttachments.count - 8) }
    }

    func removeAttachment(id: UUID) {
        contextAttachments.removeAll { $0.id == id }
        let text = contextAttachments.compactMap(\.detail).filter { !$0.isEmpty }.joined(separator: "\n\n")
        contextText = text.isEmpty ? nil : text
        contextLabel = contextAttachments.last?.name
        if contextAttachments.isEmpty { lastWindowContext = nil }
    }

    func clearAttachments() {
        contextAttachments.removeAll()
        contextLabel = nil
        contextText = nil
        lastWindowContext = nil
    }

    /// Devuelve una instantánea del contexto para que una operación pueda consumirlo
    /// sin depender de estado global que quede pegado a las siguientes preguntas.
    func contextSnapshot() -> (label: String?, text: String?) {
        (contextLabel, contextText)
    }

    func syncHistory(from memory: ConversationMemory) {
        chatTurns = memory.chatMessages().suffix(16).map { ChatTurn(role: $0.role, content: $0.content) }
    }
}

extension ArgosRuntimeState.Activity {
    var title: String {
        switch self {
        case .idle: return "Reposo"
        case .listening: return "Escuchando"
        case .thinking: return "Pensando"
        case .working: return "Trabajando"
        case .waitingApproval: return "Aprobación"
        case .speaking: return "Hablando"
        case .success: return "Completado"
        case .error: return "Error"
        }
    }

    var symbol: String {
        switch self {
        case .idle: return "circle"
        case .listening: return "waveform"
        case .thinking: return "sparkles"
        case .working: return "bolt.horizontal"
        case .waitingApproval: return "checkmark.shield"
        case .speaking: return "waveform"
        case .success: return "checkmark.circle.fill"
        case .error: return "exclamationmark.triangle.fill"
        }
    }
}
