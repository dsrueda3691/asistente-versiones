import SwiftUI

struct ArgosAgentActivityView: View {
    @ObservedObject var runtime: ArgosRuntimeState

    private var total: Int { runtime.agentSteps.count }
    private var current: Int {
        if total == 0 { return 0 }
        if runtime.activity == .success { return total }
        return max(1, runtime.activeAgentStep)
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 9) {
            HStack(alignment: .firstTextBaseline) {
                Label("Actividad del agente", systemImage: "bolt.fill")
                    .font(.headline)
                Spacer()
                if total > 0 {
                    Text("Paso \(current)/\(total)")
                        .font(.caption.monospacedDigit())
                        .foregroundStyle(.secondary)
                }
            }

            if total > 0 {
                GeometryReader { proxy in
                    Capsule().fill(Color.white.opacity(0.08)).overlay(alignment: .leading) {
                        Capsule().fill(Color.purple.opacity(0.85)).frame(width: proxy.size.width * CGFloat(current) / CGFloat(total))
                    }
                }
                .frame(height: 4)
            }

            ForEach(runtime.agentSteps) { step in
                let done = runtime.completedAgentSteps.contains(step.id) || (runtime.activity == .success && step.id <= current)
                let active = runtime.activeAgentStep == step.id && runtime.activity == .working && runtime.failedAgentStep == nil
                let failed = runtime.failedAgentStep == step.id
                HStack(alignment: .top, spacing: 9) {
                    Text(failed ? "✗" : done ? "✓" : active ? "●" : "○")
                        .font(.system(size: 12, weight: .bold, design: .monospaced))
                        .foregroundStyle(failed ? .red : done ? .green : active ? .purple : .secondary)
                        .frame(width: 16)
                    Text(step.line)
                        .font(.caption)
                        .lineLimit(3)
                        .foregroundStyle(failed ? .red : .primary)
                }
            }

            Text(runtime.activityMessage)
                .font(.caption2)
                .foregroundStyle(.secondary)
        }
        .padding(12)
        .background(.white.opacity(0.055), in: RoundedRectangle(cornerRadius: 14, style: .continuous))
    }
}
