import SwiftUI
import AppKit

/// Personaje original de Argos inspirado en la silueta Cresta del proyecto.
/// La cabeza, la melena y los ojos se construyen con Paths, no con óvalos genéricos.
struct ArgosCharacterView: View {
    let activity: ArgosRuntimeState.Activity
    let compact: Bool
    let onDragChanged: () -> Void
    let onDragEnded: () -> Void

    @State private var dragging = false

    private var accent: Color {
        switch activity {
        case .idle: return Color(red: 0.64, green: 0.47, blue: 1.0)
        case .listening: return Color(red: 0.34, green: 0.92, blue: 0.72)
        case .thinking: return Color(red: 1.0, green: 0.72, blue: 0.22)
        case .working: return Color(red: 0.34, green: 0.68, blue: 1.0)
        case .waitingApproval: return Color(red: 0.68, green: 0.48, blue: 1.0)
        case .speaking: return Color(red: 0.45, green: 0.82, blue: 1.0)
        case .success: return Color(red: 0.38, green: 0.94, blue: 0.55)
        case .error: return Color(red: 1.0, green: 0.32, blue: 0.42)
        }
    }

    var body: some View {
        TimelineView(.animation(minimumInterval: 1.0 / 60.0, paused: false)) { timeline in
            Canvas { context, size in
                let t = timeline.date.timeIntervalSinceReferenceDate
                let scale: CGFloat = compact ? 0.68 : 1.0
                let cx = size.width * 0.5
                let cy = size.height * (compact ? 0.47 : 0.48)
                let s = min(size.width, size.height) * 0.38 * scale
                let bob = CGFloat(sin(t * (activity == .working ? 5.0 : 1.7))) * (activity == .working ? 2.0 : 0.7)
                let blink = t.truncatingRemainder(dividingBy: 5.2) > 4.96
                let pulse = CGFloat((sin(t * 2.4) + 1) * 0.5)

                if !compact {
                    let aura = Path(ellipseIn: CGRect(x: cx - s * 1.28, y: cy - s * 1.30, width: s * 2.56, height: s * 2.56))
                    context.stroke(aura, with: .color(accent.opacity(0.12)), style: StrokeStyle(lineWidth: 1, dash: [5, 9]))
                    drawParticles(&context, cx: cx, cy: cy, s: s, time: t)
                }

                drawSmoke(&context, cx: cx, cy: cy, s: s, time: t)
                drawBody(&context, cx: cx, cy: cy, s: s, bob: bob)
                drawHead(&context, cx: cx, cy: cy, s: s, bob: bob)
                drawGem(&context, cx: cx, cy: cy, s: s, bob: bob)
                drawWhiskers(&context, cx: cx, cy: cy, s: s, bob: bob)

                let mouse = NSEvent.mouseLocation
                let horizontal = max(-1.0, min(1.0, (mouse.x - (NSScreen.main?.frame.midX ?? mouse.x)) / 500.0))
                let vertical = max(-1.0, min(1.0, (mouse.y - (NSScreen.main?.frame.midY ?? mouse.y)) / 400.0))
                let lookX = CGFloat(horizontal) * s * 0.06
                let lookY = CGFloat(vertical) * s * 0.03
                let eyeY = cy - s * 0.02 + bob + lookY

                if !blink {
                    drawEye(&context, center: CGPoint(x: cx - s * 0.31 + lookX, y: eyeY), width: s * 0.43, height: s * 0.17, tilt: activity == .error ? 0.13 : 0)
                    drawEye(&context, center: CGPoint(x: cx + s * 0.31 + lookX, y: eyeY), width: s * 0.43, height: s * 0.17, tilt: activity == .error ? -0.13 : 0)
                } else {
                    let blinkPath = Path { p in
                        p.move(to: CGPoint(x: cx - s * 0.52, y: eyeY)); p.addLine(to: CGPoint(x: cx - s * 0.10, y: eyeY))
                        p.move(to: CGPoint(x: cx + s * 0.10, y: eyeY)); p.addLine(to: CGPoint(x: cx + s * 0.52, y: eyeY))
                    }
                    context.stroke(blinkPath, with: .color(accent.opacity(0.9)), lineWidth: max(1.5, s * 0.035))
                }

                drawExpression(&context, cx: cx, cy: cy, s: s, bob: bob, time: t, pulse: pulse)
            }
        }
        .frame(width: compact ? 70 : 120, height: compact ? 42 : 84)
        .contentShape(Rectangle())
        .gesture(
            DragGesture(minimumDistance: 5)
                .onChanged { _ in
                    if !dragging { dragging = true; onDragChanged() }
                }
                .onEnded { _ in
                    dragging = false
                    onDragEnded()
                }
        )
        .scaleEffect(dragging ? 1.06 : 1)
        .animation(.easeOut(duration: 0.15), value: dragging)
        .accessibilityLabel("Argos, estado \(activity.title). Arrastra el personaje sobre una ventana para usarla como contexto.")
    }

    private func drawHead(_ context: inout GraphicsContext, cx: CGFloat, cy: CGFloat, s: CGFloat, bob: CGFloat) {
        var p = Path()
        p.move(to: CGPoint(x: cx - s * 0.78, y: cy + s * 0.60 + bob))
        p.addCurve(to: CGPoint(x: cx - s * 0.96, y: cy - s * 0.52 + bob), control1: CGPoint(x: cx - s * 0.98, y: cy + s * 0.28), control2: CGPoint(x: cx - s * 1.00, y: cy - s * 0.10))
        p.addLine(to: CGPoint(x: cx - s * 0.72, y: cy - s * 0.98 + bob))
        p.addLine(to: CGPoint(x: cx - s * 0.28, y: cy - s * 0.66 + bob))
        p.addLine(to: CGPoint(x: cx - s * 0.05, y: cy - s * 1.42 + bob))
        p.addLine(to: CGPoint(x: cx + s * 0.14, y: cy - s * 0.78 + bob))
        p.addLine(to: CGPoint(x: cx + s * 0.62, y: cy - s * 1.26 + bob))
        p.addLine(to: CGPoint(x: cx + s * 0.60, y: cy - s * 0.64 + bob))
        p.addLine(to: CGPoint(x: cx + s * 0.98, y: cy - s * 0.94 + bob))
        p.addCurve(to: CGPoint(x: cx + s * 0.78, y: cy + s * 0.60 + bob), control1: CGPoint(x: cx + s * 1.00, y: cy - s * 0.10), control2: CGPoint(x: cx + s * 0.98, y: cy + s * 0.30))
        p.addCurve(to: CGPoint(x: cx, y: cy + s * 0.82 + bob), control1: CGPoint(x: cx + s * 0.44, y: cy + s * 0.78), control2: CGPoint(x: cx + s * 0.22, y: cy + s * 0.90))
        p.addCurve(to: CGPoint(x: cx - s * 0.78, y: cy + s * 0.60 + bob), control1: CGPoint(x: cx - s * 0.26, y: cy + s * 0.90), control2: CGPoint(x: cx - s * 0.52, y: cy + s * 0.80))
        p.closeSubpath()
        context.fill(p, with: .color(Color(red: 0.08, green: 0.065, blue: 0.15)))
        context.stroke(p, with: .color(Color(red: 0.25, green: 0.20, blue: 0.42)), lineWidth: max(1.2, s * 0.032))

        if !compact {
            let edge = Path { e in
                e.move(to: CGPoint(x: cx - s * 0.78, y: cy - s * 0.72 + bob))
                e.addLine(to: CGPoint(x: cx - s * 0.29, y: cy - s * 0.98 + bob))
                e.move(to: CGPoint(x: cx + s * 0.62, y: cy - s * 1.04 + bob))
                e.addLine(to: CGPoint(x: cx + s * 0.94, y: cy - s * 0.72 + bob))
            }
            context.stroke(edge, with: .color(accent.opacity(activity == .error ? 0.85 : 0.38)), lineWidth: max(1, s * 0.022))
        }
    }

    private func drawBody(_ context: inout GraphicsContext, cx: CGFloat, cy: CGFloat, s: CGFloat, bob: CGFloat) {
        var p = Path()
        p.move(to: CGPoint(x: cx - s * 0.64, y: cy + s * 0.46 + bob))
        p.addCurve(to: CGPoint(x: cx - s * 0.70, y: cy + s * 1.48 + bob), control1: CGPoint(x: cx - s * 0.82, y: cy + s * 0.78), control2: CGPoint(x: cx - s * 0.70, y: cy + s * 1.18))
        p.addLine(to: CGPoint(x: cx - s * 0.08, y: cy + s * 0.86 + bob))
        p.addLine(to: CGPoint(x: cx + s * 0.05, y: cy + s * 1.56 + bob))
        p.addLine(to: CGPoint(x: cx + s * 0.34, y: cy + s * 0.88 + bob))
        p.addLine(to: CGPoint(x: cx + s * 0.72, y: cy + s * 1.42 + bob))
        p.addCurve(to: CGPoint(x: cx + s * 0.64, y: cy + s * 0.46 + bob), control1: CGPoint(x: cx + s * 0.76, y: cy + s * 0.94), control2: CGPoint(x: cx + s * 0.80, y: cy + s * 0.66))
        p.closeSubpath()
        context.fill(p, with: .color(Color(red: 0.10, green: 0.08, blue: 0.19)))
    }

    private func drawGem(_ context: inout GraphicsContext, cx: CGFloat, cy: CGFloat, s: CGFloat, bob: CGFloat) {
        var gem = Path()
        gem.move(to: CGPoint(x: cx, y: cy - s * 0.66 + bob))
        gem.addLine(to: CGPoint(x: cx + s * 0.14, y: cy - s * 0.42 + bob))
        gem.addLine(to: CGPoint(x: cx, y: cy - s * 0.18 + bob))
        gem.addLine(to: CGPoint(x: cx - s * 0.14, y: cy - s * 0.42 + bob))
        gem.closeSubpath()
        context.fill(gem, with: .color(accent.opacity(0.96)))
    }

    private func drawWhiskers(_ context: inout GraphicsContext, cx: CGFloat, cy: CGFloat, s: CGFloat, bob: CGFloat) {
        guard !compact else { return }
        let p = Path { w in
            w.move(to: CGPoint(x: cx - s * 0.63, y: cy + s * 0.25 + bob)); w.addLine(to: CGPoint(x: cx - s * 1.02, y: cy + s * 0.18 + bob))
            w.move(to: CGPoint(x: cx - s * 0.65, y: cy + s * 0.39 + bob)); w.addLine(to: CGPoint(x: cx - s * 1.04, y: cy + s * 0.47 + bob))
            w.move(to: CGPoint(x: cx + s * 0.63, y: cy + s * 0.25 + bob)); w.addLine(to: CGPoint(x: cx + s * 1.02, y: cy + s * 0.18 + bob))
            w.move(to: CGPoint(x: cx + s * 0.65, y: cy + s * 0.39 + bob)); w.addLine(to: CGPoint(x: cx + s * 1.04, y: cy + s * 0.47 + bob))
        }
        context.stroke(p, with: .color(accent.opacity(0.55)), lineWidth: 1.7)
    }

    private func drawEye(_ context: inout GraphicsContext, center: CGPoint, width: CGFloat, height: CGFloat, tilt: CGFloat) {
        var eye = Path()
        let dy = width * tilt
        eye.move(to: CGPoint(x: center.x - width * 0.50, y: center.y - dy))
        eye.addCurve(to: CGPoint(x: center.x + width * 0.50, y: center.y + dy), control1: CGPoint(x: center.x - width * 0.16, y: center.y - height * 1.25 - dy), control2: CGPoint(x: center.x + width * 0.16, y: center.y - height * 1.25 + dy))
        eye.addCurve(to: CGPoint(x: center.x - width * 0.50, y: center.y - dy), control1: CGPoint(x: center.x + width * 0.16, y: center.y + height * 1.10 + dy), control2: CGPoint(x: center.x - width * 0.16, y: center.y + height * 1.10 - dy))
        eye.closeSubpath()
        context.fill(eye, with: .color(accent))

        var pupil = Path()
        pupil.move(to: CGPoint(x: center.x - width * 0.06, y: center.y - height * 0.28))
        pupil.addLine(to: CGPoint(x: center.x + width * 0.04, y: center.y - height * 0.02))
        pupil.addLine(to: CGPoint(x: center.x + width * 0.02, y: center.y + height * 0.34))
        pupil.addLine(to: CGPoint(x: center.x - width * 0.07, y: center.y + height * 0.04))
        pupil.closeSubpath()
        context.fill(pupil, with: .color(.black.opacity(0.9)))
    }

    private func drawExpression(_ context: inout GraphicsContext, cx: CGFloat, cy: CGFloat, s: CGFloat, bob: CGFloat, time: TimeInterval, pulse: CGFloat) {
        var mouth = Path()
        switch activity {
        case .listening:
            mouth.addEllipse(in: CGRect(x: cx - s * 0.075, y: cy + s * 0.28 + bob, width: s * 0.15, height: s * 0.17))
            context.fill(mouth, with: .color(accent.opacity(0.95)))
        case .error:
            mouth.move(to: CGPoint(x: cx - s * 0.25, y: cy + s * 0.34 + bob))
            mouth.addLine(to: CGPoint(x: cx - s * 0.10, y: cy + s * 0.27 + bob))
            mouth.addLine(to: CGPoint(x: cx, y: cy + s * 0.36 + bob))
            mouth.addLine(to: CGPoint(x: cx + s * 0.10, y: cy + s * 0.27 + bob))
            mouth.addLine(to: CGPoint(x: cx + s * 0.25, y: cy + s * 0.34 + bob))
            context.stroke(mouth, with: .color(accent), lineWidth: max(1.6, s * 0.035))
        default:
            mouth.move(to: CGPoint(x: cx - s * 0.25, y: cy + s * 0.29 + bob))
            mouth.addQuadCurve(to: CGPoint(x: cx, y: cy + s * 0.42 + bob), control: CGPoint(x: cx - s * 0.10, y: cy + s * 0.50 + bob))
            mouth.addQuadCurve(to: CGPoint(x: cx + s * 0.25, y: cy + s * 0.29 + bob), control: CGPoint(x: cx + s * 0.10, y: cy + s * 0.50 + bob))
            context.stroke(mouth, with: .color(accent), lineWidth: max(1.5, s * 0.03))
        }

        // Los dos colmillos triangulares son parte fija del lenguaje visual Cresta.
        if !compact && activity != .thinking && activity != .working {
            let fangs = Path { p in
                p.move(to: CGPoint(x: cx - s * 0.17, y: cy + s * 0.31 + bob)); p.addLine(to: CGPoint(x: cx - s * 0.10, y: cy + s * 0.53 + bob)); p.addLine(to: CGPoint(x: cx - s * 0.03, y: cy + s * 0.34 + bob))
                p.move(to: CGPoint(x: cx + s * 0.03, y: cy + s * 0.34 + bob)); p.addLine(to: CGPoint(x: cx + s * 0.10, y: cy + s * 0.53 + bob)); p.addLine(to: CGPoint(x: cx + s * 0.17, y: cy + s * 0.31 + bob))
            }
            context.stroke(fangs, with: .color(accent.opacity(0.95)), lineWidth: max(1.2, s * 0.022))
        }

        if !compact {
            switch activity {
            case .thinking:
                for i in 0..<3 {
                    let y = cy - s * (1.15 + CGFloat(i) * 0.17)
                    let x = cx + s * (0.62 + CGFloat(i) * 0.12)
                    context.fill(Path(ellipseIn: CGRect(x: x - 2.5, y: y - 2.5, width: 5, height: 5)), with: .color(accent.opacity(0.45 + 0.15 * Double(i))))
                }
            case .working, .speaking:
                let count = activity == .speaking ? 4 : 3
                for i in 0..<count {
                    let phase = time * (activity == .speaking ? 5.5 : 4.0) + Double(i) * 1.7
                    let x = cx + CGFloat(cos(phase)) * s * 1.10
                    let y = cy + CGFloat(sin(phase)) * s * 0.70
                    context.fill(Path(ellipseIn: CGRect(x: x - 2, y: y - 2, width: 4, height: 4)), with: .color(accent.opacity(0.65)))
                }
            case .waitingApproval:
                let seal = Path(ellipseIn: CGRect(x: cx - s * 0.48, y: cy + s * 0.18, width: s * 0.96, height: s * 0.42))
                context.stroke(seal, with: .color(accent.opacity(0.18)), lineWidth: 1.5)
            case .success:
                let ring = Path(ellipseIn: CGRect(x: cx - s * (0.92 + pulse * 0.06), y: cy - s * (0.92 + pulse * 0.06), width: s * (1.84 + pulse * 0.12), height: s * (1.84 + pulse * 0.12)))
                context.stroke(ring, with: .color(accent.opacity(0.16 * (1 - pulse))), lineWidth: 2)
                let check = Path { p in
                    p.move(to: CGPoint(x: cx - s * 0.15, y: cy + s * 0.70)); p.addLine(to: CGPoint(x: cx - s * 0.03, y: cy + s * 0.82)); p.addLine(to: CGPoint(x: cx + s * 0.18, y: cy + s * 0.57))
                }
                context.stroke(check, with: .color(accent), lineWidth: max(1.8, s * 0.035))
            case .error:
                let mark = Path { p in
                    p.move(to: CGPoint(x: cx - s * 1.08, y: cy + s * 0.65)); p.addLine(to: CGPoint(x: cx - s * 0.92, y: cy + s * 0.49))
                    p.move(to: CGPoint(x: cx + s * 1.08, y: cy + s * 0.58)); p.addLine(to: CGPoint(x: cx + s * 0.94, y: cy + s * 0.43))
                }
                context.stroke(mark, with: .color(accent.opacity(0.8)), lineWidth: 2)
            default: break
            }
        }
    }

    private func drawSmoke(_ context: inout GraphicsContext, cx: CGFloat, cy: CGFloat, s: CGFloat, time: TimeInterval) {
        guard !compact else { return }
        let alpha = activity == .working || activity == .speaking ? 0.30 : (activity == .thinking ? 0.20 : 0.10)
        for i in 0..<3 {
            let phase = time * (0.8 + Double(i) * 0.16) + Double(i)
            let sx = cx + CGFloat(sin(phase)) * s * (0.10 + CGFloat(i) * 0.05)
            let sy = cy + s * (1.00 + CGFloat(i) * 0.24) - CGFloat((time * 8).truncatingRemainder(dividingBy: 1.8)) * 1.2
            let smoke = Path(ellipseIn: CGRect(x: sx - s * 0.10, y: sy - s * 0.08, width: s * 0.20, height: s * 0.16))
            context.fill(smoke, with: .color(accent.opacity(alpha * (1 - Double(i) * 0.22))))
        }
    }

    private func drawParticles(_ context: inout GraphicsContext, cx: CGFloat, cy: CGFloat, s: CGFloat, time: TimeInterval) {
        let particles: [(CGFloat, CGFloat, CGFloat)] = [(-1.14, -0.82, 3), (1.18, -0.58, 3), (-1.20, 0.42, 2.5), (1.10, 0.65, 2.2)]
        for (px, py, r) in particles {
            let drift = CGFloat(sin(time * 0.9 + Double(px * 4))) * 3
            context.fill(Path(ellipseIn: CGRect(x: cx + s * px - r / 2, y: cy + s * py + drift - r / 2, width: r, height: r)), with: .color(accent.opacity(0.55)))
        }
    }
}
