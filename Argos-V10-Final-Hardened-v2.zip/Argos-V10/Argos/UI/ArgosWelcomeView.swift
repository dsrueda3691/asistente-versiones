import SwiftUI
import AppKit
import ApplicationServices
import ScreenCaptureKit
import AVFoundation
import Speech

@MainActor
final class ArgosWelcomeWindowController: NSObject {
    private var window: NSWindow?

    func showIfNeeded() {
        guard !UserDefaults.standard.bool(forKey: "argos.onboardingComplete") else { return }
        let root = ArgosWelcomeView(onContinue: { [weak self] in
            UserDefaults.standard.set(true, forKey: "argos.onboardingComplete")
            self?.window?.close()
            self?.window = nil
        })
        let hosting = NSHostingController(rootView: root)
        let window = NSWindow(contentViewController: hosting)
        window.title = "Argos · Primeros pasos"
        window.styleMask = [.titled, .closable, .miniaturizable]
        window.isReleasedWhenClosed = false
        window.center()
        window.setContentSize(NSSize(width: 620, height: 620))
        window.level = .floating
        window.isMovableByWindowBackground = true
        self.window = window
        NSApp.activate(ignoringOtherApps: true)
        window.makeKeyAndOrderFront(nil)
    }
}

struct ArgosWelcomeView: View {
    let onContinue: () -> Void
    @State private var microphone = false
    @State private var speech = false
    @State private var screenCapture = false
    @State private var accessibility = false
    @State private var testing = false

    var body: some View {
        VStack(spacing: 0) {
            VStack(spacing: 12) {
                ZStack {
                    Circle().fill(Color.purple.opacity(0.16)).frame(width: 94, height: 94)
                    Text("◆").font(.system(size: 44, weight: .bold)).foregroundStyle(.purple)
                }
                Text("Bienvenido a Argos")
                    .font(.system(size: 30, weight: .bold, design: .rounded))
                Text("Tu compañero de escritorio para Mac")
                    .font(.title3)
                    .foregroundStyle(.secondary)
            }
            .padding(.top, 30)

            VStack(alignment: .leading, spacing: 12) {
                Text("Permisos")
                    .font(.headline)
                permissionRow("Micrófono", granted: microphone) {
                    Task { microphone = await PermissionGate.requestMicrophonePublic() }
                }
                permissionRow("Reconocimiento de voz", granted: speech) {
                    Task { speech = await PermissionGate.requestSpeechPublic() }
                }
                permissionRow("Grabación de pantalla", granted: screenCapture) {
                    screenCapture = CGPreflightScreenCaptureAccess() || CGRequestScreenCaptureAccess()
                }
                permissionRow("Accesibilidad", granted: accessibility) {
                    accessibility = PermissionGate.requestAccessibility()
                }

                HStack {
                    Button("Abrir Ajustes del Sistema") { PermissionGate.openPrivacySettings() }
                    Spacer()
                    Button("Comprobar permisos") { refreshPermissions() }
                        .buttonStyle(.bordered)
                }
                .padding(.top, 4)
            }
            .padding(22)
            .background(.quaternary.opacity(0.45), in: RoundedRectangle(cornerRadius: 18))
            .padding(.horizontal, 30)
            .padding(.top, 24)

            Spacer()

            HStack {
                Text("Puedes cambiar estos permisos después desde Ajustes del Sistema.")
                    .font(.caption)
                    .foregroundStyle(.secondary)
                Spacer()
                Button("Continuar") { onContinue() }
                    .buttonStyle(.borderedProminent)
                    .keyboardShortcut(.defaultAction)
            }
            .padding(24)
        }
        .frame(width: 620, height: 620)
        .onAppear { refreshPermissions() }
    }

    private func permissionRow(_ title: String, granted: Bool, action: @escaping () -> Void) -> some View {
        HStack(spacing: 12) {
            Image(systemName: granted ? "checkmark.circle.fill" : "circle")
                .foregroundStyle(granted ? .green : .secondary)
            Text(title)
            Spacer()
            Button(granted ? "Concedido" : "Permitir", action: action)
                .buttonStyle(.bordered)
                .disabled(granted)
        }
    }

    private func refreshPermissions() {
        microphone = AVCaptureDevice.authorizationStatus(for: .audio) == .authorized
        speech = SFSpeechRecognizer.authorizationStatus() == .authorized
        screenCapture = CGPreflightScreenCaptureAccess()
        accessibility = AXIsProcessTrusted()
    }
}

extension PermissionGate {
    static func requestMicrophonePublic() async -> Bool {
        await withCheckedContinuation { continuation in
            AVAudioApplication.requestRecordPermission { granted in
                continuation.resume(returning: granted)
            }
        }
    }

    static func requestSpeechPublic() async -> Bool {
        await withCheckedContinuation { continuation in
            SFSpeechRecognizer.requestAuthorization { status in
                continuation.resume(returning: status == .authorized)
            }
        }
    }

    static func requestAccessibility() -> Bool {
        if AXIsProcessTrusted() { return true }
        let options = [kAXTrustedCheckOptionPrompt.takeUnretainedValue() as String: true] as CFDictionary
        return AXIsProcessTrustedWithOptions(options)
    }

    static func openPrivacySettings() {
        let urls = [
            "x-apple.systempreferences:com.apple.preference.security?Privacy_Accessibility",
            "x-apple.systempreferences:com.apple.preference.security?Privacy_ScreenCapture"
        ]
        for raw in urls {
            if let url = URL(string: raw) { NSWorkspace.shared.open(url) }
        }
    }
}
