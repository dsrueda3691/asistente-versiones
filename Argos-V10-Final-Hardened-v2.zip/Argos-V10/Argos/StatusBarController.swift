import AppKit
import SwiftUI
import Carbon

/// Icono de barra de menús, acceso al compañero del notch y atajo global.
final class StatusBarController: NSObject {
    private let statusItem: NSStatusItem
    private let state: AppState
    private let notch: ArgosNotchPanelController
    private let onListen: () -> Void
    private let onQuit: () -> Void
    private var localMonitor: Any?
    private var globalMonitor: Any?
    private var carbonHotKey: EventHotKeyRef?
    private var carbonHandler: EventHandlerRef?
    private var lastHotKeyAt = Date.distantPast
    private var currentHotkey: HotkeyConfig = .default

    init(
        state: AppState,
        notch: ArgosNotchPanelController,
        onListen: @escaping () -> Void,
        onQuit: @escaping () -> Void
    ) {
        self.state = state
        self.notch = notch
        self.onListen = onListen
        self.onQuit = onQuit
        self.statusItem = NSStatusBar.system.statusItem(withLength: NSStatusItem.variableLength)
        super.init()
        currentHotkey = HotkeyConfig.current
        state.hotkeyDisplay = currentHotkey.display
        configureStatusItem()
        installHotkeys()
    }

    deinit { teardownHotkeys() }

    func showCompanion() { notch.showForActivity() }
    func hideCompanion() { notch.hide() }

    func applyHotkey(_ config: HotkeyConfig) {
        HotkeyConfig.current = config
        currentHotkey = config
        state.hotkeyDisplay = config.display
        teardownHotkeys()
        installHotkeys()
        statusItem.button?.toolTip = "Argos — pulsa o \(config.display) para hablar"
    }

    @objc private func statusItemClicked(_ sender: Any?) {
        // El icono de la barra solo controla la ventana. Escuchar queda reservado
        // al botón del micrófono o al atajo global para evitar dos acciones en un clic.
        notch.toggleExpanded()
    }

    private func configureStatusItem() {
        guard let button = statusItem.button else { return }
        if let image = NSImage(systemSymbolName: "sparkles", accessibilityDescription: "Argos") {
            image.isTemplate = true
            button.image = image
        } else {
            button.title = "A"
        }
        button.toolTip = "Argos — pulsa o \(currentHotkey.display) para hablar"
        button.target = self
        button.action = #selector(statusItemClicked(_:))
        button.sendAction(on: [.leftMouseUp])
    }

    private func teardownHotkeys() {
        if let localMonitor { NSEvent.removeMonitor(localMonitor); self.localMonitor = nil }
        if let globalMonitor { NSEvent.removeMonitor(globalMonitor); self.globalMonitor = nil }
        if let carbonHotKey { UnregisterEventHotKey(carbonHotKey); self.carbonHotKey = nil }
        if let carbonHandler { RemoveEventHandler(carbonHandler); self.carbonHandler = nil }
    }

    private func installHotkeys() {
        let hk = currentHotkey
        localMonitor = NSEvent.addLocalMonitorForEvents(matching: .keyDown) { [weak self] event in
            guard let self, hk.matches(event) || self.currentHotkey.matches(event) else { return event }
            self.handleHotKey()
            return nil
        }
        globalMonitor = NSEvent.addGlobalMonitorForEvents(matching: .keyDown) { [weak self] event in
            guard let self, self.currentHotkey.matches(event) else { return }
            self.handleHotKey()
        }
        registerCarbonHotKey(hk)
    }

    fileprivate func handleHotKey() {
        let now = Date()
        guard now.timeIntervalSince(lastHotKeyAt) > 0.45 else { return }
        lastHotKeyAt = now
        if Thread.isMainThread { onListen() }
        else { DispatchQueue.main.async { [weak self] in self?.onListen() } }
    }

    private func registerCarbonHotKey(_ config: HotkeyConfig) {
        var hotKeyID = EventHotKeyID(signature: OSType(0x41524753), id: 1) // 'ARGS'
        var eventType = EventTypeSpec(eventClass: OSType(kEventClassKeyboard), eventKind: UInt32(kEventHotKeyPressed))
        let context = Unmanaged.passUnretained(self).toOpaque()
        var handler: EventHandlerRef?
        let installed = InstallEventHandler(GetApplicationEventTarget(), carbonHotKeyCallback, 1, &eventType, context, &handler)
        if installed == noErr { carbonHandler = handler }
        var hotKey: EventHotKeyRef?
        let registered = RegisterEventHotKey(config.keyCode, config.carbonModifiers, hotKeyID, GetApplicationEventTarget(), 0, &hotKey)
        if registered == noErr { carbonHotKey = hotKey }
    }
}

private let carbonHotKeyCallback: EventHandlerProcPtr = { _, _, userData in
    guard let userData else { return noErr }
    let controller = Unmanaged<StatusBarController>.fromOpaque(userData).takeUnretainedValue()
    DispatchQueue.main.async { controller.handleHotKey() }
    return noErr
}
