import Foundation
import AppKit
import PDFKit
import ApplicationServices

/// Lee texto de archivos locales (Desktop/Documents/Downloads), documento frontal, o página web del navegador.
/// Nunca borra ni ejecuta. Tope ~12k caracteres.
enum DocumentReader {
    static let maxChars = 12_000

    struct Payload {
        let sourceLabel: String
        let text: String
        let truncated: Bool
    }

    enum ReadError: Error, LocalizedError {
        case notFound(String)
        case unsupported(String)
        case empty
        case failed(String)

        var userMessage: String {
            switch self {
            case .notFound(let hint):
                return "No encontré «\(hint)» en Escritorio, Documentos ni Descargas."
            case .unsupported(let kind):
                return "No puedo leer \(kind) como texto. Si quieres, dime «mira la pantalla» y lo veo ahí."
            case .empty:
                return "El documento está vacío o no tiene texto extraíble."
            case .failed(let msg):
                return msg
            }
        }

        var errorDescription: String? { userMessage }
    }

    /// Interpreta la frase del usuario y obtiene texto.
    static func read(fromPhrase phrase: String) async throws -> Payload {
        let cleaned = IntentParser.normalize(phrase)
        let original = phrase.trimmingCharacters(in: .whitespacesAndNewlines)

        // Página del navegador
        if looksLikePage(cleaned) {
            if let page = await readFrontBrowserPage() {
                return clip(page.text, label: page.label)
            }
            throw ReadError.failed("No pude leer la página del navegador. Abre Safari o Chrome con una pestaña al frente.")
        }

        // Este documento / documento frontal
        if looksLikeFrontDocument(cleaned) {
            if let front = readFrontDocumentPath() {
                return try readFile(at: front)
            }
            // Fallback: página web
            if let page = await readFrontBrowserPage() {
                return clip(page.text, label: page.label)
            }
            throw ReadError.failed("No identifiqué un documento al frente. Nombra el archivo (ej. «lee el README»).")
        }

        // Nombre de archivo en la frase
        if let name = extractFileName(from: cleaned, original: original) {
            if let url = locateFile(named: name) {
                return try readFile(at: url)
            }
            throw ReadError.notFound(name)
        }

        // Último recurso: documento frontal o página
        if let front = readFrontDocumentPath() {
            return try readFile(at: front)
        }
        if let page = await readFrontBrowserPage() {
            return clip(page.text, label: page.label)
        }
        throw ReadError.failed("Dime el nombre del archivo (en Escritorio, Documentos o Descargas) o abre la página/documento al frente.")
    }

    // MARK: - File IO

    static func readFile(at url: URL) throws -> Payload {
        let ext = url.pathExtension.lowercased()
        switch ext {
        case "txt", "md", "markdown", "swift", "json", "csv", "html", "htm", "css", "js", "ts", "py", "rb", "sh", "c", "h", "cpp", "m", "mm", "xml", "yml", "yaml", "log", "rtf":
            if ext == "rtf" {
                // Intento simple: leer como data y strip RTF vía NSAttributedString
                if let data = try? Data(contentsOf: url),
                   let attr = try? NSAttributedString(
                    data: data,
                    options: [.documentType: NSAttributedString.DocumentType.rtf],
                    documentAttributes: nil
                   ) {
                    let text = attr.string.trimmingCharacters(in: .whitespacesAndNewlines)
                    guard !text.isEmpty else { throw ReadError.empty }
                    return clip(text, label: url.lastPathComponent)
                }
            }
            let raw = try String(contentsOf: url, encoding: .utf8)
            let text = raw.trimmingCharacters(in: .whitespacesAndNewlines)
            guard !text.isEmpty else { throw ReadError.empty }
            return clip(text, label: url.lastPathComponent)

        case "pdf":
            return try readPDF(at: url)

        case "docx", "pages", "doc", "odt", "key", "pptx", "xlsx":
            throw ReadError.unsupported(".\(ext)")

        case "":
            // Sin extensión: intentar UTF-8
            if let raw = try? String(contentsOf: url, encoding: .utf8),
               !raw.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
                return clip(raw, label: url.lastPathComponent)
            }
            throw ReadError.unsupported("ese archivo")

        default:
            // Intentar texto plano
            if let raw = try? String(contentsOf: url, encoding: .utf8) {
                let text = raw.trimmingCharacters(in: .whitespacesAndNewlines)
                let nulCount = raw.utf8.filter { $0 == 0 }.count
                if !text.isEmpty && nulCount == 0 && text.count > 10 {
                    return clip(text, label: url.lastPathComponent)
                }
            }
            throw ReadError.unsupported(".\(ext)")
        }
    }

    private static func readPDF(at url: URL) throws -> Payload {
        guard let doc = PDFDocument(url: url) else {
            throw ReadError.failed("No pude abrir el PDF.")
        }
        var parts: [String] = []
        let count = doc.pageCount
        for i in 0..<count {
            guard let page = doc.page(at: i), let s = page.string else { continue }
            parts.append(s)
            if parts.joined(separator: "\n").count > maxChars { break }
        }
        let text = parts.joined(separator: "\n")
            .trimmingCharacters(in: .whitespacesAndNewlines)
        guard !text.isEmpty else { throw ReadError.empty }
        return clip(text, label: url.lastPathComponent)
    }

    private static func clip(_ text: String, label: String) -> Payload {
        let trimmed = text.trimmingCharacters(in: .whitespacesAndNewlines)
        if trimmed.count <= maxChars {
            return Payload(sourceLabel: label, text: trimmed, truncated: false)
        }
        return Payload(
            sourceLabel: label,
            text: String(trimmed.prefix(maxChars)) + "\n…[truncado]",
            truncated: true
        )
    }

    // MARK: - Locate

    static func locateFile(named raw: String) -> URL? {
        var name = raw.trimmingCharacters(in: .whitespacesAndNewlines)
        name = name.trimmingCharacters(in: CharacterSet(charactersIn: "\"'"))
        guard !name.isEmpty else { return nil }

        let fm = FileManager.default
        let folders: [URL] = [
            fm.urls(for: .desktopDirectory, in: .userDomainMask).first,
            fm.urls(for: .documentDirectory, in: .userDomainMask).first,
            fm.urls(for: .downloadsDirectory, in: .userDomainMask).first
        ].compactMap { $0 }

        let needle = name.lowercased()
        let needleBase = (name as NSString).deletingPathExtension.lowercased()

        for folder in folders {
            // Exacto
            let exact = folder.appendingPathComponent(name)
            if fm.fileExists(atPath: exact.path) { return exact }

            guard let items = try? fm.contentsOfDirectory(
                at: folder,
                includingPropertiesForKeys: [.isRegularFileKey],
                options: [.skipsHiddenFiles]
            ) else { continue }

            // Match case-insensitive / contains
            var best: URL?
            for url in items {
                let last = url.lastPathComponent
                let lastLower = last.lowercased()
                let base = (last as NSString).deletingPathExtension.lowercased()
                if lastLower == needle || base == needleBase {
                    return url
                }
                if lastLower.contains(needle) || base.contains(needleBase) || needle.contains(base) {
                    if best == nil { best = url }
                }
            }
            if let best { return best }
        }
        return nil
    }

    // MARK: - Phrase helpers

    private static func looksLikePage(_ s: String) -> Bool {
        (s.contains("pagina") || s.contains("página") || s.contains("page") || s.contains("web") || s.contains("url") || s.contains("safari") || s.contains("chrome")) &&
        (s.contains("lee") || s.contains("leer") || s.contains("documenta") || s.contains("explica") || s.contains("resume") || s.contains("esta") || s.contains("esto"))
        || s.contains("documenta esta pagina") || s.contains("documenta esta página")
        || s.contains("lee esta pagina") || s.contains("lee la pagina")
        || s.contains("esta pagina") && (s.contains("lee") || s.contains("explica") || s.contains("resume") || s.contains("documenta"))
    }

    private static func looksLikeFrontDocument(_ s: String) -> Bool {
        s.contains("este documento") || s.contains("el documento") ||
        s.contains("este archivo") || s.contains("documento al frente") ||
        s.contains("explica este documento") || s.contains("lee este documento") ||
        s.contains("documenta esto") || s.contains("lee esto")
    }

    private static func extractFileName(from cleaned: String, original: String) -> String? {
        // «lee el README», «ensayo con este PDF», «lee mitos.txt»
        let patterns = [
            "lee el ", "leer el ", "lee la ", "leer la ", "lee ",
            "abre el archivo ", "lee el archivo ", "con este ", "con el ",
            "del archivo ", "archivo ", "pdf ", "documento "
        ]
        for p in patterns {
            if let r = cleaned.range(of: p) {
                var rest = String(cleaned[r.upperBound...]).trimmingCharacters(in: .whitespaces)
                // Cortar basura
                for cut in [" y ", " con ", " para ", " por favor", " please"] {
                    if let c = rest.range(of: cut) {
                        rest = String(rest[..<c.lowerBound])
                    }
                }
                rest = rest.trimmingCharacters(in: .whitespacesAndNewlines)
                // Quitar palabras genéricas solas
                let stop = Set(["archivo", "documento", "pdf", "texto", "pagina", "página", "esto", "este", "esta", "aqui", "aquí"])
                if stop.contains(rest) { continue }
                if !rest.isEmpty && rest.count < 120 {
                    // Preferir extensión del original si existe
                    if let fromOrig = extractNamedWithExtension(original) {
                        return fromOrig
                    }
                    return rest
                }
            }
        }
        return extractNamedWithExtension(original)
    }

    private static func extractNamedWithExtension(_ original: String) -> String? {
        let pattern = #"([A-Za-z0-9_\-\.]+\.(?:txt|md|pdf|swift|html?|json|csv|rtf))"#
        guard let regex = try? NSRegularExpression(pattern: pattern, options: [.caseInsensitive]) else { return nil }
        let range = NSRange(original.startIndex..<original.endIndex, in: original)
        if let match = regex.firstMatch(in: original, options: [], range: range),
           let swiftRange = Range(match.range(at: 1), in: original) {
            return String(original[swiftRange])
        }
        return nil
    }

    // MARK: - Front document / browser (best-effort, sin keylogging)

    /// Intenta path del documento frontal vía Accessibility (apps que exponen AXDocument).
    static func readFrontDocumentPath() -> URL? {
        let system = AXUIElementCreateSystemWide()
        var focusedApp: CFTypeRef?
        guard AXUIElementCopyAttributeValue(system, kAXFocusedApplicationAttribute as CFString, &focusedApp) == .success,
              let app = focusedApp else { return nil }
        let appEl = app as! AXUIElement

        var doc: CFTypeRef?
        if AXUIElementCopyAttributeValue(appEl, kAXDocumentAttribute as CFString, &doc) == .success,
           let path = doc as? String {
            let cleaned = path.replacingOccurrences(of: "file://", with: "")
            let url = URL(fileURLWithPath: cleaned.removingPercentEncoding ?? cleaned)
            if FileManager.default.fileExists(atPath: url.path) { return url }
        }

        // Ventana enfocada
        var focusedWindow: CFTypeRef?
        if AXUIElementCopyAttributeValue(appEl, kAXFocusedWindowAttribute as CFString, &focusedWindow) == .success,
           let win = focusedWindow {
            let winEl = win as! AXUIElement
            var winDoc: CFTypeRef?
            if AXUIElementCopyAttributeValue(winEl, kAXDocumentAttribute as CFString, &winDoc) == .success,
               let path = winDoc as? String {
                let cleaned = path.replacingOccurrences(of: "file://", with: "")
                let url = URL(fileURLWithPath: cleaned.removingPercentEncoding ?? cleaned)
                if FileManager.default.fileExists(atPath: url.path) { return url }
            }
        }
        return nil
    }

    /// URL + texto HTML de Safari/Chrome vía AppleScript (solo lectura).
    static func readFrontBrowserPage() async -> (label: String, text: String)? {
        let safari = """
        tell application "System Events"
          if not (exists process "Safari") then return ""
        end tell
        tell application "Safari"
          if (count of windows) = 0 then return ""
          set theURL to URL of current tab of front window
          set theName to name of current tab of front window
          set theSource to source of current tab of front window
          return theURL & "\n" & theName & "\n" & theSource
        end tell
        """
        if let raw = runAppleScript(safari), let parsed = parseBrowserScriptResult(raw, browser: "Safari") {
            return parsed
        }

        let chrome = """
        tell application "System Events"
          if not (exists process "Google Chrome") then return ""
        end tell
        tell application "Google Chrome"
          if (count of windows) = 0 then return ""
          set theURL to URL of active tab of front window
          set theName to title of active tab of front window
          set theSource to execute active tab of front window javascript "document.body ? document.body.innerText : ''"
          return theURL & "\n" & theName & "\n" & theSource
        end tell
        """
        if let raw = runAppleScript(chrome), let parsed = parseBrowserScriptResult(raw, browser: "Chrome") {
            return parsed
        }
        return nil
    }

    private static func parseBrowserScriptResult(_ raw: String, browser: String) -> (label: String, text: String)? {
        let trimmed = raw.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmed.isEmpty else { return nil }
        let lines = trimmed.split(separator: "\n", maxSplits: 2, omittingEmptySubsequences: false)
        guard lines.count >= 3 else {
            let text = stripHTML(trimmed)
            guard !text.isEmpty else { return nil }
            return ("\(browser)", text)
        }
        let url = String(lines[0])
        let name = String(lines[1])
        let body = String(lines[2...].joined(separator: "\n"))
        let text = stripHTML(body).trimmingCharacters(in: .whitespacesAndNewlines)
        guard !text.isEmpty else { return nil }
        let label = name.isEmpty ? "\(browser) · \(url)" : "\(browser) · \(name)"
        return (label, text)
    }

    private static func stripHTML(_ html: String) -> String {
        // Si ya parece texto plano (Chrome innerText), devolver casi igual.
        if !html.contains("<") || html.contains("<") && html.count < 40 {
            return html
        }
        var s = html
        // Scripts / styles
        let patterns = [
            #"<script[^>]*>[\s\S]*?</script>"#,
            #"<style[^>]*>[\s\S]*?</style>"#,
            #"<[^>]+>"#
        ]
        for p in patterns {
            if let regex = try? NSRegularExpression(pattern: p, options: [.caseInsensitive]) {
                s = regex.stringByReplacingMatches(in: s, options: [], range: NSRange(s.startIndex..<s.endIndex, in: s), withTemplate: " ")
            }
        }
        s = s.replacingOccurrences(of: "&nbsp;", with: " ")
        s = s.replacingOccurrences(of: "&amp;", with: "&")
        s = s.replacingOccurrences(of: "&lt;", with: "<")
        s = s.replacingOccurrences(of: "&gt;", with: ">")
        s = s.replacingOccurrences(of: "&quot;", with: "\"")
        while s.contains("  ") { s = s.replacingOccurrences(of: "  ", with: " ") }
        while s.contains("\n\n\n") { s = s.replacingOccurrences(of: "\n\n\n", with: "\n\n") }
        return s.trimmingCharacters(in: .whitespacesAndNewlines)
    }

    private static func runAppleScript(_ source: String) -> String? {
        var error: NSDictionary?
        guard let script = NSAppleScript(source: source) else { return nil }
        let result = script.executeAndReturnError(&error)
        if error != nil { return nil }
        return result.stringValue
    }
}
