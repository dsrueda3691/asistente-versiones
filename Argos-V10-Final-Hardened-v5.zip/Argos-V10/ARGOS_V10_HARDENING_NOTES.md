# Argos V10 — Hardened v3

## Correcciones

- Gmail: se corrigió la documentación de OAuth para no presentar el flujo actual como un cliente Desktop con loopback. Argos mantiene el redirect URI personalizado `com.danielrueda.Argos:/oauth2redirect` y no almacena client secrets.
- WhatsApp: el cuerpo se busca exclusivamente después del teléfono; `mensaje` antes del teléfono ya no se interpreta como el contenido.
- WhatsApp: se eliminó el cálculo de índices sobre una cadena previamente recortada; el parser trabaja sobre el sufijo real posterior al número.
- Portabilidad: el `NSRange` del parser usa longitud UTF-16 explícita.

## Verificación

- 36 archivos Swift pasan `swiftc -parse`.
- Se probó el parser con mensajes WhatsApp que contienen tildes, ñ, números con espacios, guiones, marcador `diciendo`, `que diga` y `:`.
