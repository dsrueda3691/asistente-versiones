# Argos V10 — Hardened v5

## Objetivos y recordatorios
- Added explicit `createGoal` / `listGoals` intents.
- Goals are stored locally in Application Support/Argos/goals.json.
- Each goal tracks title, optional project, deadline, status, last movement and reminder ID.
- Creating a goal requires notch approval.
- Confirmation creates/uses an `Argos` Reminders list when possible and creates the corresponding reminder.
- Morning goal summary runs once per day when Argos is running (after 07:00).
- Goals without movement for >= 3 days are highlighted.

## Important mail monitor
- Every 20 minutes while Argos is running, Gmail/Outlook unread headers + snippets can be checked.
- Brain scores importance using current goal context.
- Only high-score messages (>=80/100) trigger a notch/voice alert.
- No email is sent automatically.
- Only alerted message IDs are deduplicated; non-important mail can be reconsidered later.
- If Brain scoring fails, a local urgency heuristic is used as fallback.

## iPhone bridge
- Added a small HTTP bridge on TCP 8765.
- `GET /v1/health` and authenticated `POST /v1/ask` are supported.
- Bearer token is generated once and stored in macOS Keychain.
- Bridge can be reached through a private Tailscale network.
- Remote requests use the same Argos intent/approval flow; dangerous actions remain pending in the notch.
- The app does not store or require a Telegram account.

## Verification
- All 36 Swift files pass `swiftc -parse` in the available environment.
- Actual macOS/Xcode build, notarization, signing and hardware notch testing remain required.
