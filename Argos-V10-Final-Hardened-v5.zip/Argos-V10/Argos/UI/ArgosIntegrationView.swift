import SwiftUI
import AppKit

struct ArgosIntegrationView: View {
    @State private var gmailClientID = UserDefaults.standard.string(forKey: GmailIntegration.clientIDKey) ?? ""
    @State private var outlookClientID = UserDefaults.standard.string(forKey: OutlookIntegration.clientIDKey) ?? ""
    @State private var outlookTenant = UserDefaults.standard.string(forKey: OutlookIntegration.tenantKey) ?? "common"
    @State private var githubClientID = UserDefaults.standard.string(forKey: GitHubIntegration.clientIDKey) ?? ""
    @State private var whatsappPhoneID = UserDefaults.standard.string(forKey: WhatsAppIntegration.phoneNumberIDKey) ?? ""
    @State private var whatsappGraphVersion = UserDefaults.standard.string(forKey: WhatsAppIntegration.graphVersionKey) ?? "v23.0"
    @State private var whatsappToken = ""
    @State private var message = ""

    var body: some View {
        VStack(alignment: .leading, spacing: 18) {
            Text("Integraciones reales")
                .font(.title3.weight(.semibold))
            Text("Las cuentas se conectan mediante OAuth cuando el proveedor lo permite. Los tokens se guardan en el Llavero de macOS; los Client ID son configuración pública. Las acciones que envían mensajes pasan primero por aprobación en el notch.")
                .font(.callout)
                .foregroundStyle(.secondary)
                .fixedSize(horizontal: false, vertical: true)

            integrationCard(
                title: "Gmail",
                symbol: "envelope.fill",
                connected: GmailIntegration.connected,
                description: "Leer bandeja, no leídos, abrir correos y enviar correo mediante Gmail API.",
                fields: {
                    TextField("Google OAuth Client ID (cliente iOS)", text: $gmailClientID)
                        .textFieldStyle(.roundedBorder)
                },
                actions: {
                    Button(GmailIntegration.connected ? "Reconectar" : "Conectar") {
                        UserDefaults.standard.set(gmailClientID.trimmingCharacters(in: .whitespacesAndNewlines), forKey: GmailIntegration.clientIDKey)
                        Task { await connectGmail() }
                    }
                }
            )

            integrationCard(
                title: "Outlook / Microsoft 365",
                symbol: "envelope.badge.person.crop",
                connected: OutlookIntegration.connected,
                description: "Leer bandeja, no leídos, abrir correos, calendario y enviar correo mediante Microsoft Graph.",
                fields: {
                    TextField("Microsoft Entra Client ID", text: $outlookClientID)
                        .textFieldStyle(.roundedBorder)
                    TextField("Tenant", text: $outlookTenant)
                        .textFieldStyle(.roundedBorder)
                },
                actions: {
                    Button(OutlookIntegration.connected ? "Reconectar" : "Conectar") {
                        UserDefaults.standard.set(outlookClientID.trimmingCharacters(in: .whitespacesAndNewlines), forKey: OutlookIntegration.clientIDKey)
                        UserDefaults.standard.set(outlookTenant.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty ? "common" : outlookTenant.trimmingCharacters(in: .whitespacesAndNewlines), forKey: OutlookIntegration.tenantKey)
                        Task { await connectOutlook() }
                    }
                }
            )

            integrationCard(
                title: "GitHub",
                symbol: "chevron.left.forwardslash.chevron.right",
                connected: GitHubIntegration.connected,
                description: "Consultar tus PR abiertos y preparar acciones futuras con permisos explícitos.",
                fields: {
                    TextField("GitHub App / OAuth Client ID", text: $githubClientID)
                        .textFieldStyle(.roundedBorder)
                },
                actions: {
                    Button(GitHubIntegration.connected ? "Reconectar" : "Conectar") {
                        UserDefaults.standard.set(githubClientID.trimmingCharacters(in: .whitespacesAndNewlines), forKey: GitHubIntegration.clientIDKey)
                        Task { await connectGitHub() }
                    }
                }
            )

            integrationCard(
                title: "WhatsApp Business Cloud API",
                symbol: "message.fill",
                connected: WhatsAppIntegration.configured,
                description: "Enviar mensajes mediante la Cloud API de WhatsApp Business. No usa WhatsApp Web ni automatiza una cuenta personal.",
                fields: {
                    TextField("Phone Number ID", text: $whatsappPhoneID)
                        .textFieldStyle(.roundedBorder)
                    TextField("Graph API version", text: $whatsappGraphVersion)
                        .textFieldStyle(.roundedBorder)
                    SecureField("Access Token (se guarda en Llavero)", text: $whatsappToken)
                        .textFieldStyle(.roundedBorder)
                },
                actions: {
                    Button("Guardar configuración") {
                        UserDefaults.standard.set(whatsappPhoneID.trimmingCharacters(in: .whitespacesAndNewlines), forKey: WhatsAppIntegration.phoneNumberIDKey)
                        UserDefaults.standard.set(whatsappGraphVersion.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty ? "v23.0" : whatsappGraphVersion.trimmingCharacters(in: .whitespacesAndNewlines), forKey: WhatsAppIntegration.graphVersionKey)
                        WhatsAppIntegration.saveAccessToken(whatsappToken)
                        whatsappToken = ""
                        message = "WhatsApp configurado."
                    }
                }
            )

            if !message.isEmpty {
                Label(message, systemImage: "checkmark.circle.fill")
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }

            VStack(alignment: .leading, spacing: 9) {
                HStack {
                    Image(systemName: "iphone.and.arrow.forward").frame(width: 24).foregroundStyle(.purple)
                    Text("iPhone + Atajos + Tailscale").font(.headline)
                    Spacer()
                    Label("Puente local", systemImage: "lock.shield")
                        .font(.caption).foregroundStyle(.secondary)
                }
                Text("Argos puede exponer un pequeño servidor HTTP en el Mac para que un Atajo de Siri envíe texto y reciba la respuesta. El puerto es 8765 y cada petición exige un token guardado en el Llavero. Para acceso fuera de casa, instala Tailscale en el Mac y el iPhone y usa la IP Tailscale del Mac.")
                    .font(.caption).foregroundStyle(.secondary).fixedSize(horizontal: false, vertical: true)
                HStack {
                    Text("Token")
                        .font(.caption.weight(.semibold))
                    Spacer()
                    Text(ArgosBridgeServer.configuredToken)
                        .font(.caption2.monospaced())
                        .textSelection(.enabled)
                        .lineLimit(1)
                }
                HStack {
                    Text("http://<IP-Tailscale-del-Mac>:8765/v1/ask")
                        .font(.caption2.monospaced())
                        .textSelection(.enabled)
                    Spacer()
                    Button("Regenerar token") {
                        _ = ArgosBridgeServer.regenerateToken()
                        message = "Token del puente regenerado."
                    }
                }
                Text("En el Atajo: Dictar texto → Obtener contenido de URL (POST) con {\"text\":\"Entrada de Dictar\"} → leer la propiedad reply. Si Argos necesita aprobación, la respuesta lo indicará y la acción seguirá pendiente en el Mac.")
                    .font(.caption2).foregroundStyle(.secondary).fixedSize(horizontal: false, vertical: true)
            }
            .padding(12)
            .background(.quaternary.opacity(0.35), in: RoundedRectangle(cornerRadius: 14))

            Text("Configuración externa necesaria")
                .font(.headline)
            Text("Gmail: crea en Google Cloud un cliente OAuth de tipo iOS con Bundle ID `com.danielrueda.Argos`. El redirect que usa Argos es `com.danielrueda.Argos:/oauth2redirect`; habilita Gmail API y no introduzcas un client secret en Argos. Si Google rechaza ese flujo con `redirect_uri_mismatch`, el plan B es migrar Argos a un cliente Desktop con loopback local y secreto protegido en el Llavero. Microsoft: registra Argos como aplicación nativa y concede Mail.Read, Mail.Send y Calendars.Read. GitHub usa autorización de dispositivo. WhatsApp requiere una cuenta de WhatsApp Business Cloud API, Phone Number ID y token.")
                .font(.caption)
                .foregroundStyle(.secondary)
                .fixedSize(horizontal: false, vertical: true)
        }
        .onAppear {
            reload()
        }
    }

    @ViewBuilder
    private func integrationCard<Fields: View, Actions: View>(
        title: String,
        symbol: String,
        connected: Bool,
        description: String,
        @ViewBuilder fields: () -> Fields,
        @ViewBuilder actions: () -> Actions
    ) -> some View {
        VStack(alignment: .leading, spacing: 9) {
            HStack(spacing: 10) {
                Image(systemName: symbol).frame(width: 24).foregroundStyle(.purple)
                Text(title).font(.headline)
                Spacer()
                Label(connected ? "Conectado" : "No conectado", systemImage: connected ? "checkmark.circle.fill" : "circle")
                    .font(.caption)
                    .foregroundStyle(connected ? .green : .secondary)
            }
            Text(description).font(.caption).foregroundStyle(.secondary)
            fields()
            HStack { Spacer(); actions() }
        }
        .padding(12)
        .background(.quaternary.opacity(0.35), in: RoundedRectangle(cornerRadius: 14))
    }

    private func reload() {
        gmailClientID = UserDefaults.standard.string(forKey: GmailIntegration.clientIDKey) ?? ""
        outlookClientID = UserDefaults.standard.string(forKey: OutlookIntegration.clientIDKey) ?? ""
        outlookTenant = UserDefaults.standard.string(forKey: OutlookIntegration.tenantKey) ?? "common"
        githubClientID = UserDefaults.standard.string(forKey: GitHubIntegration.clientIDKey) ?? ""
        whatsappPhoneID = UserDefaults.standard.string(forKey: WhatsAppIntegration.phoneNumberIDKey) ?? ""
        whatsappGraphVersion = UserDefaults.standard.string(forKey: WhatsAppIntegration.graphVersionKey) ?? "v23.0"
    }

    private func connectGmail() async {
        do { try await GmailIntegration.connect(); message = "Gmail conectado." }
        catch { message = "Gmail: \(error.localizedDescription)" }
    }

    private func connectOutlook() async {
        do { try await OutlookIntegration.connect(); message = "Outlook conectado." }
        catch { message = "Outlook: \(error.localizedDescription)" }
    }

    private func connectGitHub() async {
        do { try await GitHubIntegration.connect(); message = "GitHub conectado." }
        catch { message = "GitHub: \(error.localizedDescription)" }
    }
}
