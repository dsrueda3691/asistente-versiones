# Argos V10

Argos es un asistente personal nativo para macOS evolucionado desde Viernes V9. Conserva el Core de cerebro local/nube, memoria, voz, acciones del sistema y AgentMode con aprobación, y cambia la interfaz principal a un compañero que vive en el notch.

## Arquitectura

- **Core existente:** `Brain`, `Memory`, `LLMBackend`, `OllamaClient`, `OpenAIClient`, `AgentMode`, `ActionRunner`, `PendingAction`.
- **Runtime/UI:** `ArgosRuntimeState` traduce eventos del Core a estados visuales.
- **Notch:** `ArgosNotchPanelController` usa `NSPanel` + `NSHostingController`.
- **Personaje:** `ArgosCharacterView` usa SwiftUI `Canvas` + `TimelineView`, con identidad visual propia.
- **Actividad:** lista de pasos con `✓`, `●`, `○` y progreso.
- **Aprobaciones:** `PendingAction` se presenta dentro del panel expandido.
- **Contexto:** drag & drop de archivos y drag del personaje sobre una ventana para identificarla.
- **Sin dependencias de terceros.**

## Estados

Presentación: `hidden → compact → expanded`.

Actividad: `IDLE → LISTENING → THINKING → WORKING → WAITING_APPROVAL → SUCCESS/ERROR`.

## Abrir y ejecutar

1. Abre `Argos.xcodeproj` en Xcode.
2. Selecciona el target **Argos** y ejecuta en macOS 14+.
3. El compañero aparece en la zona superior; el botón de la barra de menús y el atajo global siguen disponibles.
4. En el panel expandido puedes conversar, cambiar Local/Astra/Auto, activar escucha, detener trabajos y abrir Ajustes.

## Contexto

- Arrastra un archivo al compañero para añadirlo como contexto temporal.
- Arrastra el personaje sobre una ventana y Argos registra la aplicación/título como contexto.
- El contexto no se guarda automáticamente en memoria persistente.

## Agente

El flujo existente permanece: captura → plan de hasta 5 pasos → `PendingAction` → aprobación → ejecución → progreso. La UI solo consume eventos; no reimplementa la lógica del agente.

## Seguridad

Las aprobaciones siguen pasando por `PendingAction`. El agente conserva las restricciones existentes de V9 y no se añadió shell ni borrado arbitrario.

## Referencia de UX

La experiencia de notch toma ideas de Coucou de Louis-CFM, pero Argos usa nombre, personaje, iconos, sonidos y medios propios.
