import Foundation

/// Memoria de conversación con persistencia local (Application Support).
/// Últimos ~12–16 turnos, recorte por turno y tope total. `lastDraft` sobrevive respuestas cortas
/// y también al quit (JSON en disco). No sincroniza a iCloud ni a la nube.
@MainActor
final class ConversationMemory {
    static let maxTurns = 16
    static let maxCharsPerTurn = 4_000
    static let maxTotalChars = 24_000
    /// Un detalle cuenta como borrador largo si supera este umbral.
    static let draftMinChars = 220

    struct Turn: Equatable {
        enum Role: String, Codable {
            case user
            case assistant
        }
        let role: Role
        let content: String
    }

    private struct PersistedPayload: Codable {
        var turns: [PersistedTurn]
        var lastDraft: String?
    }

    private struct PersistedTurn: Codable {
        var role: String
        var content: String
    }

    private(set) var turns: [Turn] = []
    /// Último texto largo del asistente (ensayo, ideas, documento). No lo pisan los «listo».
    private(set) var lastDraft: String? = nil

    private var saveWorkItem: DispatchWorkItem?
    private let saveDebounce: TimeInterval = 0.35

    var isEmpty: Bool { turns.isEmpty && lastDraft == nil }

    /// `~/Library/Application Support/Argos/session-memory.json`
    static var storageURL: URL {
        let base = FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask).first
            ?? URL(fileURLWithPath: NSHomeDirectory()).appendingPathComponent("Library/Application Support")
        let dir = base.appendingPathComponent("Argos", isDirectory: true)
        return dir.appendingPathComponent("session-memory.json")
    }

    func loadFromDisk() {
        let url = Self.storageURL
        guard FileManager.default.fileExists(atPath: url.path) else { return }
        do {
            let data = try Data(contentsOf: url)
            let payload = try JSONDecoder().decode(PersistedPayload.self, from: data)
            turns = payload.turns.compactMap { row in
                guard let role = Turn.Role(rawValue: row.role) else { return nil }
                return Turn(role: role, content: row.content)
            }
            lastDraft = payload.lastDraft
            trimToBudget()
        } catch {
            // Archivo corrupto: empezar limpio sin tumbar la app.
            turns = []
            lastDraft = nil
        }
    }

    func reset() {
        turns.removeAll(keepingCapacity: false)
        lastDraft = nil
        saveWorkItem?.cancel()
        saveWorkItem = nil
        deletePersistedFile()
    }

    func appendUser(_ text: String) {
        let clipped = Self.clip(text, limit: Self.maxCharsPerTurn)
        guard !clipped.isEmpty else { return }
        turns.append(Turn(role: .user, content: clipped))
        trimToBudget()
        scheduleSave()
    }

    /// Registra la respuesta. Si `detail` es largo, actualiza `lastDraft`.
    func appendAssistant(speak: String, detail: String?) {
        let detailTrim = detail?.trimmingCharacters(in: .whitespacesAndNewlines) ?? ""
        let speakTrim = speak.trimmingCharacters(in: .whitespacesAndNewlines)

        if detailTrim.count >= Self.draftMinChars {
            lastDraft = Self.clip(detailTrim, limit: Self.maxCharsPerTurn * 4)
        } else if speakTrim.count >= Self.draftMinChars && detailTrim.isEmpty {
            // Respuesta larga solo en speak (sin JSON detail).
            lastDraft = Self.clip(speakTrim, limit: Self.maxCharsPerTurn * 4)
        }

        var stored = speakTrim
        if !detailTrim.isEmpty {
            if detailTrim.count > 600 {
                stored = speakTrim + "\n[DETALLE]\n" + Self.clip(detailTrim, limit: Self.maxCharsPerTurn - speakTrim.count - 20)
            } else {
                stored = speakTrim + (speakTrim.isEmpty ? "" : "\n") + detailTrim
            }
        }
        stored = Self.clip(stored, limit: Self.maxCharsPerTurn)
        guard !stored.isEmpty else { return }
        turns.append(Turn(role: .assistant, content: stored))
        trimToBudget()
        scheduleSave()
    }

    /// Mensajes para /api/chat (sin system). Roles user/assistant.
    func chatMessages(excludingLastUser: Bool = false) -> [(role: String, content: String)] {
        var list = turns
        if excludingLastUser, list.last?.role == .user {
            list.removeLast()
        }
        return list.map { ($0.role.rawValue, $0.content) }
    }

    /// Bloque de texto compacto para prompts que no aceptan historial nativo.
    func contextBlock(maxChars: Int = 8_000) -> String {
        if turns.isEmpty {
            if let draft = lastDraft, !draft.isEmpty {
                return "Borrador vigente (lastDraft):\n" + Self.clip(draft, limit: min(maxChars, 6_000))
            }
            return ""
        }
        var lines: [String] = []
        for t in turns {
            let label = t.role == .user ? "Usuario" : "Argos"
            lines.append("\(label): \(t.content)")
        }
        if let draft = lastDraft, !draft.isEmpty {
            lines.append("Borrador vigente (lastDraft):\n" + Self.clip(draft, limit: 4_000))
        }
        return Self.clip(lines.joined(separator: "\n"), limit: maxChars)
    }

    /// Guarda de inmediato (p. ej. al salir).
    func flushSave() {
        saveWorkItem?.cancel()
        saveWorkItem = nil
        saveNow()
    }

    private func scheduleSave() {
        saveWorkItem?.cancel()
        let work = DispatchWorkItem { [weak self] in
            Task { @MainActor in
                self?.saveNow()
            }
        }
        saveWorkItem = work
        DispatchQueue.main.asyncAfter(deadline: .now() + saveDebounce, execute: work)
    }

    private func saveNow() {
        let url = Self.storageURL
        let dir = url.deletingLastPathComponent()
        do {
            try FileManager.default.createDirectory(at: dir, withIntermediateDirectories: true)
            let payload = PersistedPayload(
                turns: turns.map { PersistedTurn(role: $0.role.rawValue, content: $0.content) },
                lastDraft: lastDraft
            )
            let data = try JSONEncoder().encode(payload)
            try data.write(to: url, options: [.atomic])
        } catch {
            // Silencioso: la memoria en RAM sigue válida.
        }
    }

    private func deletePersistedFile() {
        let url = Self.storageURL
        try? FileManager.default.removeItem(at: url)
    }

    private func trimToBudget() {
        while turns.count > Self.maxTurns {
            turns.removeFirst()
        }
        var total = turns.reduce(0) { $0 + $1.content.count }
        while total > Self.maxTotalChars, turns.count > 2 {
            let removed = turns.removeFirst()
            total -= removed.content.count
        }
    }

    private static func clip(_ text: String, limit: Int) -> String {
        let t = text.trimmingCharacters(in: .whitespacesAndNewlines)
        guard t.count > limit else { return t }
        return String(t.prefix(limit)) + "…"
    }
}
