import SwiftUI
import AppKit
import AVFoundation
import Speech
import ServiceManagement

@main
struct ArgosApp: App {
    @NSApplicationDelegateAdaptor(AppDelegate.self) private var appDelegate

    var body: some Scene {
        Settings {
            SettingsHelpView(
                state: appDelegate.state,
                onHotkeyChange: { cfg in
                    appDelegate.applyHotkey(cfg)
                },
                onWakeWordChange: { enabled in
                    appDelegate.setWakeWordEnabled(enabled)
                }
            )
        }
    }
}

@MainActor
final class AppDelegate: NSObject, NSApplicationDelegate {
    private var statusBar: StatusBarController?
    let state = AppState()
    let listener = Listener()
    let speaker = Speaker()
    let parser = IntentParser()
    let runner = ActionRunner()
    let brain = Brain()
    let keyboard = KeyboardController()
    let memory = ConversationMemory()
    let wakeWord = WakeWordMonitor()
    let handsFree = HandsFreeSession()
    lazy var agent = AgentMode(brain: brain)
    let runtime = ArgosRuntimeState()
    lazy var notch: ArgosNotchPanelController = {
        ArgosNotchPanelController(
            state: state,
            runtime: runtime,
            onListen: { [weak self] in self?.toggleListening() },
            onSendChat: { [weak self] text in self?.submitTyped(text) },
            onToggleMute: { [weak self] in self?.toggleMute() },
            onStopJob: { [weak self] in self?.stopJobs() },
            onOpenSettings: { [weak self] in self?.openSettings() },
            onProviderChange: { [weak self] raw in self?.setBrainProvider(raw) },
            onConfirmPending: { [weak self] in self?.confirmPending() },
            onCancelPending: { [weak self] in self?.cancelPending() },
            onToggleWakeWord: { [weak self] in self?.toggleWakeWord() },
            onEndHandsFree: { [weak self] in self?.endHandsFreeSession(spoken: "Manos libres OFF.") },
            onFileDrop: { [weak self] url in self?.handleFileDrop(url) },
            onWindowContext: { [weak self] context in self?.handleWindowContext(context) }
        )
    }()
    private var idleStatusTimer: Timer?
    private var handsFreeFollowUpTask: Task<Void, Never>?

    func applicationDidFinishLaunching(_ notification: Notification) {
        NSApp.setActivationPolicy(.accessory)
        refreshModelLabels()
        state.isMuted = UserDefaults.standard.bool(forKey: AppState.mutedDefaultsKey)
        state.brainProvider = BrainProvider.current.rawValue
        state.hasAPIKey = KeychainHelper.hasOpenAIKey()
        state.hotkeyDisplay = HotkeyConfig.current.display
        state.wakeWordEnabled = UserDefaults.standard.bool(forKey: AppState.wakeWordDefaultsKey)
        state.handsFreePreference = HandsFreeSession.isPreferenceEnabled
        state.openAtLogin = LoginItemManager.isEnabledPreference
        state.openAtLoginRegistered = LoginItemManager.isRegistered
        runtime.resetActivity()
        runtime.presentation = .compact

        memory.loadFromDisk()
        agent.draftProvider = { [weak self] in self?.memory.lastDraft }

        speaker.onSpeakingChanged = { [weak self] speaking in
            guard let self else { return }
            self.state.isSpeaking = speaking
            self.syncWakeWordPause()
            self.syncHandsFreePauseFlags()
        }
        listener.onPartialTranscript = { [weak self] text in
            self?.state.transcript = text
        }
        handsFree.onEnded = { [weak self] spoken in
            guard let self else { return }
            self.state.isHandsFreeActive = false
            self.state.statusMessage = SystemPresence.idleStatusHint()
            if !spoken.isEmpty {
                self.state.lastReply = spoken
                self.speakReply(spoken)
            }
            self.syncWakeWordPause()
        }
        configureWakeWord()
        statusBar = StatusBarController(
            state: state,
            notch: notch,
            onListen: { [weak self] in self?.toggleListening() },
            onQuit: { [weak self] in self?.quitApp() }
        )
        notch.showCompact()
        keyboard.onProgress = { [weak self] msg in
            guard let self else { return }
            self.state.statusMessage = msg
            self.state.isKeyboardJobRunning = true
            self.runtime.activity = .working
            self.runtime.consumeProgress(msg)
            self.pauseHandsFreeForWork()
            self.syncWakeWordPause()
            self.notch.showForActivity()
        }
        agent.onProgress = { [weak self] msg in
            guard let self else { return }
            self.state.statusMessage = msg
            self.state.isAgentRunning = true
            self.runtime.activity = .working
            self.runtime.consumeProgress(msg)
            self.pauseHandsFreeForWork()
            self.syncWakeWordPause()
            self.notch.showForActivity()
        }
        // Presencia Argos V10 (una vez al lanzar).
        speakReply("Argos en línea. Sistemas listos.")
        state.statusMessage = SystemPresence.idleStatusHint()
        startIdleStatusTimer()
        if state.wakeWordEnabled {
            wakeWord.setEnabled(true)
        }
    }

    func applicationWillTerminate(_ notification: Notification) {
        idleStatusTimer?.invalidate()
        handsFreeFollowUpTask?.cancel()
        keyboard.cancel()
        agent.cancel()
        if handsFree.isActive {
            handsFree.end(spoken: "")
            state.isHandsFreeActive = false
        }
        wakeWord.setEnabled(false)
        listener.stopListening()
        speaker.stop()
        memory.flushSave()
    }

    func applyHotkey(_ config: HotkeyConfig) {
        statusBar?.applyHotkey(config)
        state.hotkeyDisplay = config.display
    }

    private func configureWakeWord() {
        wakeWord.onWakeDetected = { [weak self] in
            self?.handleWakeWord()
        }
        wakeWord.onPermissionDenied = { [weak self] message in
            guard let self else { return }
            self.state.wakeWordEnabled = false
            self.state.isWakeListening = false
            self.state.lastReply = message
            self.state.statusMessage = "Wake word off"
            self.speakReply(message)
        }
        wakeWord.onListeningChanged = { [weak self] listening in
            self?.state.isWakeListening = listening
            if listening, self?.state.isListening == false,
               self?.state.isSpeaking == false,
               self?.state.isKeyboardJobRunning == false,
               self?.state.isAgentRunning == false {
                self?.state.statusMessage = "Escuchando wake…"
            }
        }
    }

    func toggleWakeWord() {
        setWakeWordEnabled(!state.wakeWordEnabled)
    }

    func setWakeWordEnabled(_ enabled: Bool) {
        state.wakeWordEnabled = enabled
        UserDefaults.standard.set(enabled, forKey: AppState.wakeWordDefaultsKey)
        if enabled {
            wakeWord.setEnabled(true)
            if !state.isListening && !state.isSpeaking && !state.isKeyboardJobRunning && !state.isAgentRunning {
                state.statusMessage = "Escuchando wake…"
            }
        } else {
            wakeWord.setEnabled(false)
            state.isWakeListening = false
            if state.statusMessage == "Escuchando wake…" {
                state.statusMessage = "Listo"
            }
        }
    }

    /// Pausa wake durante comando / TTS / teclado / agente; reanuda cuando todo está libre.
    func syncWakeWordPause() {
        guard state.wakeWordEnabled else { return }
        let busy = state.isListening || state.isSpeaking || state.isKeyboardJobRunning || state.isAgentRunning
        if busy {
            wakeWord.pause()
        } else {
            wakeWord.resumeIfNeeded()
        }
    }

    private func handleWakeWord() {
        wakeWord.noteWakeHandled()
        state.isWakeListening = false
        statusBar?.showpanel()
        state.transcript = ""
        // Wake → manos libres si la preferencia está ON (default ON).
        if HandsFreeSession.isPreferenceEnabled {
            beginHandsFreeSession(announce: false)
        }
        let ack = Bool.random() ? "Sí." : "Te escucho."
        if !state.isMuted {
            speakReply(ack)
            Task { @MainActor in
                var waited = 0.0
                while self.state.isSpeaking && waited < 2.5 {
                    try? await Task.sleep(nanoseconds: 100_000_000)
                    waited += 0.1
                }
                try? await Task.sleep(nanoseconds: 150_000_000)
                self.startListening(fromWake: true)
            }
        } else {
            startListening(fromWake: true)
        }
    }

    func refreshModelLabels() {
        state.ollamaModel = OllamaClient.configuredModelName
        state.visionModel = OllamaClient.configuredVisionModelName
        state.openaiModel = OpenAIClient.configuredModelName
        state.modeLine = brain.modeLineLabel
        state.hasAPIKey = KeychainHelper.hasOpenAIKey()
        state.hotkeyDisplay = HotkeyConfig.current.display
    }

    func setBrainProvider(_ raw: String) {
        let provider = BrainProvider(rawValue: raw) ?? .auto
        BrainProvider.setCurrent(provider)
        state.brainProvider = provider.rawValue
        refreshModelLabels()
    }

    func stopJobs() {
        if state.isAgentRunning || agent.isRunning {
            agent.cancel()
            state.isAgentRunning = false
            // Si hay plan pendiente sin ejecutar, también cancelar
            if case .agent = state.pendingAction {
                clearPending()
            }
            let reply = "Agente detenido."
            state.lastReply = reply
            state.statusMessage = "Listo"
            runtime.markSuccess(reply)
            speakReply(reply)
            resumeHandsFreeAfterWork()
            syncWakeWordPause()
            return
        }
        keyboard.cancel()
        state.isKeyboardJobRunning = false
        state.statusMessage = SystemPresence.idleStatusHint()
        let reply = "Paré el trabajo de teclado."
        state.lastReply = reply
        speakReply(reply)
        resumeHandsFreeAfterWork()
        syncWakeWordPause()
    }

    func openSettings() {
        state.hasAPIKey = KeychainHelper.hasOpenAIKey()
        NSApp.sendAction(Selector(("showSettingsWindow:")), to: nil, from: nil)
        NSApp.activate(ignoringOtherApps: true)
    }

    func toggleMute() {
        state.isMuted.toggle()
        UserDefaults.standard.set(state.isMuted, forKey: AppState.mutedDefaultsKey)
        if state.isMuted {
            speaker.stop()
            state.isSpeaking = false
        }
    }

    func speakReply(_ text: String) {
        speaker.speak(text, muted: state.isMuted)
        if state.isMuted {
            state.isSpeaking = false
        }
    }

    func submitTyped(_ text: String) {
        let trimmed = text.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmed.isEmpty else { return }
        if state.isListening {
            listener.stopListening()
            state.isListening = false
        }
        speaker.stop()
        state.transcript = trimmed
        runtime.activity = .thinking
        notch.showForActivity()
        Task { @MainActor in
            await self.handle(phrase: trimmed)
        }
    }

    func toggleListening() {
        if state.isListening {
            listener.stopListening()
            state.isListening = false
            state.statusMessage = state.isHandsFreeActive ? "Manos libres ON" : SystemPresence.idleStatusHint()
            syncWakeWordPause()
            return
        }
        // Hotkey / icono: entra a manos libres si la preferencia está ON.
        if HandsFreeSession.isPreferenceEnabled && !handsFree.isActive {
            beginHandsFreeSession(announce: false)
        }
        startListening(fromWake: false)
    }

    func startListening(fromWake: Bool = false) {
        wakeWord.pause()
        handsFreeFollowUpTask?.cancel()
        if !fromWake {
            speaker.stop()
        }
        state.isListening = true
        runtime.activity = .listening
        state.statusMessage = state.isHandsFreeActive ? "Manos libres · te escucho…" : "Te escucho…"
        state.transcript = ""
        statusBar?.showpanel()
        let sessionGen = handsFree.currentGeneration
        let inHandsFree = handsFree.isActive && !handsFree.isPaused

        Task { @MainActor in
            let permitted = await PermissionGate.requestSpeechAndMicrophone()
            guard permitted else {
                self.state.isListening = false
                self.state.statusMessage = "Faltan permisos"
                let reply = "Necesito micrófono y reconocimiento de voz. Actívalos en Ajustes del Sistema."
                self.state.lastReply = reply
                self.speakReply(reply)
                self.syncWakeWordPause()
                return
            }

            do {
                // Manos libres: timeout largo (~28 s) sin habla → fin de sesión.
                // Wake/comando puntual: ~8–12 s.
                let maxDur: TimeInterval = inHandsFree ? HandsFreeSession.silenceTimeout : (fromWake ? 10 : 12)
                let phrase = try await self.listener.listen(maxDuration: maxDur)
                self.state.transcript = phrase
                self.state.isListening = false
                if phrase.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
                    if inHandsFree && self.handsFree.isActive && self.handsFree.currentGeneration == sessionGen {
                        self.endHandsFreeSession(spoken: "Silencio. Vuelvo a modo normal.")
                        return
                    }
                    let reply = "No te escuché. Prueba otra vez."
                    self.state.lastReply = reply
                    self.state.statusMessage = SystemPresence.idleStatusHint()
                    self.speakReply(reply)
                    self.syncWakeWordPause()
                    return
                }
                await self.handle(phrase: phrase)
            } catch {
                self.state.isListening = false
                if inHandsFree, let listenError = error as? ListenerError, case .timeout = listenError {
                    if self.handsFree.isActive && self.handsFree.currentGeneration == sessionGen {
                        self.endHandsFreeSession(spoken: "Silencio. Vuelvo a modo normal.")
                        return
                    }
                }
                let reply: String
                if let listenError = error as? ListenerError {
                    reply = listenError.userMessage
                } else {
                    reply = "No pude escucharte. Revisa el micrófono."
                }
                self.state.lastReply = reply
                self.state.statusMessage = self.state.isHandsFreeActive ? "Manos libres ON" : SystemPresence.idleStatusHint()
                self.speakReply(reply)
                self.scheduleHandsFreeFollowUpIfNeeded()
                self.syncWakeWordPause()
            }
        }
    }

    // MARK: - Intent routing

    func handle(phrase: String) async {
        // Confirmación tipada SOLO mientras hay pending.
        if state.pendingAction != nil {
            let cleaned = IntentParser.stripVocative(IntentParser.normalize(phrase))
            if Self.isConfirmPhrase(cleaned) {
                confirmPending()
                return
            }
            if Self.isCancelPhrase(cleaned) {
                cancelPending()
                return
            }
        }

        let cleaned = IntentParser.stripVocative(IntentParser.normalize(phrase))

        // En manos libres: «adiós» / frases de fin cierran la sesión (no salen de la app).
        if handsFree.isActive {
            if HandsFreeSession.isEndPhrase(cleaned) || cleaned == "adios" || cleaned.hasPrefix("adios ") {
                endHandsFreeSession(spoken: "Manos libres OFF. Modo normal.")
                return
            }
        }

        memory.appendUser(phrase)
        state.statusMessage = "Pensando…"
        refreshModelLabels()
        let intent = parser.parse(phrase)

        // Fuera de manos libres, «adiós» sigue siendo quit (Intent.quit).
        // Dentro ya lo interceptamos arriba.
        await dispatch(intent, fallbackPhrase: phrase)
    }

    private func dispatch(_ intent: Intent, fallbackPhrase: String) async {
        switch intent {
        case .handsFreeStart:
            beginHandsFreeSession(announce: true)
        case .handsFreeEnd:
            if handsFree.isActive {
                endHandsFreeSession(spoken: "Modo normal.")
            } else {
                finishReply(spoken: "No hay sesión manos libres activa. Di «modo manos libres» o usa el atajo.", detail: nil)
            }
        case .systemStatus:
            handleSystemStatus()
        case .understandMedia(let phrase):
            await handleUnderstandMedia(phrase: phrase)
        case .resetMemory:
            memory.reset()
            finishReply(spoken: "Memoria de esta conversación borrada. Empezamos de cero.", detail: nil)
        case .exportCopyDraft:
            handleExportCopy()
        case .exportSaveDraft(let filename):
            handleExportSave(filename: filename)
        case .exportPasteDraft:
            await handleExportPaste()
        case .readDocument(let phrase):
            await handleReadDocument(phrase: phrase)
        case .analyzeScreen(let question):
            await handleAnalyzeScreen(question: question)
        case .keyboardJob(let instruction):
            await handleKeyboardJob(instruction: instruction)
        case .composeMail(let to, let subject, let body, let cc):
            presentPending(.mail(PendingMail(to: to, subject: subject, body: body, cc: cc)))
        case .createCalendarEvent(let title, let startHint, let endHint, let notes, let location):
            presentCalendarDraft(title: title, startHint: startHint, endHint: endHint, notes: notes, location: location)
        case .createReminder(let title, let dueHint):
            presentReminderDraft(title: title, dueHint: dueHint)
        case .listReminders:
            await handleListReminders()
        case .createNote(let title, let body):
            handleCreateNote(title: title, body: body)
        case .agentMode(let goal):
            await handleAgentPlan(goal: goal)
        case .unknown:
            await handleUnknown(phrase: fallbackPhrase)
        case .quit where handsFree.isActive:
            // Cinturón: no salir de la app desde manos libres.
            endHandsFreeSession(spoken: "Manos libres OFF. Modo normal.")
        default:
            let outcome = await runner.run(intent)
            finishReply(spoken: outcome.spoken, detail: outcome.detail)
            if outcome.shouldQuit {
                DispatchQueue.main.asyncAfter(deadline: .now() + 1.6) {
                    NSApp.terminate(nil)
                }
            }
        }
    }

    /// Actualiza UI, memoria y voz; en manos libres re-escucha tras TTS.
    private func finishReply(spoken: String, detail: String?) {
        runtime.markSuccess(spoken)
        state.lastReply = spoken
        state.detail = detail ?? ""
        if state.isHandsFreeActive && state.pendingAction == nil {
            state.statusMessage = "Manos libres ON"
        } else if state.pendingAction == nil {
            state.statusMessage = SystemPresence.idleStatusHint()
        }
        memory.appendAssistant(speak: spoken, detail: detail)
        speakReply(spoken)
        if state.isMuted {
            syncWakeWordPause()
            scheduleHandsFreeFollowUpIfNeeded()
        } else {
            // onSpeakingChanged(false) también dispara follow-up.
            scheduleHandsFreeFollowUpIfNeeded()
        }
        Task { @MainActor in
            try? await Task.sleep(nanoseconds: 1_600_000_000)
            if self.state.pendingAction == nil && !self.state.isAgentRunning && !self.state.isKeyboardJobRunning {
                self.runtime.resetActivity()
            }
        }
    }


    private static func isConfirmPhrase(_ s: String) -> Bool {
        let keys = [
            "confirma envio", "confirma el envio", "si envia", "si envialo",
            "enviar", "envia", "envialo", "si", "confirmar", "confirma",
            "send", "confirm", "yes", "dale", "ok", "de acuerdo"
        ]
        return keys.contains(s) || s.hasPrefix("confirma") || s == "si envia" || s == "dale envia"
    }

    private static func isCancelPhrase(_ s: String) -> Bool {
        let keys = [
            "cancelar", "cancela", "cancelado", "no", "no envies", "no enviar",
            "descarta", "descartar", "olvidalo", "cancel"
        ]
        return keys.contains(s) || s.hasPrefix("no env")
    }

    // MARK: - Pending confirmations

    func presentPending(_ action: PendingAction) {
        pauseHandsFreeForWork()
        state.pendingAction = action
        state.lastReply = action.speakPrompt
        state.detail = action.detailSummary
        state.statusMessage = action.statusLabel
        runtime.activity = .waitingApproval
        if case .agent(let plan) = action { runtime.beginPlan(plan) }
        notch.expand()
        memory.appendAssistant(speak: action.speakPrompt, detail: action.detailSummary)
        speakReply(action.speakPrompt)
    }

    func clearPending() {
        state.pendingAction = nil
    }

    func confirmPending() {
        guard let pending = state.pendingAction else {
            let reply = "No hay nada pendiente por confirmar."
            state.lastReply = reply
            speakReply(reply)
            return
        }
        switch pending {
        case .mail(let draft):
            confirmMail(draft)
        case .calendar(let event):
            Task { @MainActor in await self.confirmCalendar(event) }
        case .reminder(let rem):
            Task { @MainActor in await self.confirmReminder(rem) }
        case .agent(let plan):
            Task { @MainActor in await self.confirmAgent(plan) }
        }
    }

    func cancelPending() {
        clearPending()
        state.isAgentRunning = false
        runtime.markSuccess("Cancelado")
        resumeHandsFreeAfterWork()
        finishReply(spoken: "Cancelado.", detail: nil)
    }

    private func confirmMail(_ draft: PendingMail) {
        state.statusMessage = "Enviando…"
        do {
            let spoken = try MailSender.send(draft)
            clearPending()
            resumeHandsFreeAfterWork()
            finishReply(spoken: spoken, detail: nil)
        } catch let err as MailSendError {
            state.lastReply = err.userMessage
            state.detail = draft.summary + "\n\nError: \(err.userMessage)"
            state.statusMessage = "Error al enviar"
            speakReply(err.userMessage)
        } catch {
            state.lastReply = "No pude enviar el correo."
            state.statusMessage = "Error al enviar"
            speakReply("No pude enviar el correo.")
        }
    }

    private func presentCalendarDraft(title: String, startHint: String, endHint: String, notes: String?, location: String?) {
        var args: [String: String] = ["start": startHint]
        if !endHint.isEmpty { args["end"] = endHint }
        let pair = CalendarService.parseStartEnd(from: args) ?? (
            Date().addingTimeInterval(3600),
            Date().addingTimeInterval(7200)
        )
        let event = PendingCalendarEvent(
            title: title.isEmpty ? "Evento" : title,
            start: pair.0,
            end: pair.1,
            notes: notes,
            location: location
        )
        presentPending(.calendar(event))
    }

    private func confirmCalendar(_ event: PendingCalendarEvent) async {
        state.statusMessage = "Creando evento…"
        do {
            let spoken = try await CalendarService.createEvent(event)
            clearPending()
            resumeHandsFreeAfterWork()
            finishReply(spoken: spoken, detail: event.summary)
        } catch let err as CalendarServiceError {
            state.lastReply = err.userMessage
            state.detail = event.summary + "\n\n" + err.userMessage
            state.statusMessage = "Error"
            speakReply(err.userMessage)
        } catch {
            state.lastReply = "No pude crear el evento."
            state.statusMessage = "Error"
            speakReply("No pude crear el evento.")
        }
    }

    private func presentReminderDraft(title: String, dueHint: String?) {
        var due: Date? = nil
        if let dueHint, let d = CalendarService.parseLooseDate(dueHint, relativeTo: Date()) {
            due = d
        }
        let rem = PendingReminder(title: title.isEmpty ? "Recordatorio" : title, due: due)
        presentPending(.reminder(rem))
    }

    private func confirmReminder(_ rem: PendingReminder) async {
        state.statusMessage = "Creando recordatorio…"
        do {
            let spoken = try await RemindersService.createReminder(rem)
            clearPending()
            resumeHandsFreeAfterWork()
            finishReply(spoken: spoken, detail: rem.summary)
        } catch let err as RemindersServiceError {
            state.lastReply = err.userMessage
            state.detail = rem.summary + "\n\n" + err.userMessage
            state.statusMessage = "Error"
            speakReply(err.userMessage)
        } catch {
            state.lastReply = "No pude crear el recordatorio."
            state.statusMessage = "Error"
            speakReply("No pude crear el recordatorio.")
        }
    }

    private func handleListReminders() async {
        state.statusMessage = "Revisando recordatorios…"
        do {
            let result = try await RemindersService.listUpcoming()
            finishReply(spoken: result.spoken, detail: result.detail)
        } catch let err as RemindersServiceError {
            finishReply(spoken: err.userMessage, detail: nil)
        } catch {
            finishReply(spoken: "No pude leer los recordatorios.", detail: nil)
        }
    }

    private func handleCreateNote(title: String, body: String) {
        state.statusMessage = "Creando nota…"
        do {
            let spoken = try NotesService.createNote(title: title, body: body)
            finishReply(spoken: spoken, detail: "Título: \(title)\n\(body)")
        } catch let err as NotesServiceError {
            finishReply(spoken: err.userMessage, detail: nil)
        } catch {
            finishReply(spoken: "No pude crear la nota.", detail: nil)
        }
    }

    private func handleAgentPlan(goal: String) async {
        pauseHandsFreeForWork()
        state.statusMessage = "Capturando pantalla…"
        runtime.activity = .thinking
        state.isAgentRunning = true
        do {
            let jpeg = try await ScreenCapture.captureMainDisplayJPEG()
            state.statusMessage = "Planificando…"
            let plan = try await agent.plan(goal: goal, imageJPEG: jpeg)
            state.isAgentRunning = false
            presentPending(.agent(plan))
        } catch let err as ScreenCaptureError {
            state.isAgentRunning = false
            state.lastReply = err.userMessage
            state.detail = "Ajustes → Privacidad y seguridad → Grabación de pantalla → Argos."
            state.statusMessage = "Listo"
            speakReply(err.userMessage)
        } catch let err as AgentModeError {
            state.isAgentRunning = false
            state.lastReply = err.userMessage
            state.detail = ""
            state.statusMessage = "Listo"
            speakReply(err.userMessage)
        } catch {
            state.isAgentRunning = false
            state.lastReply = "No pude preparar el plan del agente."
            state.statusMessage = "Listo"
            speakReply("No pude preparar el plan del agente.")
        }
    }

    private func confirmAgent(_ plan: PendingAgentPlan) async {
        clearPending()
        state.isAgentRunning = true
        runtime.activity = .working
        runtime.beginPlan(plan)
        state.statusMessage = "Agente en curso…"
        notch.expand()
        let result = await agent.execute(plan: plan, keyboard: keyboard) { [weak self] question, jpeg in
            guard let self else { return "Sin contexto." }
            let reply = await self.brain.analyzeScreen(question: question, imageJPEG: jpeg)
            return reply.speak
        }
        state.isAgentRunning = false
        resumeHandsFreeAfterWork()
        finishReply(spoken: result.spoken, detail: result.detail)
    }


    // MARK: - V10 hands-free / media / presence

    func setHandsFreePreference(_ enabled: Bool) {
        HandsFreeSession.isPreferenceEnabled = enabled
        state.handsFreePreference = enabled
        if !enabled && handsFree.isActive {
            endHandsFreeSession(spoken: "Manos libres desactivado.")
        }
    }

    func setOpenAtLogin(_ enabled: Bool) {
        let result = LoginItemManager.setOpenAtLogin(enabled)
        state.openAtLogin = enabled
        state.openAtLoginRegistered = LoginItemManager.isRegistered
        state.lastReply = result.message
        if !result.ok {
            state.detail = result.message
        }
        speakReply(result.message)
    }

    func beginHandsFreeSession(announce: Bool) {
        handsFree.start()
        state.isHandsFreeActive = true
        state.handsFreePreference = HandsFreeSession.isPreferenceEnabled
        if announce {
            finishReply(spoken: "Manos libres ON. Te escucho sin repetir el wake. Di «adiós» o «corta» para salir.", detail: nil)
        } else {
            state.statusMessage = "Manos libres ON"
        }
    }

    func endHandsFreeSession(spoken: String) {
        handsFreeFollowUpTask?.cancel()
        if state.isListening {
            listener.stopListening()
            state.isListening = false
        }
        handsFree.end(spoken: spoken)
        state.isHandsFreeActive = false
        state.statusMessage = SystemPresence.idleStatusHint()
        syncWakeWordPause()
    }

    private func pauseHandsFreeForWork() {
        guard handsFree.isActive else { return }
        handsFree.pause()
        handsFreeFollowUpTask?.cancel()
        if state.isListening {
            listener.stopListening()
            state.isListening = false
        }
    }

    private func resumeHandsFreeAfterWork() {
        guard handsFree.isActive else { return }
        handsFree.resume()
        scheduleHandsFreeFollowUpIfNeeded()
    }

    private func syncHandsFreePauseFlags() {
        // Cuando termina TTS, re-escuchar si la sesión sigue activa.
        if !state.isSpeaking {
            scheduleHandsFreeFollowUpIfNeeded()
        }
    }

    private func scheduleHandsFreeFollowUpIfNeeded() {
        guard handsFree.isActive, !handsFree.isPaused else { return }
        guard state.pendingAction == nil else { return }
        guard !state.isKeyboardJobRunning, !state.isAgentRunning else { return }
        guard !state.isListening else { return }
        handsFreeFollowUpTask?.cancel()
        let gen = handsFree.currentGeneration
        handsFreeFollowUpTask = Task { @MainActor in
            // Esperar a que TTS termine.
            var waited = 0.0
            while self.state.isSpeaking && waited < 60 {
                try? await Task.sleep(nanoseconds: 120_000_000)
                waited += 0.12
                if Task.isCancelled { return }
            }
            try? await Task.sleep(nanoseconds: 280_000_000)
            guard !Task.isCancelled else { return }
            guard self.handsFree.isActive, !self.handsFree.isPaused else { return }
            guard self.handsFree.currentGeneration == gen else { return }
            guard self.state.pendingAction == nil else { return }
            guard !self.state.isKeyboardJobRunning, !self.state.isAgentRunning else { return }
            guard !self.state.isListening else { return }
            self.startListening(fromWake: false)
        }
    }

    private func handleSystemStatus() {
        let report = SystemPresence.statusLine(
            muted: state.isMuted,
            wakeOn: state.wakeWordEnabled,
            handsFreeOn: state.handsFreePreference,
            handsFreeActive: state.isHandsFreeActive,
            brainMode: state.modeLine
        )
        finishReply(spoken: report.spoken, detail: report.detail)
    }

    private func handleUnderstandMedia(phrase: String) async {
        state.statusMessage = "Procesando media…"
        do {
            let result = try await MediaUnderstander.understand(phrase: phrase)
            state.statusMessage = "Pensando…"
            let history = memory.chatMessages(excludingLastUser: true).map {
                ChatMessage(role: $0.role, content: $0.content)
            }
            let headerNote = result.truncated
                ? " (excerpt: primeros ~\(Int(MediaUnderstander.maxSeconds / 60)) min; audio→texto, sin visión frame a frame)"
                : " (audio→texto local; sin visión frame a frame)"
            let reply = await brain.askAboutDocument(
                phrase: phrase,
                sourceLabel: "\(result.sourceLabel) vía \(result.engine)" + headerNote,
                documentText: result.transcript,
                history: history
            )
            if let label = reply.usedBackendLabel {
                state.modeLine = label
            } else {
                refreshModelLabels()
            }
            var detail = "Fuente: \(result.sourceLabel)\nMotor: \(result.engine)"
            if result.truncated { detail += "\nNota: transcripción truncada (excerpt)." }
            detail += "\n\n--- Transcripción ---\n" + String(result.transcript.prefix(6_000))
            if let d = reply.detail, !d.isEmpty {
                detail += "\n\n--- Respuesta ---\n" + d
            }
            let spoken = result.truncated
                ? reply.speak + " (Es un extracto del audio; no vi el video cuadro a cuadro.)"
                : reply.speak
            finishReply(spoken: spoken, detail: detail)
        } catch let err as MediaUnderstander.MediaError {
            finishReply(spoken: err.userMessage, detail: MediaUnderstander.installHintSpanish())
        } catch {
            finishReply(spoken: "No pude entender el audio o video.", detail: nil)
        }
    }

    private func startIdleStatusTimer() {
        idleStatusTimer?.invalidate()
        idleStatusTimer = Timer.scheduledTimer(withTimeInterval: 8, repeats: true) { [weak self] _ in
            Task { @MainActor in
                guard let self else { return }
                guard !self.state.isListening, !self.state.isSpeaking,
                      !self.state.isKeyboardJobRunning, !self.state.isAgentRunning,
                      self.state.pendingAction == nil else { return }
                if self.state.isHandsFreeActive {
                    if self.state.statusMessage.hasPrefix("Manos libres") { return }
                    self.state.statusMessage = "Manos libres ON"
                } else if self.state.isWakeListening {
                    self.state.statusMessage = "Escuchando wake…"
                } else if self.state.statusMessage == "Listo" || self.state.statusMessage.hasPrefix("Listo ·") {
                    self.state.statusMessage = SystemPresence.idleStatusHint()
                }
            }
        }
    }

    // MARK: - V7 export / documents

    private func handleExportCopy() {
        guard let draft = memory.lastDraft, !draft.isEmpty else {
            finishReply(spoken: "No hay borrador que copiar. Pídeme un ensayo o ideas primero.", detail: nil)
            return
        }
        let outcome = ActionRunner.copyDraftToPasteboard(draft)
        finishReply(spoken: outcome.spoken, detail: outcome.detail)
    }

    private func handleExportSave(filename: String?) {
        guard let draft = memory.lastDraft, !draft.isEmpty else {
            finishReply(spoken: "No hay borrador que guardar.", detail: nil)
            return
        }
        do {
            let fm = FileManager.default
            let desktop = fm.urls(for: .desktopDirectory, in: .userDomainMask).first
            let documents = fm.urls(for: .documentDirectory, in: .userDomainMask).first
            let fallback = documents?.appendingPathComponent("Argos", isDirectory: true)
            let directory: URL
            if let desktop, fm.fileExists(atPath: desktop.path) {
                directory = desktop
            } else if let fallback {
                try fm.createDirectory(at: fallback, withIntermediateDirectories: true)
                directory = fallback
            } else {
                finishReply(spoken: "No encontré Escritorio ni Documentos.", detail: nil)
                return
            }
            var preferred = filename?.trimmingCharacters(in: .whitespacesAndNewlines) ?? "borrador-argos.txt"
            if preferred.isEmpty { preferred = "borrador-argos.txt" }
            let url = ActionRunner.uniqueWritableURL(in: directory, preferredName: preferred)
            let body = draft.hasSuffix("\n") ? draft : draft + "\n"
            try body.write(to: url, atomically: true, encoding: .utf8)
            finishReply(spoken: "Borrador guardado.", detail: url.path)
        } catch {
            finishReply(spoken: "No pude guardar el borrador.", detail: nil)
        }
    }

    private func handleExportPaste() async {
        guard let draft = memory.lastDraft, !draft.isEmpty else {
            finishReply(spoken: "No hay borrador que pegar.", detail: nil)
            return
        }
        state.isKeyboardJobRunning = true
        state.statusMessage = "Pegando borrador…"
        do {
            let result = try await keyboard.pasteExistingText(draft)
            state.isKeyboardJobRunning = false
            finishReply(spoken: result.spoken, detail: result.detail)
        } catch let err as KeyboardError {
            state.isKeyboardJobRunning = false
            var detail: String? = nil
            if case .notTrusted = err {
                detail = "Ajustes del Sistema → Privacidad y seguridad → Accesibilidad → activa Argos."
            }
            finishReply(spoken: err.userMessage, detail: detail)
        } catch {
            state.isKeyboardJobRunning = false
            finishReply(spoken: "No pude pegar el borrador.", detail: nil)
        }
    }

    private func handleReadDocument(phrase: String) async {
        state.statusMessage = "Leyendo documento…"
        do {
            let payload = try await DocumentReader.read(fromPhrase: phrase)
            state.statusMessage = "Pensando…"
            let history = memory.chatMessages(excludingLastUser: true).map {
                ChatMessage(role: $0.role, content: $0.content)
            }
            let reply = await brain.askAboutDocument(
                phrase: phrase,
                sourceLabel: payload.sourceLabel,
                documentText: payload.text,
                history: history
            )
            if let label = reply.usedBackendLabel {
                state.modeLine = label
            } else {
                refreshModelLabels()
            }
            if let mapped = reply.intent {
                // Raro en ask-doc, pero permitido
                await dispatch(mapped, fallbackPhrase: phrase)
                return
            }
            var detail = reply.detail ?? ""
            let header = "Fuente: \(payload.sourceLabel)" + (payload.truncated ? " (truncado)" : "")
            if detail.isEmpty {
                detail = header + "\n\n" + String(payload.text.prefix(2_000))
            } else {
                detail = header + "\n\n" + detail
            }
            finishReply(spoken: reply.speak, detail: detail)
        } catch let err as DocumentReader.ReadError {
            if case .unsupported = err {
                finishReply(spoken: err.userMessage, detail: "Tipos soportados: txt, md, swift, html, json, csv, PDF. docx/pages → mira la pantalla.")
            } else {
                finishReply(spoken: err.userMessage, detail: nil)
            }
        } catch {
            finishReply(spoken: "No pude leer el documento.", detail: nil)
        }
    }

    // MARK: - Existing handlers

    private func handleKeyboardJob(instruction: String) async {
        pauseHandsFreeForWork()
        state.isKeyboardJobRunning = true
        state.statusMessage = "Trabajo en curso…"
        state.detail = "Instrucción: \(instruction)\nApp: \(keyboard.frontmostAppName())"
        speakReply("Empiezo. Avísame si paro.")
        let history = memory.chatMessages(excludingLastUser: true).map {
            ChatMessage(role: $0.role, content: $0.content)
        }
        let draftHint = memory.lastDraft.map { "\nBorrador vigente (si aplica):\n" + String($0.prefix(3_000)) } ?? ""
        do {
            let result = try await keyboard.runJob(instruction: instruction) { [brain] instr in
                let system = "Eres Argos. Generas SOLO el texto que hay que escribir o pegar en la app de adelante. Sin JSON, sin markdown, sin explicaciones ni comillas envolventes. Usa el historial/borrador si el usuario pide cambios (más formal, idea 3, título…)."
                let user = "Tarea del usuario:\n\(instr)" + draftHint
                return try await brain.generatePlainText(system: system, user: user, history: history)
            }
            state.isKeyboardJobRunning = false
            resumeHandsFreeAfterWork()
            refreshModelLabels()
            memory.appendAssistant(speak: result.spoken, detail: result.detail)
            state.lastReply = result.spoken
            state.detail = result.detail
            state.statusMessage = self.state.isHandsFreeActive ? "Manos libres ON" : SystemPresence.idleStatusHint()
            speakReply(result.spoken)
            scheduleHandsFreeFollowUpIfNeeded()
        } catch let err as KeyboardError {
            state.isKeyboardJobRunning = false
            resumeHandsFreeAfterWork()
            var detail: String? = nil
            if case .notTrusted = err {
                detail = "Ajustes del Sistema → Privacidad y seguridad → Accesibilidad → activa Argos."
            }
            finishReply(spoken: err.userMessage, detail: detail)
        } catch let err as BrainBackendError {
            state.isKeyboardJobRunning = false
            finishReply(spoken: err.userMessage, detail: nil)
        } catch {
            state.isKeyboardJobRunning = false
            finishReply(spoken: "No pude completar el trabajo de teclado.", detail: nil)
        }
    }

    private func handleAnalyzeScreen(question: String) async {
        state.statusMessage = "Mirando pantalla…"
        state.detail = ""
        let history = memory.chatMessages(excludingLastUser: true).map {
            ChatMessage(role: $0.role, content: $0.content)
        }
        do {
            let jpeg = try await ScreenCapture.captureMainDisplayJPEG()
            state.statusMessage = "Pensando…"
            let reply = await brain.analyzeScreen(question: question, imageJPEG: jpeg, history: history)
            if let label = reply.usedBackendLabel {
                state.modeLine = label
            } else {
                refreshModelLabels()
            }
            finishReply(spoken: reply.speak, detail: reply.detail)
        } catch let err as ScreenCaptureError {
            finishReply(
                spoken: err.userMessage,
                detail: "Ajustes del Sistema → Privacidad y seguridad → Grabación de pantalla → activa Argos."
            )
        } catch {
            finishReply(spoken: "No pude capturar la pantalla.", detail: nil)
        }
    }

    private func handleUnknown(phrase: String) async {
        state.statusMessage = "Pensando…"
        let history = memory.chatMessages(excludingLastUser: true).map {
            ChatMessage(role: $0.role, content: $0.content)
        }
        var contextParts: [String] = []
        if let label = runtime.contextLabel { contextParts.append("Contexto adjunto: \(label)") }
        if let text = runtime.contextText, !text.isEmpty { contextParts.append("Contenido adjunto:\n\(String(text.prefix(8_000)))") }
        if let draft = memory.lastDraft, !draft.isEmpty {
            contextParts.append("Borrador vigente (lastDraft), úsalo si el usuario pide cambios:\n" + String(draft.prefix(4_000)))
        }
        let context = contextParts.isEmpty ? nil : contextParts.joined(separator: "\n\n")
        let reply: BrainReply
        if let image = state.contextImageJPEG {
            reply = await brain.analyzeScreen(question: phrase, imageJPEG: image, history: history)
        } else {
            reply = await brain.reason(phrase: phrase, context: context, history: history)
        }
        if let label = reply.usedBackendLabel {
            state.modeLine = label
        } else {
            refreshModelLabels()
        }

        if let mapped = reply.intent {
            await dispatch(mapped, fallbackPhrase: phrase)
            return
        }

        finishReply(spoken: reply.speak, detail: reply.detail)
    }

    // MARK: - V10 context attachments

    private func handleFileDrop(_ url: URL) {
        runtime.contextLabel = url.lastPathComponent
        runtime.contextText = nil
        state.contextImageJPEG = nil
        state.statusMessage = "Contexto añadido"
        runtime.activity = .success
        runtime.presentation = .expanded
        do {
            let payload = try DocumentReader.readFile(at: url)
            runtime.contextText = payload.text
            state.contextText = payload.text
            state.detail = "Archivo: \(payload.sourceLabel)\n\n\(payload.text.prefix(2_000))"
            state.lastReply = "Añadí \(url.lastPathComponent) como contexto."
        } catch {
            let imageExtensions = ["png", "jpg", "jpeg", "heic", "webp", "tiff"]
            if imageExtensions.contains(url.pathExtension.lowercased()), let jpeg = try? ScreenCapture.encodeImageFileJPEG(at: url) {
                state.contextImageJPEG = jpeg
                runtime.contextText = "Imagen adjunta: \(url.lastPathComponent)"
                state.contextText = runtime.contextText
                state.detail = "Imagen: \(url.lastPathComponent)\nQueda lista para análisis visual en la siguiente pregunta."
            } else {
                state.detail = "Archivo: \(url.lastPathComponent)\nNo tiene texto extraíble; queda adjunto como referencia."
            }
            state.lastReply = "Añadí \(url.lastPathComponent) como referencia."
        }
        notch.expand()
    }

    private func handleWindowContext(_ context: WindowContext) {
        runtime.lastWindowContext = context
        runtime.contextLabel = context.summary
        runtime.contextText = context.summary
        state.contextText = context.summary
        state.contextImageJPEG = nil
        state.detail = "Contexto de ventana listo.\n\n\(context.summary)\nCapturando ventana…"
        state.lastReply = "Tomé \(context.summary) como contexto."
        state.statusMessage = "Capturando ventana…"
        runtime.activity = .thinking
        notch.expand()
        Task { @MainActor in
            do {
                let jpeg = try await ScreenCapture.captureWindowJPEG(pid: context.pid, title: context.title)
                self.state.contextImageJPEG = jpeg
                self.state.statusMessage = "Contexto de ventana listo"
                self.state.detail = "Contexto de ventana listo.\n\n\(context.summary)\nImagen capturada en memoria para la próxima pregunta."
                self.runtime.activity = .success
            } catch {
                self.state.statusMessage = "Contexto de ventana añadido"
                self.state.detail = "\(context.summary)\nNo pude capturar la ventana; usaré el nombre y título como contexto."
                self.runtime.activity = .success
            }
        }
    }

    func quitApp() {
        speakReply("Hasta luego.")
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.8) {
            NSApp.terminate(nil)
        }
    }
}

@MainActor
final class AppState: ObservableObject {
    static let mutedDefaultsKey = "argos.muted"
    static let wakeWordDefaultsKey = WakeWordMonitor.defaultsKey

    @Published var isListening = false
    @Published var isSpeaking = false
    @Published var isMuted = false
    @Published var isKeyboardJobRunning = false
    @Published var isAgentRunning = false
    /// Toggle del usuario (UserDefaults `argos.wakeWordEnabled`). Default OFF.
    @Published var wakeWordEnabled = false
    /// Motor de wake realmente capturando («Escuchando wake…»).
    @Published var isWakeListening = false
    /// Preferencia manos libres (`argos.handsFreeEnabled`). Default ON.
    @Published var handsFreePreference = true
    /// Sesión manos libres activa ahora.
    @Published var isHandsFreeActive = false
    /// Abrir al iniciar sesión (preferencia). Default OFF.
    @Published var openAtLogin = false
    @Published var openAtLoginRegistered = false
    @Published var pendingAction: PendingAction? = nil
    @Published var statusMessage = "Listo"
    @Published var transcript = ""
    @Published var lastReply = "Argos V10 en línea. Pulsa ⌃⌥⌘V, escribe, wake, o el icono."
    @Published var detail = ""
    @Published var ollamaModel = OllamaClient.defaultModel
    @Published var visionModel = OllamaClient.defaultVisionModel
    @Published var openaiModel = OpenAIClient.defaultModel
    @Published var brainProvider = BrainProvider.defaultValue.rawValue
    @Published var modeLine = "Auto · llama3.2"
    @Published var hasAPIKey = false
    @Published var hotkeyDisplay = HotkeyConfig.default.display
    @Published var contextLabel: String?
    @Published var contextText: String?
    @Published var contextImageJPEG: Data?
}

struct SettingsHelpView: View {
    @ObservedObject var state: AppState
    var onHotkeyChange: (HotkeyConfig) -> Void
    var onWakeWordChange: ((Bool) -> Void)? = nil
    var onHandsFreePrefChange: ((Bool) -> Void)? = nil
    var onLoginItemChange: ((Bool) -> Void)? = nil

    @State private var apiKeyDraft = ""
    @State private var keySaveMessage: String?
    @State private var selectedHotkeyDisplay: String = HotkeyConfig.current.display

    private var modelName: String { OllamaClient.configuredModelName }
    private var visionName: String { OllamaClient.configuredVisionModelName }
    private var astraName: String { OpenAIClient.configuredModelName }

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 10) {
                Text("Argos V10")
                    .font(.title2.weight(.semibold))
                Text("Argos V10 · compañero nativo del notch: manos libres, Whisper local para audio/video, agente hasta 5 pasos, Login Item, presencia real. Sin hologramas MCU ni HUD sobre el escritorio.")
                    .foregroundStyle(.secondary)

                Divider()
                Text("Manos libres (conversación)")
                    .font(.headline)
                Text("Tras wake o el atajo, Argos se queda en «te escucho» y vuelve a escuchar cuando termina de hablar. Fin: «adiós», «corta», «modo normal», silencio ~28 s, o el botón del panel. Preferencia default ON; el wake word sigue default OFF.")
                    .font(.callout)
                    .fixedSize(horizontal: false, vertical: true)
                Toggle("Preferencia manos libres", isOn: Binding(
                    get: { state.handsFreePreference },
                    set: { newValue in
                        if let onHandsFreePrefChange {
                            onHandsFreePrefChange(newValue)
                        } else {
                            HandsFreeSession.isPreferenceEnabled = newValue
                            state.handsFreePreference = newValue
                        }
                    }
                ))
                Text("UserDefaults `argos.handsFreeEnabled`. También: «modo manos libres» / «quédate escuchando».")
                    .font(.caption)
                    .foregroundStyle(.secondary)

                Divider()
                Text("Abrir al iniciar sesión")
                    .font(.headline)
                Text("Registra Argos como Login Item (SMAppService, macOS 13+). Default OFF. No es un daemon oculto: tú lo activas.")
                    .font(.callout)
                    .fixedSize(horizontal: false, vertical: true)
                Toggle("Abrir Argos al iniciar sesión", isOn: Binding(
                    get: { state.openAtLogin },
                    set: { newValue in
                        if let onLoginItemChange {
                            onLoginItemChange(newValue)
                        } else {
                            _ = LoginItemManager.setOpenAtLogin(newValue)
                            state.openAtLogin = newValue
                        }
                    }
                ))
                Text(state.openAtLoginRegistered ? "Login Item: registrado en el sistema." : "Login Item: no registrado.")
                    .font(.caption)
                    .foregroundStyle(.secondary)

                Divider()
                Text("Wake word 24/7 (opcional)")
                    .font(.headline)
                Text("Frases: «Argos», «oye Argos», «hey Argos». Default OFF — gasta batería y deja el micrófono activo. No es un chip tipo Alexa/MCU; usa Speech de Apple (on-device si está disponible). Falsos positivos posibles.")
                    .font(.callout)
                    .fixedSize(horizontal: false, vertical: true)
                Toggle("Wake word 24/7", isOn: Binding(
                    get: { state.wakeWordEnabled },
                    set: { newValue in
                        if let onWakeWordChange {
                            onWakeWordChange(newValue)
                        } else {
                            state.wakeWordEnabled = newValue
                            UserDefaults.standard.set(newValue, forKey: AppState.wakeWordDefaultsKey)
                        }
                    }
                ))
                Text("UserDefaults `argos.wakeWordEnabled`. Con OFF, solo atajo/hotkey como V7.")
                    .font(.caption)
                    .foregroundStyle(.secondary)

                Divider()
                Text("Atajo global")
                    .font(.headline)
                Text("Por defecto ⌃⌥⌘V (reemplaza ⌥Espacio). Accesibilidad necesaria para capturar desde otras apps. UserDefaults `argos.hotkey`.")
                    .font(.callout)
                    .fixedSize(horizontal: false, vertical: true)
                Picker("Atajo", selection: $selectedHotkeyDisplay) {
                    ForEach(HotkeyConfig.presets, id: \.display) { preset in
                        Text(preset.display).tag(preset.display)
                    }
                }
                .onChange(of: selectedHotkeyDisplay) { _, newValue in
                    if let cfg = HotkeyConfig.presets.first(where: { $0.display == newValue }) {
                        onHotkeyChange(cfg)
                        state.hotkeyDisplay = cfg.display
                    }
                }
                .onAppear { selectedHotkeyDisplay = HotkeyConfig.current.display }

                Divider()
                Text("Cerebro (Local / Astra / Auto)")
                    .font(.headline)
                Picker("Proveedor", selection: Binding(
                    get: { state.brainProvider },
                    set: { newValue in
                        let p = BrainProvider(rawValue: newValue) ?? .auto
                        BrainProvider.setCurrent(p)
                        state.brainProvider = p.rawValue
                        state.modeLine = {
                            switch p {
                            case .local: return "Local · \(OllamaClient.configuredModelName)"
                            case .astra: return "Astra · \(OpenAIClient.configuredModelName)"
                            case .auto:
                                return KeychainHelper.hasOpenAIKey()
                                    ? "Auto · Astra"
                                    : "Auto · \(OllamaClient.configuredModelName)"
                            }
                        }()
                    }
                )) {
                    Text("Local").tag(BrainProvider.local.rawValue)
                    Text("Astra").tag(BrainProvider.astra.rawValue)
                    Text("Auto").tag(BrainProvider.auto.rawValue)
                }
                .pickerStyle(.segmented)

                Divider()
                Text("API key OpenAI (Keychain)")
                    .font(.headline)
                Text("Clave guardada: \(state.hasAPIKey ? "sí" : "no").")
                    .font(.callout)
                SecureField("Pegar API key (sk-…)", text: $apiKeyDraft)
                    .textFieldStyle(.roundedBorder)
                HStack {
                    Button("Guardar en Keychain") {
                        let ok = KeychainHelper.saveOpenAIKey(apiKeyDraft)
                        apiKeyDraft = ""
                        state.hasAPIKey = KeychainHelper.hasOpenAIKey()
                        keySaveMessage = ok
                            ? (state.hasAPIKey ? "Clave guardada." : "Clave borrada.")
                            : "No pude guardar en el Keychain."
                    }
                    .disabled(apiKeyDraft.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
                    Button("Borrar clave") {
                        KeychainHelper.deleteOpenAIKey()
                        apiKeyDraft = ""
                        state.hasAPIKey = false
                        keySaveMessage = "Clave eliminada del Keychain."
                    }
                }
                if let keySaveMessage {
                    Text(keySaveMessage).font(.caption).foregroundStyle(.secondary)
                }

                Divider()
                Text("Correo (confirmación)")
                    .font(.headline)
                Text("«envía un correo…» → borrador → Enviar/Cancelar. Nunca envío ciego por voz. Automatización → Mail.")
                    .font(.callout)
                    .fixedSize(horizontal: false, vertical: true)

                Divider()
                Text("Calendario / Recordatorios / Notas")
                    .font(.headline)
                Text("Eventos y recordatorios nuevos piden Confirmar. Listar recordatorios es inmediato. Notas se crean al instante. Permisos: Calendarios, Recordatorios, Automatización (Notas/Mail).")
                    .font(.callout)
                    .fixedSize(horizontal: false, vertical: true)

                Divider()
                Text("Agente corto")
                    .font(.headline)
                Text("«haz esto en pantalla» / «agente: …» → captura → plan hasta 5 pasos → Confirmar → analyze / type / openApp / webSearch / clipboard / draft / openURL (http/https). Tope ~3 min. Sin borrar, shell ni envío de correo dentro del agente.")
                    .font(.callout)
                    .fixedSize(horizontal: false, vertical: true)

                Divider()
                Text("Memoria / Media / Documentos")
                    .font(.headline)
                Text("Memoria persistente como V8. Audio/video: «transcribe esto» / «resume el video» usa Whisper local (whisper / whisper-cpp / ollama whisper); si no hay, pista de instalación — no inventa. Audio→texto→LLM; sin visión frame a frame.")
                    .font(.callout)
                    .fixedSize(horizontal: false, vertical: true)

                Divider()
                Text("Pantalla / Teclado")
                    .font(.headline)
                Text("Pantalla bajo demanda (Grabación de pantalla). Teclado bajo pedido (Accesibilidad).")
                    .font(.callout)
                    .fixedSize(horizontal: false, vertical: true)

                Divider()
                Text("Ollama (local)")
                    .font(.headline)
                Text("ollama pull \(modelName) · ollama pull \(visionName)\nAstra: \(astraName)")
                    .font(.callout)
                    .fixedSize(horizontal: false, vertical: true)
            }
            .padding(20)
        }
        .frame(width: 460, height: 720)
        .onAppear {
            state.hasAPIKey = KeychainHelper.hasOpenAIKey()
            selectedHotkeyDisplay = HotkeyConfig.current.display
        }
    }
}

enum PermissionGate {
    static func requestSpeechAndMicrophone() async -> Bool {
        let mic = await requestMicrophone()
        let speech = await requestSpeech()
        return mic && speech
    }

    private static func requestMicrophone() async -> Bool {
        await withCheckedContinuation { continuation in
            AVAudioApplication.requestRecordPermission { granted in
                continuation.resume(returning: granted)
            }
        }
    }

    private static func requestSpeech() async -> Bool {
        await withCheckedContinuation { continuation in
            SFSpeechRecognizer.requestAuthorization { status in
                continuation.resume(returning: status == .authorized)
            }
        }
    }
}
