import AppKit
import SwiftUI
import UniformTypeIdentifiers

final class ArgosNotchPanel: NSPanel {
    override var canBecomeKey: Bool { true }
    override var canBecomeMain: Bool { false }
}

@MainActor
final class ArgosNotchPanelController: NSObject {
    private let state: AppState
    private let runtime: ArgosRuntimeState
    private let onListen: () -> Void
    private let onSendChat: (String) -> Void
    private let onToggleMute: () -> Void
    private let onStopJob: () -> Void
    private let onOpenSettings: () -> Void
    private let onProviderChange: (String) -> Void
    private let onConfirmPending: () -> Void
    private let onCancelPending: () -> Void
    private let onToggleWakeWord: () -> Void
    private let onEndHandsFree: () -> Void
    private let onFileDrop: (URL) -> Void
    private let onWindowContext: (WindowContext) -> Void
    private var panel: ArgosNotchPanel!
    private var hosting: NSHostingController<ArgosNotchRootView>!
    private var dragMonitor: Any?
    private var dragEndMonitor: Any?

    init(
        state: AppState,
        runtime: ArgosRuntimeState,
        onListen: @escaping () -> Void,
        onSendChat: @escaping (String) -> Void,
        onToggleMute: @escaping () -> Void,
        onStopJob: @escaping () -> Void,
        onOpenSettings: @escaping () -> Void,
        onProviderChange: @escaping (String) -> Void,
        onConfirmPending: @escaping () -> Void,
        onCancelPending: @escaping () -> Void,
        onToggleWakeWord: @escaping () -> Void,
        onEndHandsFree: @escaping () -> Void,
        onFileDrop: @escaping (URL) -> Void,
        onWindowContext: @escaping (WindowContext) -> Void
    ) {
        self.state = state
        self.runtime = runtime
        self.onListen = onListen
        self.onSendChat = onSendChat
        self.onToggleMute = onToggleMute
        self.onStopJob = onStopJob
        self.onOpenSettings = onOpenSettings
        self.onProviderChange = onProviderChange
        self.onConfirmPending = onConfirmPending
        self.onCancelPending = onCancelPending
        self.onToggleWakeWord = onToggleWakeWord
        self.onEndHandsFree = onEndHandsFree
        self.onFileDrop = onFileDrop
        self.onWindowContext = onWindowContext
        super.init()
        buildPanel()
    }

    deinit {
        if let dragMonitor { NSEvent.removeMonitor(dragMonitor) }
        if let dragEndMonitor { NSEvent.removeMonitor(dragEndMonitor) }
    }

    func showCompact() {
        runtime.presentation = .compact
        positionPanel(expanded: false)
        panel.orderFrontRegardless()
    }

    func toggleExpanded() {
        if runtime.presentation == .expanded {
            collapse()
        } else {
            expand()
        }
    }

    func expand() {
        runtime.presentation = .expanded
        positionPanel(expanded: true)
        panel.makeKeyAndOrderFront(nil)
    }

    func collapse() {
        runtime.presentation = .compact
        positionPanel(expanded: false)
        panel.orderFrontRegardless()
    }

    func hide() {
        runtime.presentation = .hidden
        panel.orderOut(nil)
    }

    func showForActivity() {
        runtime.presentation = .compact
        positionPanel(expanded: false)
        panel.orderFrontRegardless()
    }


    private func beginCharacterDrag() {
        guard dragMonitor == nil else { return }
        runtime.isDraggingCharacter = true
        dragMonitor = NSEvent.addGlobalMonitorForEvents(matching: .leftMouseDragged) { [weak self] _ in
            DispatchQueue.main.async { [weak self] in
                guard let self, self.runtime.isDraggingCharacter else { return }
                self.movePanelToMouse()
            }
        }
        dragEndMonitor = NSEvent.addGlobalMonitorForEvents(matching: .leftMouseUp) { [weak self] _ in
            DispatchQueue.main.async { [weak self] in self?.endCharacterDrag() }
        }
    }

    private func endCharacterDrag() {
        guard runtime.isDraggingCharacter else { return }
        runtime.isDraggingCharacter = false
        if let dragMonitor { NSEvent.removeMonitor(dragMonitor); self.dragMonitor = nil }
        if let dragEndMonitor { NSEvent.removeMonitor(dragEndMonitor); self.dragEndMonitor = nil }
        if let context = ArgosWindowContextProvider.contextAtCurrentMouse() {
            onWindowContext(context)
        } else {
            positionPanel(expanded: runtime.presentation == .expanded)
        }
    }

    private func movePanelToMouse() {
        let point = NSEvent.mouseLocation
        let size = panel.frame.size
        panel.setFrameOrigin(NSPoint(x: point.x - size.width / 2, y: point.y - size.height / 2), display: true)
    }
    private func buildPanel() {
        let root = ArgosNotchRootView(
            state: state,
            runtime: runtime,
            onListen: onListen,
            onSendChat: onSendChat,
            onToggleMute: onToggleMute,
            onStopJob: onStopJob,
            onOpenSettings: onOpenSettings,
            onProviderChange: onProviderChange,
            onConfirmPending: onConfirmPending,
            onCancelPending: onCancelPending,
            onToggleWakeWord: onToggleWakeWord,
            onEndHandsFree: onEndHandsFree,
            onCharacterDragChanged: { [weak self] in self?.beginCharacterDrag() },
            onCharacterDragEnded: { [weak self] in self?.endCharacterDrag() },
            onExpand: { [weak self] in self?.toggleExpanded() },
            onCollapse: { [weak self] in self?.collapse() },
            onFileDrop: onFileDrop
        )
        hosting = NSHostingController(rootView: root)
        hosting.view.wantsLayer = true
        hosting.view.layer?.backgroundColor = NSColor.clear.cgColor

        panel = ArgosNotchPanel(
            contentRect: CGRect(x: 0, y: 0, width: 250, height: 62),
            styleMask: [.borderless, .nonactivatingPanel],
            backing: .buffered,
            defer: false
        )
        panel.isOpaque = false
        panel.backgroundColor = .clear
        panel.hasShadow = false
        panel.level = .statusBar
        panel.collectionBehavior = [.canJoinAllSpaces, .fullScreenAuxiliary, .ignoresCycle]
        panel.hidesOnDeactivate = false
        panel.isMovable = false
        panel.contentView = hosting.view
        panel.isReleasedWhenClosed = false

    }

    private func positionPanel(expanded: Bool) {
        guard let screen = NSScreen.main ?? NSScreen.screens.first else { return }
        let width: CGFloat = expanded ? min(620, screen.visibleFrame.width - 40) : 250
        let height: CGFloat = expanded ? 640 : 62
        let x = screen.frame.midX - width / 2
        let top = screen.frame.maxY
        let y = top - height
        panel.setFrame(NSRect(x: x, y: y, width: width, height: height), display: true, animate: true)
    }
}

struct ArgosNotchRootView: View {
    @ObservedObject var state: AppState
    @ObservedObject var runtime: ArgosRuntimeState
    let onListen: () -> Void
    let onSendChat: (String) -> Void
    let onToggleMute: () -> Void
    let onStopJob: () -> Void
    let onOpenSettings: () -> Void
    let onProviderChange: (String) -> Void
    let onConfirmPending: () -> Void
    let onCancelPending: () -> Void
    let onToggleWakeWord: () -> Void
    let onEndHandsFree: () -> Void
    let onCharacterDragChanged: () -> Void
    let onCharacterDragEnded: () -> Void
    let onExpand: () -> Void
    let onCollapse: () -> Void
    let onFileDrop: (URL) -> Void

    @State private var draft = ""
    @State private var isDropTargeted = false
    @FocusState private var focused: Bool

    private var expanded: Bool { runtime.presentation == .expanded }

    private var activity: ArgosRuntimeState.Activity {
        if state.pendingAction != nil { return .waitingApproval }
        if state.isListening { return .listening }
        if state.isAgentRunning || state.isKeyboardJobRunning { return .working }
        if state.statusMessage.localizedCaseInsensitiveContains("pens") || state.statusMessage.localizedCaseInsensitiveContains("plan") { return .thinking }
        if runtime.activity == .success { return .success }
        if runtime.activity == .error { return .error }
        return .idle
    }

    var body: some View {
        ZStack {
            RoundedRectangle(cornerRadius: expanded ? 26 : 30, style: .continuous)
                .fill(Color(nsColor: .windowBackgroundColor).opacity(expanded ? 0.96 : 0.93))
                .overlay(RoundedRectangle(cornerRadius: expanded ? 26 : 30, style: .continuous).stroke(Color.white.opacity(0.10), lineWidth: 1))
                .shadow(color: .black.opacity(expanded ? 0.25 : 0.15), radius: expanded ? 22 : 10, y: 6)

            if expanded {
                expandedView
            } else {
                compactView
            }
        }
        .onDrop(of: [UTType.fileURL.identifier], isTargeted: $isDropTargeted) { providers in
            guard let provider = providers.first else { return false }
            provider.loadDataRepresentation(forTypeIdentifier: UTType.fileURL.identifier) { data, _ in
                guard let data,
                      let url = URL(dataRepresentation: data, relativeTo: nil) else { return }
                DispatchQueue.main.async { onFileDrop(url) }
            }
            return true
        }
        .onChange(of: isDropTargeted) { _, newValue in runtime.isFileDropTargeted = newValue }
    }

    private var compactView: some View {
        HStack(spacing: 8) {
            ArgosCharacterView(activity: activity, compact: true, onDragChanged: onCharacterDragChanged, onDragEnded: onCharacterDragEnded)
            .frame(width: 78)
            VStack(alignment: .leading, spacing: 1) {
                Text("Argos")
                    .font(.caption.weight(.semibold))
                Text(runtime.activity.title)
                    .font(.caption2)
                    .foregroundStyle(.secondary)
                    .lineLimit(1)
            }
            Spacer(minLength: 0)
            Button(action: onExpand) {
                Image(systemName: "plus")
                    .font(.system(size: 13, weight: .bold))
                    .frame(width: 28, height: 28)
            }
            .buttonStyle(.plain)
        }
        .padding(.horizontal, 10)
    }

    private var expandedView: some View {
        VStack(spacing: 12) {
            HStack(spacing: 10) {
                ArgosCharacterView(activity: activity, compact: false, onDragChanged: onCharacterDragChanged, onDragEnded: onCharacterDragEnded)
                .frame(width: 145, height: 145)
                VStack(alignment: .leading, spacing: 4) {
                    Text("Argos")
                        .font(.title3.weight(.bold))
                    Text(activity.title)
                        .font(.caption.weight(.semibold))
                        .foregroundStyle(.secondary)
                    Text(state.statusMessage)
                        .font(.caption)
                        .foregroundStyle(.secondary)
                        .lineLimit(2)
                    if let label = runtime.contextLabel {
                        Label(label, systemImage: "paperclip")
                            .font(.caption2)
                            .foregroundStyle(.purple)
                            .lineLimit(2)
                    }
                }
                Spacer()
                Button(action: onCollapse) { Image(systemName: "minus") }
                    .buttonStyle(.plain)
            }

            if !runtime.agentSteps.isEmpty && (state.isAgentRunning || state.pendingAction != nil || runtime.activity == .success || runtime.activity == .error) {
                ArgosAgentActivityView(runtime: runtime)
            }

            if let pending = state.pendingAction {
                ArgosApprovalView(pending: pending, onConfirm: onConfirmPending, onCancel: onCancelPending)
            }

            if let context = runtime.lastWindowContext {
                HStack {
                    Image(systemName: "macwindow")
                    Text(context.summary).lineLimit(2)
                    Spacer()
                    Button("Quitar") {
                        runtime.lastWindowContext = nil
                        runtime.contextLabel = nil
                        runtime.contextText = nil
                        state.contextText = nil
                        state.contextImageJPEG = nil
                    }.buttonStyle(.plain)
                }
                .font(.caption)
                .padding(10)
                .background(.blue.opacity(0.08), in: RoundedRectangle(cornerRadius: 12))
            }

            if !state.detail.isEmpty && state.pendingAction == nil {
                ScrollView {
                    Text(state.detail)
                        .font(.caption.monospaced())
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .textSelection(.enabled)
                }
                .frame(maxHeight: 110)
                .padding(10)
                .background(.white.opacity(0.04), in: RoundedRectangle(cornerRadius: 12))
            }

            HStack(spacing: 8) {
                TextField("Habla con Argos…", text: $draft, axis: .vertical)
                    .textFieldStyle(.plain)
                    .padding(10)
                    .background(.white.opacity(0.05), in: RoundedRectangle(cornerRadius: 12))
                    .lineLimit(1...4)
                    .focused($focused)
                    .onSubmit(sendDraft)
                Button(action: sendDraft) {
                    Image(systemName: "arrow.up.circle.fill")
                        .font(.title2)
                }
                .buttonStyle(.plain)
                .disabled(draft.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
            }

            HStack(spacing: 8) {
                Button(action: onListen) { Image(systemName: state.isListening ? "stop.fill" : "mic.fill") }
                    .buttonStyle(.borderedProminent)
                Button(action: onToggleMute) { Image(systemName: state.isMuted ? "speaker.slash.fill" : "speaker.wave.2.fill") }
                    .buttonStyle(.bordered)
                Button(action: onToggleWakeWord) { Image(systemName: state.wakeWordEnabled ? "ear.fill" : "ear") }
                    .buttonStyle(.bordered)
                if state.isHandsFreeActive { Button(action: onEndHandsFree) { Image(systemName: "hand.raised.fill") }.buttonStyle(.bordered) }
                if state.isAgentRunning || state.isKeyboardJobRunning { Button(action: onStopJob) { Image(systemName: "stop.fill") }.buttonStyle(.bordered).tint(.red) }
                Spacer()
                Button(action: onOpenSettings) { Image(systemName: "gearshape.fill") }.buttonStyle(.plain)
            }

            HStack(spacing: 8) {
                Text("Cerebro")
                    .font(.caption2)
                    .foregroundStyle(.secondary)
                Picker("", selection: Binding(get: { state.brainProvider }, set: onProviderChange)) {
                    Text("Local").tag(BrainProvider.local.rawValue)
                    Text("Astra").tag(BrainProvider.astra.rawValue)
                    Text("Auto").tag(BrainProvider.auto.rawValue)
                }
                .pickerStyle(.segmented)
                .labelsHidden()
            }
        }
        .padding(14)
    }

    private func sendDraft() {
        let value = draft.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !value.isEmpty else { return }
        draft = ""
        onSendChat(value)
    }
}
