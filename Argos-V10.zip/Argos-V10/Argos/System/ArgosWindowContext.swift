import AppKit
import ApplicationServices

struct WindowContext: Equatable {
    let application: String
    let title: String
    let pid: pid_t
    let frame: CGRect

    var summary: String {
        let app = application.isEmpty ? "Aplicación" : application
        let t = title.isEmpty ? "Ventana sin título" : title
        return "Ventana: \(app) · \(t)"
    }
}

enum ArgosWindowContextProvider {
    static func contextAtCurrentMouse() -> WindowContext? {
        context(atScreenPoint: NSEvent.mouseLocation)
    }

    static func context(atScreenPoint point: CGPoint) -> WindowContext? {
        guard let list = CGWindowListCopyWindowInfo([.optionOnScreenOnly, .excludeDesktopElements], kCGNullWindowID) as? [[String: Any]] else { return nil }
        for info in list {
            guard let layer = info[kCGWindowLayer as String] as? Int, layer == 0 else { continue }
            guard let ownerPID = info[kCGWindowOwnerPID as String] as? pid_t else { continue }
            let ownerName = info[kCGWindowOwnerName as String] as? String ?? ""
            let title = info[kCGWindowName as String] as? String ?? ""
            guard let boundsDict = info[kCGWindowBounds as String] as? NSDictionary,
                  let bounds = CGRect(dictionaryRepresentation: boundsDict as CFDictionary) else { continue }
            guard bounds.width > 80, bounds.height > 50, bounds.contains(point) else { continue }
            if ownerPID == NSRunningApplication.current.processIdentifier { continue }
            let axTitle = accessibilityTitle(pid: ownerPID) ?? title
            return WindowContext(application: ownerName, title: axTitle, pid: ownerPID, frame: bounds)
        }
        return nil
    }

    private static func accessibilityTitle(pid: pid_t) -> String? {
        let app = AXUIElementCreateApplication(pid)
        var value: CFTypeRef?
        guard AXUIElementCopyAttributeValue(app, kAXTitleAttribute as CFString, &value) == .success else { return nil }
        return value as? String
    }
}
