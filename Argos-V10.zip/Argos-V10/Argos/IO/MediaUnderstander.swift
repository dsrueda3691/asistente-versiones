import Foundation
import AppKit
import AVFoundation

/// Audio → texto local (Whisper CLI / whisper.cpp / Ollama whisper) → LLM.
/// Honestidad: no visión frame-a-frame de video; solo pista de audio (primeros ~4 min).
enum MediaUnderstander {
    static let maxSeconds: TimeInterval = 240 // ~4 min excerpt

    enum MediaError: Error, LocalizedError {
        case noMediaFound
        case noWhisperInstalled(String)
        case extractFailed(String)
        case transcribeFailed(String)
        case emptyTranscript

        var userMessage: String {
            switch self {
            case .noMediaFound:
                return "No encontré un audio o video. Abre uno en QuickTime, IINA, VLC o Finder, o nómbralo en Escritorio/Descargas."
            case .noWhisperInstalled(let hint):
                return hint
            case .extractFailed(let m):
                return "No pude extraer el audio. \(m)"
            case .transcribeFailed(let m):
                return "Falló la transcripción local. \(m)"
            case .emptyTranscript:
                return "La transcripción quedó vacía. ¿El archivo tiene pista de audio?"
            }
        }
    }

    struct Result {
        let transcript: String
        let sourceLabel: String
        let truncated: Bool
        let engine: String
        let durationSeconds: TimeInterval?
    }

    enum WhisperEngine: String {
        case whisperCLI = "whisper"
        case whisperCpp = "whisper-cli / whisper.cpp"
        case ollama = "ollama (whisper)"
    }

    /// Detecta herramientas en PATH (y rutas homebrew comunes). No inventa si no hay nada.
    static func detectWhisper() -> (engine: WhisperEngine, executable: String, hint: String)? {
        let pathDirs = (ProcessInfo.processInfo.environment["PATH"] ?? "/usr/bin:/bin:/usr/sbin:/sbin")
            .split(separator: ":").map(String.init)
        let extras = [
            "/opt/homebrew/bin",
            "/usr/local/bin",
            "\(NSHomeDirectory())/.local/bin"
        ]
        let dirs = pathDirs + extras

        func find(_ names: [String]) -> String? {
            for dir in dirs {
                for name in names {
                    let p = (dir as NSString).appendingPathComponent(name)
                    if FileManager.default.isExecutableFile(atPath: p) { return p }
                }
            }
            // which via /usr/bin/which
            for name in names {
                if let p = which(name) { return p }
            }
            return nil
        }

        if let w = find(["whisper-cli"]) {
            return (.whisperCpp, w, "")
        }
        if let w = find(["whisper.cpp"]) {
            return (.whisperCpp, w, "")
        }
        if let w = find(["whisper"]) {
            return (.whisperCLI, w, "")
        }
        // Ollama con modelo whisper documentado (si ollama está y el usuario tiene un modelo whisper)
        if let ollama = find(["ollama"]) {
            if hasOllamaWhisperModel(ollama: ollama) {
                return (.ollama, ollama, "")
            }
        }
        return nil
    }

    static func installHintSpanish() -> String {
        """
        No tengo Whisper local instalado; no invento lo que dice el audio.
        Prueba: brew install whisper-cpp (y un modelo ggml), o pip install openai-whisper.
        Luego: «transcribe esto» o «resume el video» con el archivo abierto o nombrado.
        """
    }

    /// Resuelve archivo + transcribe (excerpt).
    static func understand(phrase: String) async throws -> Result {
        guard let mediaURL = resolveMediaURL(from: phrase) else {
            throw MediaError.noMediaFound
        }
        guard let detected = detectWhisper() else {
            throw MediaError.noWhisperInstalled(installHintSpanish())
        }

        let duration = probeDuration(url: mediaURL)
        let truncated = (duration ?? 0) > maxSeconds || duration == nil
        let wavURL = try await extractAudioWAV(from: mediaURL, maxSeconds: maxSeconds)
        defer { try? FileManager.default.removeItem(at: wavURL) }

        let transcript = try await runWhisper(
            engine: detected.engine,
            executable: detected.executable,
            audioURL: wavURL
        )
        let cleaned = transcript.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !cleaned.isEmpty else { throw MediaError.emptyTranscript }

        let label = mediaURL.lastPathComponent
        return Result(
            transcript: cleaned,
            sourceLabel: label,
            truncated: truncated || (duration ?? maxSeconds) >= maxSeconds,
            engine: detected.engine.rawValue,
            durationSeconds: duration
        )
    }

    // MARK: - Resolve media

    static func resolveMediaURL(from phrase: String) -> URL? {
        let fm = FileManager.default
        let mediaExt: Set<String> = [
            "mp3", "m4a", "wav", "aac", "aiff", "aif", "flac", "caf",
            "mp4", "mov", "m4v", "mkv", "avi", "webm"
        ]

        // 1) Nombre explícito en la frase
        let pattern = #"([A-Za-z0-9_\-\.\u00C0-\u024F ]+\.(?:mp3|m4a|wav|aac|aiff|flac|mp4|mov|m4v|mkv|avi|webm))"#
        if let regex = try? NSRegularExpression(pattern: pattern, options: [.caseInsensitive]) {
            let range = NSRange(phrase.startIndex..., in: phrase)
            if let match = regex.firstMatch(in: phrase, range: range),
               let swiftRange = Range(match.range(at: 1), in: phrase) {
                let name = String(phrase[swiftRange]).trimmingCharacters(in: .whitespaces)
                if let found = findFile(named: name) {
                    return found
                }
            }
        }

        // 2) App frontal con documento de media
        if let front = frontmostMediaURL(extensions: mediaExt) {
            return front
        }

        // 3) Último media reciente en Desktop / Downloads
        let folders = [
            fm.urls(for: .desktopDirectory, in: .userDomainMask).first,
            fm.urls(for: .downloadsDirectory, in: .userDomainMask).first
        ].compactMap { $0 }

        var candidates: [(URL, Date)] = []
        for folder in folders {
            guard let items = try? fm.contentsOfDirectory(
                at: folder,
                includingPropertiesForKeys: [.contentModificationDateKey],
                options: [.skipsHiddenFiles]
            ) else { continue }
            for url in items where mediaExt.contains(url.pathExtension.lowercased()) {
                let date = (try? url.resourceValues(forKeys: [.contentModificationDateKey]).contentModificationDate) ?? .distantPast
                candidates.append((url, date))
            }
        }
        return candidates.sorted { $0.1 > $1.1 }.first?.0
    }

    private static func findFile(named name: String) -> URL? {
        let fm = FileManager.default
        let folders = [
            fm.urls(for: .desktopDirectory, in: .userDomainMask).first,
            fm.urls(for: .downloadsDirectory, in: .userDomainMask).first,
            fm.urls(for: .documentDirectory, in: .userDomainMask).first,
            fm.homeDirectoryForCurrentUser
        ].compactMap { $0 }
        for folder in folders {
            let direct = folder.appendingPathComponent(name)
            if fm.fileExists(atPath: direct.path) { return direct }
            // case-insensitive scan
            guard let items = try? fm.contentsOfDirectory(at: folder, includingPropertiesForKeys: nil, options: [.skipsHiddenFiles]) else { continue }
            if let match = items.first(where: { $0.lastPathComponent.compare(name, options: [.caseInsensitive, .diacriticInsensitive]) == .orderedSame }) {
                return match
            }
        }
        return nil
    }

    private static func frontmostMediaURL(extensions: Set<String>) -> URL? {
        guard let app = NSWorkspace.shared.frontmostApplication else { return nil }
        let bid = app.bundleIdentifier ?? ""
        let name = (app.localizedName ?? "").lowercased()
        let mediaApps = [
            "com.apple.QuickTimePlayerX",
            "com.apple.QuickTimePlayer",
            "com.colliderli.iina",
            "org.videolan.vlc",
            "com.apple.finder"
        ]
        let looksMedia = mediaApps.contains(bid) ||
            name.contains("quicktime") || name.contains("iina") || name.contains("vlc") || name.contains("finder")
        guard looksMedia else { return nil }

        // AppleScript: documento/URL de la app frontal (solo lectura).
        let script: String
        if bid.contains("finder") || name.contains("finder") {
            script = """
            tell application "Finder"
              if (count of (selection as list)) > 0 then
                return POSIX path of (item 1 of (selection as list) as alias)
              end if
            end tell
            return ""
            """
        } else if name.contains("vlc") {
            script = """
            tell application "VLC"
              try
                return path of current item
              end try
            end tell
            return ""
            """
        } else {
            // QuickTime / IINA / genérico: intenta document 1
            let appName = app.localizedName ?? "QuickTime Player"
            script = """
            tell application "\(appName)"
              try
                if (count of documents) > 0 then
                  return POSIX path of (path of document 1 as alias)
                end if
              end try
            end tell
            return ""
            """
        }
        var error: NSDictionary?
        if let appleScript = NSAppleScript(source: script) {
            let out = appleScript.executeAndReturnError(&error)
            let path = out.stringValue?.trimmingCharacters(in: .whitespacesAndNewlines) ?? ""
            if !path.isEmpty {
                let url = URL(fileURLWithPath: path)
                if extensions.contains(url.pathExtension.lowercased()) || FileManager.default.fileExists(atPath: path) {
                    if extensions.contains(url.pathExtension.lowercased()) {
                        return url
                    }
                }
            }
        }
        return nil
    }

    // MARK: - Extract audio

    private static func probeDuration(url: URL) -> TimeInterval? {
        let asset = AVURLAsset(url: url)
        let d = asset.duration
        let seconds = CMTimeGetSeconds(d)
        return seconds.isFinite ? seconds : nil
    }

    private static func extractAudioWAV(from url: URL, maxSeconds: TimeInterval) async throws -> URL {
        let out = FileManager.default.temporaryDirectory
            .appendingPathComponent("argos-media-\(UUID().uuidString).wav")

        // Prefer ffmpeg if present (handles mkv/webm better).
        if let ffmpeg = which("ffmpeg") ?? whichInBrew("ffmpeg") {
            let args = [
                "-y", "-i", url.path,
                "-t", String(Int(maxSeconds)),
                "-vn", "-acodec", "pcm_s16le", "-ar", "16000", "-ac", "1",
                out.path
            ]
            let ok = runProcess(ffmpeg, args: args)
            if ok, FileManager.default.fileExists(atPath: out.path) {
                return out
            }
        }

        // afconvert for formats it supports
        if let af = which("afconvert") {
            let mid = FileManager.default.temporaryDirectory
                .appendingPathComponent("argos-mid-\(UUID().uuidString).caf")
            let ok1 = runProcess(af, args: ["-d", "LEI16@16000", "-f", "caff", "-c", "1", url.path, mid.path])
            if ok1 {
                let ok2 = runProcess(af, args: ["-f", "WAVE", "-d", "LEI16@16000", mid.path, out.path])
                try? FileManager.default.removeItem(at: mid)
                if ok2, FileManager.default.fileExists(atPath: out.path) {
                    return out
                }
            }
        }

        // AVFoundation export
        let asset = AVURLAsset(url: url)
        guard let track = asset.tracks(withMediaType: .audio).first else {
            throw MediaError.extractFailed("Sin pista de audio.")
        }
        _ = track
        guard let exporter = AVAssetExportSession(asset: asset, presetName: AVAssetExportPresetAppleM4A) else {
            throw MediaError.extractFailed("AVAssetExportSession no disponible.")
        }
        let m4a = FileManager.default.temporaryDirectory
            .appendingPathComponent("argos-media-\(UUID().uuidString).m4a")
        exporter.outputURL = m4a
        exporter.outputFileType = .m4a
        let start = CMTime.zero
        let duration = CMTime(seconds: maxSeconds, preferredTimescale: 600)
        exporter.timeRange = CMTimeRange(start: start, duration: duration)
        await withCheckedContinuation { (cont: CheckedContinuation<Void, Never>) in
            exporter.exportAsynchronously { cont.resume() }
        }
        guard exporter.status == .completed else {
            throw MediaError.extractFailed(exporter.error?.localizedDescription ?? "export falló")
        }
        // Convert m4a → wav via afconvert if possible
        if let af = which("afconvert") {
            let ok = runProcess(af, args: ["-f", "WAVE", "-d", "LEI16@16000", m4a.path, out.path])
            try? FileManager.default.removeItem(at: m4a)
            if ok { return out }
        }
        // Devolver m4a si whisper CLI lo acepta
        return m4a
    }

    // MARK: - Whisper runners

    private static func runWhisper(engine: WhisperEngine, executable: String, audioURL: URL) async throws -> String {
        switch engine {
        case .whisperCLI:
            // openai-whisper: whisper audio.wav --language Spanish --output_format txt --output_dir …
            let dir = FileManager.default.temporaryDirectory
                .appendingPathComponent("argos-whisper-\(UUID().uuidString)", isDirectory: true)
            try FileManager.default.createDirectory(at: dir, withIntermediateDirectories: true)
            defer { try? FileManager.default.removeItem(at: dir) }
            let ok = runProcess(executable, args: [
                audioURL.path,
                "--language", "Spanish",
                "--task", "transcribe",
                "--output_format", "txt",
                "--output_dir", dir.path,
                "--fp16", "False"
            ], timeout: 600)
            guard ok else { throw MediaError.transcribeFailed("whisper CLI salió con error.") }
            if let txt = try? FileManager.default.contentsOfDirectory(at: dir, includingPropertiesForKeys: nil)
                .first(where: { $0.pathExtension.lowercased() == "txt" }) {
                return try String(contentsOf: txt, encoding: .utf8)
            }
            throw MediaError.transcribeFailed("No apareció el .txt de whisper.")

        case .whisperCpp:
            let outBase = FileManager.default.temporaryDirectory
                .appendingPathComponent("argos-wcpp-\(UUID().uuidString)")
            var args = ["-m", findGGMLModel() ?? "", "-f", audioURL.path, "-l", "es", "-otxt", "-of", outBase.path]
            args = args.filter { !$0.isEmpty }
            if findGGMLModel() == nil {
                // Sin -m: algunos builds buscan modelo por defecto; si falla, mensaje claro
                args = ["-f", audioURL.path, "-l", "es", "-otxt", "-of", outBase.path]
            } else {
                args = ["-m", findGGMLModel()!, "-f", audioURL.path, "-l", "es", "-otxt", "-of", outBase.path]
            }
            let ok = runProcess(executable, args: args, timeout: 600)
            let txtURL = URL(fileURLWithPath: outBase.path + ".txt")
            if ok, let text = try? String(contentsOf: txtURL, encoding: .utf8) {
                try? FileManager.default.removeItem(at: txtURL)
                return text
            }
            // stdout fallback
            let (code, stdout) = runProcessCapture(executable, args: args, timeout: 600)
            if code == 0, !stdout.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
                return stdout
            }
            throw MediaError.transcribeFailed(
                findGGMLModel() == nil
                    ? "whisper.cpp necesita un modelo ggml (p. ej. ggml-base.bin). Descárgalo y ponlo en ~/models o /opt/homebrew/share."
                    : "whisper-cli falló."
            )

        case .ollama:
            // ollama run <whisper-model> con archivo — soporte limitado; intentamos modelo detectado
            let model = ollamaWhisperModelName(ollama: executable) ?? "whisper"
            let prompt = "Transcribe este audio a texto en español. Solo el texto."
            // Muchas builds de ollama no aceptan wav directo; pedimos al usuario si falla.
            let (code, stdout) = runProcessCapture(
                executable,
                args: ["run", model, prompt],
                timeout: 120
            )
            if code == 0, !stdout.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
                return stdout
            }
            throw MediaError.transcribeFailed(
                "Ollama no transcribió el archivo. Prefiere whisper-cpp o el CLI whisper. Modelo intentado: \(model)."
            )
        }
    }

    private static func findGGMLModel() -> String? {
        let candidates = [
            "\(NSHomeDirectory())/models/ggml-base.bin",
            "\(NSHomeDirectory())/models/ggml-small.bin",
            "\(NSHomeDirectory())/whisper.cpp/models/ggml-base.bin",
            "/opt/homebrew/share/whisper-cpp/ggml-base.bin",
            "/usr/local/share/whisper-cpp/ggml-base.bin"
        ]
        for c in candidates where FileManager.default.fileExists(atPath: c) {
            return c
        }
        // Escaneo ligero en ~/models
        let modelsDir = URL(fileURLWithPath: NSHomeDirectory()).appendingPathComponent("models")
        if let items = try? FileManager.default.contentsOfDirectory(at: modelsDir, includingPropertiesForKeys: nil) {
            if let ggml = items.first(where: { $0.lastPathComponent.hasPrefix("ggml") && $0.pathExtension == "bin" }) {
                return ggml.path
            }
        }
        return nil
    }

    private static func hasOllamaWhisperModel(ollama: String) -> Bool {
        ollamaWhisperModelName(ollama: ollama) != nil
    }

    private static func ollamaWhisperModelName(ollama: String) -> String? {
        let (_, out) = runProcessCapture(ollama, args: ["list"], timeout: 15)
        let lines = out.lowercased().split(separator: "\n").map(String.init)
        for line in lines where line.contains("whisper") {
            let name = line.split(whereSeparator: { $0.isWhitespace }).first.map(String.init)
            if let name, !name.isEmpty, name != "name" { return name }
        }
        return nil
    }

    // MARK: - Process helpers

    private static func which(_ name: String) -> String? {
        let (code, out) = runProcessCapture("/usr/bin/which", args: [name], timeout: 5)
        let path = out.trimmingCharacters(in: .whitespacesAndNewlines)
        return code == 0 && !path.isEmpty ? path : nil
    }

    private static func whichInBrew(_ name: String) -> String? {
        for root in ["/opt/homebrew/bin", "/usr/local/bin"] {
            let p = (root as NSString).appendingPathComponent(name)
            if FileManager.default.isExecutableFile(atPath: p) { return p }
        }
        return nil
    }

    @discardableResult
    private static func runProcess(_ exe: String, args: [String], timeout: TimeInterval = 300) -> Bool {
        runProcessCapture(exe, args: args, timeout: timeout).0 == 0
    }

    private static func runProcessCapture(_ exe: String, args: [String], timeout: TimeInterval) -> (Int32, String) {
        let task = Process()
        task.executableURL = URL(fileURLWithPath: exe)
        task.arguments = args
        let out = Pipe()
        let err = Pipe()
        task.standardOutput = out
        task.standardError = err
        do {
            try task.run()
        } catch {
            return (1, "")
        }
        let deadline = Date().addingTimeInterval(timeout)
        while task.isRunning, Date() < deadline {
            Thread.sleep(forTimeInterval: 0.1)
        }
        if task.isRunning {
            task.terminate()
            return (1, "")
        }
        let data = out.fileHandleForReading.readDataToEndOfFile()
        let errData = err.fileHandleForReading.readDataToEndOfFile()
        var text = String(data: data, encoding: .utf8) ?? ""
        if text.isEmpty {
            text = String(data: errData, encoding: .utf8) ?? ""
        }
        return (task.terminationStatus, text)
    }
}
