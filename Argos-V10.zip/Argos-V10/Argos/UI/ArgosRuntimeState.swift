import Foundation
import SwiftUI

@MainActor
final class ArgosRuntimeState: ObservableObject {
    enum Presentation: Equatable { case hidden, compact, expanded }
    enum Activity: Equatable { case idle, listening, thinking, working, waitingApproval, success, error }

    @Published var presentation: Presentation = .compact
    @Published var activity: Activity = .idle
    @Published var activityMessage = "Listo"
    @Published var agentSteps: [AgentStep] = []
    @Published var activeAgentStep: Int = 0
    @Published var completedAgentSteps: Set<Int> = []
    @Published var failedAgentStep: Int?
    @Published var contextLabel: String?
    @Published var contextText: String?
    @Published var isFileDropTargeted = false
    @Published var isDraggingCharacter = false
    @Published var lastWindowContext: WindowContext?

    func beginPlan(_ plan: PendingAgentPlan) {
        agentSteps = plan.steps
        activeAgentStep = 0
        completedAgentSteps = []
        failedAgentStep = nil
    }

    func consumeProgress(_ message: String) {
        activityMessage = message
        if let range = message.range(of: #"Paso\s+(\d+)\s+de\s+(\d+)"#, options: .regularExpression) {
            let fragment = String(message[range])
            let numbers = fragment.split(whereSeparator: { !$0.isNumber }).compactMap { Int($0) }
            if let current = numbers.first {
                activeAgentStep = current
                if current > 1 { completedAgentSteps.formUnion(1..<current) }
            }
        }
    }

    func markSuccess(_ message: String) {
        activity = .success
        activityMessage = message
        if !agentSteps.isEmpty { completedAgentSteps = Set(agentSteps.map(\.id)) }
        activeAgentStep = 0
    }

    func markError(_ message: String) {
        activity = .error
        activityMessage = message
        if activeAgentStep > 0 { failedAgentStep = activeAgentStep }
    }

    func resetActivity() {
        activity = .idle
        activityMessage = "Listo"
        activeAgentStep = 0
        failedAgentStep = nil
    }
}

extension ArgosRuntimeState.Activity {
    var title: String {
        switch self {
        case .idle: return "Reposo"
        case .listening: return "Escuchando"
        case .thinking: return "Pensando"
        case .working: return "Trabajando"
        case .waitingApproval: return "Aprobación"
        case .success: return "Listo"
        case .error: return "Error"
        }
    }

    var symbol: String {
        switch self {
        case .idle: return "sparkles"
        case .listening: return "waveform"
        case .thinking: return "brain.head.profile"
        case .working: return "bolt.horizontal"
        case .waitingApproval: return "checkmark.shield"
        case .success: return "checkmark"
        case .error: return "exclamationmark.triangle"
        }
    }
}
