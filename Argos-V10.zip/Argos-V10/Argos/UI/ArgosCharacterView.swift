import SwiftUI

struct ArgosCharacterView: View {
    let activity: ArgosRuntimeState.Activity
    let compact: Bool
    let onDragChanged: () -> Void
    let onDragEnded: () -> Void

    @State private var pulse = false

    var body: some View {
        TimelineView(.animation(minimumInterval: 1.0 / 30.0, paused: false)) { timeline in
            Canvas { context, size in
                let t = timeline.date.timeIntervalSinceReferenceDate
                let blinkNow = (t.truncatingRemainder(dividingBy: 4.6) > 4.25)
                let scale = compact ? 0.72 : 1.0
                let cx = size.width / 2
                let cy = size.height / 2 + (compact ? 1 : 8)
                let bob = activity == .working ? CGFloat(sin(t * 5.0) * 2.0) : CGFloat(sin(t * 1.8) * 1.2)
                let s = min(size.width, size.height) * 0.42 * scale

                var cat = Path()
                cat.move(to: CGPoint(x: cx - s * 0.80, y: cy + s * 0.95 + bob))
                cat.addLine(to: CGPoint(x: cx - s * 0.92, y: cy - s * 0.75 + bob))
                cat.addLine(to: CGPoint(x: cx - s * 0.35, y: cy - s * 0.48 + bob))
                cat.addLine(to: CGPoint(x: cx - s * 0.25, y: cy - s * 1.00 + bob))
                cat.addLine(to: CGPoint(x: cx, y: cy - s * 0.52 + bob))
                cat.addLine(to: CGPoint(x: cx + s * 0.38, y: cy - s * 1.00 + bob))
                cat.addLine(to: CGPoint(x: cx + s * 0.38, y: cy - s * 0.48 + bob))
                cat.addLine(to: CGPoint(x: cx + s * 0.92, y: cy - s * 0.76 + bob))
                cat.addLine(to: CGPoint(x: cx + s * 0.78, y: cy + s * 0.92 + bob))
                cat.addQuadCurve(to: CGPoint(x: cx, y: cy + s * 1.12 + bob), control: CGPoint(x: cx + s * 0.30, y: cy + s * 1.15 + bob))
                cat.addQuadCurve(to: CGPoint(x: cx - s * 0.80, y: cy + s * 0.95 + bob), control: CGPoint(x: cx - s * 0.35, y: cy + s * 1.15 + bob))
                context.fill(cat, with: .color(Color(red: 0.10, green: 0.08, blue: 0.17)))
                context.stroke(cat, with: .color(Color(red: 0.30, green: 0.24, blue: 0.48)), lineWidth: max(1.5, s * 0.035))

                let eyeY = cy - s * 0.10 + bob
                let eyeW = s * 0.40
                let eyeH = activity == .listening ? s * 0.20 : s * 0.15
                let eyeColor: Color = {
                    switch activity {
                    case .listening: return Color(red: 0.40, green: 0.95, blue: 0.78)
                    case .thinking: return Color(red: 0.98, green: 0.76, blue: 0.26)
                    case .working: return Color(red: 0.32, green: 0.68, blue: 1.0)
                    case .waitingApproval: return Color(red: 0.65, green: 0.45, blue: 1.0)
                    case .error: return Color(red: 1.0, green: 0.30, blue: 0.40)
                    case .success: return Color(red: 0.35, green: 0.95, blue: 0.55)
                    case .idle: return Color(red: 0.65, green: 0.48, blue: 1.0)
                    }
                }()

                var leftEye = Path()
                leftEye.move(to: CGPoint(x: cx - eyeW, y: eyeY))
                leftEye.addQuadCurve(to: CGPoint(x: cx - s * 0.10, y: eyeY + eyeH), control: CGPoint(x: cx - s * 0.48, y: eyeY + eyeH * 1.4))
                leftEye.addQuadCurve(to: CGPoint(x: cx - eyeW, y: eyeY), control: CGPoint(x: cx - s * 0.42, y: eyeY - eyeH * 0.6))
                var rightEye = Path()
                rightEye.move(to: CGPoint(x: cx + s * 0.10, y: eyeY + eyeH))
                rightEye.addQuadCurve(to: CGPoint(x: cx + eyeW, y: eyeY), control: CGPoint(x: cx + s * 0.48, y: eyeY + eyeH * 1.4))
                rightEye.addQuadCurve(to: CGPoint(x: cx + s * 0.10, y: eyeY + eyeH), control: CGPoint(x: cx + s * 0.42, y: eyeY - eyeH * 0.6))
                if !blinkNow {
                    context.fill(leftEye, with: .color(eyeColor))
                    context.fill(rightEye, with: .color(eyeColor))
                }

                var gem = Path()
                gem.move(to: CGPoint(x: cx, y: cy - s * 0.58 + bob))
                gem.addLine(to: CGPoint(x: cx + s * 0.13, y: cy - s * 0.40 + bob))
                gem.addLine(to: CGPoint(x: cx, y: cy - s * 0.22 + bob))
                gem.addLine(to: CGPoint(x: cx - s * 0.13, y: cy - s * 0.40 + bob))
                gem.closeSubpath()
                context.fill(gem, with: .color(eyeColor))

                var mouth = Path()
                mouth.move(to: CGPoint(x: cx - s * 0.27, y: cy + s * 0.30 + bob))
                mouth.addQuadCurve(to: CGPoint(x: cx, y: cy + s * 0.40 + bob), control: CGPoint(x: cx - s * 0.12, y: cy + s * 0.50 + bob))
                mouth.addQuadCurve(to: CGPoint(x: cx + s * 0.27, y: cy + s * 0.30 + bob), control: CGPoint(x: cx + s * 0.12, y: cy + s * 0.50 + bob))
                context.stroke(mouth, with: .color(eyeColor), lineWidth: max(1.5, s * 0.028))

                if activity == .working {
                    for i in 0..<3 {
                        let phase = t * 4.0 + Double(i) * 1.7
                        let x = cx + CGFloat(cos(phase)) * s * 1.10
                        let y = cy + CGFloat(sin(phase)) * s * 0.80
                        context.fill(Path(ellipseIn: CGRect(x: x - 2, y: y - 2, width: 4, height: 4)), with: .color(eyeColor.opacity(0.8)))
                    }
                }
                if activity == .error {
                    let slash = Path { p in
                        p.move(to: CGPoint(x: cx - s * 0.95, y: cy + s * 0.65))
                        p.addLine(to: CGPoint(x: cx - s * 0.75, y: cy + s * 0.45))
                    }
                    context.stroke(slash, with: .color(eyeColor), lineWidth: 2)
                }
            }
        }
        .frame(width: compact ? 72 : 150, height: compact ? 46 : 150)
        .contentShape(Rectangle())
        .gesture(
            DragGesture(minimumDistance: 8)
                .onChanged { _ in
                    pulse = true
                    onDragChanged()
                }
                .onEnded { _ in
                    pulse = false
                    onDragEnded()
                }
        )
        .scaleEffect(pulse ? 1.05 : 1)
        .animation(.easeOut(duration: 0.16), value: pulse)
        .accessibilityLabel("Argos, estado \(activity.title). Arrastra el personaje sobre una ventana para usarla como contexto.")
    }
}
