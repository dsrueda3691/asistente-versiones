import SwiftUI

struct ArgosAgentActivityView: View {
    @ObservedObject var runtime: ArgosRuntimeState

    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack {
                Text("Actividad")
                    .font(.headline)
                Spacer()
                if !runtime.agentSteps.isEmpty {
                    Text("Paso \(max(1, runtime.activeAgentStep == 0 ? runtime.agentSteps.count : runtime.activeAgentStep))/\(runtime.agentSteps.count)")
                        .font(.caption.monospacedDigit())
                        .foregroundStyle(.secondary)
                }
            }
            ForEach(runtime.agentSteps) { step in
                let done = runtime.completedAgentSteps.contains(step.id)
                let active = runtime.activeAgentStep == step.id && runtime.failedAgentStep == nil
                let failed = runtime.failedAgentStep == step.id
                HStack(spacing: 8) {
                    Text(failed ? "✗" : done ? "✓" : active ? "●" : "○")
                        .font(.system(size: 12, weight: .bold, design: .monospaced))
                        .frame(width: 16)
                    Text(step.line)
                        .font(.caption)
                        .lineLimit(2)
                        .foregroundStyle(failed ? .red : .primary)
                }
            }
            if runtime.agentSteps.isEmpty {
                Text(runtime.activityMessage)
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }
        }
        .padding(12)
        .background(.white.opacity(0.055), in: RoundedRectangle(cornerRadius: 14, style: .continuous))
    }
}
