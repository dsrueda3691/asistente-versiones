import SwiftUI

struct ArgosApprovalView: View {
    let pending: PendingAction
    let onConfirm: () -> Void
    let onCancel: () -> Void

    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            HStack(spacing: 8) {
                Image(systemName: "checkmark.shield.fill")
                    .foregroundStyle(.purple)
                Text(pending.statusLabel)
                    .font(.headline)
                Spacer()
            }
            Text(pending.detailSummary)
                .font(.caption)
                .foregroundStyle(.secondary)
                .lineLimit(8)
                .textSelection(.enabled)
            HStack(spacing: 8) {
                Button("Cancelar", action: onCancel)
                    .buttonStyle(.bordered)
                Button(pending.confirmButtonTitle, action: onConfirm)
                    .buttonStyle(.borderedProminent)
            }
        }
        .padding(12)
        .background(.purple.opacity(0.10), in: RoundedRectangle(cornerRadius: 14, style: .continuous))
    }
}
