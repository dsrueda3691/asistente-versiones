# Argos V10 — Final Hardened v7

## Seguridad del puente remoto
- Rotación de token inmediata: regenerar el token actualiza el valor que el servidor compara en memoria, limpia los bloqueos de autenticación y revoca el token anterior sin reiniciar Argos.
- Comparación del Bearer token en tiempo constante.
- Estado del token y `failedAuth` protegido con `NSLock`.
- Hosts Tailscale IPv4 toleran sufijos de interfaz (`%utun4`) e IPv4-mapped IPv6 (`::ffff:100.x.x.x`). Se reconoce además el prefijo IPv6 ULA de Tailscale `fd7a:115c:a1e0::/48`.
- PIN remoto migrado de SHA-256 simple a PBKDF2-HMAC-SHA256 con 150.000 iteraciones. Los PIN v6 se actualizan automáticamente a PBKDF2 al verificarse correctamente.
- Desafíos de aprobación y contador de intentos protegidos con `NSLock`.
- Tres PIN incorrectos bloquean 10 minutos; cinco tokens Bearer incorrectos por host bloquean 10 minutos.

## Acciones remotas
- `handsFreeStart` / `handsFreeEnd` eliminados de la lista permitida: el iPhone no puede encender ni apagar el micrófono del Mac.
- Pantalla, teclado, documentos y agente siguen fuera de la superficie remota.
- Correo, WhatsApp y otras acciones con efectos siguen requiriendo PendingAction + PIN remoto.
- `/v1/ask` continúa sin aceptar «confirma» ni «cancelar».

## Brain remoto de solo lectura
- Una frase que no corresponde a una acción permitida se puede tratar como pregunta libre.
- Argos llama al Brain con el historial de conversación y sin contexto de pantalla/documentos.
- Aunque el Brain devuelva un `intent` mapeado, el puente remoto ignora ese intent y solo devuelve la respuesta textual: no ejecuta acciones desde la pregunta libre.
- Las preguntas remotas no generan voz en el Mac.

## Voz durante aprobación remota
- La ejecución aprobada desde iPhone mantiene la supresión de voz hasta la primera respuesta de finalización/error, evitando que la acción aprobada remotamente haga hablar al Mac.

## Validación
- Los archivos Swift se validaron con `swiftc -parse` en el entorno disponible.
- No se afirma compilación real de macOS/Xcode; falta validar en un Mac con Xcode y probar Tailscale real.
