import SwiftUI

struct ArgosApprovalView: View {
    let pending: PendingAction
    let onConfirm: () -> Void
    let onCancel: () -> Void
    @State private var showDetails = false

    private var riskLabel: String {
        switch pending {
        case .mail, .integrationMail, .whatsapp: return "Envío externo"
        case .calendar, .reminder, .goal: return "Cambio de datos"
        case .agent: return "Acciones en el Mac"
        }
    }

    private var riskColor: Color {
        switch pending {
        case .mail, .integrationMail, .whatsapp: return .orange
        case .calendar, .reminder, .goal: return .yellow
        case .agent: return .purple
        }
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            HStack(spacing: 8) {
                Image(systemName: "shield.lefthalf.filled")
                    .foregroundStyle(riskColor)
                VStack(alignment: .leading, spacing: 1) {
                    Text(pending.statusLabel).font(.headline)
                    Text("Revisión necesaria · \(riskLabel)")
                        .font(.caption2).foregroundStyle(.secondary)
                }
                Spacer()
                Text("PENDIENTE")
                    .font(.system(size: 9, weight: .bold, design: .rounded))
                    .padding(.horizontal, 7).padding(.vertical, 4)
                    .background(riskColor.opacity(0.15), in: Capsule())
                    .foregroundStyle(riskColor)
            }

            Text(pending.detailSummary)
                .font(.caption)
                .foregroundStyle(.secondary)
                .lineLimit(10)
                .textSelection(.enabled)

            if case .agent(let plan) = pending {
                VStack(alignment: .leading, spacing: 5) {
                    Text("Plan · \(plan.steps.count) paso\(plan.steps.count == 1 ? "" : "s")")
                        .font(.caption.weight(.semibold))
                    ForEach(plan.steps) { step in
                        Label(step.line, systemImage: "circle")
                            .font(.caption2)
                            .foregroundStyle(.secondary)
                            .lineLimit(2)
                    }
                }
                .padding(9)
                .background(.white.opacity(0.045), in: RoundedRectangle(cornerRadius: 11))
            }

            if showDetails {
                VStack(alignment: .leading, spacing: 5) {
                    Text("Detalle de ejecución")
                        .font(.caption.weight(.semibold))
                    Text(pending.detailSummary)
                        .font(.caption2.monospaced())
                        .foregroundStyle(.secondary)
                        .textSelection(.enabled)
                }
                .padding(9)
                .background(.black.opacity(0.14), in: RoundedRectangle(cornerRadius: 10))
            }

            HStack(spacing: 8) {
                Button("Cancelar", action: onCancel)
                    .buttonStyle(.bordered)
                Button(showDetails ? "Ocultar detalle" : "Ver detalle / plan") {
                    withAnimation(.easeOut(duration: 0.16)) { showDetails.toggle() }
                }
                .buttonStyle(.plain)
                .foregroundStyle(.secondary)
                Spacer()
                Button(pending.confirmButtonTitle, action: onConfirm)
                    .buttonStyle(.borderedProminent)
            }
        }
        .padding(12)
        .background(riskColor.opacity(0.09), in: RoundedRectangle(cornerRadius: 14, style: .continuous))
        .overlay(RoundedRectangle(cornerRadius: 14).stroke(riskColor.opacity(0.18), lineWidth: 1))
    }
}
