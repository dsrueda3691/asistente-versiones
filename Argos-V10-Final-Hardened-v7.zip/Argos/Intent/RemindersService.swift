import Foundation
import EventKit

enum RemindersServiceError: Error, LocalizedError {
    case accessDenied
    case saveFailed(String)

    var errorDescription: String? { userMessage }
    var userMessage: String {
        switch self {
        case .accessDenied:
            return "Necesito acceso a Recordatorios. Actívalo en Ajustes → Privacidad y seguridad → Recordatorios."
        case .saveFailed(let m):
            return "No pude crear el recordatorio. \(m)"
        }
    }
}

enum RemindersService {
    private static let store = EKEventStore()

    static func requestAccess() async throws {
        let granted: Bool
        if #available(macOS 14.0, *) {
            granted = try await store.requestFullAccessToReminders()
        } else {
            granted = try await store.requestAccess(to: .reminder)
        }
        guard granted else { throw RemindersServiceError.accessDenied }
    }

    /// Solo tras confirmación.
    static func createReminder(_ pending: PendingReminder) async throws -> String {
        try await requestAccess()
        let reminder = EKReminder(eventStore: store)
        reminder.title = pending.title
        if let due = pending.due {
            reminder.dueDateComponents = Calendar.current.dateComponents(
                [.year, .month, .day, .hour, .minute], from: due
            )
        }
        let calendars = store.calendars(for: .reminder)
        let calendar: EKCalendar
        if let argos = calendars.first(where: { $0.title.caseInsensitiveCompare("Argos") == .orderedSame }) {
            calendar = argos
        } else if let created = try? createArgosCalendar() {
            calendar = created
        } else if let fallback = store.defaultCalendarForNewReminders() {
            calendar = fallback
        } else {
            throw RemindersServiceError.saveFailed("No hay lista de recordatorios disponible.")
        }
        reminder.calendar = calendar
        do {
            try store.save(reminder, commit: true)
        } catch {
            throw RemindersServiceError.saveFailed(error.localizedDescription)
        }
        return "Recordatorio creado: \(pending.title)."
    }

    private static func createArgosCalendar() throws -> EKCalendar {
        let calendar = EKCalendar(for: .reminder, eventStore: store)
        calendar.title = "Argos"
        if let source = store.sources.first(where: { $0.sourceType == .local })
            ?? store.defaultCalendarForNewReminders()?.source {
            calendar.source = source
        } else {
            throw RemindersServiceError.saveFailed("No encontré una cuenta de Recordatorios donde crear la lista Argos.")
        }
        try store.saveCalendar(calendar, commit: true)
        return calendar
    }

    /// Lectura inmediata (sin confirmación).
    static func listUpcoming(limit: Int = 8) async throws -> (spoken: String, detail: String) {
        try await requestAccess()
        let cal = Calendar.current
        let start = cal.startOfDay(for: Date())
        let end = cal.date(byAdding: .day, value: 14, to: start) ?? start.addingTimeInterval(14 * 86400)
        let predicate = store.predicateForIncompleteReminders(
            withDueDateStarting: start,
            ending: end,
            calendars: nil
        )
        let items: [EKReminder] = await withCheckedContinuation { cont in
            store.fetchReminders(matching: predicate) { reminders in
                cont.resume(returning: reminders ?? [])
            }
        }
        let sorted = items.sorted { a, b in
            let da = a.dueDateComponents.flatMap { Calendar.current.date(from: $0) } ?? .distantFuture
            let db = b.dueDateComponents.flatMap { Calendar.current.date(from: $0) } ?? .distantFuture
            return da < db
        }
        let slice = Array(sorted.prefix(limit))
        if slice.isEmpty {
            return ("No hay recordatorios próximos.", "")
        }
        let f = DateFormatter()
        f.locale = Locale(identifier: "es_CO")
        f.dateStyle = .short
        f.timeStyle = .short
        let lines: [String] = slice.map { r in
            let due = r.dueDateComponents.flatMap { Calendar.current.date(from: $0) }
            let dueText = due.map { f.string(from: $0) } ?? "sin fecha"
            return "• \(r.title ?? "(sin título)") — \(dueText)"
        }
        let spokenTitles = slice.prefix(3).compactMap(\.title).joined(separator: ", ")
        let spoken = "\(slice.count) recordatorio\(slice.count == 1 ? "" : "s") próximos. Entre ellos: \(spokenTitles)."
        return (spoken, lines.joined(separator: "\n"))
    }
}

// MARK: - Argos goals

struct ArgosGoal: Codable, Identifiable, Equatable {
    let id: UUID
    var title: String
    var project: String?
    var due: Date?
    var status: String
    var lastTouched: Date
    var reminderID: String?

    var isCompleted: Bool { status.lowercased() == "completed" || status.lowercased() == "completado" }
}

enum GoalStore {
    private static let queue = DispatchQueue(label: "com.danielrueda.Argos.goals", qos: .utility)

    private static var fileURL: URL {
        let base = FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask).first!
            .appendingPathComponent("Argos", isDirectory: true)
        try? FileManager.default.createDirectory(at: base, withIntermediateDirectories: true)
        return base.appendingPathComponent("goals.json")
    }

    static func all() -> [ArgosGoal] {
        guard let data = try? Data(contentsOf: fileURL),
              let goals = try? JSONDecoder().decode([ArgosGoal].self, from: data) else { return [] }
        return goals.sorted { ($0.due ?? .distantFuture) < ($1.due ?? .distantFuture) }
    }

    @discardableResult
    static func add(title: String, project: String?, due: Date?, reminderID: String? = nil) -> ArgosGoal {
        var goals = all()
        let goal = ArgosGoal(id: UUID(), title: title, project: project, due: due, status: "pendiente", lastTouched: Date(), reminderID: reminderID)
        goals.append(goal)
        save(goals)
        return goal
    }

    static func touch(_ id: UUID, status: String? = nil) {
        var goals = all()
        guard let index = goals.firstIndex(where: { $0.id == id }) else { return }
        goals[index].lastTouched = Date()
        if let status { goals[index].status = status }
        save(goals)
    }

    static func markCompleted(_ id: UUID) { touch(id, status: "completado") }

    static func snapshotText(limit: Int = 20) -> String {
        let now = Date()
        let formatter = ISO8601DateFormatter()
        return all().prefix(limit).map { goal in
            let due = goal.due.map(formatter.string(from:)) ?? "sin fecha"
            let staleDays = max(0, Int(now.timeIntervalSince(goal.lastTouched) / 86400))
            return "id=\(goal.id.uuidString); objetivo=\(goal.title); proyecto=\(goal.project ?? ""); vence=\(due); estado=\(goal.status); dias_sin_movimiento=\(staleDays)"
        }.joined(separator: "\n")
    }

    static func morningSummary() -> (summary: String, detail: String, stale: [ArgosGoal]) {
        let goals = all().filter { !$0.isCompleted }
        let now = Date()
        let calendar = Calendar.current
        let today = calendar.startOfDay(for: now)
        let stale = goals.filter { now.timeIntervalSince($0.lastTouched) >= 3 * 86400 }
        let dueSoon = goals.filter {
            guard let due = $0.due else { return false }
            return due >= today && due <= calendar.date(byAdding: .day, value: 7, to: today)!
        }
        if goals.isEmpty { return ("No tienes objetivos pendientes registrados.", "", stale) }
        let summary = "Tienes \(goals.count) objetivo\(goals.count == 1 ? "" : "s") pendiente\(goals.count == 1 ? "" : "s"). \(dueSoon.count) vence\(dueSoon.count == 1 ? "" : "n") en los próximos 7 días."
        let lines = goals.prefix(10).map { goal in
            let due = goal.due.map { DateFormatter.localizedString(from: $0, dateStyle: .medium, timeStyle: .short) } ?? "sin fecha"
            return "• \(goal.title) — \(goal.status) — vence: \(due) — último movimiento: \(DateFormatter.localizedString(from: goal.lastTouched, dateStyle: .short, timeStyle: .short))"
        }
        return (summary, lines.joined(separator: "\n"), stale)
    }

    private static func save(_ goals: [ArgosGoal]) {
        queue.async {
            let encoder = JSONEncoder()
            encoder.dateEncodingStrategy = .iso8601
            if let data = try? encoder.encode(goals) { try? data.write(to: fileURL, options: .atomic) }
        }
    }
}
