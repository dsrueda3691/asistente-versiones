# Viernes (V5)

Asistente de barra de menús para macOS. Habla en español, te escucha cuando se lo pides, responde con voz, y **puede mirar la pantalla solo cuando se lo pides**. Inspirado en Friday (MCU): seco, breve, competente.

**V5** = V4 **+** cerebro en la nube opcional (**OpenAI `gpt-6-astra`**) con **Ollama local como respaldo/por defecto**, selector Local / Astra / Auto, API key en **Keychain**.

Viernes es una herramienta personal. **No está pensada para el App Store**: el sandbox está desactivado para poder leer y crear archivos en el Escritorio.

## Qué cambió en V5

- **Proveedor de cerebro** (`viernes.brainProvider`):
  - `local` — solo Ollama (comportamiento V4).
  - `astra` — solo OpenAI `gpt-6-astra` (error claro en español si no hay clave o red).
  - `auto` (**default**) — intenta Astra si hay API key; si falla, cae a Ollama; si ninguno funciona, error en español.
- Selector **Local / Astra / Auto** en el popover (segmented) y en Ajustes. Persistido.
- Línea de modo: p. ej. `Auto · Astra` o `Local · llama3.2`.
- API key en Keychain: service `com.danielrueda.Viernes`, account `openai_api_key`. Nunca hardcodeada ni en logs.
- Chat libre, visión de pantalla y generación de texto para teclado usan el proveedor activo.
- **Las reglas locales (hora, abrir apps, buscar…) siguen offline** — no requieren nube.
- Marketing version **5.0**.

### Coste Astra (importante)

Precios API aproximados para Astra: **~$10 / millón de tokens de entrada** y **~$50 / millón de salida**. Son cifras orientativas; **confirma siempre** en la [página de pricing de OpenAI](https://openai.com/api/pricing/). El uso en modo Astra/Auto con clave genera cargos en tu cuenta OpenAI.

## Qué cambió en V4

- UI del popover más cercana al mockup: filas Tú/Viernes, punto de estado, ondas más marcadas, chat con enviar, mute naranja, engranaje de ayuda. Sigue claro/oscuro del sistema.
- **Teclado bajo pedido**: di o escribe frases como «usa el teclado…», «mientras como, escribe…», «deja escribiendo…». Viernes genera texto y lo pega en la app de adelante (Cmd+V).
- Requiere **Accesibilidad** (Ajustes → Privacidad y seguridad → Accesibilidad → Viernes).
- Tope ~10 minutos / ~12 000 caracteres. Botón **Detener trabajo**. No escribe en campos de contraseña. Sin keylogging ni control siempre encendido.
- Sigue sin borrar archivos, sin shell arbitrario, sin enviar Mail.

## Qué cambió en V3

- **Pantalla bajo demanda**, **mute**, **chat escrito**, **ondas al hablar**, apariencia sistema. Marketing 3.0.

## Voz (honestidad vs MCU)

**No existe la voz exacta de FRIDAY del MCU en macOS.** Viernes elige la mejor voz **española femenina** disponible: prioriza `es-CO` → `es-ES` → `es-MX`, calidad **premium** → **enhanced** → default.

## Requisitos

- Mac con **macOS 14** o posterior.
- **Xcode** gratis desde el App Store (cuenta Apple personal, sin pago).
- Micrófono (para voz).
- **Opcional:** [Ollama](https://ollama.com) para chat libre y visión local.
- **Opcional:** API key de OpenAI para Astra (`gpt-6-astra`).
- **Para mirar la pantalla:** permiso de **Grabación de pantalla** + backend de visión (Ollama visión o Astra).

## API key (Keychain)

Desde Terminal:

```bash
security add-generic-password -a openai_api_key -s com.danielrueda.Viernes -w 'sk-...' -U
```

O en la app: engranaje → Ajustes → **Pegar API key** (SecureField) → Guardar en Keychain (el campo se limpia).

Modelo OpenAI por defecto: `gpt-6-astra` (`viernes.openaiModel`). Timeouts: texto ~60 s, visión ~120 s.

## Proveedor (comportamiento)

| Modo | Comportamiento |
| --- | --- |
| **Local** | Nunca llama a OpenAI. Solo Ollama. |
| **Astra** | Solo OpenAI. Sin clave → error en español. 401 / rate limit / red → error en español. |
| **Auto** | Si hay clave → intenta Astra; si falla → Ollama. Sin clave → Ollama. Si ambos fallan → error combinado en español. |

Reglas locales (hora, apps, búsqueda, archivos…) **no pasan por LLM**.

## Ollama

### Texto

```bash
ollama pull llama3.2
```

Modelo por defecto: `llama3.2` (`viernes.ollamaModel`).

### Visión

```bash
ollama pull llava
```

Modelo por defecto: `llava` (`viernes.ollamaVisionModel`).

Sin Ollama ni Astra, las **reglas locales** siguen funcionando.

## Cómo abrirlo

1. Instala **Xcode** y ábrelo una vez para aceptar la licencia.
2. Abre **`Viernes.xcodeproj`**.
3. Destino **My Mac**.
4. Signing: Personal Team, bundle id `com.danielrueda.Viernes`.
5. **Product → Run** (⌘R).
6. Primera vez: micrófono y reconocimiento de voz. Si pides mirar la pantalla, macOS pedirá **Grabación de pantalla**.
7. Busca **✦** en la barra de menús (`LSUIElement`, sin Dock).

## Cómo usarlo

- Clic en el icono **o** **⌥Espacio** → escucha.
- **Escribe** en el popover y pulsa Enviar.
- **Mute**: «Sin voz» / «Con voz».
- **Local / Astra / Auto** en el popover o en Ajustes.
- Frases de pantalla: «mira la pantalla», «qué hay en pantalla», «qué estoy haciendo».

### Frases de ejemplo (reglas, sin LLM)

| Intent | Prueba |
| --- | --- |
| Saludo | «hola», «quién eres» |
| Hora / fecha | «qué hora es», «qué fecha es hoy» |
| Abrir app | «abre Safari», «abre Finder», … |
| Buscar | «busca recetas de arepas» |
| Crear archivo | «crea un archivo llamado tareas» |
| Listar escritorio | «lista el escritorio» |
| **Mirar pantalla** | «mira la pantalla» (visión Ollama o Astra) |
| Código | «prepárame un html de landing» |
| Portapapeles | «lee el portapapeles» |
| Teclado | «usa el teclado…» / «mientras como, escribe…» |
| Salir | «adiós» |

## Permisos

| Permiso | Para qué | Obligatorio |
| --- | --- | --- |
| Micrófono | Solo mientras escuchas | Sí (voz) |
| Reconocimiento de voz | Audio → texto | Sí (voz) |
| **Grabación de pantalla** | Solo cuando pides mirar la pantalla | Solo para visión |
| Accesibilidad | ⌥Espacio desde otras apps + teclado bajo pedido | Recomendado |

### Activar Grabación de pantalla

**Ajustes del Sistema → Privacidad y seguridad → Grabación de pantalla →** activa **Viernes**.

La captura es **una foto en memoria** (JPEG, lado largo ~1280). No se guarda a disco por defecto. Con Astra, esa imagen se envía a OpenAI para la respuesta de visión.

## Qué hace V5 (y qué no)

**Sí**

- Barra de menús, sin Dock; claro/oscuro del sistema.
- Voz entrada/salida; mute persistente; chat escrito.
- Reglas locales + Brain (Ollama y/o Astra) + visión bajo demanda + teclado bajo pedido.
- Selector de proveedor; Keychain para la API key.
- Ondas al hablar (si no está muteado).
- Una acción segura por turno del catálogo conocido.

**No (a propósito)**

- Wake word 24/7.
- Grabación de pantalla continua / siempre encendida.
- Enviar correo / Mail automation sin confirmación.
- Borrar archivos.
- Shell arbitrario.
- Keylogging o teclado siempre encendido.
- Requerir nube para comandos V1 con reglas.

**Sandbox OFF.** **Hardened Runtime OFF** para Run local con Personal Team.

`Info.plist`: `NSAllowsLocalNetworking` para Ollama; `NSScreenCaptureUsageDescription` en español.

## Estructura

```
viernes-mac/
  README.md
  Viernes.xcodeproj
  Viernes/
    ViernesApp.swift            ← handle, mute, chat, provider, Settings + Keychain UI
    StatusBarController.swift
    Speech/Listener.swift
    Speech/Speaker.swift
    Intent/IntentParser.swift
    Intent/ActionRunner.swift
    Intent/LLMBackend.swift     ← protocolo + BrainProvider + errores ES
    Intent/OllamaClient.swift   ← chat + chatVision (local)
    Intent/OpenAIClient.swift   ← Chat Completions gpt-6-astra
    Intent/KeychainHelper.swift ← Keychain API key
    Intent/Brain.swift          ← reason / vision / plain con auto-fallback
    Intent/KeyboardController.swift
    Capture/ScreenCapture.swift
    UI/PopoverView.swift        ← mute, chat, waveform, selector Local/Astra/Auto
    Info.plist
    Viernes.entitlements
    Assets.xcassets
```

Mínimo macOS 14. Marketing version 5.0.

## Siguientes pasos

1. Puente Cursor / VS Code local.
2. Mail con confirmación en el popover.
3. Wake word opcional con interruptor.

## Licencia

Uso personal de Daniel Rueda Mier. Haz lo que quieras con el código en tu Mac.
