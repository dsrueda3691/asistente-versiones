import SwiftUI
import AppKit
import AVFoundation
import Speech

@main
struct ViernesApp: App {
    @NSApplicationDelegateAdaptor(AppDelegate.self) private var appDelegate

    var body: some Scene {
        Settings {
            SettingsHelpView(state: appDelegate.state)
        }
    }
}

@MainActor
final class AppDelegate: NSObject, NSApplicationDelegate {
    private var statusBar: StatusBarController?
    let state = AppState()
    let listener = Listener()
    let speaker = Speaker()
    let parser = IntentParser()
    let runner = ActionRunner()
    let brain = Brain()
    let keyboard = KeyboardController()

    func applicationDidFinishLaunching(_ notification: Notification) {
        NSApp.setActivationPolicy(.accessory)
        refreshModelLabels()
        state.isMuted = UserDefaults.standard.bool(forKey: AppState.mutedDefaultsKey)
        state.brainProvider = BrainProvider.current.rawValue
        state.hasAPIKey = KeychainHelper.hasOpenAIKey()

        speaker.onSpeakingChanged = { [weak self] speaking in
            self?.state.isSpeaking = speaking
        }
        listener.onPartialTranscript = { [weak self] text in
            self?.state.transcript = text
        }
        statusBar = StatusBarController(
            state: state,
            onListen: { [weak self] in
                self?.toggleListening()
            },
            onQuit: { [weak self] in
                self?.quitApp()
            },
            onSendChat: { [weak self] text in
                self?.submitTyped(text)
            },
            onToggleMute: { [weak self] in
                self?.toggleMute()
            },
            onStopJob: { [weak self] in
                self?.stopKeyboardJob()
            },
            onOpenSettings: { [weak self] in
                self?.openSettings()
            },
            onProviderChange: { [weak self] raw in
                self?.setBrainProvider(raw)
            }
        )
        keyboard.onProgress = { [weak self] msg in
            self?.state.statusMessage = msg
            self?.state.isKeyboardJobRunning = true
        }
        speakReply("Viernes en línea.")
    }

    func applicationWillTerminate(_ notification: Notification) {
        keyboard.cancel()
        listener.stopListening()
        speaker.stop()
    }

    func refreshModelLabels() {
        state.ollamaModel = OllamaClient.configuredModelName
        state.visionModel = OllamaClient.configuredVisionModelName
        state.openaiModel = OpenAIClient.configuredModelName
        state.modeLine = brain.modeLineLabel
        state.hasAPIKey = KeychainHelper.hasOpenAIKey()
    }

    func setBrainProvider(_ raw: String) {
        let provider = BrainProvider(rawValue: raw) ?? .auto
        BrainProvider.setCurrent(provider)
        state.brainProvider = provider.rawValue
        refreshModelLabels()
    }

    func stopKeyboardJob() {
        keyboard.cancel()
        state.isKeyboardJobRunning = false
        state.statusMessage = "Listo"
        let reply = "Paré el trabajo de teclado."
        state.lastReply = reply
        speakReply(reply)
    }

    func openSettings() {
        state.hasAPIKey = KeychainHelper.hasOpenAIKey()
        NSApp.sendAction(Selector(("showSettingsWindow:")), to: nil, from: nil)
        NSApp.activate(ignoringOtherApps: true)
    }

    func toggleMute() {
        state.isMuted.toggle()
        UserDefaults.standard.set(state.isMuted, forKey: AppState.mutedDefaultsKey)
        if state.isMuted {
            speaker.stop()
            state.isSpeaking = false
        }
    }

    func speakReply(_ text: String) {
        speaker.speak(text, muted: state.isMuted)
        if state.isMuted {
            state.isSpeaking = false
        }
    }

    func submitTyped(_ text: String) {
        let trimmed = text.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmed.isEmpty else { return }
        if state.isListening {
            listener.stopListening()
            state.isListening = false
        }
        speaker.stop()
        state.transcript = trimmed
        statusBar?.showPopover()
        Task { @MainActor in
            await self.handle(phrase: trimmed)
        }
    }

    func toggleListening() {
        if state.isListening {
            listener.stopListening()
            state.isListening = false
            state.statusMessage = "Listo"
            return
        }
        startListening()
    }

    func startListening() {
        speaker.stop()
        state.isListening = true
        state.statusMessage = "Te escucho…"
        state.transcript = ""
        statusBar?.showPopover()

        Task { @MainActor in
            let permitted = await PermissionGate.requestSpeechAndMicrophone()
            guard permitted else {
                self.state.isListening = false
                self.state.statusMessage = "Faltan permisos"
                let reply = "Necesito micrófono y reconocimiento de voz. Actívalos en Ajustes del Sistema."
                self.state.lastReply = reply
                self.speakReply(reply)
                return
            }

            do {
                let phrase = try await self.listener.listen(maxDuration: 12)
                self.state.transcript = phrase
                self.state.isListening = false
                if phrase.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
                    let reply = "No te escuché. Prueba otra vez."
                    self.state.lastReply = reply
                    self.state.statusMessage = "Listo"
                    self.speakReply(reply)
                    return
                }
                await self.handle(phrase: phrase)
            } catch {
                self.state.isListening = false
                let reply: String
                if let listenError = error as? ListenerError {
                    reply = listenError.userMessage
                } else {
                    reply = "No pude escucharte. Revisa el micrófono."
                }
                self.state.lastReply = reply
                self.state.statusMessage = "Listo"
                self.speakReply(reply)
            }
        }
    }

    func handle(phrase: String) async {
        state.statusMessage = "Pensando…"
        refreshModelLabels()
        let intent = parser.parse(phrase)

        if case .analyzeScreen(let question) = intent {
            await handleAnalyzeScreen(question: question)
            return
        }

        if case .keyboardJob(let instruction) = intent {
            await handleKeyboardJob(instruction: instruction)
            return
        }

        if case .unknown = intent {
            await handleUnknown(phrase: phrase)
            return
        }

        let outcome = await runner.run(intent)
        state.lastReply = outcome.spoken
        state.statusMessage = "Listo"
        if let extra = outcome.detail {
            state.detail = extra
        } else {
            state.detail = ""
        }
        speakReply(outcome.spoken)
        if outcome.shouldQuit {
            DispatchQueue.main.asyncAfter(deadline: .now() + 1.6) {
                NSApp.terminate(nil)
            }
        }
    }

    private func handleKeyboardJob(instruction: String) async {
        state.isKeyboardJobRunning = true
        state.statusMessage = "Trabajo en curso…"
        state.detail = "Instrucción: \(instruction)\nApp: \(keyboard.frontmostAppName())"
        speakReply("Empiezo. Avísame si paro.")
        do {
            let result = try await keyboard.runJob(instruction: instruction) { [brain] instr in
                let system = "Eres Viernes. Generas SOLO el texto que hay que escribir o pegar en la app de adelante. Sin JSON, sin markdown, sin explicaciones ni comillas envolventes."
                let user = "Tarea del usuario:\n\(instr)"
                return try await brain.generatePlainText(system: system, user: user)
            }
            state.lastReply = result.spoken
            state.detail = result.detail
            state.statusMessage = "Listo"
            state.isKeyboardJobRunning = false
            refreshModelLabels()
            speakReply(result.spoken)
        } catch let err as KeyboardError {
            state.lastReply = err.userMessage
            if case .notTrusted = err {
                state.detail = "Ajustes del Sistema → Privacidad y seguridad → Accesibilidad → activa Viernes."
            } else {
                state.detail = ""
            }
            state.statusMessage = "Listo"
            state.isKeyboardJobRunning = false
            speakReply(err.userMessage)
        } catch let err as BrainBackendError {
            state.lastReply = err.userMessage
            state.detail = ""
            state.statusMessage = "Listo"
            state.isKeyboardJobRunning = false
            speakReply(err.userMessage)
        } catch {
            let msg = "No pude completar el trabajo de teclado."
            state.lastReply = msg
            state.statusMessage = "Listo"
            state.isKeyboardJobRunning = false
            speakReply(msg)
        }
    }

    private func handleAnalyzeScreen(question: String) async {
        state.statusMessage = "Mirando pantalla…"
        state.detail = ""
        do {
            let jpeg = try await ScreenCapture.captureMainDisplayJPEG()
            state.statusMessage = "Pensando…"
            let reply = await brain.analyzeScreen(question: question, imageJPEG: jpeg)
            state.lastReply = reply.speak
            state.detail = reply.detail ?? ""
            if let label = reply.usedBackendLabel {
                state.modeLine = label
            } else {
                refreshModelLabels()
            }
            state.statusMessage = "Listo"
            speakReply(reply.speak)
        } catch let err as ScreenCaptureError {
            state.lastReply = err.userMessage
            state.detail = "Ajustes del Sistema → Privacidad y seguridad → Grabación de pantalla → activa Viernes."
            state.statusMessage = "Listo"
            speakReply(err.userMessage)
        } catch {
            let msg = "No pude capturar la pantalla."
            state.lastReply = msg
            state.statusMessage = "Listo"
            speakReply(msg)
        }
    }

    /// Frase sin regla → Brain (Astra/Ollama según proveedor). Si pide analyzeScreen u otra acción, se ejecuta.
    private func handleUnknown(phrase: String) async {
        state.statusMessage = "Pensando…"
        let reply = await brain.reason(phrase: phrase)
        if let label = reply.usedBackendLabel {
            state.modeLine = label
        } else {
            refreshModelLabels()
        }

        if let mapped = reply.intent {
            if case .analyzeScreen(let question) = mapped {
                await handleAnalyzeScreen(question: question)
                return
            }
            if case .keyboardJob(let instruction) = mapped {
                await handleKeyboardJob(instruction: instruction)
                return
            }
            let outcome = await runner.run(mapped)
            var spoken = outcome.spoken
            let brainSpeak = reply.speak.trimmingCharacters(in: .whitespacesAndNewlines)
            if !brainSpeak.isEmpty && brainSpeak != spoken {
                spoken = brainSpeak
            }
            state.lastReply = spoken
            var detailParts: [String] = []
            if let d = reply.detail, !d.isEmpty { detailParts.append(d) }
            if let d = outcome.detail, !d.isEmpty { detailParts.append(d) }
            state.detail = detailParts.joined(separator: "\n")
            state.statusMessage = "Listo"
            speakReply(spoken)
            if outcome.shouldQuit {
                DispatchQueue.main.asyncAfter(deadline: .now() + 1.6) {
                    NSApp.terminate(nil)
                }
            }
            return
        }

        state.lastReply = reply.speak
        state.detail = reply.detail ?? ""
        state.statusMessage = "Listo"
        speakReply(reply.speak)
    }

    func quitApp() {
        speakReply("Hasta luego.")
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.8) {
            NSApp.terminate(nil)
        }
    }
}

@MainActor
final class AppState: ObservableObject {
    static let mutedDefaultsKey = "viernes.muted"

    @Published var isListening = false
    @Published var isSpeaking = false
    @Published var isMuted = false
    @Published var isKeyboardJobRunning = false
    @Published var statusMessage = "Listo"
    @Published var transcript = ""
    @Published var lastReply = "Viernes, en línea. Pulsa ⌥Espacio, escribe, o el icono."
    @Published var detail = ""
    @Published var ollamaModel = OllamaClient.defaultModel
    @Published var visionModel = OllamaClient.defaultVisionModel
    @Published var openaiModel = OpenAIClient.defaultModel
    @Published var brainProvider = BrainProvider.defaultValue.rawValue
    @Published var modeLine = "Auto · llama3.2"
    @Published var hasAPIKey = false
}

struct SettingsHelpView: View {
    @ObservedObject var state: AppState
    @State private var apiKeyDraft = ""
    @State private var keySaveMessage: String?

    private var modelName: String { OllamaClient.configuredModelName }
    private var visionName: String { OllamaClient.configuredVisionModelName }
    private var astraName: String { OpenAIClient.configuredModelName }

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 10) {
                Text("Viernes V5")
                    .font(.title2.weight(.semibold))
                Text("Asistente de barra de menús: reglas locales + cerebro Local (Ollama) o nube Astra (gpt-6-astra) + visión y teclado bajo demanda. Chat, mute y UI al estilo del sistema.")
                    .foregroundStyle(.secondary)
                Text("Atajo: ⌥Espacio. Si no responde desde otras apps, da Accesibilidad a Viernes en Ajustes del Sistema.")
                    .font(.callout)

                Divider()
                Text("Cerebro (Local / Astra / Auto)")
                    .font(.headline)
                Picker("Proveedor", selection: Binding(
                    get: { state.brainProvider },
                    set: { newValue in
                        let p = BrainProvider(rawValue: newValue) ?? .auto
                        BrainProvider.setCurrent(p)
                        state.brainProvider = p.rawValue
                        state.modeLine = {
                            switch p {
                            case .local: return "Local · \(OllamaClient.configuredModelName)"
                            case .astra: return "Astra · \(OpenAIClient.configuredModelName)"
                            case .auto:
                                return KeychainHelper.hasOpenAIKey()
                                    ? "Auto · Astra"
                                    : "Auto · \(OllamaClient.configuredModelName)"
                            }
                        }()
                    }
                )) {
                    Text("Local").tag(BrainProvider.local.rawValue)
                    Text("Astra").tag(BrainProvider.astra.rawValue)
                    Text("Auto").tag(BrainProvider.auto.rawValue)
                }
                .pickerStyle(.segmented)
                Text("Local = solo Ollama. Astra = solo OpenAI \(astraName) (falla sin clave). Auto = Astra si hay clave; si falla, Ollama.")
                    .font(.caption)
                    .foregroundStyle(.secondary)
                    .fixedSize(horizontal: false, vertical: true)

                Divider()
                Text("API key OpenAI (Keychain)")
                    .font(.headline)
                Text("Clave guardada: \(state.hasAPIKey ? "sí" : "no"). Service `com.danielrueda.Viernes`, account `openai_api_key`. Nunca se hardcodea ni se registra en logs.")
                    .font(.callout)
                    .fixedSize(horizontal: false, vertical: true)
                SecureField("Pegar API key (sk-…)", text: $apiKeyDraft)
                    .textFieldStyle(.roundedBorder)
                HStack {
                    Button("Guardar en Keychain") {
                        let ok = KeychainHelper.saveOpenAIKey(apiKeyDraft)
                        apiKeyDraft = ""
                        state.hasAPIKey = KeychainHelper.hasOpenAIKey()
                        keySaveMessage = ok
                            ? (state.hasAPIKey ? "Clave guardada." : "Clave borrada.")
                            : "No pude guardar en el Keychain."
                        if state.hasAPIKey, state.brainProvider == BrainProvider.auto.rawValue {
                            state.modeLine = "Auto · Astra"
                        }
                    }
                    .disabled(apiKeyDraft.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
                    Button("Borrar clave") {
                        KeychainHelper.deleteOpenAIKey()
                        apiKeyDraft = ""
                        state.hasAPIKey = false
                        keySaveMessage = "Clave eliminada del Keychain."
                        if state.brainProvider == BrainProvider.auto.rawValue {
                            state.modeLine = "Auto · \(OllamaClient.configuredModelName)"
                        }
                    }
                }
                if let keySaveMessage {
                    Text(keySaveMessage)
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }
                Text("O desde Terminal:\nsecurity add-generic-password -a openai_api_key -s com.danielrueda.Viernes -w 'sk-...' -U")
                    .font(.caption.monospaced())
                    .fixedSize(horizontal: false, vertical: true)

                Divider()
                Text("Coste Astra (aprox.)")
                    .font(.headline)
                Text("API gpt-6-astra ~$10/M tokens entrada y ~$50/M salida (aproximado). Confirma precios actuales en la página de pricing de OpenAI.")
                    .font(.callout)
                    .fixedSize(horizontal: false, vertical: true)

                Divider()
                Text("Voz y mute")
                    .font(.headline)
                Text("Por defecto habla las respuestas (TTS). El botón Con voz / Sin voz en el popover silencia el audio; el texto sigue en el chat. No existe la voz exacta de FRIDAY del MCU en macOS: se usa la mejor voz española femenina premium/enhanced disponible (es-CO / es-ES / es-MX).")
                    .font(.callout)
                    .fixedSize(horizontal: false, vertical: true)

                Divider()
                Text("Pantalla (bajo demanda)")
                    .font(.headline)
                Text("Di «mira la pantalla» o escribe lo mismo. Una sola captura → visión (Astra o Ollama según proveedor). Activa Grabación de pantalla: Ajustes → Privacidad y seguridad → Grabación de pantalla → Viernes.")
                    .font(.callout)
                    .fixedSize(horizontal: false, vertical: true)

                Divider()
                Text("Teclado (bajo pedido)")
                    .font(.headline)
                Text("Di «usa el teclado…» o «mientras como, escribe…». Necesita Accesibilidad. Tope ~10 min / 12k caracteres. Botón Detener trabajo. No escribe en campos de contraseña. El texto lo genera Astra u Ollama según el proveedor.")
                    .font(.callout)
                    .fixedSize(horizontal: false, vertical: true)

                Divider()
                Text("Ollama (local)")
                    .font(.headline)
                Text("1. Instala Ollama (ollama.com)\n2. ollama pull \(modelName)\n3. ollama pull \(visionName)\n4. Deja Ollama corriendo\nTexto: \(modelName) (`viernes.ollamaModel`)\nVisión: \(visionName) (`viernes.ollamaVisionModel`)\nAstra: \(astraName) (`viernes.openaiModel`)")
                    .font(.callout)
                    .fixedSize(horizontal: false, vertical: true)
                Text("Las reglas locales (hora, abrir apps, buscar…) nunca requieren nube. Sin Ollama ni clave Astra: error claro en español para chat libre / visión / teclado.")
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }
            .padding(20)
        }
        .frame(width: 440, height: 560)
        .onAppear {
            state.hasAPIKey = KeychainHelper.hasOpenAIKey()
        }
    }
}

enum PermissionGate {
    static func requestSpeechAndMicrophone() async -> Bool {
        let mic = await requestMicrophone()
        let speech = await requestSpeech()
        return mic && speech
    }

    private static func requestMicrophone() async -> Bool {
        await withCheckedContinuation { continuation in
            AVAudioApplication.requestRecordPermission { granted in
                continuation.resume(returning: granted)
            }
        }
    }

    private static func requestSpeech() async -> Bool {
        await withCheckedContinuation { continuation in
            SFSpeechRecognizer.requestAuthorization { status in
                continuation.resume(returning: status == .authorized)
            }
        }
    }
}
