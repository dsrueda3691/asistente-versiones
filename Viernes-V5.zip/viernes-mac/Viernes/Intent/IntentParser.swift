import Foundation

enum CodeTemplate: Equatable {
    case landingHTML
    case navbarHTML
}

enum Intent: Equatable {
    case greet
    case whoAmI
    case help
    case time
    case date
    case openApp(bundleID: String, displayName: String)
    case webSearch(query: String)
    case createFile(name: String, contents: String)
    case listDesktop
    case copyTemplate(CodeTemplate)
    case readClipboard
    case analyzeScreen(question: String)
    case keyboardJob(instruction: String)
    case quit
    case unknown(original: String)
}

/// Intents locales, en español, sin red. Quita vocativos tipo «Viernes», «oye», «hola».
struct IntentParser {
    func parse(_ raw: String) -> Intent {
        let cleaned = Self.stripVocative(Self.normalize(raw))
        if cleaned.isEmpty {
            return .greet
        }

        if Self.isQuit(cleaned) { return .quit }
        if Self.isWho(cleaned) { return .whoAmI }
        // Pantalla antes de help/escritorio: «qué estoy haciendo» / «mira la pantalla».
        if let screen = Self.analyzeScreen(cleaned, original: raw) { return screen }
        if let job = Self.keyboardJob(cleaned, original: raw) { return job }
        if Self.isHelp(cleaned) { return .help }
        if Self.isGreet(cleaned) { return .greet }
        if Self.isTime(cleaned) { return .time }
        if Self.isDate(cleaned) { return .date }
        if Self.isClipboard(cleaned) { return .readClipboard }
        if Self.isListDesktop(cleaned) { return .listDesktop }
        if let template = Self.codeTemplate(cleaned) { return .copyTemplate(template) }
        if let app = Self.openApp(cleaned) { return app }
        if let search = Self.webSearch(cleaned) { return search }
        if let file = Self.createFile(cleaned) { return file }

        return .unknown(original: raw)
    }

    static func normalize(_ text: String) -> String {
        text.folding(options: [.diacriticInsensitive, .caseInsensitive], locale: Locale(identifier: "es"))
            .replacingOccurrences(of: "¿", with: "")
            .replacingOccurrences(of: "?", with: "")
            .replacingOccurrences(of: "¡", with: "")
            .replacingOccurrences(of: "!", with: "")
            .replacingOccurrences(of: ",", with: " ")
            .replacingOccurrences(of: ".", with: " ")
            .replacingOccurrences(of: "  ", with: " ")
            .trimmingCharacters(in: .whitespacesAndNewlines)
            .lowercased()
    }

    static func stripVocative(_ text: String) -> String {
        var s = text
        let prefixes = [
            "oye viernes ", "hola viernes ", "hey viernes ", "ok viernes ",
            "bueno viernes ", "bien viernes ", "viernes ", "hola ", "oye ",
            "hey ", "ok ", "bueno ", "a ver "
        ]
        var changed = true
        while changed {
            changed = false
            for p in prefixes where s.hasPrefix(p) {
                s = String(s.dropFirst(p.count))
                changed = true
            }
        }
        if s == "viernes" || s == "oye" || s == "hola" {
            return s == "hola" ? "hola" : ""
        }
        return s.trimmingCharacters(in: .whitespacesAndNewlines)
    }

    private static func isQuit(_ s: String) -> Bool {
        let keys = [
            "adios", "hasta luego", "hasta pronto", "chao", "chau",
            "cierra", "cierra viernes", "cierra la app", "cierra la aplicacion",
            "sal", "salir", "apagate", "apagate viernes", "termina",
            "cierra te", "quit", "exit"
        ]
        return keys.contains(s) || s.hasPrefix("cierra viernes") || s.hasPrefix("apagate")
    }

    private static func isWho(_ s: String) -> Bool {
        s.contains("quien eres") || s.contains("como te llamas") ||
        s.contains("cual es tu nombre") || s.contains("quien es viernes") ||
        s.contains("que eres") || s.contains("presentate") || s == "quien eres tu"
    }

    private static func isHelp(_ s: String) -> Bool {
        // Evitar confundir «qué estoy haciendo» con ayuda.
        if s.contains("que estoy haciendo") || s.contains("que estoy viendo") { return false }
        return s.contains("que puedes") || s.contains("que sabes") ||
        s.contains("ayuda") || s.contains("que haces") ||
        s.contains("comandos") || s.contains("que se puede")
    }

    private static func isGreet(_ s: String) -> Bool {
        let keys = ["hola", "buenas", "buenos dias", "buenas tardes", "buenas noches", "hey", "que tal", "como estas", "holi"]
        return keys.contains(s)
    }

    private static func words(_ s: String) -> [String] {
        s.split(whereSeparator: { $0.isWhitespace || $0.isPunctuation }).map(String.init)
    }

    private static func isTime(_ s: String) -> Bool {
        let w = Set(words(s))
        return w.contains("hora") || s.contains("que hora") || s.contains("la hora")
    }

    private static func isDate(_ s: String) -> Bool {
        s.contains("fecha") || s.contains("que dia") || s.contains("que dia es") ||
        s.contains("dia de hoy") || s.contains("a cuanto estamos")
    }

    private static func isClipboard(_ s: String) -> Bool {
        s.contains("portapapeles") || s.contains("clipboard") ||
        s.contains("que copie") || s.contains("lee lo que copie") ||
        s.contains("di lo del porta") || (s.contains("lee") && s.contains("porta"))
    }

    private static func isListDesktop(_ s: String) -> Bool {
        // Solo archivos del Escritorio, no «pantalla».
        if s.contains("pantalla") || s.contains("screen") { return false }
        return (s.contains("escritorio") || s.contains("desktop")) &&
        (s.contains("lista") || s.contains("enumera") || s.contains("archivos") ||
         s.contains("que hay") || s.contains("muestra") || s.contains("cuantos"))
    }

    /// «mira la pantalla», «qué hay en pantalla», «qué estoy haciendo», etc.
    private static func keyboardJob(_ s: String, original: String) -> Intent? {
        let triggers = [
            "usa el teclado", "usar el teclado", "con el teclado",
            "mientras como", "mientras salgo", "mientras no estoy",
            "deja haciendo", "deja escribiendo", "sigue escribiendo",
            "escribe en la app", "escribe esto", "tipea", "tipear",
            "trabajo de teclado", "modo teclado", "keyboard"
        ]
        guard triggers.contains(where: { s.contains($0) }) else { return nil }
        var instruction = s
        for prefix in ["viernes ", "oye ", "por favor "] {
            if instruction.hasPrefix(prefix) {
                instruction = String(instruction.dropFirst(prefix.count))
            }
        }
        instruction = instruction.trimmingCharacters(in: .whitespacesAndNewlines)
        if instruction.isEmpty {
            instruction = original.trimmingCharacters(in: .whitespacesAndNewlines)
        }
        return .keyboardJob(instruction: instruction)
    }

    private static func analyzeScreen(_ s: String, original: String) -> Intent? {
        let question = original.trimmingCharacters(in: .whitespacesAndNewlines)
        let fallbackQ = question.isEmpty ? "¿Qué hay en pantalla?" : question

        let whatAmIDoing =
            s.contains("que estoy haciendo") ||
            s.contains("que estoy viendo") ||
            s.contains("en que estoy") ||
            s.contains("que hago ahora") ||
            s.contains("que tengo abierto") ||
            s.contains("que tengo en pantalla")

        if whatAmIDoing {
            return .analyzeScreen(question: fallbackQ)
        }

        let hasScreen =
            s.contains("pantalla") ||
            s.contains("screen") ||
            s.contains("monitor") ||
            s.contains("display")

        let lookVerb =
            s.contains("mira") || s.contains("mirar") ||
            s.contains("observa") || s.contains("observar") ||
            s.contains("describe") || s.contains("describeme") ||
            s.contains("ve la") || s.contains("ves la") ||
            s.contains("ve mi") || s.contains("ves mi") ||
            s.contains("que hay") || s.contains("que se ve") ||
            s.contains("dime que") || s.contains("analiza") ||
            s.contains("revisa") || s.contains("chequea") ||
            s.contains("echale un vistazo") || s.contains("un vistazo")

        if hasScreen && lookVerb {
            return .analyzeScreen(question: fallbackQ)
        }

        // «mira lo que estoy haciendo / viendo» sin decir pantalla.
        if (s.contains("mira") || s.contains("observa") || s.contains("revisa")) &&
            (s.contains("haciendo") || s.contains("viendo") || s.contains("trabajo")) {
            return .analyzeScreen(question: fallbackQ)
        }

        return nil
    }

    private static func codeTemplate(_ s: String) -> CodeTemplate? {
        if s.contains("navbar") || s.contains("barra de navegacion") || s.contains("nav bar") ||
            (s.contains("codigo") && s.contains("nav")) {
            return .navbarHTML
        }
        if s.contains("landing") || s.contains("pagina de aterrizaje") ||
            (s.contains("html") && (s.contains("pagina") || s.contains("web") || s.contains("landing"))) ||
            s.contains("preparame un html") || s.contains("prepara un html") {
            return .landingHTML
        }
        if s.contains("codigo de navbar") { return .navbarHTML }
        return nil
    }

    private static let apps: [(names: [String], bundle: String, display: String)] = [
        (["safari"], "com.apple.Safari", "Safari"),
        (["finder", "el finder"], "com.apple.finder", "Finder"),
        (["notas", "notes", "la app notas"], "com.apple.Notes", "Notas"),
        (["mail", "correo", "el correo"], "com.apple.mail", "Mail"),
        (["calendario", "calendar"], "com.apple.iCal", "Calendario"),
        (["terminal"], "com.apple.Terminal", "Terminal"),
        (["ajustes del sistema", "preferencias del sistema", "system settings",
          "ajustes", "configuracion"], "com.apple.systempreferences", "Ajustes del Sistema")
    ]

    private static func openApp(_ s: String) -> Intent? {
        let triggers = ["abre", "abrir", "abra", "lanzar", "lanza", "abreme", "iniciame", "inicia"]
        let looksLikeOpen = triggers.contains(where: { s.hasPrefix($0) || s.contains(" \($0) ") })
            || s.hasPrefix("abre ") || s.hasPrefix("abrir ") || s.hasPrefix("lanza ")
        guard looksLikeOpen else { return nil }

        for app in apps {
            for name in app.names {
                if s.contains(name) {
                    return .openApp(bundleID: app.bundle, displayName: app.display)
                }
            }
        }
        return nil
    }

    private static func webSearch(_ s: String) -> Intent? {
        let patterns = ["busca en google ", "buscar en google ", "busca en internet ",
                        "busca por ", "buscar ", "busca ", "googlea ", "google "]
        for p in patterns where s.hasPrefix(p) {
            let q = String(s.dropFirst(p.count)).trimmingCharacters(in: .whitespaces)
            if !q.isEmpty { return .webSearch(query: q) }
        }
        if s.hasPrefix("busca") {
            let q = String(s.dropFirst(5)).trimmingCharacters(in: .whitespaces)
            if !q.isEmpty { return .webSearch(query: q) }
        }
        return nil
    }

    private static func createFile(_ s: String) -> Intent? {
        guard s.contains("archivo") || s.contains("fichero") || s.contains("nota en el escritorio") else {
            return nil
        }
        guard s.contains("crea") || s.contains("crear") || s.contains("haz un") ||
                s.contains("escribe") || s.contains("guardame") || s.contains("nuevo archivo") else {
            return nil
        }

        var name = "nota-viernes"
        var contents = "Creado por Viernes.\n"

        if let range = s.range(of: "llamado ") ?? s.range(of: "que se llame ") ?? s.range(of: "con nombre ") {
            var rest = String(s[range.upperBound...]).trimmingCharacters(in: .whitespaces)
            if let con = rest.range(of: " con ") {
                name = String(rest[..<con.lowerBound])
                contents = String(rest[con.upperBound...]).trimmingCharacters(in: .whitespaces)
                if contents.isEmpty { contents = "Creado por Viernes.\n" }
            } else {
                name = rest
            }
        } else if s.contains("archivo ") {
            if let r = s.range(of: "archivo ") {
                var rest = String(s[r.upperBound...]).trimmingCharacters(in: .whitespaces)
                rest = rest.replacingOccurrences(of: "en el escritorio", with: "")
                    .trimmingCharacters(in: .whitespaces)
                if !rest.isEmpty && rest != "de texto" && rest != "txt" {
                    name = rest
                }
            }
        }

        name = name.trimmingCharacters(in: .whitespacesAndNewlines)
        if name.isEmpty { name = "nota-viernes" }
        return .createFile(name: name, contents: contents)
    }
}
