import SwiftUI
import AppKit

struct PopoverView: View {
    @ObservedObject var state: AppState
    var onListen: () -> Void
    var onQuit: () -> Void
    var onSendChat: (String) -> Void
    var onToggleMute: () -> Void
    var onStopJob: () -> Void
    var onOpenSettings: () -> Void
    var onProviderChange: (String) -> Void

    @Environment(\.colorScheme) private var colorScheme
    @State private var draft = ""
    @FocusState private var chatFocused: Bool

    var body: some View {
        VStack(alignment: .leading, spacing: 14) {
            header

            SpeakingWaveform(
                isSpeaking: state.isSpeaking,
                isListening: state.isListening,
                colorScheme: colorScheme
            )
            .frame(height: 36)

            HStack(spacing: 8) {
                Text("Modo · \(state.modeLine)")
                    .font(.caption2)
                    .foregroundStyle(.secondary)
                    .lineLimit(1)
                Spacer(minLength: 0)
                Picker("", selection: Binding(
                    get: { state.brainProvider },
                    set: { onProviderChange($0) }
                )) {
                    Text("Local").tag(BrainProvider.local.rawValue)
                    Text("Astra").tag(BrainProvider.astra.rawValue)
                    Text("Auto").tag(BrainProvider.auto.rawValue)
                }
                .pickerStyle(.segmented)
                .frame(maxWidth: 200)
                .controlSize(.small)
                .labelsHidden()
                .help("Cerebro: Local (Ollama), Astra (OpenAI), o Auto")
            }

            participantRow(
                title: "Tú",
                badge: "T",
                status: state.isListening ? "Escuchando…" : (state.transcript.isEmpty ? "—" : "Listo"),
                body: state.transcript.isEmpty ? "⌥Espacio, Escuchar, o escribe abajo." : state.transcript,
                accentListening: state.isListening
            )

            participantRow(
                title: "Viernes",
                badge: "V",
                status: state.isSpeaking ? "Hablando…" : (state.isKeyboardJobRunning ? "Trabajando…" : statusLabel),
                body: state.lastReply.isEmpty ? "—" : state.lastReply,
                accentSpeaking: state.isSpeaking
            )

            if !state.detail.isEmpty {
                ScrollView {
                    Text(state.detail)
                        .font(.caption.monospaced())
                        .foregroundStyle(.primary)
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .textSelection(.enabled)
                }
                .frame(maxHeight: 72)
                .padding(10)
                .background(Color(nsColor: .textBackgroundColor).opacity(colorScheme == .dark ? 0.4 : 0.55))
                .clipShape(RoundedRectangle(cornerRadius: 10, style: .continuous))
            }

            HStack(spacing: 8) {
                TextField("Escribe tu mensaje…", text: $draft, axis: .vertical)
                    .textFieldStyle(.plain)
                    .padding(10)
                    .background(Color(nsColor: .textBackgroundColor).opacity(colorScheme == .dark ? 0.5 : 0.7))
                    .clipShape(RoundedRectangle(cornerRadius: 10, style: .continuous))
                    .lineLimit(1...3)
                    .focused($chatFocused)
                    .onSubmit { sendDraft() }

                Button {
                    sendDraft()
                } label: {
                    Image(systemName: "paperplane.fill")
                        .frame(width: 36, height: 36)
                }
                .buttonStyle(.borderedProminent)
                .disabled(draft.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty || state.isListening)
            }

            HStack(spacing: 8) {
                Button {
                    onListen()
                } label: {
                    Label(state.isListening ? "Detener" : "Escuchar", systemImage: state.isListening ? "stop.fill" : "headphones")
                }
                .buttonStyle(.bordered)

                Button {
                    onToggleMute()
                } label: {
                    Label(
                        state.isMuted ? "Sin voz" : "Con voz",
                        systemImage: state.isMuted ? "speaker.slash.fill" : "speaker.wave.2.fill"
                    )
                }
                .buttonStyle(.bordered)
                .tint(state.isMuted ? Color.orange : Color.accentColor)

                if state.isKeyboardJobRunning {
                    Button("Detener trabajo") {
                        onStopJob()
                    }
                    .buttonStyle(.bordered)
                    .tint(.red)
                }

                Spacer(minLength: 0)

                Button("Salir") {
                    onQuit()
                }
                .buttonStyle(.borderless)
                .foregroundStyle(.secondary)
            }

            Text(footerHint)
                .font(.caption2)
                .foregroundStyle(.tertiary)
                .fixedSize(horizontal: false, vertical: true)
        }
        .padding(16)
        .frame(width: 390)
        .background(Color(nsColor: .windowBackgroundColor))
        .preferredColorScheme(nil)
    }

    private var header: some View {
        HStack(alignment: .center, spacing: 10) {
            Image(systemName: state.isListening ? "waveform" : "sparkles")
                .symbolRenderingMode(.hierarchical)
                .foregroundStyle(.tint)
                .font(.title2)
            VStack(alignment: .leading, spacing: 2) {
                Text("Viernes")
                    .font(.title3.weight(.semibold))
                    .foregroundStyle(.primary)
                HStack(spacing: 6) {
                    Circle()
                        .fill(statusDotColor)
                        .frame(width: 7, height: 7)
                    Text(headerStatus)
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }
            }
            Spacer()
            Button {
                onOpenSettings()
            } label: {
                Image(systemName: "gearshape")
                    .foregroundStyle(.secondary)
            }
            .buttonStyle(.borderless)
            .help("Ayuda y configuración")
        }
    }

    private var headerStatus: String {
        if state.isKeyboardJobRunning { return state.statusMessage.isEmpty ? "Trabajo en curso…" : state.statusMessage }
        if state.isSpeaking { return "Hablando…" }
        if state.isListening { return "Escuchando…" }
        return state.statusMessage
    }

    private var statusLabel: String {
        if state.statusMessage == "Pensando…" || state.statusMessage.hasPrefix("Mirando") {
            return state.statusMessage
        }
        return state.statusMessage
    }

    private var statusDotColor: Color {
        if state.isSpeaking { return .cyan }
        if state.isListening { return .green }
        if state.isKeyboardJobRunning { return .orange }
        return .green.opacity(0.7)
    }

    private var footerHint: String {
        if state.isMuted {
            return "Mute activo: responde en chat, sin TTS. Teclado solo si lo pides. Pantalla solo bajo demanda."
        }
        switch BrainProvider(rawValue: state.brainProvider) ?? .auto {
        case .local:
            return "Local: ollama pull \(state.ollamaModel) y \(state.visionModel). Reglas offline siempre."
        case .astra:
            return "Astra: \(state.openaiModel). Necesitas API key en Keychain. Reglas locales siguen offline."
        case .auto:
            return "Auto: Astra si hay clave; si no, Ollama. Reglas locales no usan nube."
        }
    }

    private func sendDraft() {
        let text = draft.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !text.isEmpty else { return }
        draft = ""
        onSendChat(text)
    }

    @ViewBuilder
    private func participantRow(
        title: String,
        badge: String,
        status: String,
        body: String,
        accentListening: Bool = false,
        accentSpeaking: Bool = false
    ) -> some View {
        HStack(alignment: .top, spacing: 10) {
            ZStack {
                Circle()
                    .fill(Color.accentColor.opacity(colorScheme == .dark ? 0.35 : 0.2))
                    .frame(width: 32, height: 32)
                Text(badge)
                    .font(.caption.weight(.bold))
                    .foregroundStyle(.primary)
            }
            VStack(alignment: .leading, spacing: 4) {
                HStack {
                    Text(title)
                        .font(.caption.weight(.semibold))
                        .foregroundStyle(.secondary)
                    Spacer()
                    Text(status)
                        .font(.caption2)
                        .foregroundStyle(accentSpeaking ? Color.cyan : (accentListening ? Color.green : Color.secondary))
                }
                Text(body)
                    .font(.callout)
                    .foregroundStyle(.primary)
                    .fixedSize(horizontal: false, vertical: true)
            }
        }
        .padding(10)
        .background(
            RoundedRectangle(cornerRadius: 12, style: .continuous)
                .fill(Color(nsColor: .controlBackgroundColor).opacity(colorScheme == .dark ? 0.55 : 0.65))
        )
    }
}

struct SpeakingWaveform: View {
    var isSpeaking: Bool
    var isListening: Bool
    var colorScheme: ColorScheme

    private let barCount = 11
    @State private var phase = false

    var body: some View {
        HStack(spacing: 3) {
            ForEach(0..<barCount, id: \.self) { index in
                Capsule()
                    .fill(barColor)
                    .frame(width: 5, height: height(for: index))
                    .shadow(color: isSpeaking ? Color.cyan.opacity(0.45) : .clear, radius: 4)
                    .animation(
                        isSpeaking
                            ? .easeInOut(duration: 0.32 + Double(index % 4) * 0.05).repeatForever(autoreverses: true)
                            : isListening
                                ? .easeInOut(duration: 0.5).repeatForever(autoreverses: true)
                                : .easeOut(duration: 0.25),
                        value: phase
                    )
            }
        }
        .frame(maxWidth: .infinity)
        .padding(.vertical, 6)
        .padding(.horizontal, 8)
        .background(
            RoundedRectangle(cornerRadius: 10, style: .continuous)
                .fill(Color(nsColor: .controlBackgroundColor).opacity(colorScheme == .dark ? 0.65 : 0.75))
        )
        .opacity(isSpeaking || isListening ? 1.0 : 0.5)
        .onAppear { phase = true }
        .onChange(of: isSpeaking) { _, _ in phase.toggle() }
        .onChange(of: isListening) { _, _ in phase.toggle() }
    }

    private var barColor: Color {
        if isSpeaking {
            return colorScheme == .dark ? Color.cyan.opacity(0.95) : Color(red: 0.0, green: 0.55, blue: 0.78)
        }
        if isListening {
            return Color.accentColor.opacity(colorScheme == .dark ? 0.9 : 0.8)
        }
        return Color.secondary.opacity(colorScheme == .dark ? 0.45 : 0.35)
    }

    private func height(for index: Int) -> CGFloat {
        if isSpeaking {
            let base: [CGFloat] = [8, 14, 22, 18, 28, 16, 24, 12, 20, 10, 14]
            return phase ? base[index % base.count] : (7 + CGFloat((index * 2) % 12))
        }
        if isListening {
            let base: [CGFloat] = [7, 12, 9, 14, 10, 13, 8, 12, 9, 11, 7]
            return phase ? base[index % base.count] : 7
        }
        return 5
    }
}
