import Foundation

enum CodeTemplate: Equatable {
    case landingHTML
    case navbarHTML
}

enum Intent: Equatable {
    case greet
    case whoAmI
    case help
    case time
    case date
    case openApp(bundleID: String, displayName: String)
    case webSearch(query: String)
    case createFile(name: String, contents: String)
    case listDesktop
    case copyTemplate(CodeTemplate)
    case readClipboard
    case analyzeScreen(question: String)
    case keyboardJob(instruction: String)
    case composeMail(to: String, subject: String, body: String, cc: String?)
    case createCalendarEvent(title: String, startHint: String, endHint: String, notes: String?, location: String?)
    case createReminder(title: String, dueHint: String?)
    case listReminders
    case createNote(title: String, body: String)
    case agentMode(goal: String)
    case quit
    case unknown(original: String)
}

/// Intents locales, en español, sin red. Quita vocativos tipo «Viernes», «oye», «hola».
struct IntentParser {
    func parse(_ raw: String) -> Intent {
        let cleaned = Self.stripVocative(Self.normalize(raw))
        if cleaned.isEmpty {
            return .greet
        }

        if Self.isQuit(cleaned) { return .quit }
        if Self.isWho(cleaned) { return .whoAmI }
        // Pantalla antes de help/escritorio: «qué estoy haciendo» / «mira la pantalla».
        if let screen = Self.analyzeScreen(cleaned, original: raw) { return screen }
        if let job = Self.keyboardJob(cleaned, original: raw) { return job }
        if let mail = Self.composeMail(cleaned, original: raw) { return mail }
        if let agent = Self.agentMode(cleaned, original: raw) { return agent }
        if let cal = Self.createCalendarEvent(cleaned, original: raw) { return cal }
        if let rem = Self.createReminder(cleaned, original: raw) { return rem }
        if Self.isListReminders(cleaned) { return .listReminders }
        if let note = Self.createNote(cleaned, original: raw) { return note }
        if Self.isHelp(cleaned) { return .help }
        if Self.isGreet(cleaned) { return .greet }
        if Self.isTime(cleaned) { return .time }
        if Self.isDate(cleaned) { return .date }
        if Self.isClipboard(cleaned) { return .readClipboard }
        if Self.isListDesktop(cleaned) { return .listDesktop }
        if let template = Self.codeTemplate(cleaned) { return .copyTemplate(template) }
        if let app = Self.openApp(cleaned) { return app }
        if let search = Self.webSearch(cleaned) { return search }
        if let file = Self.createFile(cleaned) { return file }

        return .unknown(original: raw)
    }

    static func normalize(_ text: String) -> String {
        text.folding(options: [.diacriticInsensitive, .caseInsensitive], locale: Locale(identifier: "es"))
            .replacingOccurrences(of: "¿", with: "")
            .replacingOccurrences(of: "?", with: "")
            .replacingOccurrences(of: "¡", with: "")
            .replacingOccurrences(of: "!", with: "")
            .replacingOccurrences(of: ",", with: " ")
            .replacingOccurrences(of: ".", with: " ")
            .replacingOccurrences(of: "  ", with: " ")
            .trimmingCharacters(in: .whitespacesAndNewlines)
            .lowercased()
    }

    static func stripVocative(_ text: String) -> String {
        var s = text
        let prefixes = [
            "oye viernes ", "hola viernes ", "hey viernes ", "ok viernes ",
            "bueno viernes ", "bien viernes ", "viernes ", "hola ", "oye ",
            "hey ", "ok ", "bueno ", "a ver "
        ]
        var changed = true
        while changed {
            changed = false
            for p in prefixes where s.hasPrefix(p) {
                s = String(s.dropFirst(p.count))
                changed = true
            }
        }
        if s == "viernes" || s == "oye" || s == "hola" {
            return s == "hola" ? "hola" : ""
        }
        return s.trimmingCharacters(in: .whitespacesAndNewlines)
    }

    private static func isQuit(_ s: String) -> Bool {
        let keys = [
            "adios", "hasta luego", "hasta pronto", "chao", "chau",
            "cierra", "cierra viernes", "cierra la app", "cierra la aplicacion",
            "sal", "salir", "apagate", "apagate viernes", "termina",
            "cierra te", "quit", "exit"
        ]
        return keys.contains(s) || s.hasPrefix("cierra viernes") || s.hasPrefix("apagate")
    }

    private static func isWho(_ s: String) -> Bool {
        s.contains("quien eres") || s.contains("como te llamas") ||
        s.contains("cual es tu nombre") || s.contains("quien es viernes") ||
        s.contains("que eres") || s.contains("presentate") || s == "quien eres tu"
    }

    private static func isHelp(_ s: String) -> Bool {
        // Evitar confundir «qué estoy haciendo» con ayuda.
        if s.contains("que estoy haciendo") || s.contains("que estoy viendo") { return false }
        return s.contains("que puedes") || s.contains("que sabes") ||
        s.contains("ayuda") || s.contains("que haces") ||
        s.contains("comandos") || s.contains("que se puede")
    }

    private static func isGreet(_ s: String) -> Bool {
        let keys = ["hola", "buenas", "buenos dias", "buenas tardes", "buenas noches", "hey", "que tal", "como estas", "holi"]
        return keys.contains(s)
    }

    private static func words(_ s: String) -> [String] {
        s.split(whereSeparator: { $0.isWhitespace || $0.isPunctuation }).map(String.init)
    }

    private static func isTime(_ s: String) -> Bool {
        let w = Set(words(s))
        return w.contains("hora") || s.contains("que hora") || s.contains("la hora")
    }

    private static func isDate(_ s: String) -> Bool {
        s.contains("fecha") || s.contains("que dia") || s.contains("que dia es") ||
        s.contains("dia de hoy") || s.contains("a cuanto estamos")
    }

    private static func isClipboard(_ s: String) -> Bool {
        s.contains("portapapeles") || s.contains("clipboard") ||
        s.contains("que copie") || s.contains("lee lo que copie") ||
        s.contains("di lo del porta") || (s.contains("lee") && s.contains("porta"))
    }

    private static func isListDesktop(_ s: String) -> Bool {
        // Solo archivos del Escritorio, no «pantalla».
        if s.contains("pantalla") || s.contains("screen") { return false }
        return (s.contains("escritorio") || s.contains("desktop")) &&
        (s.contains("lista") || s.contains("enumera") || s.contains("archivos") ||
         s.contains("que hay") || s.contains("muestra") || s.contains("cuantos"))
    }



    private static func agentMode(_ s: String, original: String) -> Intent? {
        let triggers = [
            "haz esto en pantalla", "haz esto en la pantalla",
            "agente:", "modo agente", "agent:", "agente ",
            "resuelve esto en pantalla", "arregla esto en pantalla",
            "hazlo en pantalla", "actua en pantalla"
        ]
        guard triggers.contains(where: { s.contains($0) || s.hasPrefix($0.trimmingCharacters(in: .whitespaces)) }) else {
            // "agente: …" con prefijo
            if s.hasPrefix("agente") || s.hasPrefix("agent") {
                var goal = original.trimmingCharacters(in: .whitespacesAndNewlines)
                if let r = goal.range(of: ":") {
                    goal = String(goal[r.upperBound...]).trimmingCharacters(in: .whitespacesAndNewlines)
                } else {
                    goal = s.replacingOccurrences(of: "agente", with: "")
                        .replacingOccurrences(of: "agent", with: "")
                        .trimmingCharacters(in: .whitespacesAndNewlines)
                }
                if goal.isEmpty { goal = original }
                return .agentMode(goal: goal)
            }
            return nil
        }
        var goal = original.trimmingCharacters(in: .whitespacesAndNewlines)
        for p in ["agente:", "Agente:", "agent:", "Agent:"] {
            if let r = goal.range(of: p) {
                goal = String(goal[r.upperBound...]).trimmingCharacters(in: .whitespacesAndNewlines)
                break
            }
        }
        if goal.isEmpty { goal = "Haz lo que se ve en pantalla." }
        return .agentMode(goal: goal)
    }

    private static func createCalendarEvent(_ s: String, original: String) -> Intent? {
        let triggers = [
            "crea un evento", "crear un evento", "agenda un evento", "agendar un evento",
            "nuevo evento", "anade un evento", "añade un evento", "pon un evento",
            "crea evento", "agendar ", "agenda reunion", "agenda una reunion",
            "crea una cita", "nueva cita", "calendar event"
        ]
        guard triggers.contains(where: { s.contains($0) }) else { return nil }
        var title = "Evento"
        var startHint = ""
        var endHint = ""
        var notes: String? = nil
        var location: String? = nil

        if let r = s.range(of: " llamado ") ?? s.range(of: " titulado ") ?? s.range(of: " titulo ") ?? s.range(of: " que se llame ") {
            var rest = String(s[r.upperBound...]).trimmingCharacters(in: .whitespaces)
            let cuts = [" manana", " hoy", " a las", " el ", " desde", " hasta", " en ", " notas ", " ubicacion ", " lugar "]
            var end = rest.endIndex
            for c in cuts {
                if let f = rest.range(of: c), f.lowerBound < end { end = f.lowerBound }
            }
            let t = String(rest[..<end]).trimmingCharacters(in: .whitespacesAndNewlines)
            if !t.isEmpty { title = t }
        } else if let r = s.range(of: "evento ") {
            var rest = String(s[r.upperBound...]).trimmingCharacters(in: .whitespaces)
            for prefix in ["llamado ", "de ", "para "] {
                if rest.hasPrefix(prefix) { rest = String(rest.dropFirst(prefix.count)) }
            }
            let cuts = [" manana", " hoy", " a las", " el "]
            var end = rest.endIndex
            for c in cuts {
                if let f = rest.range(of: c), f.lowerBound < end { end = f.lowerBound }
            }
            let t = String(rest[..<end]).trimmingCharacters(in: .whitespacesAndNewlines)
            if !t.isEmpty && t.count < 80 { title = t }
        }

        // Tiempo
        for key in [" manana", " hoy", " pasado manana", " a las ", " el lunes", " el martes", " el miercoles", " el jueves", " el viernes"] {
            if s.contains(key.trimmingCharacters(in: .whitespaces)) {
                startHint = s // el servicio parsea loose
                break
            }
        }
        if startHint.isEmpty { startHint = original }

        if let r = s.range(of: " hasta ") ?? s.range(of: " hasta las ") {
            endHint = String(s[r.lowerBound...])
        }
        if let r = s.range(of: " en ") ?? s.range(of: " lugar ") ?? s.range(of: " ubicacion ") {
            var loc = String(s[r.upperBound...]).trimmingCharacters(in: .whitespaces)
            if let cut = loc.range(of: " notas ") { loc = String(loc[..<cut.lowerBound]) }
            location = loc.trimmingCharacters(in: .whitespacesAndNewlines)
        }
        if let r = s.range(of: " notas ") ?? s.range(of: " nota ") ?? s.range(of: " diciendo ") {
            notes = String(s[r.upperBound...]).trimmingCharacters(in: .whitespacesAndNewlines)
        }
        return .createCalendarEvent(title: title, startHint: startHint, endHint: endHint, notes: notes, location: location)
    }

    private static func createReminder(_ s: String, original: String) -> Intent? {
        // Evitar choque con list
        if isListReminders(s) { return nil }
        let triggers = [
            "crea un recordatorio", "crear un recordatorio", "recuerdame", "recuerda me",
            "nuevo recordatorio", "pon un recordatorio", "anade un recordatorio",
            "añade un recordatorio", "create reminder", "remind me"
        ]
        guard triggers.contains(where: { s.contains($0) }) else { return nil }
        var title = "Recordatorio"
        var dueHint: String? = nil

        if let r = s.range(of: "recuerdame ") ?? s.range(of: "remind me ") ?? s.range(of: "recordatorio ") {
            var rest = String(s[r.upperBound...]).trimmingCharacters(in: .whitespaces)
            for p in ["que ", "de ", "llamado "] {
                if rest.hasPrefix(p) { rest = String(rest.dropFirst(p.count)) }
            }
            title = rest
            // Separar due
            for key in [" manana", " hoy", " el ", " a las ", " para el "] {
                if let f = rest.range(of: key) {
                    title = String(rest[..<f.lowerBound]).trimmingCharacters(in: .whitespaces)
                    dueHint = String(rest[f.lowerBound...]).trimmingCharacters(in: .whitespaces)
                    break
                }
            }
        }
        title = title.trimmingCharacters(in: .whitespacesAndNewlines)
        if title.isEmpty { title = "Recordatorio" }
        if dueHint == nil {
            for key in ["manana", "hoy", "a las"] where s.contains(key) {
                dueHint = s
                break
            }
        }
        return .createReminder(title: title, dueHint: dueHint)
    }

    private static func isListReminders(_ s: String) -> Bool {
        let listish = s.contains("lista") || s.contains("muestra") || s.contains("que recordatorios") ||
            s.contains("proximos recordatorios") || s.contains("mis recordatorios") ||
            s.contains("list reminders") || s.contains("recordatorios pendientes")
        return listish && s.contains("recordator")
    }

    private static func createNote(_ s: String, original: String) -> Intent? {
        let triggers = [
            "crea una nota", "crear una nota", "nueva nota", "haz una nota",
            "anade una nota", "añade una nota", "nota en notes", "create note",
            "escribe una nota", "guardar nota", "guarda una nota"
        ]
        guard triggers.contains(where: { s.contains($0) }) else { return nil }
        var title = "Nota Viernes"
        var body = ""

        if let r = s.range(of: " llamada ") ?? s.range(of: " titulada ") ?? s.range(of: " titulo ") ?? s.range(of: " llamado ") {
            var rest = String(s[r.upperBound...]).trimmingCharacters(in: .whitespaces)
            if let con = rest.range(of: " que diga ") ?? rest.range(of: " con ") ?? rest.range(of: " cuerpo ") ?? rest.range(of: " body ") {
                title = String(rest[..<con.lowerBound]).trimmingCharacters(in: .whitespaces)
                body = String(rest[con.upperBound...]).trimmingCharacters(in: .whitespaces)
            } else {
                title = rest
            }
        } else if let r = s.range(of: " que diga ") ?? s.range(of: " diciendo ") ?? s.range(of: " con texto ") {
            body = String(s[r.upperBound...]).trimmingCharacters(in: .whitespacesAndNewlines)
        } else if let r = s.range(of: "nota ") {
            let rest = String(s[r.upperBound...]).trimmingCharacters(in: .whitespaces)
            if !rest.isEmpty && rest.count < 60 { title = rest }
        }
        if title.isEmpty { title = "Nota Viernes" }
        return .createNote(title: title, body: body)
    }

    /// «envía un correo a…», «manda un mail…», «redacta un correo…».
    /// Parsea lo que pueda; campos vacíos los puede completar el Brain.
    private static func composeMail(_ s: String, original: String) -> Intent? {
        let triggers = [
            "envia un correo", "enviar un correo", "envia un mail", "enviar un mail",
            "manda un correo", "mandar un correo", "manda un mail", "mandar un mail",
            "redacta un correo", "redactar un correo", "redacta un mail", "redactar un mail",
            "escribe un correo", "escribir un correo", "escribe un mail", "escribir un mail",
            "manda correo", "envia correo", "envio un correo", "envio un mail",
            "compose mail", "send mail", "send email", "enviar correo", "enviar mail"
        ]
        guard triggers.contains(where: { s.contains($0) }) else { return nil }

        var to = ""
        var subject = ""
        var body = ""
        var cc: String? = nil

        // Destinatario: "a X" / "para X" / "to X"
        if let r = s.range(of: " a ") ?? s.range(of: " para ") ?? s.range(of: " to ") {
            var rest = String(s[r.upperBound...]).trimmingCharacters(in: .whitespaces)
            // Cortar en con asunto / que diga / diciendo / sobre / subject / cuerpo / cc
            let cutKeys = [" con asunto ", " asunto ", " que diga ", " diciendo ", " sobre ",
                           " subject ", " cuerpo ", " body ", " cc ", " con copia "]
            var cutAt: String.Index? = nil
            for key in cutKeys {
                if let found = rest.range(of: key) {
                    if cutAt == nil || found.lowerBound < cutAt! {
                        cutAt = found.lowerBound
                    }
                }
            }
            if let cutAt {
                to = String(rest[..<cutAt]).trimmingCharacters(in: .whitespaces)
            } else {
                // Puede ser solo email/nombre al final de un disparador corto
                to = rest.trimmingCharacters(in: .whitespaces)
            }
            // Limpiar restos de puntuación / "por favor"
            to = to.replacingOccurrences(of: " por favor", with: "")
                .trimmingCharacters(in: CharacterSet.whitespacesAndNewlines.union(.punctuationCharacters))
        }

        // Asunto
        for key in [" con asunto ", " asunto ", " subject "] {
            if let r = s.range(of: key) {
                var rest = String(s[r.upperBound...]).trimmingCharacters(in: .whitespaces)
                let cutKeys = [" que diga ", " diciendo ", " cuerpo ", " body ", " y cuerpo ", " cc "]
                var end = rest.endIndex
                for ck in cutKeys {
                    if let found = rest.range(of: ck), found.lowerBound < end {
                        end = found.lowerBound
                    }
                }
                subject = String(rest[..<end]).trimmingCharacters(in: .whitespacesAndNewlines)
                break
            }
        }

        // Cuerpo: "que diga", "diciendo", "cuerpo", "body"
        for key in [" que diga ", " diciendo ", " cuerpo ", " body ", " y diga ", " texto "] {
            if let r = s.range(of: key) {
                body = String(s[r.upperBound...]).trimmingCharacters(in: .whitespacesAndNewlines)
                // Quitar un posible "cc …" al final
                if let ccRange = body.range(of: " cc ") {
                    let maybeCC = String(body[ccRange.upperBound...]).trimmingCharacters(in: .whitespaces)
                    body = String(body[..<ccRange.lowerBound]).trimmingCharacters(in: .whitespaces)
                    if !maybeCC.isEmpty { cc = maybeCC }
                }
                break
            }
        }

        // Cc explícito
        if cc == nil, let r = s.range(of: " cc ") ?? s.range(of: " con copia a ") ?? s.range(of: " copia a ") {
            cc = String(s[r.upperBound...]).trimmingCharacters(in: .whitespacesAndNewlines)
        }

        // Si no hay "a X" pero hay un email en la frase, úsalo
        if to.isEmpty {
            let pattern = #"[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}"#
            if let regex = try? NSRegularExpression(pattern: pattern, options: [.caseInsensitive]) {
                let range = NSRange(s.startIndex..<s.endIndex, in: s)
                if let match = regex.firstMatch(in: s, options: [], range: range),
                   let swiftRange = Range(match.range, in: s) {
                    to = String(s[swiftRange])
                }
            }
        }

        // Si no logramos casi nada, aún devolvemos composeMail con lo que hay
        // (Brain puede enriquecer si vino por unknown; aquí ya detectamos la intención).
        return .composeMail(to: to, subject: subject, body: body, cc: cc)
    }

    /// «mira la pantalla», «qué hay en pantalla», «qué estoy haciendo», etc.
    private static func keyboardJob(_ s: String, original: String) -> Intent? {
        let triggers = [
            "usa el teclado", "usar el teclado", "con el teclado",
            "mientras como", "mientras salgo", "mientras no estoy",
            "deja haciendo", "deja escribiendo", "sigue escribiendo",
            "escribe en la app", "escribe esto", "tipea", "tipear",
            "trabajo de teclado", "modo teclado", "keyboard"
        ]
        guard triggers.contains(where: { s.contains($0) }) else { return nil }
        var instruction = s
        for prefix in ["viernes ", "oye ", "por favor "] {
            if instruction.hasPrefix(prefix) {
                instruction = String(instruction.dropFirst(prefix.count))
            }
        }
        instruction = instruction.trimmingCharacters(in: .whitespacesAndNewlines)
        if instruction.isEmpty {
            instruction = original.trimmingCharacters(in: .whitespacesAndNewlines)
        }
        return .keyboardJob(instruction: instruction)
    }

    private static func analyzeScreen(_ s: String, original: String) -> Intent? {
        let question = original.trimmingCharacters(in: .whitespacesAndNewlines)
        let fallbackQ = question.isEmpty ? "¿Qué hay en pantalla?" : question

        let whatAmIDoing =
            s.contains("que estoy haciendo") ||
            s.contains("que estoy viendo") ||
            s.contains("en que estoy") ||
            s.contains("que hago ahora") ||
            s.contains("que tengo abierto") ||
            s.contains("que tengo en pantalla")

        if whatAmIDoing {
            return .analyzeScreen(question: fallbackQ)
        }

        let hasScreen =
            s.contains("pantalla") ||
            s.contains("screen") ||
            s.contains("monitor") ||
            s.contains("display")

        let lookVerb =
            s.contains("mira") || s.contains("mirar") ||
            s.contains("observa") || s.contains("observar") ||
            s.contains("describe") || s.contains("describeme") ||
            s.contains("ve la") || s.contains("ves la") ||
            s.contains("ve mi") || s.contains("ves mi") ||
            s.contains("que hay") || s.contains("que se ve") ||
            s.contains("dime que") || s.contains("analiza") ||
            s.contains("revisa") || s.contains("chequea") ||
            s.contains("echale un vistazo") || s.contains("un vistazo")

        if hasScreen && lookVerb {
            return .analyzeScreen(question: fallbackQ)
        }

        // «mira lo que estoy haciendo / viendo» sin decir pantalla.
        if (s.contains("mira") || s.contains("observa") || s.contains("revisa")) &&
            (s.contains("haciendo") || s.contains("viendo") || s.contains("trabajo")) {
            return .analyzeScreen(question: fallbackQ)
        }

        return nil
    }

    private static func codeTemplate(_ s: String) -> CodeTemplate? {
        if s.contains("navbar") || s.contains("barra de navegacion") || s.contains("nav bar") ||
            (s.contains("codigo") && s.contains("nav")) {
            return .navbarHTML
        }
        if s.contains("landing") || s.contains("pagina de aterrizaje") ||
            (s.contains("html") && (s.contains("pagina") || s.contains("web") || s.contains("landing"))) ||
            s.contains("preparame un html") || s.contains("prepara un html") {
            return .landingHTML
        }
        if s.contains("codigo de navbar") { return .navbarHTML }
        return nil
    }

    private static let apps: [(names: [String], bundle: String, display: String)] = [
        (["safari"], "com.apple.Safari", "Safari"),
        (["finder", "el finder"], "com.apple.finder", "Finder"),
        (["notas", "notes", "la app notas"], "com.apple.Notes", "Notas"),
        (["mail", "correo", "el correo"], "com.apple.mail", "Mail"),
        (["calendario", "calendar"], "com.apple.iCal", "Calendario"),
        (["terminal"], "com.apple.Terminal", "Terminal"),
        (["ajustes del sistema", "preferencias del sistema", "system settings",
          "ajustes", "configuracion"], "com.apple.systempreferences", "Ajustes del Sistema")
    ]

    private static func openApp(_ s: String) -> Intent? {
        let triggers = ["abre", "abrir", "abra", "lanzar", "lanza", "abreme", "iniciame", "inicia"]
        let looksLikeOpen = triggers.contains(where: { s.hasPrefix($0) || s.contains(" \($0) ") })
            || s.hasPrefix("abre ") || s.hasPrefix("abrir ") || s.hasPrefix("lanza ")
        guard looksLikeOpen else { return nil }

        for app in apps {
            for name in app.names {
                if s.contains(name) {
                    return .openApp(bundleID: app.bundle, displayName: app.display)
                }
            }
        }
        return nil
    }

    private static func webSearch(_ s: String) -> Intent? {
        let patterns = ["busca en google ", "buscar en google ", "busca en internet ",
                        "busca por ", "buscar ", "busca ", "googlea ", "google "]
        for p in patterns where s.hasPrefix(p) {
            let q = String(s.dropFirst(p.count)).trimmingCharacters(in: .whitespaces)
            if !q.isEmpty { return .webSearch(query: q) }
        }
        if s.hasPrefix("busca") {
            let q = String(s.dropFirst(5)).trimmingCharacters(in: .whitespaces)
            if !q.isEmpty { return .webSearch(query: q) }
        }
        return nil
    }

    private static func createFile(_ s: String) -> Intent? {
        guard s.contains("archivo") || s.contains("fichero") || s.contains("nota en el escritorio") else {
            return nil
        }
        guard s.contains("crea") || s.contains("crear") || s.contains("haz un") ||
                s.contains("escribe") || s.contains("guardame") || s.contains("nuevo archivo") else {
            return nil
        }

        var name = "nota-viernes"
        var contents = "Creado por Viernes.\n"

        if let range = s.range(of: "llamado ") ?? s.range(of: "que se llame ") ?? s.range(of: "con nombre ") {
            var rest = String(s[range.upperBound...]).trimmingCharacters(in: .whitespaces)
            if let con = rest.range(of: " con ") {
                name = String(rest[..<con.lowerBound])
                contents = String(rest[con.upperBound...]).trimmingCharacters(in: .whitespaces)
                if contents.isEmpty { contents = "Creado por Viernes.\n" }
            } else {
                name = rest
            }
        } else if s.contains("archivo ") {
            if let r = s.range(of: "archivo ") {
                var rest = String(s[r.upperBound...]).trimmingCharacters(in: .whitespaces)
                rest = rest.replacingOccurrences(of: "en el escritorio", with: "")
                    .trimmingCharacters(in: .whitespaces)
                if !rest.isEmpty && rest != "de texto" && rest != "txt" {
                    name = rest
                }
            }
        }

        name = name.trimmingCharacters(in: .whitespacesAndNewlines)
        if name.isEmpty { name = "nota-viernes" }
        return .createFile(name: name, contents: contents)
    }
}
