import Foundation

/// Confirmación unificada en el popover (Enviar/Confirmar + Cancelar).
enum PendingAction: Equatable {
    case mail(PendingMail)
    case calendar(PendingCalendarEvent)
    case reminder(PendingReminder)
    case agent(PendingAgentPlan)

    var confirmButtonTitle: String {
        switch self {
        case .mail: return "Enviar"
        case .calendar, .reminder, .agent: return "Confirmar"
        }
    }

    var speakPrompt: String {
        switch self {
        case .mail(let m):
            let dest = m.to.trimmingCharacters(in: .whitespacesAndNewlines)
            let label = dest.isEmpty ? "(sin destinatario)" : dest
            return "Borrador listo para \(label). Confirma Enviar o Cancelar."
        case .calendar(let e):
            return "Evento listo: \(e.title). Confirma o Cancelar."
        case .reminder(let r):
            return "Recordatorio listo: \(r.title). Confirma o Cancelar."
        case .agent(let p):
            return "Plan de \(p.steps.count) paso\(p.steps.count == 1 ? "" : "s"). Confirma o Cancelar."
        }
    }

    var detailSummary: String {
        switch self {
        case .mail(let m): return m.summary
        case .calendar(let e): return e.summary
        case .reminder(let r): return r.summary
        case .agent(let p): return p.summary
        }
    }

    var statusLabel: String {
        switch self {
        case .mail: return "Confirma correo"
        case .calendar: return "Confirma evento"
        case .reminder: return "Confirma recordatorio"
        case .agent: return "Confirma plan"
        }
    }
}

struct PendingCalendarEvent: Equatable {
    var title: String
    var start: Date
    var end: Date
    var notes: String?
    var location: String?

    var summary: String {
        let f = DateFormatter()
        f.locale = Locale(identifier: "es_CO")
        f.dateStyle = .medium
        f.timeStyle = .short
        var lines = [
            "Título: \(title)",
            "Inicio: \(f.string(from: start))",
            "Fin: \(f.string(from: end))"
        ]
        if let location, !location.isEmpty { lines.append("Lugar: \(location)") }
        if let notes, !notes.isEmpty {
            let preview = notes.count > 200 ? String(notes.prefix(200)) + "…" : notes
            lines.append("Notas: \(preview)")
        }
        return lines.joined(separator: "\n")
    }
}

struct PendingReminder: Equatable {
    var title: String
    var due: Date?

    var summary: String {
        var lines = ["Título: \(title)"]
        if let due {
            let f = DateFormatter()
            f.locale = Locale(identifier: "es_CO")
            f.dateStyle = .medium
            f.timeStyle = .short
            lines.append("Vence: \(f.string(from: due))")
        } else {
            lines.append("Vence: (sin fecha)")
        }
        return lines.joined(separator: "\n")
    }
}

struct AgentStep: Equatable, Identifiable {
    var id: Int
    var kind: Kind
    var detail: String

    enum Kind: String, Equatable {
        case analyze
        case type
        case openApp
    }

    var line: String {
        switch kind {
        case .analyze: return "\(id). Mirar: \(detail)"
        case .type: return "\(id). Escribir: \(detail)"
        case .openApp: return "\(id). Abrir: \(detail)"
        }
    }
}

struct PendingAgentPlan: Equatable {
    var goal: String
    var steps: [AgentStep]
    /// JPEG de la captura usada para planificar (no se persiste a disco).
    var screenJPEGBase64: String?

    var summary: String {
        var lines = ["Objetivo: \(goal)", "Pasos (máx. 3):"]
        lines.append(contentsOf: steps.map(\.line))
        lines.append("Tope: 3 pasos · ~2–3 min. Detener cancela.")
        return lines.joined(separator: "\n")
    }
}
