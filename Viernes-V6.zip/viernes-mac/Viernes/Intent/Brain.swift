import Foundation

/// Respuesta estructurada del LLM (local o nube).
struct BrainReply {
    let speak: String
    let detail: String?
    let intent: Intent?
    /// Backend que produjo la respuesta (para UI).
    var usedBackendLabel: String? = nil
}

/// Razona con el proveedor seleccionado solo cuando IntentParser no reconoce la frase.
/// El modelo puede pedir UNA acción del catálogo seguro de ActionRunner.
@MainActor
final class Brain {
    private let ollama: OllamaClient
    private let openAI: OpenAIClient

    init(ollama: OllamaClient = OllamaClient(), openAI: OpenAIClient = OpenAIClient()) {
        self.ollama = ollama
        self.openAI = openAI
    }

    var provider: BrainProvider { BrainProvider.current }

    /// Etiqueta corta para el popover: "Auto · Astra", "Local · llama3.2", etc.
    var modeLineLabel: String {
        let p = provider
        switch p {
        case .local:
            return "Local · \(ollama.displayModelName)"
        case .astra:
            return "Astra · \(openAI.displayModelName)"
        case .auto:
            if KeychainHelper.hasOpenAIKey() {
                return "Auto · Astra"
            }
            return "Auto · \(ollama.displayModelName)"
        }
    }

    var localModelName: String { ollama.displayModelName }
    var localVisionModelName: String { ollama.displayVisionModelName }
    var cloudModelName: String { openAI.displayModelName }

    func reason(phrase: String, context: String? = nil) async -> BrainReply {
        let system = Self.systemPrompt
        var user = "Frase del usuario: \(phrase)"
        if let context, !context.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
            user += "\nContexto breve: \(context)"
        }
        user += "\nResponde SOLO con el JSON pedido."

        do {
            let (raw, label) = try await runChat { backend in
                try await backend.chat(system: system, user: user)
            }
            var reply = Self.parse(raw: raw, fallbackPhrase: phrase)
            reply.usedBackendLabel = label
            return reply
        } catch let err as BrainBackendError {
            return Self.fallback(for: err)
        } catch let err as OllamaError {
            return Self.fallback(for: err.asBrainError)
        } catch {
            return Self.fallback(for: .network)
        }
    }

    /// Visión on-demand: describe/responde sobre una captura JPEG (sin JSON de acciones).
    func analyzeScreen(question: String, imageJPEG: Data) async -> BrainReply {
        let system = Self.visionSystemPrompt
        let user = """
        Pregunta del usuario sobre lo que hay en pantalla ahora:
        \(question)

        Responde en español colombiano, breve (1–3 oraciones), como si hablaras en voz alta.
        Describe solo lo necesario para responder. No inventes texto ilegible. No enumeres toda la UI.
        """
        do {
            let (raw, label) = try await runChat { backend in
                try await backend.chatVision(system: system, user: user, imageJPEG: imageJPEG)
            }
            let speak = String(raw.prefix(500)).trimmingCharacters(in: .whitespacesAndNewlines)
            return BrainReply(
                speak: speak.isEmpty ? "No pude interpretar la pantalla." : speak,
                detail: raw.count > 500 ? raw : nil,
                intent: nil,
                usedBackendLabel: label
            )
        } catch let err as BrainBackendError {
            return Self.visionFallback(for: err)
        } catch let err as OllamaError {
            return Self.visionFallback(for: err.asBrainError)
        } catch {
            return Self.visionFallback(for: .network)
        }
    }

    /// Genera texto libre (keyboard job) con el proveedor activo.
    func generatePlainText(system: String, user: String) async throws -> String {
        let (raw, _) = try await runChat { backend in
            try await backend.plainChat(system: system, user: user)
        }
        return raw
    }

    // MARK: - Provider routing

    private func runChat(_ work: (any LLMBackend) async throws -> String) async throws -> (String, String) {
        switch provider {
        case .local:
            do {
                let result = try await work(ollama)
                return (result, "Local · \(ollama.displayModelName)")
            } catch let err as OllamaError {
                throw err.asBrainError
            }

        case .astra:
            let result = try await work(openAI)
            return (result, "Astra · \(openAI.displayModelName)")

        case .auto:
            let hasKey = KeychainHelper.hasOpenAIKey()
            if hasKey {
                do {
                    let result = try await work(openAI)
                    return (result, "Auto · Astra")
                } catch let astraErr {
                    let astraMsg = (astraErr as? BrainBackendError)?.userMessage
                        ?? astraErr.localizedDescription
                    do {
                        let result = try await work(ollama)
                        return (result, "Auto · \(ollama.displayModelName)")
                    } catch let localErr {
                        let localMsg: String
                        if let o = localErr as? OllamaError {
                            localMsg = o.asBrainError.userMessage
                        } else if let b = localErr as? BrainBackendError {
                            localMsg = b.userMessage
                        } else {
                            localMsg = localErr.localizedDescription
                        }
                        throw BrainBackendError.bothFailed(astraMessage: astraMsg, localMessage: localMsg)
                    }
                }
            } else {
                do {
                    let result = try await work(ollama)
                    return (result, "Auto · \(ollama.displayModelName)")
                } catch let err as OllamaError {
                    throw err.asBrainError
                }
            }
        }
    }

    private static func fallback(for error: BrainBackendError) -> BrainReply {
        switch error {
        case .missingAPIKey:
            return BrainReply(
                speak: error.userMessage,
                detail: "Terminal: security add-generic-password -a openai_api_key -s com.danielrueda.Viernes -w 'sk-...' -U\nO pégala en Ajustes (engranaje).",
                intent: nil
            )
        case .unauthorized, .rateLimited, .network, .badStatus, .bothFailed:
            return BrainReply(speak: error.userMessage, detail: nil, intent: nil)
        case .unreachableLocal:
            return BrainReply(
                speak: "Ollama no está corriendo o el modelo no está instalado. Los comandos con reglas siguen funcionando.",
                detail: "Instala Ollama, ejecuta `ollama pull \(OllamaClient.configuredModelName)` y déjalo abierto. Modelo: \(OllamaClient.configuredModelName).",
                intent: nil
            )
        case .emptyResponse, .decodeFailed:
            return BrainReply(
                speak: "El modelo no me dio una respuesta útil. Prueba otra vez o usa un comando conocido.",
                detail: nil,
                intent: nil
            )
        }
    }

    private static func visionFallback(for error: BrainBackendError) -> BrainReply {
        switch error {
        case .missingAPIKey:
            return BrainReply(
                speak: error.userMessage,
                detail: "Sin clave Astra, usa modo Local/Auto con Ollama visión (`ollama pull \(OllamaClient.configuredVisionModelName)`).",
                intent: nil
            )
        case .unreachableLocal:
            return BrainReply(
                speak: "No tengo el modelo de visión de Ollama. Instálalo con ollama pull \(OllamaClient.configuredVisionModelName).",
                detail: "Modelo de visión: \(OllamaClient.configuredVisionModelName) (UserDefaults `viernes.ollamaVisionModel`). Ollama debe estar corriendo en localhost.",
                intent: nil
            )
        default:
            return BrainReply(speak: error.userMessage, detail: nil, intent: nil)
        }
    }

    private static func parse(raw: String, fallbackPhrase: String) -> BrainReply {
        let jsonText = extractJSONObject(from: raw) ?? raw
        guard let data = jsonText.data(using: .utf8),
              let obj = try? JSONSerialization.jsonObject(with: data) as? [String: Any] else {
            let speak = String(raw.prefix(280)).trimmingCharacters(in: .whitespacesAndNewlines)
            return BrainReply(
                speak: speak.isEmpty ? "No entendí. Prueba otra vez." : speak,
                detail: raw.count > 280 ? raw : nil,
                intent: nil
            )
        }

        let speak = (obj["speak"] as? String)?
            .trimmingCharacters(in: .whitespacesAndNewlines)
            ?? "Listo."
        let detail = (obj["detail"] as? String)?
            .trimmingCharacters(in: .whitespacesAndNewlines)
        let detailOrNil = (detail?.isEmpty == false) ? detail : nil

        let intent = mapAction(obj["action"])
        let safeSpeak = speak.isEmpty ? "Listo." : speak
        return BrainReply(speak: safeSpeak, detail: detailOrNil, intent: intent)
    }

    private static func extractJSONObject(from text: String) -> String? {
        guard let start = text.firstIndex(of: "{"),
              let end = text.lastIndex(of: "}"),
              start < end else { return nil }
        return String(text[start...end])
    }

    private static func mapAction(_ raw: Any?) -> Intent? {
        guard let dict = raw as? [String: Any] else { return nil }
        let type = ((dict["type"] as? String) ?? "")
            .trimmingCharacters(in: .whitespacesAndNewlines)
            .lowercased()
        if type.isEmpty { return nil }

        let args = dict["args"] as? [String: Any] ?? [:]

        switch type {
        case "greet":
            return .greet
        case "whoami", "who_am_i":
            return .whoAmI
        case "help":
            return .help
        case "time":
            return .time
        case "date":
            return .date
        case "listdesktop", "list_desktop":
            return .listDesktop
        case "readclipboard", "read_clipboard":
            return .readClipboard
        case "quit":
            return .quit
        case "analyzescreen", "analyze_screen", "lookatscreen", "look_at_screen", "screen":
            let question = stringArg(args, keys: ["question", "query", "q", "text", "prompt"]) ?? "¿Qué hay en pantalla?"
            let q = question.trimmingCharacters(in: .whitespacesAndNewlines)
            return .analyzeScreen(question: q.isEmpty ? "¿Qué hay en pantalla?" : q)
        case "keyboardjob", "keyboard_job", "type", "typing", "usekeyboard", "use_keyboard":
            let instruction = stringArg(args, keys: ["instruction", "task", "text", "prompt", "content"]) ?? ""
            let i = instruction.trimmingCharacters(in: .whitespacesAndNewlines)
            guard !i.isEmpty else { return nil }
            return .keyboardJob(instruction: i)
        case "websearch", "web_search":
            let query = stringArg(args, keys: ["query", "q", "text"]) ?? ""
            let q = query.trimmingCharacters(in: .whitespacesAndNewlines)
            guard !q.isEmpty else { return nil }
            return .webSearch(query: q)
        case "openapp", "open_app":
            return mapOpenApp(args)
        case "createfile", "create_file":
            let name = stringArg(args, keys: ["name", "filename", "file"]) ?? "nota-viernes"
            let contents = stringArg(args, keys: ["contents", "content", "text", "body"]) ?? "Creado por Viernes.\n"
            return .createFile(name: name, contents: contents)
        case "copytemplate", "copy_template":
            let kind = (stringArg(args, keys: ["kind", "template", "name"]) ?? "landing")
                .lowercased()
            if kind.contains("nav") {
                return .copyTemplate(.navbarHTML)
            }
            return .copyTemplate(.landingHTML)
        case "composemail", "compose_mail", "sendmail", "send_mail", "email", "mail":
            let to = stringArg(args, keys: ["to", "recipient", "email", "address", "para"]) ?? ""
            let subject = stringArg(args, keys: ["subject", "asunto", "title"]) ?? ""
            let body = stringArg(args, keys: ["body", "content", "contents", "text", "message", "cuerpo"]) ?? ""
            let ccRaw = stringArg(args, keys: ["cc", "copia", "copy"])
            let cc = ccRaw?.trimmingCharacters(in: .whitespacesAndNewlines)
            return .composeMail(
                to: to.trimmingCharacters(in: .whitespacesAndNewlines),
                subject: subject.trimmingCharacters(in: .whitespacesAndNewlines),
                body: body,
                cc: (cc?.isEmpty == false) ? cc : nil
            )
        case "createcalendarevent", "create_calendar_event", "calendarevent", "calendar_event", "event":
            let title = stringArg(args, keys: ["title", "name", "titulo"]) ?? "Evento"
            let startHint = stringArg(args, keys: ["start", "startHint", "when", "inicio", "startISO"]) ?? ""
            let endHint = stringArg(args, keys: ["end", "endHint", "fin", "endISO"]) ?? ""
            let notes = stringArg(args, keys: ["notes", "note", "notas"])
            let location = stringArg(args, keys: ["location", "lugar", "ubicacion"])
            return .createCalendarEvent(
                title: title.trimmingCharacters(in: .whitespacesAndNewlines),
                startHint: startHint,
                endHint: endHint,
                notes: notes,
                location: location
            )
        case "createreminder", "create_reminder", "reminder":
            let title = stringArg(args, keys: ["title", "name", "text", "titulo"]) ?? "Recordatorio"
            let due = stringArg(args, keys: ["due", "dueHint", "when", "fecha"])
            return .createReminder(title: title.trimmingCharacters(in: .whitespacesAndNewlines), dueHint: due)
        case "listreminders", "list_reminders":
            return .listReminders
        case "createnote", "create_note", "note":
            let title = stringArg(args, keys: ["title", "name", "titulo"]) ?? "Nota Viernes"
            let body = stringArg(args, keys: ["body", "content", "text", "cuerpo"]) ?? ""
            return .createNote(title: title.trimmingCharacters(in: .whitespacesAndNewlines), body: body)
        case "agentmode", "agent_mode", "agent", "shortagent", "short_agent":
            let goal = stringArg(args, keys: ["goal", "task", "instruction", "objetivo", "text"]) ?? ""
            let g = goal.trimmingCharacters(in: .whitespacesAndNewlines)
            guard !g.isEmpty else { return nil }
            return .agentMode(goal: g)
        default:
            return nil
        }
    }

    private static func mapOpenApp(_ args: [String: Any]) -> Intent? {
        let name = (stringArg(args, keys: ["name", "app", "displayName", "display"]) ?? "")
            .folding(options: [.diacriticInsensitive, .caseInsensitive], locale: Locale(identifier: "es"))
            .lowercased()
        let bundle = (stringArg(args, keys: ["bundleID", "bundle", "bundleId"]) ?? "").lowercased()

        for app in knownApps {
            if !bundle.isEmpty, app.bundle.lowercased() == bundle {
                return .openApp(bundleID: app.bundle, displayName: app.display)
            }
            if !name.isEmpty {
                if app.display.folding(options: [.diacriticInsensitive, .caseInsensitive], locale: Locale(identifier: "es"))
                    .lowercased()
                    .contains(name) || name.contains(app.display.lowercased()) {
                    return .openApp(bundleID: app.bundle, displayName: app.display)
                }
                for alias in app.aliases where name.contains(alias) || alias.contains(name) {
                    return .openApp(bundleID: app.bundle, displayName: app.display)
                }
            }
        }
        return nil
    }

    private static func stringArg(_ args: [String: Any], keys: [String]) -> String? {
        for key in keys {
            if let s = args[key] as? String { return s }
            if let n = args[key] as? NSNumber { return n.stringValue }
        }
        return nil
    }

    private static let knownApps: [(aliases: [String], bundle: String, display: String)] = [
        (["safari"], "com.apple.Safari", "Safari"),
        (["finder"], "com.apple.finder", "Finder"),
        (["notas", "notes"], "com.apple.Notes", "Notas"),
        (["mail", "correo"], "com.apple.mail", "Mail"),
        (["calendario", "calendar"], "com.apple.iCal", "Calendario"),
        (["terminal"], "com.apple.Terminal", "Terminal"),
        (["ajustes", "preferencias", "system settings", "configuracion"], "com.apple.systempreferences", "Ajustes del Sistema")
    ]

    static let systemPrompt = """
    Eres Viernes, asistente local de Daniel Rueda Mier. Persona estilo FRIDAY (MCU): femenina, seca, breve, competente. Español colombiano natural.
    Respuestas para voz: máximo ~2 oraciones en "speak". Sin relleno, sin "claro que sí", sin disculpas innecesarias. "detail" puede ser más largo (solo UI).
    No inventes acciones peligrosas. Nunca pidas shell ni borrar archivos. Nunca digas que ya enviaste un correo: composeMail solo prepara un borrador; el usuario debe pulsar Enviar.
    Si el usuario pide mirar la pantalla / qué hay en pantalla / qué está haciendo, usa action analyzeScreen.
    Si pide usar el teclado / escribir en la app / seguir trabajando mientras no está, usa action keyboardJob (solo si lo pide explícito).
    Si pide enviar / mandar / redactar un correo o mail, usa action composeMail con to/subject/body (cc opcional). En "speak" di que el borrador está listo y que debe confirmar Enviar o Cancelar. No inventes que ya se envió.
    Si pide crear evento / agendar, usa createCalendarEvent (title, start/end hints). Requiere confirmación UI.
    Si pide recordatorio, usa createReminder; si pide listar recordatorios, listReminders.
    Si pide crear una nota en Notas, usa createNote (title, body) — se crea al instante.
    Si pide "haz esto en pantalla" / agente corto, usa agentMode con goal. El plan se confirma antes de ejecutar. Máx 3 pasos. Nunca mail-send ni borrar ni shell dentro del agente.
    Responde ÚNICAMENTE con JSON válido (sin markdown) de esta forma:
    {"speak":"...","detail":"...opcional o null","action":null}
    O con una sola acción segura:
    {"speak":"...","detail":null,"action":{"type":"TIPO","args":{...}}}

    Tipos de action permitidos (uno solo, o null):
    - greet | whoAmI | help | time | date | listDesktop | readClipboard | quit  (args vacíos {})
    - analyzeScreen args: {"question":"..."}  (captura puntual de pantalla + visión)
    - keyboardJob args: {"instruction":"..."}  (escribir en la app de adelante; solo bajo pedido explícito)
    - composeMail args: {"to":"...","subject":"...","body":"...","cc":"...opcional"}  (borrador; NUNCA envía solo)
    - createCalendarEvent args: {"title":"...","start":"...","end":"...","notes":null,"location":null}
    - createReminder args: {"title":"...","due":"...opcional"}
    - listReminders args: {}
    - createNote args: {"title":"...","body":"..."}
    - agentMode args: {"goal":"..."}  (plan corto; requiere Confirmar; máx 3 pasos)
    - webSearch  args: {"query":"..."}
    - openApp    args: {"name":"Safari|Finder|Notas|Mail|Calendario|Terminal|Ajustes"} (solo esas)
    - createFile args: {"name":"...","contents":"..."}  (solo Escritorio vía la app)
    - copyTemplate args: {"kind":"landing"|"navbar"}

    Si solo conversas, action debe ser null. Si no estás seguro de la acción, action=null y habla.
    """

    static let visionSystemPrompt = """
    Eres Viernes, asistente estilo FRIDAY (MCU): femenina, seca, breve, competente. Español colombiano.
    Te pasan UNA captura de pantalla tomada justo ahora porque el usuario te pidió mirar.
    Responde solo lo necesario para contestar su pregunta. No vuelques toda la interfaz. No inventes texto que no puedas leer.
    Respuesta hablada: 1 a 3 oraciones. Sin markdown innecesario.
    """
}
