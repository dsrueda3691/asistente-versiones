import Foundation
import AppKit

enum AgentModeError: Error, LocalizedError {
    case emptyGoal
    case planFailed(String)
    case cancelled
    case stepFailed(String)
    case timedOut

    var errorDescription: String? { userMessage }
    var userMessage: String {
        switch self {
        case .emptyGoal: return "¿Qué quieres que haga en pantalla?"
        case .planFailed(let m): return "No pude armar el plan. \(m)"
        case .cancelled: return "Agente detenido."
        case .stepFailed(let m): return m
        case .timedOut: return "Se agotó el tiempo del agente (~3 min)."
        }
    }
}

/// Modo agente corto: captura → plan 1–3 pasos seguros → confirmación → ejecución.
@MainActor
final class AgentMode {
    static let maxSteps = 3
    static let timeCapSeconds: TimeInterval = 180

    private let brain: Brain
    private(set) var isRunning = false
    private var cancelled = false
    var onProgress: ((String) -> Void)?

    init(brain: Brain) {
        self.brain = brain
    }

    func cancel() {
        cancelled = true
        isRunning = false
    }

    /// Pide al LLM un plan JSON a partir de la captura + objetivo.
    func plan(goal: String, imageJPEG: Data) async throws -> PendingAgentPlan {
        let trimmed = goal.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmed.isEmpty else { throw AgentModeError.emptyGoal }

        let system = """
        Eres Viernes planificando un agente CORTO y seguro en macOS.
        Dado el objetivo y UNA captura de pantalla, responde SOLO JSON:
        {"steps":[{"kind":"analyze|type|openApp","detail":"..."}]}
        Reglas:
        - Máximo \(Self.maxSteps) pasos.
        - kind analyze: mirar/describir algo (detail = pregunta).
        - kind type: texto a escribir/pegar en la app de adelante (detail = texto o instrucción corta).
        - kind openApp: solo Safari, Finder, Notas, Mail, Calendario, Terminal, Ajustes (detail = nombre).
        - PROHIBIDO: borrar, shell, enviar correo, crear eventos/recordatorios, descargas, claves.
        - Si no hace falta acción, un solo paso analyze.
        """
        let user = "Objetivo del usuario:\n\(trimmed)\n\nDevuelve el plan JSON (máx. \(Self.maxSteps) pasos)."

        do {
            let raw = try await brain.generatePlainText(system: system, user: user)
            let steps = Self.parseSteps(from: raw)
            guard !steps.isEmpty else {
                throw AgentModeError.planFailed("El modelo no devolvió pasos útiles.")
            }
            let limited = Array(steps.prefix(Self.maxSteps))
            return PendingAgentPlan(
                goal: trimmed,
                steps: limited,
                screenJPEGBase64: imageJPEG.base64EncodedString()
            )
        } catch let err as BrainBackendError {
            throw AgentModeError.planFailed(err.userMessage)
        } catch let err as AgentModeError {
            throw err
        } catch {
            throw AgentModeError.planFailed(error.localizedDescription)
        }
    }

    /// Ejecuta el plan confirmado. Respeta Detener y tope de tiempo.
    func execute(
        plan: PendingAgentPlan,
        keyboard: KeyboardController,
        analyze: @escaping (String, Data) async -> String
    ) async -> (spoken: String, detail: String) {
        cancelled = false
        isRunning = true
        defer { isRunning = false }
        let started = Date()
        var log: [String] = []
        var jpegData: Data?
        if let b64 = plan.screenJPEGBase64 {
            jpegData = Data(base64Encoded: b64)
        }

        for step in plan.steps {
            if cancelled { return (AgentModeError.cancelled.userMessage, log.joined(separator: "\n")) }
            if Date().timeIntervalSince(started) > Self.timeCapSeconds {
                return (AgentModeError.timedOut.userMessage, log.joined(separator: "\n"))
            }
            onProgress?("Agente: paso \(step.id)/\(plan.steps.count)…")
            switch step.kind {
            case .analyze:
                if let jpeg = jpegData {
                    let reply = await analyze(step.detail, jpeg)
                    log.append("✓ \(step.line)\n  → \(reply)")
                } else {
                    log.append("⚠ \(step.line) (sin captura)")
                }
            case .type:
                do {
                    let result = try await keyboard.runJob(instruction: step.detail) { [brain] instr in
                        // Si el detail ya es texto corto a pegar, úsalo; si parece instrucción, genera.
                        if instr.count < 400 && !instr.lowercased().contains("escribe") {
                            return instr
                        }
                        let system = "Eres Viernes. Generas SOLO el texto a pegar. Sin markdown ni explicaciones."
                        return try await brain.generatePlainText(system: system, user: instr)
                    }
                    log.append("✓ \(step.line)\n  → \(result.spoken)")
                } catch {
                    let msg = (error as? KeyboardError)?.userMessage ?? "Falló escribir."
                    log.append("✗ \(step.line)\n  → \(msg)")
                    return ("Paso de teclado falló: \(msg)", log.joined(separator: "\n"))
                }
            case .openApp:
                let name = step.detail.trimmingCharacters(in: .whitespacesAndNewlines)
                if let bundle = Self.bundleID(for: name) {
                    let config = NSWorkspace.OpenConfiguration()
                    config.activates = true
                    if let url = NSWorkspace.shared.urlForApplication(withBundleIdentifier: bundle) {
                        NSWorkspace.shared.openApplication(at: url, configuration: config) { _, _ in }
                        log.append("✓ \(step.line)")
                    } else {
                        log.append("✗ No encontré \(name)")
                    }
                } else {
                    log.append("✗ App no permitida: \(name)")
                }
            }
        }
        let spoken = cancelled ? AgentModeError.cancelled.userMessage : "Listo. Completé el plan de \(plan.steps.count) paso\(plan.steps.count == 1 ? "" : "s")."
        return (spoken, log.joined(separator: "\n"))
    }

    private static func parseSteps(from raw: String) -> [AgentStep] {
        let jsonText: String
        if let start = raw.firstIndex(of: "{"), let end = raw.lastIndex(of: "}"), start < end {
            jsonText = String(raw[start...end])
        } else {
            jsonText = raw
        }
        guard let data = jsonText.data(using: .utf8),
              let obj = try? JSONSerialization.jsonObject(with: data) as? [String: Any],
              let arr = obj["steps"] as? [[String: Any]] else {
            return []
        }
        var steps: [AgentStep] = []
        for (idx, item) in arr.prefix(maxSteps).enumerated() {
            let kindRaw = ((item["kind"] as? String) ?? "").lowercased()
            let detail = ((item["detail"] as? String) ?? "").trimmingCharacters(in: .whitespacesAndNewlines)
            guard !detail.isEmpty else { continue }
            let kind: AgentStep.Kind
            switch kindRaw {
            case "analyze", "look", "screen": kind = .analyze
            case "type", "typing", "keyboard", "paste": kind = .type
            case "openapp", "open_app", "open": kind = .openApp
            default: continue
            }
            steps.append(AgentStep(id: idx + 1, kind: kind, detail: detail))
        }
        return steps
    }

    private static func bundleID(for name: String) -> String? {
        let n = name.folding(options: [.diacriticInsensitive, .caseInsensitive], locale: Locale(identifier: "es")).lowercased()
        let map: [(String, String)] = [
            ("safari", "com.apple.Safari"),
            ("finder", "com.apple.finder"),
            ("notas", "com.apple.Notes"),
            ("notes", "com.apple.Notes"),
            ("mail", "com.apple.mail"),
            ("correo", "com.apple.mail"),
            ("calendario", "com.apple.iCal"),
            ("calendar", "com.apple.iCal"),
            ("terminal", "com.apple.Terminal"),
            ("ajustes", "com.apple.systempreferences"),
            ("preferencias", "com.apple.systempreferences")
        ]
        for (alias, bundle) in map where n.contains(alias) {
            return bundle
        }
        return nil
    }
}
