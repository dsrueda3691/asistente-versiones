import SwiftUI
import AppKit
import AVFoundation
import Speech

@main
struct ViernesApp: App {
    @NSApplicationDelegateAdaptor(AppDelegate.self) private var appDelegate

    var body: some Scene {
        Settings {
            SettingsHelpView(state: appDelegate.state, onHotkeyChange: { cfg in
                appDelegate.applyHotkey(cfg)
            })
        }
    }
}

@MainActor
final class AppDelegate: NSObject, NSApplicationDelegate {
    private var statusBar: StatusBarController?
    let state = AppState()
    let listener = Listener()
    let speaker = Speaker()
    let parser = IntentParser()
    let runner = ActionRunner()
    let brain = Brain()
    let keyboard = KeyboardController()
    lazy var agent = AgentMode(brain: brain)

    func applicationDidFinishLaunching(_ notification: Notification) {
        NSApp.setActivationPolicy(.accessory)
        refreshModelLabels()
        state.isMuted = UserDefaults.standard.bool(forKey: AppState.mutedDefaultsKey)
        state.brainProvider = BrainProvider.current.rawValue
        state.hasAPIKey = KeychainHelper.hasOpenAIKey()
        state.hotkeyDisplay = HotkeyConfig.current.display

        speaker.onSpeakingChanged = { [weak self] speaking in
            self?.state.isSpeaking = speaking
        }
        listener.onPartialTranscript = { [weak self] text in
            self?.state.transcript = text
        }
        statusBar = StatusBarController(
            state: state,
            onListen: { [weak self] in self?.toggleListening() },
            onQuit: { [weak self] in self?.quitApp() },
            onSendChat: { [weak self] text in self?.submitTyped(text) },
            onToggleMute: { [weak self] in self?.toggleMute() },
            onStopJob: { [weak self] in self?.stopJobs() },
            onOpenSettings: { [weak self] in self?.openSettings() },
            onProviderChange: { [weak self] raw in self?.setBrainProvider(raw) },
            onConfirmPending: { [weak self] in self?.confirmPending() },
            onCancelPending: { [weak self] in self?.cancelPending() }
        )
        keyboard.onProgress = { [weak self] msg in
            self?.state.statusMessage = msg
            self?.state.isKeyboardJobRunning = true
        }
        agent.onProgress = { [weak self] msg in
            self?.state.statusMessage = msg
            self?.state.isAgentRunning = true
        }
        speakReply("Viernes en línea.")
    }

    func applicationWillTerminate(_ notification: Notification) {
        keyboard.cancel()
        agent.cancel()
        listener.stopListening()
        speaker.stop()
    }

    func applyHotkey(_ config: HotkeyConfig) {
        statusBar?.applyHotkey(config)
        state.hotkeyDisplay = config.display
    }

    func refreshModelLabels() {
        state.ollamaModel = OllamaClient.configuredModelName
        state.visionModel = OllamaClient.configuredVisionModelName
        state.openaiModel = OpenAIClient.configuredModelName
        state.modeLine = brain.modeLineLabel
        state.hasAPIKey = KeychainHelper.hasOpenAIKey()
        state.hotkeyDisplay = HotkeyConfig.current.display
    }

    func setBrainProvider(_ raw: String) {
        let provider = BrainProvider(rawValue: raw) ?? .auto
        BrainProvider.setCurrent(provider)
        state.brainProvider = provider.rawValue
        refreshModelLabels()
    }

    func stopJobs() {
        if state.isAgentRunning || agent.isRunning {
            agent.cancel()
            state.isAgentRunning = false
            // Si hay plan pendiente sin ejecutar, también cancelar
            if case .agent = state.pendingAction {
                clearPending()
            }
            let reply = "Agente detenido."
            state.lastReply = reply
            state.statusMessage = "Listo"
            speakReply(reply)
            return
        }
        keyboard.cancel()
        state.isKeyboardJobRunning = false
        state.statusMessage = "Listo"
        let reply = "Paré el trabajo de teclado."
        state.lastReply = reply
        speakReply(reply)
    }

    func openSettings() {
        state.hasAPIKey = KeychainHelper.hasOpenAIKey()
        NSApp.sendAction(Selector(("showSettingsWindow:")), to: nil, from: nil)
        NSApp.activate(ignoringOtherApps: true)
    }

    func toggleMute() {
        state.isMuted.toggle()
        UserDefaults.standard.set(state.isMuted, forKey: AppState.mutedDefaultsKey)
        if state.isMuted {
            speaker.stop()
            state.isSpeaking = false
        }
    }

    func speakReply(_ text: String) {
        speaker.speak(text, muted: state.isMuted)
        if state.isMuted {
            state.isSpeaking = false
        }
    }

    func submitTyped(_ text: String) {
        let trimmed = text.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmed.isEmpty else { return }
        if state.isListening {
            listener.stopListening()
            state.isListening = false
        }
        speaker.stop()
        state.transcript = trimmed
        statusBar?.showPopover()
        Task { @MainActor in
            await self.handle(phrase: trimmed)
        }
    }

    func toggleListening() {
        if state.isListening {
            listener.stopListening()
            state.isListening = false
            state.statusMessage = "Listo"
            return
        }
        startListening()
    }

    func startListening() {
        speaker.stop()
        state.isListening = true
        state.statusMessage = "Te escucho…"
        state.transcript = ""
        statusBar?.showPopover()

        Task { @MainActor in
            let permitted = await PermissionGate.requestSpeechAndMicrophone()
            guard permitted else {
                self.state.isListening = false
                self.state.statusMessage = "Faltan permisos"
                let reply = "Necesito micrófono y reconocimiento de voz. Actívalos en Ajustes del Sistema."
                self.state.lastReply = reply
                self.speakReply(reply)
                return
            }

            do {
                let phrase = try await self.listener.listen(maxDuration: 12)
                self.state.transcript = phrase
                self.state.isListening = false
                if phrase.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
                    let reply = "No te escuché. Prueba otra vez."
                    self.state.lastReply = reply
                    self.state.statusMessage = "Listo"
                    self.speakReply(reply)
                    return
                }
                await self.handle(phrase: phrase)
            } catch {
                self.state.isListening = false
                let reply: String
                if let listenError = error as? ListenerError {
                    reply = listenError.userMessage
                } else {
                    reply = "No pude escucharte. Revisa el micrófono."
                }
                self.state.lastReply = reply
                self.state.statusMessage = "Listo"
                self.speakReply(reply)
            }
        }
    }

    // MARK: - Intent routing

    func handle(phrase: String) async {
        // Confirmación tipada SOLO mientras hay pending.
        if state.pendingAction != nil {
            let cleaned = IntentParser.stripVocative(IntentParser.normalize(phrase))
            if Self.isConfirmPhrase(cleaned) {
                confirmPending()
                return
            }
            if Self.isCancelPhrase(cleaned) {
                cancelPending()
                return
            }
        }

        state.statusMessage = "Pensando…"
        refreshModelLabels()
        let intent = parser.parse(phrase)
        await dispatch(intent, fallbackPhrase: phrase)
    }

    private func dispatch(_ intent: Intent, fallbackPhrase: String) async {
        switch intent {
        case .analyzeScreen(let question):
            await handleAnalyzeScreen(question: question)
        case .keyboardJob(let instruction):
            await handleKeyboardJob(instruction: instruction)
        case .composeMail(let to, let subject, let body, let cc):
            presentPending(.mail(PendingMail(to: to, subject: subject, body: body, cc: cc)))
        case .createCalendarEvent(let title, let startHint, let endHint, let notes, let location):
            presentCalendarDraft(title: title, startHint: startHint, endHint: endHint, notes: notes, location: location)
        case .createReminder(let title, let dueHint):
            presentReminderDraft(title: title, dueHint: dueHint)
        case .listReminders:
            await handleListReminders()
        case .createNote(let title, let body):
            handleCreateNote(title: title, body: body)
        case .agentMode(let goal):
            await handleAgentPlan(goal: goal)
        case .unknown:
            await handleUnknown(phrase: fallbackPhrase)
        default:
            let outcome = await runner.run(intent)
            state.lastReply = outcome.spoken
            state.statusMessage = "Listo"
            state.detail = outcome.detail ?? ""
            speakReply(outcome.spoken)
            if outcome.shouldQuit {
                DispatchQueue.main.asyncAfter(deadline: .now() + 1.6) {
                    NSApp.terminate(nil)
                }
            }
        }
    }

    private static func isConfirmPhrase(_ s: String) -> Bool {
        let keys = [
            "confirma envio", "confirma el envio", "si envia", "si envialo",
            "enviar", "envia", "envialo", "si", "confirmar", "confirma",
            "send", "confirm", "yes", "dale", "ok", "de acuerdo"
        ]
        return keys.contains(s) || s.hasPrefix("confirma") || s == "si envia" || s == "dale envia"
    }

    private static func isCancelPhrase(_ s: String) -> Bool {
        let keys = [
            "cancelar", "cancela", "cancelado", "no", "no envies", "no enviar",
            "descarta", "descartar", "olvidalo", "cancel"
        ]
        return keys.contains(s) || s.hasPrefix("no env")
    }

    // MARK: - Pending confirmations

    func presentPending(_ action: PendingAction) {
        state.pendingAction = action
        state.lastReply = action.speakPrompt
        state.detail = action.detailSummary
        state.statusMessage = action.statusLabel
        statusBar?.showPopover()
        speakReply(action.speakPrompt)
    }

    func clearPending() {
        state.pendingAction = nil
    }

    func confirmPending() {
        guard let pending = state.pendingAction else {
            let reply = "No hay nada pendiente por confirmar."
            state.lastReply = reply
            speakReply(reply)
            return
        }
        switch pending {
        case .mail(let draft):
            confirmMail(draft)
        case .calendar(let event):
            Task { @MainActor in await self.confirmCalendar(event) }
        case .reminder(let rem):
            Task { @MainActor in await self.confirmReminder(rem) }
        case .agent(let plan):
            Task { @MainActor in await self.confirmAgent(plan) }
        }
    }

    func cancelPending() {
        clearPending()
        state.isAgentRunning = false
        let reply = "Cancelado."
        state.lastReply = reply
        state.detail = ""
        state.statusMessage = "Listo"
        speakReply(reply)
    }

    private func confirmMail(_ draft: PendingMail) {
        state.statusMessage = "Enviando…"
        do {
            let spoken = try MailSender.send(draft)
            clearPending()
            state.lastReply = spoken
            state.detail = ""
            state.statusMessage = "Listo"
            speakReply(spoken)
        } catch let err as MailSendError {
            state.lastReply = err.userMessage
            state.detail = draft.summary + "\n\nError: \(err.userMessage)"
            state.statusMessage = "Error al enviar"
            speakReply(err.userMessage)
        } catch {
            state.lastReply = "No pude enviar el correo."
            state.statusMessage = "Error al enviar"
            speakReply("No pude enviar el correo.")
        }
    }

    private func presentCalendarDraft(title: String, startHint: String, endHint: String, notes: String?, location: String?) {
        var args: [String: String] = ["start": startHint]
        if !endHint.isEmpty { args["end"] = endHint }
        let pair = CalendarService.parseStartEnd(from: args) ?? (
            Date().addingTimeInterval(3600),
            Date().addingTimeInterval(7200)
        )
        let event = PendingCalendarEvent(
            title: title.isEmpty ? "Evento" : title,
            start: pair.0,
            end: pair.1,
            notes: notes,
            location: location
        )
        presentPending(.calendar(event))
    }

    private func confirmCalendar(_ event: PendingCalendarEvent) async {
        state.statusMessage = "Creando evento…"
        do {
            let spoken = try await CalendarService.createEvent(event)
            clearPending()
            state.lastReply = spoken
            state.detail = event.summary
            state.statusMessage = "Listo"
            speakReply(spoken)
        } catch let err as CalendarServiceError {
            state.lastReply = err.userMessage
            state.detail = event.summary + "\n\n" + err.userMessage
            state.statusMessage = "Error"
            speakReply(err.userMessage)
        } catch {
            state.lastReply = "No pude crear el evento."
            state.statusMessage = "Error"
            speakReply("No pude crear el evento.")
        }
    }

    private func presentReminderDraft(title: String, dueHint: String?) {
        var due: Date? = nil
        if let dueHint, let d = CalendarService.parseLooseDate(dueHint, relativeTo: Date()) {
            due = d
        }
        let rem = PendingReminder(title: title.isEmpty ? "Recordatorio" : title, due: due)
        presentPending(.reminder(rem))
    }

    private func confirmReminder(_ rem: PendingReminder) async {
        state.statusMessage = "Creando recordatorio…"
        do {
            let spoken = try await RemindersService.createReminder(rem)
            clearPending()
            state.lastReply = spoken
            state.detail = rem.summary
            state.statusMessage = "Listo"
            speakReply(spoken)
        } catch let err as RemindersServiceError {
            state.lastReply = err.userMessage
            state.detail = rem.summary + "\n\n" + err.userMessage
            state.statusMessage = "Error"
            speakReply(err.userMessage)
        } catch {
            state.lastReply = "No pude crear el recordatorio."
            state.statusMessage = "Error"
            speakReply("No pude crear el recordatorio.")
        }
    }

    private func handleListReminders() async {
        state.statusMessage = "Revisando recordatorios…"
        do {
            let result = try await RemindersService.listUpcoming()
            state.lastReply = result.spoken
            state.detail = result.detail
            state.statusMessage = "Listo"
            speakReply(result.spoken)
        } catch let err as RemindersServiceError {
            state.lastReply = err.userMessage
            state.detail = ""
            state.statusMessage = "Listo"
            speakReply(err.userMessage)
        } catch {
            state.lastReply = "No pude leer los recordatorios."
            state.statusMessage = "Listo"
            speakReply("No pude leer los recordatorios.")
        }
    }

    private func handleCreateNote(title: String, body: String) {
        state.statusMessage = "Creando nota…"
        do {
            let spoken = try NotesService.createNote(title: title, body: body)
            state.lastReply = spoken
            state.detail = "Título: \(title)\n\(body)"
            state.statusMessage = "Listo"
            speakReply(spoken)
        } catch let err as NotesServiceError {
            state.lastReply = err.userMessage
            state.detail = ""
            state.statusMessage = "Listo"
            speakReply(err.userMessage)
        } catch {
            state.lastReply = "No pude crear la nota."
            state.statusMessage = "Listo"
            speakReply("No pude crear la nota.")
        }
    }

    private func handleAgentPlan(goal: String) async {
        state.statusMessage = "Capturando pantalla…"
        state.isAgentRunning = true
        do {
            let jpeg = try await ScreenCapture.captureMainDisplayJPEG()
            state.statusMessage = "Planificando…"
            let plan = try await agent.plan(goal: goal, imageJPEG: jpeg)
            state.isAgentRunning = false
            presentPending(.agent(plan))
        } catch let err as ScreenCaptureError {
            state.isAgentRunning = false
            state.lastReply = err.userMessage
            state.detail = "Ajustes → Privacidad y seguridad → Grabación de pantalla → Viernes."
            state.statusMessage = "Listo"
            speakReply(err.userMessage)
        } catch let err as AgentModeError {
            state.isAgentRunning = false
            state.lastReply = err.userMessage
            state.detail = ""
            state.statusMessage = "Listo"
            speakReply(err.userMessage)
        } catch {
            state.isAgentRunning = false
            state.lastReply = "No pude preparar el plan del agente."
            state.statusMessage = "Listo"
            speakReply("No pude preparar el plan del agente.")
        }
    }

    private func confirmAgent(_ plan: PendingAgentPlan) async {
        clearPending()
        state.isAgentRunning = true
        state.statusMessage = "Agente en curso…"
        statusBar?.showPopover()
        let result = await agent.execute(plan: plan, keyboard: keyboard) { [weak self] question, jpeg in
            guard let self else { return "Sin contexto." }
            let reply = await self.brain.analyzeScreen(question: question, imageJPEG: jpeg)
            return reply.speak
        }
        state.isAgentRunning = false
        state.lastReply = result.spoken
        state.detail = result.detail
        state.statusMessage = "Listo"
        speakReply(result.spoken)
    }

    // MARK: - Existing handlers

    private func handleKeyboardJob(instruction: String) async {
        state.isKeyboardJobRunning = true
        state.statusMessage = "Trabajo en curso…"
        state.detail = "Instrucción: \(instruction)\nApp: \(keyboard.frontmostAppName())"
        speakReply("Empiezo. Avísame si paro.")
        do {
            let result = try await keyboard.runJob(instruction: instruction) { [brain] instr in
                let system = "Eres Viernes. Generas SOLO el texto que hay que escribir o pegar en la app de adelante. Sin JSON, sin markdown, sin explicaciones ni comillas envolventes."
                let user = "Tarea del usuario:\n\(instr)"
                return try await brain.generatePlainText(system: system, user: user)
            }
            state.lastReply = result.spoken
            state.detail = result.detail
            state.statusMessage = "Listo"
            state.isKeyboardJobRunning = false
            refreshModelLabels()
            speakReply(result.spoken)
        } catch let err as KeyboardError {
            state.lastReply = err.userMessage
            if case .notTrusted = err {
                state.detail = "Ajustes del Sistema → Privacidad y seguridad → Accesibilidad → activa Viernes."
            } else {
                state.detail = ""
            }
            state.statusMessage = "Listo"
            state.isKeyboardJobRunning = false
            speakReply(err.userMessage)
        } catch let err as BrainBackendError {
            state.lastReply = err.userMessage
            state.detail = ""
            state.statusMessage = "Listo"
            state.isKeyboardJobRunning = false
            speakReply(err.userMessage)
        } catch {
            let msg = "No pude completar el trabajo de teclado."
            state.lastReply = msg
            state.statusMessage = "Listo"
            state.isKeyboardJobRunning = false
            speakReply(msg)
        }
    }

    private func handleAnalyzeScreen(question: String) async {
        state.statusMessage = "Mirando pantalla…"
        state.detail = ""
        do {
            let jpeg = try await ScreenCapture.captureMainDisplayJPEG()
            state.statusMessage = "Pensando…"
            let reply = await brain.analyzeScreen(question: question, imageJPEG: jpeg)
            state.lastReply = reply.speak
            state.detail = reply.detail ?? ""
            if let label = reply.usedBackendLabel {
                state.modeLine = label
            } else {
                refreshModelLabels()
            }
            state.statusMessage = "Listo"
            speakReply(reply.speak)
        } catch let err as ScreenCaptureError {
            state.lastReply = err.userMessage
            state.detail = "Ajustes del Sistema → Privacidad y seguridad → Grabación de pantalla → activa Viernes."
            state.statusMessage = "Listo"
            speakReply(err.userMessage)
        } catch {
            let msg = "No pude capturar la pantalla."
            state.lastReply = msg
            state.statusMessage = "Listo"
            speakReply(msg)
        }
    }

    private func handleUnknown(phrase: String) async {
        state.statusMessage = "Pensando…"
        let reply = await brain.reason(phrase: phrase)
        if let label = reply.usedBackendLabel {
            state.modeLine = label
        } else {
            refreshModelLabels()
        }

        if let mapped = reply.intent {
            await dispatch(mapped, fallbackPhrase: phrase)
            // Si Brain también dio speak distinto y fue acción simple ya hablada por dispatch, ok.
            // Para acciones que van a pending, presentPending ya habló.
            return
        }

        state.lastReply = reply.speak
        state.detail = reply.detail ?? ""
        state.statusMessage = "Listo"
        speakReply(reply.speak)
    }

    func quitApp() {
        speakReply("Hasta luego.")
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.8) {
            NSApp.terminate(nil)
        }
    }
}

@MainActor
final class AppState: ObservableObject {
    static let mutedDefaultsKey = "viernes.muted"

    @Published var isListening = false
    @Published var isSpeaking = false
    @Published var isMuted = false
    @Published var isKeyboardJobRunning = false
    @Published var isAgentRunning = false
    @Published var pendingAction: PendingAction? = nil
    @Published var statusMessage = "Listo"
    @Published var transcript = ""
    @Published var lastReply = "Viernes, en línea. Pulsa ⌃⌥⌘V, escribe, o el icono."
    @Published var detail = ""
    @Published var ollamaModel = OllamaClient.defaultModel
    @Published var visionModel = OllamaClient.defaultVisionModel
    @Published var openaiModel = OpenAIClient.defaultModel
    @Published var brainProvider = BrainProvider.defaultValue.rawValue
    @Published var modeLine = "Auto · llama3.2"
    @Published var hasAPIKey = false
    @Published var hotkeyDisplay = HotkeyConfig.default.display
}

struct SettingsHelpView: View {
    @ObservedObject var state: AppState
    var onHotkeyChange: (HotkeyConfig) -> Void

    @State private var apiKeyDraft = ""
    @State private var keySaveMessage: String?
    @State private var selectedHotkeyDisplay: String = HotkeyConfig.current.display

    private var modelName: String { OllamaClient.configuredModelName }
    private var visionName: String { OllamaClient.configuredVisionModelName }
    private var astraName: String { OpenAIClient.configuredModelName }

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 10) {
                Text("Viernes V6")
                    .font(.title2.weight(.semibold))
                Text("Asistente de barra de menús: reglas locales + Local/Astra/Auto, visión, teclado, correo con confirmación, calendario, recordatorios, notas y agente corto.")
                    .foregroundStyle(.secondary)

                Divider()
                Text("Atajo global")
                    .font(.headline)
                Text("Por defecto ⌃⌥⌘V (reemplaza ⌥Espacio). Accesibilidad necesaria para capturar desde otras apps. UserDefaults `viernes.hotkey`.")
                    .font(.callout)
                    .fixedSize(horizontal: false, vertical: true)
                Picker("Atajo", selection: $selectedHotkeyDisplay) {
                    ForEach(HotkeyConfig.presets, id: \.display) { preset in
                        Text(preset.display).tag(preset.display)
                    }
                }
                .onChange(of: selectedHotkeyDisplay) { _, newValue in
                    if let cfg = HotkeyConfig.presets.first(where: { $0.display == newValue }) {
                        onHotkeyChange(cfg)
                        state.hotkeyDisplay = cfg.display
                    }
                }
                .onAppear { selectedHotkeyDisplay = HotkeyConfig.current.display }

                Divider()
                Text("Cerebro (Local / Astra / Auto)")
                    .font(.headline)
                Picker("Proveedor", selection: Binding(
                    get: { state.brainProvider },
                    set: { newValue in
                        let p = BrainProvider(rawValue: newValue) ?? .auto
                        BrainProvider.setCurrent(p)
                        state.brainProvider = p.rawValue
                        state.modeLine = {
                            switch p {
                            case .local: return "Local · \(OllamaClient.configuredModelName)"
                            case .astra: return "Astra · \(OpenAIClient.configuredModelName)"
                            case .auto:
                                return KeychainHelper.hasOpenAIKey()
                                    ? "Auto · Astra"
                                    : "Auto · \(OllamaClient.configuredModelName)"
                            }
                        }()
                    }
                )) {
                    Text("Local").tag(BrainProvider.local.rawValue)
                    Text("Astra").tag(BrainProvider.astra.rawValue)
                    Text("Auto").tag(BrainProvider.auto.rawValue)
                }
                .pickerStyle(.segmented)

                Divider()
                Text("API key OpenAI (Keychain)")
                    .font(.headline)
                Text("Clave guardada: \(state.hasAPIKey ? "sí" : "no").")
                    .font(.callout)
                SecureField("Pegar API key (sk-…)", text: $apiKeyDraft)
                    .textFieldStyle(.roundedBorder)
                HStack {
                    Button("Guardar en Keychain") {
                        let ok = KeychainHelper.saveOpenAIKey(apiKeyDraft)
                        apiKeyDraft = ""
                        state.hasAPIKey = KeychainHelper.hasOpenAIKey()
                        keySaveMessage = ok
                            ? (state.hasAPIKey ? "Clave guardada." : "Clave borrada.")
                            : "No pude guardar en el Keychain."
                    }
                    .disabled(apiKeyDraft.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
                    Button("Borrar clave") {
                        KeychainHelper.deleteOpenAIKey()
                        apiKeyDraft = ""
                        state.hasAPIKey = false
                        keySaveMessage = "Clave eliminada del Keychain."
                    }
                }
                if let keySaveMessage {
                    Text(keySaveMessage).font(.caption).foregroundStyle(.secondary)
                }

                Divider()
                Text("Correo (confirmación)")
                    .font(.headline)
                Text("«envía un correo…» → borrador → Enviar/Cancelar. Nunca envío ciego por voz. Automatización → Mail.")
                    .font(.callout)
                    .fixedSize(horizontal: false, vertical: true)

                Divider()
                Text("Calendario / Recordatorios / Notas")
                    .font(.headline)
                Text("Eventos y recordatorios nuevos piden Confirmar. Listar recordatorios es inmediato. Notas se crean al instante. Permisos: Calendarios, Recordatorios, Automatización (Notas/Mail).")
                    .font(.callout)
                    .fixedSize(horizontal: false, vertical: true)

                Divider()
                Text("Agente corto")
                    .font(.headline)
                Text("«haz esto en pantalla» / «agente: …» → captura → plan 1–3 pasos → Confirmar → ejecuta (analyze / type / openApp). Tope ~3 min. Detener cancela. Sin borrar, shell ni envío de correo dentro del agente.")
                    .font(.callout)
                    .fixedSize(horizontal: false, vertical: true)

                Divider()
                Text("Pantalla / Teclado")
                    .font(.headline)
                Text("Pantalla bajo demanda (Grabación de pantalla). Teclado bajo pedido (Accesibilidad).")
                    .font(.callout)
                    .fixedSize(horizontal: false, vertical: true)

                Divider()
                Text("Ollama (local)")
                    .font(.headline)
                Text("ollama pull \(modelName) · ollama pull \(visionName)\nAstra: \(astraName)")
                    .font(.callout)
                    .fixedSize(horizontal: false, vertical: true)
            }
            .padding(20)
        }
        .frame(width: 460, height: 620)
        .onAppear {
            state.hasAPIKey = KeychainHelper.hasOpenAIKey()
            selectedHotkeyDisplay = HotkeyConfig.current.display
        }
    }
}

enum PermissionGate {
    static func requestSpeechAndMicrophone() async -> Bool {
        let mic = await requestMicrophone()
        let speech = await requestSpeech()
        return mic && speech
    }

    private static func requestMicrophone() async -> Bool {
        await withCheckedContinuation { continuation in
            AVAudioApplication.requestRecordPermission { granted in
                continuation.resume(returning: granted)
            }
        }
    }

    private static func requestSpeech() async -> Bool {
        await withCheckedContinuation { continuation in
            SFSpeechRecognizer.requestAuthorization { status in
                continuation.resume(returning: status == .authorized)
            }
        }
    }
}
