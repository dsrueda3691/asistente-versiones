import AppKit
import SwiftUI
import Carbon

/// Icono de barra de menús, popover y atajo global configurable (default ⌃⌥⌘V).
final class StatusBarController: NSObject {
    private let statusItem: NSStatusItem
    private let popover = NSPopover()
    private let state: AppState
    private let onListen: () -> Void
    private let onQuit: () -> Void
    private let onSendChat: (String) -> Void
    private let onToggleMute: () -> Void
    private let onStopJob: () -> Void
    private let onOpenSettings: () -> Void
    private let onProviderChange: (String) -> Void
    private let onConfirmPending: () -> Void
    private let onCancelPending: () -> Void

    private var localMonitor: Any?
    private var globalMonitor: Any?
    private var carbonHotKey: EventHotKeyRef?
    private var carbonHandler: EventHandlerRef?
    private var lastHotKeyAt = Date.distantPast
    private var currentHotkey: HotkeyConfig = .default

    init(
        state: AppState,
        onListen: @escaping () -> Void,
        onQuit: @escaping () -> Void,
        onSendChat: @escaping (String) -> Void,
        onToggleMute: @escaping () -> Void,
        onStopJob: @escaping () -> Void,
        onOpenSettings: @escaping () -> Void,
        onProviderChange: @escaping (String) -> Void,
        onConfirmPending: @escaping () -> Void,
        onCancelPending: @escaping () -> Void
    ) {
        self.state = state
        self.onListen = onListen
        self.onQuit = onQuit
        self.onSendChat = onSendChat
        self.onToggleMute = onToggleMute
        self.onStopJob = onStopJob
        self.onOpenSettings = onOpenSettings
        self.onProviderChange = onProviderChange
        self.onConfirmPending = onConfirmPending
        self.onCancelPending = onCancelPending
        self.statusItem = NSStatusBar.system.statusItem(withLength: NSStatusItem.variableLength)
        super.init()
        currentHotkey = HotkeyConfig.current
        state.hotkeyDisplay = currentHotkey.display
        configureStatusItem()
        configurePopover()
        installHotkeys()
    }

    deinit {
        teardownHotkeys()
    }

    func showPopover() {
        guard let button = statusItem.button else { return }
        if !popover.isShown {
            popover.show(relativeTo: button.bounds, of: button, preferredEdge: .minY)
        }
    }

    func hidePopover() {
        popover.performClose(nil)
    }

    /// Re-registra monitores Carbon/local/global tras cambiar el atajo en Ajustes.
    func applyHotkey(_ config: HotkeyConfig) {
        HotkeyConfig.current = config
        currentHotkey = config
        state.hotkeyDisplay = config.display
        teardownHotkeys()
        installHotkeys()
        if let button = statusItem.button {
            button.toolTip = "Viernes — pulsa o \(config.display) para hablar"
        }
    }

    @objc private func statusItemClicked(_ sender: Any?) {
        showPopover()
        onListen()
    }

    private func configureStatusItem() {
        guard let button = statusItem.button else { return }
        if let image = NSImage(systemSymbolName: "sparkles", accessibilityDescription: "Viernes") {
            image.isTemplate = true
            button.image = image
            button.title = ""
        } else if let image = NSImage(systemSymbolName: "waveform", accessibilityDescription: "Viernes") {
            image.isTemplate = true
            button.image = image
            button.title = ""
        } else {
            button.title = "V"
        }
        button.toolTip = "Viernes — pulsa o \(currentHotkey.display) para hablar"
        button.target = self
        button.action = #selector(statusItemClicked(_:))
        button.sendAction(on: [.leftMouseUp])
    }

    private func configurePopover() {
        popover.behavior = .transient
        popover.animates = true
        popover.contentSize = NSSize(width: 400, height: 600)
        let root = PopoverView(
            state: state,
            onListen: { [weak self] in self?.onListen() },
            onQuit: { [weak self] in self?.onQuit() },
            onSendChat: { [weak self] text in self?.onSendChat(text) },
            onToggleMute: { [weak self] in self?.onToggleMute() },
            onStopJob: { [weak self] in self?.onStopJob() },
            onOpenSettings: { [weak self] in self?.onOpenSettings() },
            onProviderChange: { [weak self] raw in self?.onProviderChange(raw) },
            onConfirmPending: { [weak self] in self?.onConfirmPending() },
            onCancelPending: { [weak self] in self?.onCancelPending() }
        )
        popover.contentViewController = NSHostingController(rootView: root)
    }

    private func teardownHotkeys() {
        if let localMonitor {
            NSEvent.removeMonitor(localMonitor)
            self.localMonitor = nil
        }
        if let globalMonitor {
            NSEvent.removeMonitor(globalMonitor)
            self.globalMonitor = nil
        }
        if let carbonHotKey {
            UnregisterEventHotKey(carbonHotKey)
            self.carbonHotKey = nil
        }
        if let carbonHandler {
            RemoveEventHandler(carbonHandler)
            self.carbonHandler = nil
        }
    }

    private func installHotkeys() {
        let hk = currentHotkey
        localMonitor = NSEvent.addLocalMonitorForEvents(matching: .keyDown) { [weak self] event in
            guard let self, hk.matches(event) || self.currentHotkey.matches(event) else { return event }
            self.handleHotKey()
            return nil
        }

        globalMonitor = NSEvent.addGlobalMonitorForEvents(matching: .keyDown) { [weak self] event in
            guard let self, self.currentHotkey.matches(event) else { return }
            self.handleHotKey()
        }

        registerCarbonHotKey(hk)
    }

    fileprivate func handleHotKey() {
        let now = Date()
        guard now.timeIntervalSince(lastHotKeyAt) > 0.45 else { return }
        lastHotKeyAt = now
        if Thread.isMainThread {
            onListen()
        } else {
            DispatchQueue.main.async { [weak self] in
                self?.onListen()
            }
        }
    }

    private func registerCarbonHotKey(_ config: HotkeyConfig) {
        var hotKeyID = EventHotKeyID(signature: OSType(0x56524E53), id: 1) // 'VRNS'
        var eventType = EventTypeSpec(
            eventClass: OSType(kEventClassKeyboard),
            eventKind: UInt32(kEventHotKeyPressed)
        )
        let context = Unmanaged.passUnretained(self).toOpaque()
        var handler: EventHandlerRef?
        let installed = InstallEventHandler(
            GetApplicationEventTarget(),
            carbonHotKeyCallback,
            1,
            &eventType,
            context,
            &handler
        )
        if installed == noErr {
            carbonHandler = handler
        }
        var hotKey: EventHotKeyRef?
        let registered = RegisterEventHotKey(
            config.keyCode,
            config.carbonModifiers,
            hotKeyID,
            GetApplicationEventTarget(),
            0,
            &hotKey
        )
        if registered == noErr {
            carbonHotKey = hotKey
        }
    }
}

private let carbonHotKeyCallback: EventHandlerProcPtr = { _, _, userData in
    guard let userData else { return noErr }
    let controller = Unmanaged<StatusBarController>.fromOpaque(userData).takeUnretainedValue()
    DispatchQueue.main.async {
        controller.handleHotKey()
    }
    return noErr
}
