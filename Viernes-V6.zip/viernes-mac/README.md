# Viernes (V6)

Asistente de barra de menús para macOS. Habla en español, te escucha cuando se lo pides, responde con voz, mira la pantalla bajo demanda, y ahora también **correo con confirmación**, **calendario**, **recordatorios**, **notas**, y un **agente corto** (máx. 3 pasos). Inspirado en Friday (MCU): seco, breve, competente.

**V6** = V5 (Local / Astra / Auto, pantalla, teclado, mute, chat) **+** Mail confirmado **+** Calendario/Recordatorios/Notas **+** agente corto **+** atajo global configurable (default **⌃⌥⌘V**).

Viernes es una herramienta personal. **No está pensada para el App Store**: el sandbox está desactivado.

## Qué cambió en V6

### Correo (nunca envío ciego)
- Frases: «envía un correo a…», «manda un mail…», «redacta un correo…».
- Se arma un **borrador** (`to` / `subject` / `body`, `cc` opcional) en el popover.
- Botones **Enviar** / **Cancelar**. Solo entonces AppleScript crea y envía en Mail.app.
- Confirmación tipada («confirma envío», «sí envía») **solo** mientras hay borrador pendiente.
- `NSAppleEventsUsageDescription` para Automatización → Mail.

### Atajo global
- Default: **⌃⌥⌘V** (Control+Option+Command+V). Reemplaza ⌥Espacio.
- Tres rutas: monitor local, monitor global, Carbon `RegisterEventHotKey`.
- Configurable en Ajustes (presets). Persistido en UserDefaults `viernes.hotkey`.
- **Accesibilidad** sigue siendo necesaria para capturar el atajo desde otras apps.

### Calendario
- «crea un evento…», «agenda…» → borrador (título, inicio/fin, notas/lugar) → **Confirmar** / **Cancelar**.
- EventKit (`NSCalendarsUsageDescription` / full access). Nunca crea sin confirmar.

### Recordatorios
- Crear: «recuérdame…» → Confirmar / Cancelar.
- Listar: «lista recordatorios» / «próximos recordatorios» → inmediato (solo lectura).
- EventKit Reminders.

### Notas
- «crea una nota…» → creación inmediata en Apple Notes (AppleScript). Respuesta: «Nota creada».
- Automatización → Notas.

### Agente corto
- «haz esto en pantalla» / «agente: …».
- Flujo: captura → LLM planifica **1–3** pasos seguros → resumen en popover → **Confirmar** → ejecuta.
- Pasos permitidos: `analyze` (visión), `type` (KeyboardController), `openApp` (catálogo conocido).
- Tope ~2–3 min. **Detener** cancela. Prohibido: borrar, shell, envío de correo dentro del agente.

### Confirmaciones unificadas
`AppState.pendingAction` cubre mail / calendar / reminder / agentPlan. El popover muestra resumen + **Enviar|Confirmar** + **Cancelar**.

Marketing version **6.0**.

## Qué cambió en V5

- Proveedor Local / Astra / Auto; API key en Keychain; chat/visión/teclado según proveedor.
- Reglas locales offline. Marketing 5.0.

## Requisitos

- macOS 14+, Xcode, micrófono.
- Opcional: Ollama (local), API key OpenAI (Astra).
- Permisos según función (tabla abajo).

## Cómo usarlo

- Clic en **✦** o **⌃⌥⌘V** (o el atajo elegido en Ajustes).
- Chat escrito + mute + selector Local/Astra/Auto.
- Correo / evento / recordatorio / agente: **confirma en el popover**.

### Frases de ejemplo

| Intent | Prueba |
| --- | --- |
| Correo | «envía un correo a ana@ejemplo.com con asunto Hola que diga …» |
| Evento | «crea un evento llamado Dentista mañana a las 10» |
| Recordatorio | «recuérdame pagar la luz mañana» / «lista recordatorios» |
| Nota | «crea una nota llamada Ideas que diga …» |
| Agente | «haz esto en pantalla» / «agente: resume lo que hay abierto» |
| Pantalla | «mira la pantalla» |
| Teclado | «usa el teclado…» |
| Clásicos | hora, abre Safari, busca…, crea archivo, adiós |

## Permisos

| Permiso | Para qué | Obligatorio |
| --- | --- | --- |
| Micrófono + Reconocimiento de voz | Escuchar | Sí (voz) |
| **Accesibilidad** | Atajo global desde otras apps + teclado + pasos type del agente | Recomendado / sí para esas funciones |
| **Grabación de pantalla** | Mirar pantalla + plan del agente | Solo esas funciones |
| **Automatización → Mail** | Enviar correo tras Enviar | Solo correo |
| **Automatización → Notas** | Crear notas | Solo notas |
| **Calendarios** | Crear eventos confirmados | Solo calendario |
| **Recordatorios** | Crear (confirmado) y listar | Solo recordatorios |

## Proveedor (igual que V5)

| Modo | Comportamiento |
| --- | --- |
| **Local** | Solo Ollama |
| **Astra** | Solo OpenAI `gpt-6-astra` |
| **Auto** | Astra si hay clave; si falla, Ollama |

Reglas locales no pasan por LLM.

## API key (Keychain)

```bash
security add-generic-password -a openai_api_key -s com.danielrueda.Viernes -w 'sk-...' -U
```

O Ajustes → Pegar API key.

## Estructura (V6)

```
viernes-mac/
  README.md
  Viernes.xcodeproj
  Viernes/
    ViernesApp.swift              ← routing, pending confirm, settings + hotkey UI
    StatusBarController.swift     ← ⌃⌥⌘V / hotkey configurable (local+global+Carbon)
    Speech/…
    Capture/ScreenCapture.swift
    Intent/
      IntentParser.swift
      ActionRunner.swift
      Brain.swift / LLMBackend / Ollama / OpenAI / Keychain
      KeyboardController.swift
      MailSender.swift
      CalendarService.swift       ← EventKit
      RemindersService.swift      ← EventKit
      NotesService.swift          ← AppleScript Notes
      AgentMode.swift             ← plan 1–3 + execute
      PendingAction.swift         ← mail|calendar|reminder|agent
      HotkeyConfig.swift          ← UserDefaults viernes.hotkey
    UI/PopoverView.swift          ← Enviar/Confirmar/Cancelar unificados
    Info.plist                    ← mic, speech, screen, AppleEvents, calendars, reminders
```

## Qué hace V6 (y qué no)

**Sí:** menú bar, voz, mute, chat, Local/Astra/Auto, pantalla bajo demanda, teclado bajo pedido, correo/evento/recordatorio con confirmación, notas rápidas, agente corto confirmado, atajo configurable.

**No:** wake word 24/7, grabación continua, envío de correo sin confirmar, borrar archivos, shell arbitrario, keylogging, mail-send dentro del agente.

**Sandbox OFF.** Marketing **6.0**.

## Licencia

Uso personal de Daniel Rueda Mier. Haz lo que quieras con el código en tu Mac.
